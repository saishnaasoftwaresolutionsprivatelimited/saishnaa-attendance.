/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        saishnaa: {
          navy: '#146063',
          'navy-dark': '#0f2c3d',
          'navy-light': '#0d647e',
          blue: '#16af81',
          'blue-light': '#4D82F5',
          'blue-dark': '#1E40AF',
          emerald: '#10A981',
          'emerald-light': '#35C49D',
          'emerald-dark': '#087F65',
          bg: '#F4F7FC',
          section: '#EEF4FF',
          card: '#FFFFFF',
          text: '#172033',
          muted: '#64748B',
          border: '#DCE5F2',
        },
      },
      fontFamily: {
        sans: ['"Inter"', '"Segoe UI"', 'Arial', 'sans-serif'],
        display: ['"Inter"', '"Segoe UI"', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        'xs': '0 1px 2px 0 rgba(0, 0, 0, 0.04)',
        'corporate': '0 4px 20px -2px rgba(32, 38, 109, 0.06), 0 2px 6px -1px rgba(0, 0, 0, 0.03)',
        'corporate-lg': '0 10px 30px -4px rgba(32, 38, 109, 0.10), 0 4px 10px -2px rgba(0, 0, 0, 0.04)',
        'subtle': '0 1px 3px 0 rgba(0, 0, 0, 0.04), 0 1px 2px -1px rgba(0, 0, 0, 0.02)',
      },
    },
  },
  plugins: [],
}
