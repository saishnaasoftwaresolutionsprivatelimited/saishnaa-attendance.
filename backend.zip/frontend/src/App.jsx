import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardLayout from './layouts/DashboardLayout';

// Public Auth Pages
import LoginPage from './pages/auth/LoginPage';
import ActivateAccountPage from './pages/auth/ActivateAccountPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';

// Admin / HR Management Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import EmployeeManagement from './pages/admin/EmployeeManagement';
import AttendanceManagementPage from './pages/admin/AttendanceManagementPage';
import PayrollManagementPage from './pages/admin/PayrollManagementPage';
import PayslipManagementPage from './pages/admin/PayslipManagementPage';
import PayrollCalendarPage from './pages/admin/PayrollCalendarPage';
import RequestsApprovalsPage from './pages/admin/RequestsApprovalsPage';
import ReportsPage from './pages/admin/ReportsPage';
import TaskManagementPage from './pages/admin/TaskManagementPage';
import HolidayCalendarPage from './pages/admin/HolidayCalendarPage';
import SettingsPage from './pages/admin/SettingsPage';
import SalaryConfigurationPage from './pages/admin/SalaryConfigurationPage';
import AuditTrailPage from './pages/admin/AuditTrailPage';

// Employee Portal Pages
import EmployeeDashboard from './pages/employee/EmployeeDashboard';
import MyAttendance from './pages/employee/MyAttendance';
import MySalary from './pages/employee/MySalary';
import MyPayslips from './pages/employee/MyPayslips';
import ApplyLeave from './pages/employee/ApplyLeave';
import ApplyPermission from './pages/employee/ApplyPermission';
import ApplyOnDuty from './pages/employee/ApplyOnDuty';
import ApplicationHistory from './pages/employee/ApplicationHistory';
import AttendanceCalendar from './pages/employee/AttendanceCalendar';
import ApplyCorrection from './pages/employee/ApplyCorrection';
import ProfilePage from './pages/employee/ProfilePage';
import EmployeeTasksPage from './pages/employee/EmployeeTasksPage';

// Helper component for Root index route
function RootRedirect() {
  const { user, isAuthenticated, loading } = useAuth();
  if (loading) return null;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user?.role === 'ADMIN') return <Navigate to="/admin/dashboard" replace />;
  if (user?.role === 'HR') return <Navigate to="/hr/my-dashboard" replace />;
  return <Navigate to="/employee/dashboard" replace />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Auth Routes */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/activate" element={<ActivateAccountPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />

          {/* Root Redirect */}
          <Route path="/" element={<RootRedirect />} />

          {/* Admin & HR Protected Routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['ADMIN', 'HR']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            {/* Core 11 Admin Modules matching the exact UI specification */}
            <Route index element={<AdminDashboard />} />
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="employees" element={<EmployeeManagement />} />
            <Route path="attendance" element={<AttendanceManagementPage />} />
            <Route path="payroll" element={<PayrollManagementPage />} />
            <Route path="payslips" element={<PayslipManagementPage />} />
            <Route path="tasks" element={<TaskManagementPage />} />
            <Route path="requests" element={<RequestsApprovalsPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="holidays" element={<HolidayCalendarPage />} />
            <Route path="settings" element={<SettingsPage />} />

            {/* Backwards-compatible aliases & redirects */}
            <Route path="tax-compliance" element={<Navigate to="/admin/tasks" replace />} />
            <Route path="payroll-calendar" element={<Navigate to="/admin/payroll" replace />} />

            {/* Backwards-compatible aliases */}
            <Route path="salary-config" element={<PayrollManagementPage />} />
            <Route path="leaves" element={<RequestsApprovalsPage />} />
            <Route path="permissions" element={<RequestsApprovalsPage />} />
            <Route path="on-duty" element={<RequestsApprovalsPage />} />
            <Route path="corrections" element={<RequestsApprovalsPage />} />
            <Route path="audit" element={<AuditTrailPage />} />
          </Route>

          {/* HR Dedicated Routes */}
          <Route
            path="/hr"
            element={
              <ProtectedRoute allowedRoles={['HR', 'ADMIN']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route path="my-dashboard" element={<EmployeeDashboard />} />
            <Route path="attendance" element={<MyAttendance />} />
            <Route path="calendar" element={<AttendanceCalendar />} />
            <Route path="corrections" element={<ApplyCorrection />} />
            <Route path="salary" element={<MySalary />} />
            <Route path="payslips" element={<MyPayslips />} />
            <Route path="leaves" element={<ApplyLeave />} />
            <Route path="permission" element={<ApplyPermission />} />
            <Route path="on-duty" element={<ApplyOnDuty />} />
            <Route path="history" element={<ApplicationHistory />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="employees" element={<EmployeeManagement />} />
            <Route path="payroll" element={<PayrollManagementPage />} />
            <Route path="leave-approvals" element={<RequestsApprovalsPage />} />
          </Route>

          {/* Employee Protected Routes */}
          <Route
            path="/employee"
            element={
              <ProtectedRoute allowedRoles={['EMPLOYEE']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route path="dashboard" element={<EmployeeDashboard />} />
            <Route path="attendance" element={<MyAttendance />} />
            <Route path="salary" element={<MySalary />} />
            <Route path="payslips" element={<MyPayslips />} />
            <Route path="leaves" element={<ApplyLeave />} />
            <Route path="permission" element={<ApplyPermission />} />
            <Route path="on-duty" element={<ApplyOnDuty />} />
            <Route path="history" element={<ApplicationHistory />} />
            <Route path="calendar" element={<AttendanceCalendar />} />
            <Route path="corrections" element={<ApplyCorrection />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="tasks" element={<EmployeeTasksPage />} />
            <Route path="notices" element={<Navigate to="/employee/tasks" replace />} />
          </Route>

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
