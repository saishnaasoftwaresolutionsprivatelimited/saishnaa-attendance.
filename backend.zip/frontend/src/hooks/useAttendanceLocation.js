import { useCallback, useEffect, useRef, useState } from 'react';
import api from '../services/api';
import { checkAttendanceLocation, getCurrentAttendanceLocation } from '../utils/attendanceLocation';

export default function useAttendanceLocation() {
  const [settings, setSettings] = useState(null);
  const [locationState, setLocationState] = useState({ status: 'checking', message: 'Checking office location...' });
  const sequence = useRef(0);
  const pending = useRef(false);

  const verifyLocation = useCallback(async () => {
    const request = ++sequence.current;
    pending.current = true;
    setLocationState({ status: 'checking', message: 'Checking office location...' });
    try {
      const response = await api.get('/payroll/company-branding');
      if (!response.success || !response.data) throw new Error('Office settings are unavailable. Please retry.');
      const currentSettings = response.data;
      if (request !== sequence.current) throw new Error('Location check was superseded. Please retry.');
      setSettings(currentSettings);
      if (currentSettings.attendanceLocationEnabled === false) {
        setLocationState({ status: 'disabled', message: 'Office location is not required by Admin.' });
        return {};
      }
      const location = await getCurrentAttendanceLocation();
      if (request !== sequence.current) throw new Error('Location check was superseded. Please retry.');
      const result = checkAttendanceLocation(currentSettings, location);
      const message = result.allowed ? 'Office location verified' : result.message;
      setLocationState({ status: result.allowed ? 'inside' : result.statusCode === 403 ? 'outside' : 'error',
        message, location, result });
      if (!result.allowed) throw Object.assign(new Error(message), { locationResult: true });
      return location;
    } catch (error) {
      if (request === sequence.current && !error.locationResult) {
        setLocationState({ status: 'error', message: error.message || 'Unable to determine your current location. Please retry.' });
      }
      throw error;
    } finally {
      if (request === sequence.current) pending.current = false;
    }
  }, []);

  const refreshLocation = useCallback(() => {
    // Returning from a browser permission prompt must not cancel an active check.
    if (!pending.current) verifyLocation().catch(() => {});
  }, [verifyLocation]);
  useEffect(() => {
    refreshLocation();
    window.addEventListener('focus', refreshLocation);
    return () => {
      ++sequence.current;
      pending.current = false;
      window.removeEventListener('focus', refreshLocation);
    };
  }, [refreshLocation]);

  return { settings, locationState, verifyLocation, refreshLocation,
    locationReady: locationState.status === 'inside' || locationState.status === 'disabled' };
}
