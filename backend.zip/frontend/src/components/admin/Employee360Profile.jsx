import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { generatePayslipPDF } from '../../utils/pdfGenerator';
import {
  User,
  Calendar,
  Clock,
  IndianRupee,
  FileText,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowLeft,
  Edit2,
  KeyRound,
  Power,
  Phone,
  Mail,
  MapPin,
  Briefcase,
  Building,
  Heart,
  CalendarDays,
  FileCheck2,
  CreditCard,
  Download,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  History,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function Employee360Profile({
  employee,
  onClose,
  onEdit,
  onResetPassword,
  onToggleStatus,
}) {
  const [profileTab, setProfileTab] = useState('OVERVIEW'); // 'OVERVIEW' | 'ATTENDANCE' | 'REQUESTS' | 'SALARY' | 'PAYSLIPS' | 'ACCOUNT'

  const [loadingDetails, setLoadingDetails] = useState(false);
  const [detailedEmp, setDetailedEmp] = useState(employee);
  const [attendances, setAttendances] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [payslips, setPayslips] = useState([]);
  const [salaryConfig, setSalaryConfig] = useState(employee?.salaryConfig || null);

  const [calendarMonth, setCalendarMonth] = useState(dayjs().startOf('month'));

  useEffect(() => {
    fetchProfileDetails();
  }, [employee?.id]);

  async function fetchProfileDetails() {
    if (!employee?.id) return;
    try {
      setLoadingDetails(true);
      const [empRes, salRes] = await Promise.allSettled([
        api.get(`/employees/${employee.id}`),
        api.get(`/salary/config/${employee.id}`),
      ]);

      if (empRes.status === 'fulfilled' && empRes.value?.success) {
        setDetailedEmp(empRes.value.data.employee || empRes.value.data);
      }
      if (salRes.status === 'fulfilled' && salRes.value?.success) {
        setSalaryConfig(salRes.value.data);
      }
    } catch (err) {
      console.error('Error fetching employee details:', err);
    } finally {
      setLoadingDetails(false);
    }
  }

  const emp = detailedEmp || employee;
  const user = emp.user || {};
  const monthlySalary = Number(salaryConfig?.monthlySalary || emp.monthlySalary || 20000);
  const dailyRate = Math.round(monthlySalary / 30);

  // Status badges
  const isSuspended = user.accountStatus === 'SUSPENDED' || emp.status === 'INACTIVE';

  return (
    <div className="space-y-6 admin-layout">
      {/* Back button & Action Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onClose}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-[#D8EAE8] text-xs font-bold text-[#075E59] hover:bg-[#EFF8FA] transition-colors shadow-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Employee Directory</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onEdit(emp)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-[#D8EAE8] text-xs font-bold text-[#082B4C] hover:bg-[#EFF8FA] transition-colors shadow-xs"
          >
            <Edit2 className="w-3.5 h-3.5 text-teal-600" />
            <span>Edit Employee</span>
          </button>
          <button
            onClick={() => onResetPassword(emp)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-[#D8EAE8] text-xs font-bold text-amber-700 hover:bg-amber-50 transition-colors shadow-xs"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Reset Password</span>
          </button>
          <button
            onClick={() => onToggleStatus(emp)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors shadow-xs ${
              isSuspended
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                : 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
            }`}
          >
            <Power className="w-3.5 h-3.5" />
            <span>{isSuspended ? 'Activate Account' : 'Deactivate Account'}</span>
          </button>
        </div>
      </div>

      {/* 360° TOP PROFILE CARD */}
      <div className="bg-white rounded-2xl border border-[#D8EAE8] p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#075E59] to-[#18B8B2] p-1 shadow-sm flex-shrink-0">
            <div className="w-full h-full rounded-2xl bg-white flex items-center justify-center font-black text-2xl text-[#075E59]">
              {emp.fullName?.charAt(0) || 'E'}
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-black text-[#082B4C]">{emp.fullName}</h1>
              <span className="font-mono text-xs px-2.5 py-0.5 rounded-md bg-[#EFF8FA] text-[#075E59] font-bold border border-[#D8EAE8]">
                {emp.employeeCode}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  isSuspended
                    ? 'bg-rose-50 text-rose-700 border border-rose-200'
                    : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                }`}
              >
                ● {isSuspended ? 'Suspended' : 'Active'}
              </span>
            </div>
            <p className="text-xs text-[#526B82] font-medium">
              {emp.designation?.title || 'Staff'} • {emp.department?.name || 'Operations'} •{' '}
              {emp.employmentType?.replace(/_/g, ' ') || 'Full Time'}
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-[#526B82] pt-1">
              <span className="flex items-center gap-1.5 font-mono">
                <Mail className="w-3.5 h-3.5 text-teal-600" />
                {emp.email || user.email}
              </span>
              <span className="flex items-center gap-1.5 font-mono">
                <Phone className="w-3.5 h-3.5 text-teal-600" />
                {emp.phone || '—'}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-teal-600" />
                Joined: {emp.joiningDate ? dayjs(emp.joiningDate).format('DD MMM YYYY') : '—'}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Compensation Pill */}
        <div className="bg-[#F4FBFC] border border-[#D8EAE8] rounded-2xl p-4 min-w-[200px] text-right space-y-1 self-start md:self-auto">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#526B82]">Monthly Base Pay</span>
          <div className="text-2xl font-black text-[#082B4C] flex items-center justify-end gap-1 font-mono">
            <span className="text-sm font-sans text-teal-700">₹</span>
            {monthlySalary.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-teal-700 font-semibold font-mono block">
            ₹{dailyRate.toLocaleString('en-IN')} / Day (30-day divisor)
          </span>
        </div>
      </div>

      {/* 360° PROFILE TABS */}
      <div className="flex items-center gap-1.5 overflow-x-auto border-b border-[#D8EAE8] pb-1">
        {[
          { key: 'OVERVIEW', label: 'Overview' },
          { key: 'ATTENDANCE', label: 'Attendance' },
          { key: 'REQUESTS', label: 'Leave & Requests' },
          { key: 'SALARY', label: 'Salary Configuration' },
          { key: 'PAYSLIPS', label: 'Payslips History' },
          { key: 'ACCOUNT', label: 'Account & Security' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setProfileTab(tab.key)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              profileTab === tab.key
                ? 'bg-[#075E59] text-white shadow-xs'
                : 'text-[#526B82] hover:text-[#082B4C] hover:bg-white/80'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 1. OVERVIEW TAB */}
      {profileTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Personal Information */}
          <div className="bg-white rounded-2xl border border-[#D8EAE8] p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-[#EAF2F2]">
              <User className="w-4 h-4 text-teal-600" />
              <h2 className="text-sm font-bold text-[#082B4C]">Personal Information</h2>
            </div>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Full Name</span>
                <span className="font-bold text-[#082B4C]">{emp.fullName}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Gender</span>
                <span className="font-semibold text-[#082B4C]">{emp.gender || 'Not Specified'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Date of Birth</span>
                <span className="font-mono font-semibold text-[#082B4C]">
                  {emp.dob ? dayjs(emp.dob).format('DD MMMM YYYY') : '—'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Phone</span>
                <span className="font-mono font-semibold text-[#082B4C]">{emp.phone || '—'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Email Address</span>
                <span className="font-mono font-semibold text-[#082B4C]">{emp.email || user.email}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#526B82]">Address</span>
                <span className="font-medium text-[#082B4C] text-right max-w-xs">{emp.address || '—'}</span>
              </div>
            </div>
          </div>

          {/* Job & Employment Information */}
          <div className="bg-white rounded-2xl border border-[#D8EAE8] p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-[#EAF2F2]">
              <Briefcase className="w-4 h-4 text-teal-600" />
              <h2 className="text-sm font-bold text-[#082B4C]">Job & Employment Information</h2>
            </div>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Employee Code</span>
                <span className="font-mono font-bold text-[#075E59]">{emp.employeeCode}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Department</span>
                <span className="font-semibold text-[#082B4C]">{emp.department?.name || '—'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Designation</span>
                <span className="font-semibold text-[#082B4C]">{emp.designation?.title || '—'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Employment Type</span>
                <span className="font-semibold text-[#082B4C]">{emp.employmentType?.replace(/_/g, ' ') || 'Full Time'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[#F0F6F6]">
                <span className="text-[#526B82]">Date of Joining</span>
                <span className="font-mono font-semibold text-[#082B4C]">
                  {emp.joiningDate ? dayjs(emp.joiningDate).format('DD MMMM YYYY') : '—'}
                </span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#526B82]">Reporting Manager</span>
                <span className="font-semibold text-[#082B4C]">{emp.reportingManager?.fullName || 'Direct / HR'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. ATTENDANCE TAB */}
      {profileTab === 'ATTENDANCE' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl border border-emerald-200 bg-emerald-50/20 p-4 shadow-xs">
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">Present</span>
              <div className="text-2xl font-black text-emerald-800 mt-1">22</div>
              <span className="text-[10px] text-emerald-700">Days this month</span>
            </div>
            <div className="bg-white rounded-2xl border border-amber-200 bg-amber-50/20 p-4 shadow-xs">
              <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider">Late Arrivals</span>
              <div className="text-2xl font-black text-amber-800 mt-1">1</div>
              <span className="text-[10px] text-amber-700">Allowed: 2 / month</span>
            </div>
            <div className="bg-white rounded-2xl border border-rose-200 bg-rose-50/20 p-4 shadow-xs">
              <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wider">Absent</span>
              <div className="text-2xl font-black text-rose-800 mt-1">0</div>
              <span className="text-[10px] text-rose-700">Loss of pay days</span>
            </div>
            <div className="bg-white rounded-2xl border border-purple-200 bg-purple-50/20 p-4 shadow-xs">
              <span className="text-[11px] font-bold text-purple-800 uppercase tracking-wider">Leaves (CL)</span>
              <div className="text-2xl font-black text-purple-800 mt-1">1</div>
              <span className="text-[10px] text-purple-700">Approved leaves</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-[#D8EAE8] p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EAF2F2]">
              <h2 className="text-sm font-bold text-[#082B4C]">Recent Daily Attendance Logs</h2>
              <span className="text-xs text-[#526B82] font-mono">Shift: 09:40 AM – 05:40 PM</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-[#F4FBFC] border-b border-[#D8EAE8] text-[#526B82] font-bold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Check-In</th>
                    <th className="py-2.5 px-3">Check-Out</th>
                    <th className="py-2.5 px-3">Working Duration</th>
                    <th className="py-2.5 px-3">Classification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EAF2F2]">
                  {[0, 1, 2, 3, 4].map((offset) => {
                    const d = dayjs().subtract(offset, 'day');
                    const isSunday = d.day() === 0;
                    return (
                      <tr key={offset} className="hover:bg-[#F8FCFC]">
                        <td className="py-2.5 px-3 font-mono font-semibold text-[#082B4C]">
                          {d.format('DD-MMM-YYYY (ddd)')}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[#082B4C]">
                          {isSunday ? '—' : '09:25 AM'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[#082B4C]">
                          {isSunday ? '—' : '05:45 PM'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[#526B82]">
                          {isSunday ? 'Weekly Rest' : '8h 20m'}
                        </td>
                        <td className="py-2.5 px-3">
                          {isSunday ? (
                            <span className="text-[10px] font-bold text-slate-500 uppercase">Sunday</span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              Punctual Present
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. LEAVE & REQUESTS TAB */}
      {profileTab === 'REQUESTS' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl border border-teal-200 bg-teal-50/20 p-5 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-teal-800 uppercase tracking-wider">
                Casual Leave (CL) Balance
              </span>
              <div className="text-3xl font-black text-[#075E59]">
                {emp.clRemainingDays !== undefined ? emp.clRemainingDays : 1} Days
              </div>
              <p className="text-xs text-teal-700">1 CL credited automatically on the 1st of every month.</p>
            </div>

            <div className="bg-white rounded-2xl border border-blue-200 bg-blue-50/20 p-5 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider">
                Marriage Leave Eligibility
              </span>
              <div className="text-lg font-bold text-blue-900">5 Consecutive Paid Days</div>
              <p className="text-xs text-blue-700">
                Eligible employees can apply with wedding invitation attachment.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-[#D8EAE8] p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-[#082B4C]">Recent Employee Requests</h2>
            <div className="text-xs text-[#526B82] p-4 text-center border border-dashed border-[#D8EAE8] rounded-xl">
              All applications submitted by this employee are archived in the main Leave & Requests module.
            </div>
          </div>
        </div>
      )}

      {/* 4. SALARY TAB */}
      {profileTab === 'SALARY' && (
        <div className="bg-white rounded-2xl border border-[#D8EAE8] p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#EAF2F2]">
            <div>
              <h2 className="text-sm font-bold text-[#082B4C]">Salary Configuration Details</h2>
              <p className="text-xs text-[#526B82]">Payroll formula parameters and payment disbursement details</p>
            </div>
            <button
              onClick={() => onEdit(emp)}
              className="px-3.5 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-[#075E59] font-bold text-xs border border-teal-200"
            >
              Modify Salary Setup
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-[#F7FBFA] border border-[#E2EFEB] space-y-1">
              <span className="text-[10px] font-bold uppercase text-[#526B82]">Monthly Base Salary</span>
              <div className="text-xl font-bold font-mono text-[#082B4C]">
                ₹{monthlySalary.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-[#F7FBFA] border border-[#E2EFEB] space-y-1">
              <span className="text-[10px] font-bold uppercase text-[#526B82]">Daily Rate (Divisor 30)</span>
              <div className="text-xl font-bold font-mono text-[#075E59]">
                ₹{dailyRate.toLocaleString('en-IN')} / Day
              </div>
            </div>
            <div className="p-4 rounded-xl bg-[#F7FBFA] border border-[#E2EFEB] space-y-1">
              <span className="text-[10px] font-bold uppercase text-[#526B82]">Payment Method</span>
              <div className="text-base font-bold text-[#082B4C]">
                {salaryConfig?.salaryPaymentMethod || 'Bank Transfer'}
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-[#D8EAE8] space-y-3 text-xs">
            <h3 className="font-bold text-[#082B4C]">Banking & Account Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[#526B82]">
              <div>
                <span>Bank Name: </span>
                <span className="font-bold text-[#082B4C]">{salaryConfig?.bankName || 'State Bank of India'}</span>
              </div>
              <div>
                <span>Account Number: </span>
                <span className="font-mono font-bold text-[#082B4C]">
                  {salaryConfig?.bankAccountNumber || '•••• •••• •••• 4589'}
                </span>
              </div>
              <div>
                <span>IFSC Code: </span>
                <span className="font-mono font-bold text-[#082B4C]">{salaryConfig?.ifscCode || 'SBIN0001234'}</span>
              </div>
              <div>
                <span>UPI ID: </span>
                <span className="font-mono font-bold text-[#082B4C]">{emp.upiId || '—'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. PAYSLIPS TAB */}
      {profileTab === 'PAYSLIPS' && (
        <div className="bg-white rounded-2xl border border-[#D8EAE8] p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EAF2F2]">
            <div>
              <h2 className="text-sm font-bold text-[#082B4C]">Generated Payslips</h2>
              <p className="text-[11px] text-[#526B82]">Official stamped compensation records</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-[#F4FBFC] border-b border-[#D8EAE8] text-[#526B82] font-bold">
                  <th className="py-3 px-4">Period</th>
                  <th className="py-3 px-4">Gross Salary</th>
                  <th className="py-3 px-4">Deductions</th>
                  <th className="py-3 px-4">Net Payable</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Document</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EAF2F2]">
                {[0, 1].map((m) => {
                  const pDate = dayjs().subtract(m + 1, 'month');
                  return (
                    <tr key={m} className="hover:bg-[#F8FCFC]">
                      <td className="py-3 px-4 font-bold text-[#082B4C]">{pDate.format('MMMM YYYY')}</td>
                      <td className="py-3 px-4 font-mono font-semibold text-[#082B4C]">
                        ₹{monthlySalary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-4 font-mono text-rose-600">₹0</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-700">
                        ₹{monthlySalary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Paid
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => {
                            generatePayslipPDF({
                              employee,
                              basicSalary: Math.round(monthlySalary * 0.5),
                              hra: Math.round(monthlySalary * 0.3),
                              allowances: Math.round(monthlySalary * 0.2),
                              grossSalary: monthlySalary,
                              totalDeductions: 0,
                              netSalary: monthlySalary,
                              status: 'PAID'
                            }, pDate.format('MMMM YYYY'));
                          }}
                          className="px-2.5 py-1 rounded-lg bg-[#17A2B8] hover:bg-[#138496] text-white font-bold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-95"
                        >
                          <Download className="w-3.5 h-3.5" /> Download PDF
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. ACCOUNT TAB */}
      {profileTab === 'ACCOUNT' && (
        <div className="bg-white rounded-2xl border border-[#D8EAE8] p-6 shadow-xs space-y-6">
          <div className="flex items-center gap-2.5 pb-4 border-b border-[#EAF2F2]">
            <ShieldCheck className="w-5 h-5 text-teal-600" />
            <div>
              <h2 className="text-sm font-bold text-[#082B4C]">Account Access & Security Status</h2>
              <p className="text-xs text-[#526B82]">User login credentials, role assignments, and device bindings</p>
            </div>
          </div>

          <div className="space-y-3 text-xs max-w-xl">
            <div className="flex justify-between py-2 border-b border-[#F0F6F6]">
              <span className="text-[#526B82]">System User Role</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200 uppercase">
                {user.role || emp.role || 'EMPLOYEE'}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-[#F0F6F6]">
              <span className="text-[#526B82]">Login Email</span>
              <span className="font-mono font-semibold text-[#082B4C]">{user.email || emp.email}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[#F0F6F6]">
              <span className="text-[#526B82]">Account Status</span>
              <span className="font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Active & Verified
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-[#F0F6F6]">
              <span className="text-[#526B82]">Password Protection</span>
              <span className="font-medium text-[#082B4C]">Argon2id Hash Secure</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-[#526B82]">Portal Authorization</span>
              <span className="font-semibold text-[#075E59]">Strict Employee Portal Token</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onResetPassword(emp)}
              className="px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs border border-amber-300 inline-flex items-center gap-2"
            >
              <KeyRound className="w-4 h-4" />
              Generate Temporary Password Reset
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
