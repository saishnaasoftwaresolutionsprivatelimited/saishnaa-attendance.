export default function AppFooter({ dark = false }) {
  return (
    <footer
      className={`px-4 py-3 text-center text-[11px] ${
        dark
          ? 'border-t border-white/10 bg-[#064E52] text-[#8DB4B5]'
          : 'border-t border-[#D8EAE8] bg-[#EFF8FA] text-[#526B82]'
      }`}
    >
      © {new Date().getFullYear()} Saishnaa Software Solutions Private Limited. All rights reserved.
    </footer>
  );
}
