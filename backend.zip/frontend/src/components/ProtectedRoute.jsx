import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children, allowedRoles }) {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F7F9FC] flex flex-col items-center justify-center">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#20266D] to-[#2563EB] flex items-center justify-center text-white text-xl font-bold shadow-lg animate-bounce">
          S
        </div>
        <div className="mt-4 text-xs font-semibold tracking-wider text-slate-500 uppercase">
          Verifying Authenticated Session...
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect to the user's primary authorized role dashboard
    if (user.role === 'ADMIN') return <Navigate to="/admin/dashboard" replace />;
    if (user.role === 'HR') return <Navigate to="/hr/my-dashboard" replace />;
    return <Navigate to="/employee/dashboard" replace />;
  }

  return children;
}
