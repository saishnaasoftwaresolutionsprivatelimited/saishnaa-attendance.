import { evaluateAttendanceLocation, locationConfigFromSettings } from '../../../shared/attendanceLocation.mjs';

export function checkAttendanceLocation(settings, location) {
  const result = evaluateAttendanceLocation(locationConfigFromSettings(settings), location.latitude, location.longitude);
  if (import.meta.env?.DEV) {
    console.log({ employeeLatitude: location.latitude, employeeLongitude: location.longitude,
      accuracy: location.accuracy, officeLatitude: result.config.latitude,
      officeLongitude: result.config.longitude, allowedRadius: result.config.radiusMeters,
      distanceMeters: result.distanceMeters });
  }
  return result;
}

export function getCurrentAttendanceLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Unable to determine your current location. Please retry.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      ({ coords }) => resolve({ latitude: coords.latitude, longitude: coords.longitude, accuracy: coords.accuracy }),
      (error) => {
        const message = error.code === 1
          ? 'Location permission is required for Check-In/Check-Out.'
          : 'Unable to determine your current location. Please retry.';
        reject(new Error(message));
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  });
}
