import { jsPDF } from 'jspdf';
import { adminStore } from '../services/adminStore';

/**
 * Converts Indian currency numbers to words
 * e.g. 18667 -> "Rupees Eighteen Thousand Six Hundred Sixty Seven Only"
 */
export function numberToWordsINR(amount) {
  const num = Math.round(Number(amount) || 0);
  if (num === 0) return 'Rupees Zero Only';

  const a = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertTwoDigits(n) {
    if (n < 20) return a[n];
    return b[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + a[n % 10] : '');
  }

  function convertThreeDigits(n) {
    if (n === 0) return '';
    const hundred = Math.floor(n / 100);
    const rest = n % 100;
    let res = '';
    if (hundred > 0) res += a[hundred] + ' Hundred';
    if (rest > 0) {
      if (res !== '') res += ' ';
      res += convertTwoDigits(rest);
    }
    return res;
  }

  let crore = Math.floor(num / 10000000);
  let rem = num % 10000000;
  let lakh = Math.floor(rem / 100000);
  rem = rem % 100000;
  let thousand = Math.floor(rem / 1000);
  let hundred = rem % 1000;

  let words = '';
  if (crore > 0) words += convertTwoDigits(crore) + ' Crore ';
  if (lakh > 0) words += convertTwoDigits(lakh) + ' Lakh ';
  if (thousand > 0) words += convertTwoDigits(thousand) + ' Thousand ';
  if (hundred > 0) words += convertThreeDigits(hundred) + ' ';

  return `Rupees ${words.trim()} Only`;
}

/**
 * Formats numbers in Indian locale with 2 decimal places (e.g. 20,000.00)
 */
function formatINR(val) {
  return Number(val || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Generates an exact match payslip matching the Saishnaa reference design
 * - NO LOGO (per user request: only company name shows)
 * - Safe typography: Uses INR/Rs. to prevent jsPDF Helvetica font corruption where '₹' prints as '1'
 * - Exact alignment: Guaranteed no text overflow or card clipping
 * - Future proof: Dynamically pulls company name and subtitles from persistent adminStore
 */
export function generatePayslipPDF(payslip, month = 'October 2026') {
  if (!payslip) return null;

  // Retrieve current dynamic company branding from persistent adminStore
  let companySettings = {};
  try {
    companySettings = adminStore.getSettings() || {};
  } catch (err) {
    console.warn('Could not read adminStore settings:', err);
  }

  const companyName = companySettings.companyName || payslip.companyName || 'Saishnaa Technologies Pvt Ltd';
  const companySubtitle =
    companySettings.companySubtitle ||
    payslip.companySubtitle ||
    'Software Solutions Private Limited';
  const companyTagline =
    companySettings.companyTagline || payslip.companyTagline || 'Empowering Bright Futures.';

  // Normalize Employee data
  const emp = payslip.employee || {};
  const fullName = emp.fullName || payslip.fullName || 'Employee';
  const employeeCode = emp.employeeCode || payslip.employeeCode || 'EMP001';
  const department =
    typeof emp.department === 'string'
      ? emp.department
      : emp.department?.name || payslip.department || 'Engineering';
  const designation =
    typeof emp.designation === 'string'
      ? emp.designation
      : emp.designation?.title || payslip.designation || payslip.position || 'Staff';
  const joiningDate = emp.joiningDate || payslip.joiningDate || '15 Jan 2024';

  // Attendance metrics
  const workingDays = Number(payslip.workingDays || 30);
  const lopDays = Number(payslip.lopDays ?? (payslip.unpaidLeaveDays || 2));
  const presentDays = Number(payslip.presentDays || (workingDays - lopDays));

  // Compute Salary Details
  const basicSalary = Number(payslip.basicSalary || 20000);
  const hra = Number(payslip.hra || 0);
  const allowances = Number(payslip.allowances || 0);
  const bonus = Number(payslip.bonusAmount ?? payslip.bonus ?? 0);

  // Compute LOP deduction based on per-day basic or explicit
  const perDayRate = workingDays > 0 ? basicSalary / workingDays : 0;
  const computedLopDeduction = lopDays > 0 ? Math.round(perDayRate * lopDays) : 0;
  const lopDeduction = Number(payslip.lopDeduction ?? (payslip.lossOfPay || computedLopDeduction));

  const pf = Number(payslip.pfDeduction ?? payslip.pf ?? 0);
  const esi = Number(payslip.esiDeduction ?? payslip.esi ?? 0);
  const otherDeductions = Number(payslip.otherDeductions ?? 0);

  const totalDeductions = lopDeduction + pf + esi + otherDeductions;
  const grossEarnings = basicSalary + hra + allowances + bonus;
  const netSalary = Number(payslip.netSalary || (grossEarnings - totalDeductions));

  // Format Dates
  const payPeriod = payslip.payPeriod || `01 ${month} – ${workingDays} ${month}`;
  const paymentDate = payslip.paymentDate || `${workingDays} ${month}`;
  const netWords = numberToWordsINR(netSalary);

  // Initialize jsPDF A4 Document (210mm x 297mm)
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const leftMargin = 15;
  const contentWidth = 180;
  const rightMargin = leftMargin + contentWidth; // 195mm

  // Palette grounded in exact reference theme
  const deepNavy = [11, 25, 44]; // #0B192C (Header badge)
  const bannerNavy = [15, 39, 68]; // #0F2744 (Highlight banner)
  const brandCyan = [2, 132, 199]; // #0284C7
  const softCardBg = [248, 250, 252]; // #F8FAFC
  const borderLight = [226, 232, 240]; // #E2E8F0
  const textMuted = [100, 116, 139]; // #64748B
  const textDark = [15, 23, 42]; // #0F172A

  /* -------------------------------------------------------------
   * 1. TOP HEADER SECTION (COMPANY NAME ONLY - NO LOGO)
   * ------------------------------------------------------------- */

  // Left Side: Company Name, Subtitle & Tagline (starting cleanly at leftMargin=15mm)
  doc.setFont('helvetica', 'bold');
  const maxNameWidth = 120; // safe clearance from badge at 142mm
  let nameFontSize = 20;
  doc.setFontSize(nameFontSize);
  while (doc.getTextWidth(companyName) > maxNameWidth && nameFontSize > 13) {
    nameFontSize -= 0.5;
    doc.setFontSize(nameFontSize);
  }
  doc.setTextColor(...textDark);
  doc.text(companyName, leftMargin, 16);

  if (companySubtitle) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 41, 59);
    doc.text(companySubtitle, leftMargin, 22);
  }

  if (companyTagline) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.setTextColor(...textMuted);
    doc.text(companyTagline, leftMargin, 27);
  }

  // Right Side: Dark Navy PAYSLIP Period Badge (x = 142 to 195, width = 53mm)
  const badgeX = rightMargin - 53;
  const badgeY = 9;
  const badgeW = 53;
  const badgeH = 18;
  doc.setFillColor(...deepNavy);
  doc.roundedRect(badgeX, badgeY, badgeW, badgeH, 2.5, 2.5, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text('P A Y S L I P', badgeX + badgeW / 2, badgeY + 7.5, { align: 'center' });

  doc.setFontSize(8.5);
  doc.setTextColor(125, 211, 252); // Light Cyan
  doc.text(month.toUpperCase(), badgeX + badgeW / 2, badgeY + 14, { align: 'center' });

  // Thin separator line below header
  doc.setFillColor(...brandCyan);
  doc.rect(leftMargin, 31, 32, 1.2, 'F'); // Left cyan accent bar

  doc.setDrawColor(...borderLight);
  doc.setLineWidth(0.4);
  doc.line(leftMargin + 32, 31.6, rightMargin, 31.6);

  /* -------------------------------------------------------------
   * 2. EMPLOYEE INFORMATION CARD (CLEAN KEY-VALUE COLUMNS)
   * ------------------------------------------------------------- */
  const empCardY = 36;
  const empCardH = 43;
  doc.setFillColor(...softCardBg);
  doc.setDrawColor(...borderLight);
  doc.setLineWidth(0.4);
  doc.roundedRect(leftMargin, empCardY, contentWidth, empCardH, 3, 3, 'FD');

  // Left Sub-Panel: Avatar + Name + Core IDs
  // Avatar Circle (x = 27, y = 47)
  const avX = leftMargin + 11;
  const avY = empCardY + 11;
  doc.setFillColor(219, 234, 254); // #DBEAFE
  doc.circle(avX, avY, 6.5, 'F');

  // Draw crisp User Avatar vector glyph inside circle
  doc.setFillColor(37, 99, 235);
  doc.circle(avX, avY - 1.5, 2.2, 'F'); // head
  // Shoulders arc
  doc.ellipse(avX, avY + 3.8, 3.8, 2, 'F');

  // Name & Designation
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(...textDark);
  doc.text(fullName, leftMargin + 22, empCardY + 9.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(...textMuted);
  doc.text(designation, leftMargin + 22, empCardY + 14.5);

  // Thin divider line under designation
  doc.setDrawColor(...borderLight);
  doc.line(leftMargin + 22, empCardY + 17.5, 96, empCardY + 17.5);

  // Left Column Key-Values (aligned cleanly with colon)
  const leftLabelX = leftMargin + 5;
  const leftColonX = leftMargin + 31;
  const leftValX = leftMargin + 35;
  let leftY = empCardY + 24;

  const leftDetails = [
    { label: 'Employee ID', val: employeeCode },
    { label: 'Department', val: department },
    { label: 'Date of Joining', val: joiningDate },
  ];

  leftDetails.forEach((item) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(...textMuted);
    doc.text(item.label, leftLabelX, leftY);
    doc.text(':', leftColonX, leftY);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...textDark);
    doc.text(String(item.val), leftValX, leftY);
    leftY += 6;
  });

  // Vertical Card Divider
  doc.setDrawColor(...borderLight);
  doc.line(103, empCardY + 6, 103, empCardY + empCardH - 6);

  // Right Column Key-Values (aligned cleanly with colon)
  const rightLabelX = 108;
  const rightColonX = 135;
  const rightValX = 139;
  let rightY = empCardY + 9.5;

  const rightDetails = [
    { label: 'Pay Period', val: payPeriod },
    { label: 'Working Days', val: workingDays },
    { label: 'Present Days', val: presentDays },
    { label: 'LOP Days', val: lopDays },
    { label: 'Payment Date', val: paymentDate },
  ];

  rightDetails.forEach((item) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(...textMuted);
    doc.text(item.label, rightLabelX, rightY);
    doc.text(':', rightColonX, rightY);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...textDark);
    doc.text(String(item.val), rightValX, rightY);
    rightY += 6.5;
  });

  /* -------------------------------------------------------------
   * 3. SALARY DETAILS CARD (TABLE WITH PRECISE MARGINS)
   * ------------------------------------------------------------- */
  const salCardY = empCardY + empCardH + 5; // 84mm

  // Items to display
  const salaryRows = [
    { label: 'Basic Salary', amount: formatINR(basicSalary), isDeduction: false },
  ];

  if (hra > 0) {
    salaryRows.push({ label: 'House Rent Allowance (HRA)', amount: formatINR(hra), isDeduction: false });
  }
  if (allowances > 0) {
    salaryRows.push({ label: 'Special Allowances', amount: formatINR(allowances), isDeduction: false });
  }
  if (bonus > 0) {
    salaryRows.push({ label: 'Performance Bonus', amount: formatINR(bonus), isDeduction: false });
  }

  // Deductions
  if (lopDays > 0 || lopDeduction > 0) {
    salaryRows.push({
      label: `LOP Deduction (${lopDays} Days)`,
      amount: `-   ${formatINR(lopDeduction)}`,
      isDeduction: true,
    });
  }
  if (pf > 0) {
    salaryRows.push({ label: 'Provident Fund (EPF)', amount: `-   ${formatINR(pf)}`, isDeduction: true });
  }
  if (esi > 0) {
    salaryRows.push({ label: 'ESI Contribution', amount: `-   ${formatINR(esi)}`, isDeduction: true });
  }
  if (otherDeductions > 0) {
    salaryRows.push({ label: 'Other Deductions / TDS', amount: `-   ${formatINR(otherDeductions)}`, isDeduction: true });
  }

  const rowHeight = 9.5;
  const salCardH = 10 + salaryRows.length * rowHeight + 3;

  // Outer container
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(...borderLight);
  doc.roundedRect(leftMargin, salCardY, contentWidth, salCardH, 3, 3, 'FD');

  // Header Banner Bar inside Salary Details
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(...borderLight);
  doc.roundedRect(leftMargin, salCardY, contentWidth, 10, 3, 3, 'FD');

  // Clean Coin Vector Glyph on left of header
  const coinX = leftMargin + 7;
  const coinY = salCardY + 5;
  doc.setFillColor(...brandCyan);
  doc.circle(coinX, coinY, 3.2, 'F');
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.3);
  doc.circle(coinX, coinY, 2.2, 'S'); // inner rim

  // Header Titles
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(...textDark);
  doc.text('Salary Details', leftMargin + 13, salCardY + 6.5);

  // Safe Header: Amount (INR) prevents font corruption
  doc.setFontSize(9.5);
  doc.text('Amount (INR)', rightMargin - 6, salCardY + 6.5, { align: 'right' });

  // Rows rendering with safe right margin
  let currentY = salCardY + 17;
  salaryRows.forEach((row, idx) => {
    // Row label
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);
    doc.text(row.label, leftMargin + 7, currentY);

    // Row Amount (cleanly aligned to right margin - 6mm)
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...textDark);
    doc.text(row.amount, rightMargin - 6, currentY, { align: 'right' });

    // Row separator
    if (idx < salaryRows.length - 1) {
      doc.setDrawColor(241, 245, 249);
      doc.line(leftMargin + 3, currentY + 3.5, rightMargin - 3, currentY + 3.5);
    }
    currentY += rowHeight;
  });

  /* -------------------------------------------------------------
   * 4. TOTAL SALARY EARNED THIS MONTH (HIGHLIGHT BANNER CARD)
   * ------------------------------------------------------------- */
  const bannerY = salCardY + salCardH + 5;
  const bannerH = 15;

  // Solid Deep Navy pill
  doc.setFillColor(...bannerNavy);
  doc.roundedRect(leftMargin, bannerY, contentWidth, bannerH, 3, 3, 'F');

  // Vector Wallet Icon in white box (NO text '₹' so no font corruption)
  const iconBoxX = leftMargin + 6;
  const iconBoxY = bannerY + 3;
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(iconBoxX, iconBoxY, 9, 9, 2, 2, 'F');

  // Draw clean vector wallet inside icon box
  doc.setFillColor(...brandCyan);
  doc.roundedRect(iconBoxX + 1.5, iconBoxY + 2.5, 6, 4.2, 0.6, 0.6, 'F');
  doc.setFillColor(255, 255, 255);
  doc.circle(iconBoxX + 5.5, iconBoxY + 4.6, 0.6, 'F'); // clasp

  // Banner Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text('Total Salary Earned This Month', leftMargin + 19, bannerY + 9.5);

  // Vertical White Separator
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.4);
  doc.line(125, bannerY + 3.5, 125, bannerY + bannerH - 3.5);

  // Big Bold Take Home Amount with safe 'Rs.' prefix (100% immune to font corruption)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(255, 255, 255);
  doc.text(`Rs. ${formatINR(netSalary)}`, rightMargin - 6, bannerY + 10.2, { align: 'right' });

  /* -------------------------------------------------------------
   * 5. NET PAY IN WORDS CARD
   * ------------------------------------------------------------- */
  const wordsCardY = bannerY + bannerH + 4;
  const wordsCardH = 10;

  doc.setFillColor(240, 249, 255); // #F0F9FF
  doc.setDrawColor(186, 230, 253); // #BAE6FD
  doc.setLineWidth(0.4);
  doc.roundedRect(leftMargin, wordsCardY, contentWidth, wordsCardH, 2.5, 2.5, 'FD');

  // Small document vector indicator
  doc.setFillColor(...brandCyan);
  doc.roundedRect(leftMargin + 5, wordsCardY + 2.5, 5, 5, 1, 1, 'F');
  doc.setFillColor(255, 255, 255);
  doc.rect(leftMargin + 6.2, wordsCardY + 4, 2.6, 0.6, 'F');
  doc.rect(leftMargin + 6.2, wordsCardY + 5.2, 2.6, 0.6, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(...textDark);
  doc.text('Net Pay in Words', leftMargin + 13, wordsCardY + 6.3);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...textMuted);
  doc.text(':', leftMargin + 42, wordsCardY + 6.3);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...textDark);
  doc.text(netWords, leftMargin + 46, wordsCardY + 6.3);

  /* -------------------------------------------------------------
   * 6. FOOTER & AUTHORIZED SIGNATURE SECTION
   * ------------------------------------------------------------- */
  const footerY = 250;

  // Bottom left decorative geometric polygon accent (watermark)
  doc.setFillColor(240, 249, 255);
  doc.triangle(0, 297, 30, 297, 0, 267, 'F');
  doc.setFillColor(224, 242, 254);
  doc.triangle(0, 297, 20, 297, 0, 277, 'F');

  // Left Note
  doc.setFillColor(...brandCyan);
  doc.rect(leftMargin, footerY - 5, 30, 0.8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(...textDark);
  doc.text('Note:', leftMargin, footerY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...textMuted);
  doc.text('• This is a computer-generated payslip and does not require a signature.', leftMargin, footerY + 5);

  // Right Signatory
  const sigLineW = 55;
  const sigLineX = rightMargin - sigLineW;

  doc.setDrawColor(148, 163, 184); // #94A3B8
  doc.setLineWidth(0.5);
  doc.line(sigLineX, footerY - 2, rightMargin, footerY - 2);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(...textDark);
  doc.text('Authorized Signatory', sigLineX + sigLineW / 2, footerY + 3.5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text(`${companyName} ${companySubtitle}`, sigLineX + sigLineW / 2, footerY + 8, {
    align: 'center',
  });

  // Save to file and trigger browser download
  const safeName = fullName.replace(/[^a-zA-Z0-9]/g, '_');
  const safeMonth = month.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `Payslip_${safeName}_${employeeCode}_${safeMonth}.pdf`;
  doc.save(filename);
  return filename;
}

/**
 * Generates an official Tabular Report PDF
 */
export function generateReportPDF(reportTitle, month, columns, rows) {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  let companySettings = {};
  try {
    companySettings = adminStore.getSettings() || {};
  } catch (err) {
    console.warn('Could not read adminStore settings:', err);
  }

  const companyName = companySettings.companyName || 'Saishnaa Technologies Pvt Ltd';
  const companySubtitle =
    companySettings.companySubtitle || 'Software Solutions Private Limited';

  // Top header bar
  doc.setFillColor(15, 39, 68);
  doc.rect(0, 0, pageWidth, 4, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42);
  doc.text(`${companyName.toUpperCase()} ${companySubtitle.toUpperCase()}`, 15, 14);

  doc.setFontSize(11);
  doc.setTextColor(2, 132, 199);
  doc.text(reportTitle.replace(/_/g, ' ').toUpperCase(), 15, 21);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(
    `Audit Period: ${month} | Generated: ${new Date().toLocaleDateString('en-GB')}`,
    pageWidth - 15,
    21,
    { align: 'right' }
  );

  doc.setDrawColor(226, 232, 240);
  doc.line(15, 26, pageWidth - 15, 26);

  // Table Columns
  let y = 34;
  const colSpacing = (pageWidth - 30) / columns.length;

  doc.setFillColor(248, 250, 252);
  doc.rect(15, y - 5, pageWidth - 30, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  columns.forEach((col, idx) => {
    doc.text(col, 18 + idx * colSpacing, y);
  });

  // Table Rows
  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);

  rows.forEach((row) => {
    if (y > pageHeight - 20) {
      doc.addPage();
      y = 20;
    }

    doc.setTextColor(51, 65, 85);
    row.forEach((cell, cIdx) => {
      doc.text(String(cell), 18 + cIdx * colSpacing, y);
    });

    doc.setDrawColor(241, 245, 249);
    doc.line(15, y + 2, pageWidth - 15, y + 2);
    y += 7;
  });

  const filename = `${reportTitle.replace(/\s+/g, '_')}_${month.replace(/\s+/g, '_')}.pdf`;
  doc.save(filename);
  return filename;
}
