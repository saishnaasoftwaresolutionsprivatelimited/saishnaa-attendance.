import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { adminStore } from '../services/adminStore';
import FirstLoginModal from '../components/FirstLoginModal';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  CalendarDays,
  CreditCard,
  Receipt,
  Calendar,
  FileCheck2,
  BarChart3,
  CheckSquare,
  ShieldCheck,
  UserRound,
  Gift,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  Search,
  ChevronDown,
  CheckCircle2,
} from 'lucide-react';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(utc);
dayjs.extend(timezone);

export default function DashboardLayout() {
  const { user, logout, role } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(dayjs().tz('Asia/Kolkata').format('hh:mm:ss A'));
  const [currentDate, setCurrentDate] = useState(dayjs().tz('Asia/Kolkata').format('ddd, DD MMM YYYY'));
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [adminSettings, setAdminSettings] = useState(() => adminStore.getSettings());

  useEffect(() => {
    const refreshAdminSettings = () => setAdminSettings(adminStore.getSettings());
    window.addEventListener('saishnaa-settings-updated', refreshAdminSettings);
    return () => window.removeEventListener('saishnaa-settings-updated', refreshAdminSettings);
  }, []);

  const displayName = role === 'ADMIN'
    ? (adminSettings.adminName || user?.employee?.fullName || 'Administrator')
    : (user?.employee?.fullName || 'User');
  const displayEmail = role === 'ADMIN'
    ? (adminSettings.adminEmail || user?.email || '')
    : (user?.email || '');
  const displayPhoto = role === 'ADMIN' ? adminSettings.adminPhoto : (user?.employee?.profilePhoto || '');
  const adminOnlyHrPaths = ['/hr/dashboard', '/hr/employees', '/hr/payroll', '/hr/leave-approvals'];
  const isEmployeePortal = location.pathname.startsWith('/employee/')
    || (location.pathname.startsWith('/hr/') && !adminOnlyHrPaths.includes(location.pathname));
  const portalBase = location.pathname.startsWith('/hr/') ? '/hr' : '/employee';

  // Live IST Clock update every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(dayjs().tz('Asia/Kolkata').format('hh:mm:ss A'));
      setCurrentDate(dayjs().tz('Asia/Kolkata').format('ddd, DD MMM YYYY'));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Close mobile sidebar on route change
  useEffect(() => {
    setSidebarOpen(false);
    setUserDropdownOpen(false);
    setNotificationsOpen(false);
  }, [location.pathname]);

  // Admin Navigation Modules (Flat Greens palette, No 3D gradients)
  const adminNavItems = [
    { name: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
    { name: 'Employees', path: '/admin/employees', icon: Users },
    { name: 'Attendance', path: '/admin/attendance', icon: CalendarCheck },
    { name: 'Payroll', path: '/admin/payroll', icon: CreditCard },
    { name: 'Payslip', path: '/admin/payslips', icon: Receipt },
    { name: 'Tasks & Assignments', path: '/admin/tasks', icon: CheckSquare },
    { name: 'Requests & Approvals', path: '/admin/requests', icon: FileCheck2 },
    { name: 'Report & Analytics', path: '/admin/reports', icon: BarChart3 },
    { name: 'Holiday Calendar', path: '/admin/holidays', icon: Gift },
    { name: 'Settings', path: '/admin/settings', icon: Settings },
  ];
  const employeeNavItems = [
    { name: 'My Dashboard', path: `${portalBase}/${portalBase === '/hr' ? 'my-dashboard' : 'dashboard'}`, icon: LayoutDashboard },
    { name: 'My Attendance', path: `${portalBase}/attendance`, icon: CalendarCheck },
    { name: 'Attendance Calendar', path: `${portalBase}/calendar`, icon: CalendarDays },
    { name: 'Leave Requests', path: `${portalBase}/leaves`, icon: Gift },
    { name: 'My Salary', path: `${portalBase}/salary`, icon: CreditCard },
    { name: 'Payslips', path: `${portalBase}/payslips`, icon: Receipt },
    { name: 'Request History', path: `${portalBase}/history`, icon: FileCheck2 },
    { name: 'My Profile', path: `${portalBase}/profile`, icon: UserRound },
    ...(portalBase === '/employee' ? [{ name: 'My Tasks', path: '/employee/tasks', icon: CheckSquare }] : []),
  ];
  const navigationItems = isEmployeePortal ? employeeNavItems : adminNavItems;
  const dashboardPath = portalBase === '/hr' ? '/hr/my-dashboard' : '/employee/dashboard';

  return (
    <div className={`min-h-screen ${isEmployeePortal ? 'bg-[#D6EBEE]/40' : 'bg-[#F8FAFC]'} flex antialiased text-[#0F172A] font-sans`}>
      <FirstLoginModal />

      {/* 1. BLACK/NAVY SLEEK SIDEBAR */}
      <aside
        className={`fixed inset-y-0 left-0 w-64 ${isEmployeePortal ? 'bg-[#D6EBEE] text-[#123B50] border-r border-[#97CADB]' : 'bg-[#0F172A] text-slate-200 border-r border-[#1E293B]'} z-50 flex flex-col justify-between transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Top: Brand Header & Navigation Items */}
        <div className="flex flex-col flex-1 overflow-y-auto px-3.5 py-4 scrollbar-thin">
          {/* Brand Header */}
          <div
            className="flex items-center justify-between cursor-pointer mb-5 px-2.5 py-1.5"
            onClick={() => navigate(isEmployeePortal ? dashboardPath : '/admin/dashboard')}
          >
            <div className="flex items-center gap-3">
              {/* Solid Green Brand Square - NO Gradient */}
              <div className={`w-10 h-10 rounded-xl ${isEmployeePortal ? 'bg-[#018ABE] text-white' : 'bg-[#16A34A] text-white'} flex items-center justify-center font-black text-xl shadow-xs tracking-tighter`}>
                S
              </div>
              <div className="flex flex-col">
                <span className={`text-base font-bold ${isEmployeePortal ? 'text-[#123B50]' : 'text-white'} tracking-tight leading-tight flex items-center gap-1.5`}>
                  Saishnaa
                  <span className={`text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded ${isEmployeePortal ? 'bg-[#FAFFA3] text-[#123B50]' : 'bg-[#166534] text-[#BBF7D0]'} font-bold`}>
                    {isEmployeePortal ? 'Employee' : 'Admin'}
                  </span>
                </span>
                <span className={`text-[11px] ${isEmployeePortal ? 'text-[#426B7A]' : 'text-slate-400'} font-medium leading-tight`}>
                  {isEmployeePortal ? 'Employee Workspace' : 'Workforce & Payroll'}
                </span>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setSidebarOpen(false);
              }}
              className={`lg:hidden p-1.5 ${isEmployeePortal ? 'text-[#426B7A] hover:bg-[#97CADB]/50' : 'text-slate-400 hover:text-white hover:bg-slate-800'} rounded-lg`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Title */}
          <div className="px-2.5 pb-2 pt-1">
            <span className={`text-[10px] font-bold uppercase tracking-wider ${isEmployeePortal ? 'text-[#426B7A]' : 'text-slate-400'}`}>
              {isEmployeePortal ? 'My Workspace' : 'Main Menu'}
            </span>
          </div>

          {/* Nav Links */}
          <nav className="space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.path === '/admin/dashboard' || item.path === '/employee/dashboard' || item.path === '/hr/my-dashboard'
                  ? location.pathname === item.path || location.pathname === '/admin' || location.pathname === '/hr'
                  : location.pathname.startsWith(item.path);

              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={`group flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-colors duration-150 ${
                    isActive
                      ? (isEmployeePortal ? 'bg-[#018ABE] text-white' : 'bg-[#16A34A] text-white shadow-xs')
                      : (isEmployeePortal ? 'text-[#24566B] hover:text-[#123B50] hover:bg-[#97CADB]/50' : 'text-slate-300 hover:text-white hover:bg-[#1E293B]')
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 flex-shrink-0 transition-colors ${
                      isActive ? 'text-white' : (isEmployeePortal ? 'text-[#426B7A] group-hover:text-[#018ABE]' : 'text-slate-400 group-hover:text-[#4ADE80]')
                    }`}
                  />
                  <span className="truncate">{item.name}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar: User Pill & Logout */}
        <div className={`p-3 border-t ${isEmployeePortal ? 'border-[#97CADB] bg-[#D6EBEE]' : 'border-[#1E293B] bg-[#0B1322]'}`}>
          <div className={`flex items-center justify-between p-2 rounded-xl ${isEmployeePortal ? 'hover:bg-[#97CADB]/50' : 'hover:bg-[#1E293B]'} transition-colors`}>
            <div className="flex items-center gap-2.5 min-w-0">
              {displayPhoto ? (
                <img src={displayPhoto} alt="" className="w-8 h-8 rounded-full object-cover border border-slate-600 flex-shrink-0" />
              ) : (
                <div className={`w-8 h-8 rounded-full ${isEmployeePortal ? 'bg-[#018ABE]' : 'bg-[#16A34A]'} text-white flex items-center justify-center font-bold text-xs flex-shrink-0`}>
                  {displayName.charAt(0) || 'A'}
                </div>
              )}
              <div className="flex flex-col min-w-0">
                <span className={`text-xs font-bold ${isEmployeePortal ? 'text-[#123B50]' : 'text-white'} truncate`}>
                  {displayName}
                </span>
                <span className={`text-[10px] ${isEmployeePortal ? 'text-[#426B7A]' : 'text-emerald-400'} font-medium truncate`}>
                  {role === 'ADMIN' ? (adminSettings.adminDesignation || 'Super Administrator') : (user?.employee?.designation || role)}
                </span>
              </div>
            </div>
            <button
              onClick={logout}
              title="Logout"
              className={`p-1.5 rounded-lg ${isEmployeePortal ? 'text-[#426B7A] hover:text-rose-600 hover:bg-[#97CADB]/50' : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'} transition-colors`}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Backdrop */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* 2. MAIN VIEWPORT */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        {/* TOPBAR */}
        <header className={`sticky top-0 z-30 ${isEmployeePortal ? 'bg-white border-b border-[#D6EBEE]' : 'bg-white border-b border-slate-200'} px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 shadow-xs`}>
          {/* Left: Mobile Toggle & Global Search Bar */}
          <div className="flex items-center gap-3 flex-1 max-w-xl">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle Navigation"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Global Search Bar */}
            {!isEmployeePortal && <div className="relative w-full max-w-md hidden sm:block">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search employee, attendance, payroll, records..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#16A34A] focus:bg-white transition-all font-medium"
              />
            </div>}
          </div>

          {/* Right: Date/Time Pill, Notifications & User Dropdown */}
          <div className="flex items-center gap-3">
            {/* Live IST Date & Time Pill */}
            <div className={`hidden md:flex items-center gap-2 ${isEmployeePortal ? 'bg-[#D6EBEE]/50 border-[#D6EBEE]' : 'bg-slate-50 border-slate-200'} border px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700`}>
              <Calendar className={`w-3.5 h-3.5 ${isEmployeePortal ? 'text-[#018ABE]' : 'text-[#16A34A]'}`} />
              <span>{currentDate}</span>
              <span className="text-slate-300">|</span>
              <span className={`font-mono ${isEmployeePortal ? 'text-[#018ABE]' : 'text-emerald-700'}`}>{currentTime}</span>
            </div>

            {/* Notification Bell with Badge */}
            {!isEmployeePortal && <div className="relative">
              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="w-9 h-9 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white flex items-center justify-center text-slate-600 transition-colors relative"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4 text-slate-600" />
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#16A34A] text-white text-[9px] font-bold flex items-center justify-center border-2 border-white">
                  3
                </span>
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl border border-slate-200 shadow-xl p-3 z-50 animate-in fade-in">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-800">System Notifications</span>
                    <span
                      onClick={() => setNotificationsOpen(false)}
                      className="text-[10px] text-[#16A34A] font-semibold cursor-pointer hover:underline"
                    >
                      Close
                    </span>
                  </div>
                  <div className="space-y-2 pt-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900">
                      <p className="font-bold text-[11px] flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        October Payroll Cycle Ready
                      </p>
                      <p className="text-[10px] text-emerald-700 mt-0.5">
                        Attendance reconciled for 9 active staff.
                      </p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900">
                      <p className="font-bold text-[11px]">Pending Leave Request</p>
                      <p className="text-[10px] text-amber-700 mt-0.5">
                        Rajesh Kannan requested 2 days Casual Leave.
                      </p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900">
                      <p className="font-bold text-[11px]">Holiday Tomorrow</p>
                      <p className="text-[10px] text-blue-700 mt-0.5">
                        Gandhi Jayanti declared corporate holiday.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>}

            {/* User Profile Pill */}
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {displayPhoto ? (
                  <img src={displayPhoto} alt="" className="w-8 h-8 rounded-full object-cover border border-slate-200" />
                ) : (
                  <div className={`w-8 h-8 rounded-full ${isEmployeePortal ? 'bg-[#018ABE]' : 'bg-[#16A34A]'} flex items-center justify-center text-white font-bold text-xs shadow-xs`}>
                    {displayName.charAt(0) || 'A'}
                  </div>
                )}
                <div className="hidden sm:flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-800 leading-tight">
                    {displayName}
                  </span>
                  <span className={`text-[10px] ${isEmployeePortal ? 'text-[#018ABE]' : 'text-emerald-600'} font-semibold leading-tight`}>
                    {isEmployeePortal ? (user?.employee?.designation || 'Employee') : 'Admin'}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-52 bg-white rounded-2xl border border-slate-200 shadow-xl p-2 z-50 space-y-1 animate-in fade-in">
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-800">
                      {displayName}
                    </p>
                    <p className="text-[10px] text-emerald-600 font-medium">{displayEmail}</p>
                  </div>
                  <button
                    onClick={() => navigate(isEmployeePortal ? `${portalBase}/profile` : '/admin/settings')}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors text-left"
                  >
                    <Users className="w-3.5 h-3.5 text-slate-500" /> {isEmployeePortal ? 'My Profile' : 'Admin Profile'}
                  </button>
                  {!isEmployeePortal && <button
                    onClick={() => navigate('/admin/settings')}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors text-left"
                  >
                    <Settings className="w-3.5 h-3.5 text-slate-500" /> System Settings
                  </button>}
                  {!isEmployeePortal && <button
                    onClick={() => navigate('/admin/employees')}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors text-left"
                  >
                    <Users className="w-3.5 h-3.5 text-slate-500" /> Employee Directory
                  </button>}
                  <div className="border-t border-slate-100 my-1" />
                  <button
                    onClick={logout}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors text-left"
                  >
                    <LogOut className="w-3.5 h-3.5 text-rose-600" /> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Content Outlet */}
        <main className={`p-4 sm:p-6 lg:p-7 max-w-[1680px] w-full mx-auto ${isEmployeePortal ? 'employee-portal-content' : ''}`}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
