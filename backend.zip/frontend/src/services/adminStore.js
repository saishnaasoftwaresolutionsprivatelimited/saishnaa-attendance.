/**
 * Persistent Store for Saishnaa Attendance & Payroll Admin System
 * Ensures all user changes, edits, creations, payroll runs, and approvals
 * permanently remain saved across browser page refreshes!
 */

const STORAGE_KEY = 'SAISHNAA_ADMIN_DATA_V4';
const LEGACY_STORAGE_KEYS = ['SAISHNAA_ADMIN_DATA_V2', 'SAISHNAA_ADMIN_DATA_V3'];

const DEMO_DATA = {
  employees: [
    {
      id: 'EMP-001',
      employeeCode: 'SN-1001',
      fullName: 'Suresh Kumar',
      email: 'suresh.k@saishnaa.com',
      phone: '+91 98401 23456',
      department: 'Engineering',
      designation: 'Lead Architect',
      joiningDate: '2022-03-15',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 65000,
      hra: 22000,
      allowances: 13000,
      bonus: 5000,
      pf: 1800,
      esi: 750,
      otherDeductions: 500,
      bankName: 'HDFC Bank',
      bankAccountNumber: '50100234981122',
      ifscCode: 'HDFC0001234',
      lastLogin: 'Today, 09:12 AM',
      avatar: 'SK',
      presenceRate: 98,
      leavesTaken: 3,
      leavesRemaining: 15,
      gender: 'Male',
      address: 'No 45, Anna Nagar, Chennai - 600040',
    },
    {
      id: 'EMP-002',
      employeeCode: 'SN-1002',
      fullName: 'Priya Mohan',
      email: 'priya.m@saishnaa.com',
      phone: '+91 98402 34567',
      department: 'Human Resources',
      designation: 'Senior HR Specialist',
      joiningDate: '2022-07-01',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 42000,
      hra: 14000,
      allowances: 8000,
      bonus: 3000,
      pf: 1800,
      esi: 650,
      otherDeductions: 350,
      bankName: 'ICICI Bank',
      bankAccountNumber: '001205009871',
      ifscCode: 'ICIC0000012',
      lastLogin: 'Today, 09:05 AM',
      avatar: 'PM',
      presenceRate: 95,
      leavesTaken: 5,
      leavesRemaining: 13,
      gender: 'Female',
      address: 'Flat 3B, T. Nagar, Chennai - 600017',
    },
    {
      id: 'EMP-003',
      employeeCode: 'SN-1003',
      fullName: 'Rajesh Kannan',
      email: 'rajesh.k@saishnaa.com',
      phone: '+91 98403 45678',
      department: 'Engineering',
      designation: 'Senior Full Stack Developer',
      joiningDate: '2023-01-10',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 48000,
      hra: 16000,
      allowances: 10000,
      bonus: 4000,
      pf: 1800,
      esi: 700,
      otherDeductions: 400,
      bankName: 'State Bank of India',
      bankAccountNumber: '20491823901',
      ifscCode: 'SBIN0000800',
      lastLogin: 'Today, 09:28 AM',
      avatar: 'RK',
      presenceRate: 92,
      leavesTaken: 6,
      leavesRemaining: 12,
      gender: 'Male',
      address: '22, Velachery Main Rd, Chennai - 600042',
    },
    {
      id: 'EMP-004',
      employeeCode: 'SN-1004',
      fullName: 'Deepika Sundaram',
      email: 'deepika.s@saishnaa.com',
      phone: '+91 98404 56789',
      department: 'Product & Design',
      designation: 'UI/UX Lead Designer',
      joiningDate: '2023-04-18',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 46000,
      hra: 15500,
      allowances: 8500,
      bonus: 3500,
      pf: 1800,
      esi: 680,
      otherDeductions: 300,
      bankName: 'Axis Bank',
      bankAccountNumber: '917010045678912',
      ifscCode: 'UTIB0000123',
      lastLogin: 'Today, 09:02 AM',
      avatar: 'DS',
      presenceRate: 96,
      leavesTaken: 4,
      leavesRemaining: 14,
      gender: 'Female',
      address: '88, Alwarpet, Chennai - 600018',
    },
    {
      id: 'EMP-005',
      employeeCode: 'SN-1005',
      fullName: 'Karthik Subramanian',
      email: 'karthik.s@saishnaa.com',
      phone: '+91 98405 67890',
      department: 'Quality Assurance',
      designation: 'QA Automation Engineer',
      joiningDate: '2023-08-20',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 36000,
      hra: 12000,
      allowances: 6000,
      bonus: 2500,
      pf: 1800,
      esi: 580,
      otherDeductions: 250,
      bankName: 'Kotak Mahindra',
      bankAccountNumber: '4512984501',
      ifscCode: 'KKBK0000451',
      lastLogin: 'Today, 09:18 AM',
      avatar: 'KS',
      presenceRate: 91,
      leavesTaken: 7,
      leavesRemaining: 11,
      gender: 'Male',
      address: '15, Tambaram West, Chennai - 600045',
    },
    {
      id: 'EMP-006',
      employeeCode: 'SN-1006',
      fullName: 'Ananya Ramesh',
      email: 'ananya.r@saishnaa.com',
      phone: '+91 98406 78901',
      department: 'Marketing & Sales',
      designation: 'Growth Marketing Manager',
      joiningDate: '2023-11-05',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 40000,
      hra: 13500,
      allowances: 7500,
      bonus: 3000,
      pf: 1800,
      esi: 620,
      otherDeductions: 300,
      bankName: 'HDFC Bank',
      bankAccountNumber: '50100459812401',
      ifscCode: 'HDFC0001234',
      lastLogin: 'Yesterday, 06:45 PM',
      avatar: 'AR',
      presenceRate: 88,
      leavesTaken: 8,
      leavesRemaining: 10,
      gender: 'Female',
      address: '7, Kilpauk Garden Rd, Chennai - 600010',
    },
    {
      id: 'EMP-007',
      employeeCode: 'SN-1007',
      fullName: 'Vijay Narayanan',
      email: 'vijay.n@saishnaa.com',
      phone: '+91 98407 89012',
      department: 'Operations',
      designation: 'Operations Coordinator',
      joiningDate: '2024-02-14',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 32000,
      hra: 10500,
      allowances: 5000,
      bonus: 2000,
      pf: 1800,
      esi: 540,
      otherDeductions: 200,
      bankName: 'Indian Bank',
      bankAccountNumber: '6019284710',
      ifscCode: 'IDIB000C024',
      lastLogin: 'Today, 09:10 AM',
      avatar: 'VN',
      presenceRate: 94,
      leavesTaken: 4,
      leavesRemaining: 14,
      gender: 'Male',
      address: '34, Mylapore, Chennai - 600004',
    },
    {
      id: 'EMP-008',
      employeeCode: 'SN-1008',
      fullName: 'Meera Krishnan',
      email: 'meera.k@saishnaa.com',
      phone: '+91 98408 90123',
      department: 'Finance & Accounts',
      designation: 'Accounts Executive',
      joiningDate: '2024-05-02',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 34000,
      hra: 11000,
      allowances: 5500,
      bonus: 2200,
      pf: 1800,
      esi: 560,
      otherDeductions: 220,
      bankName: 'Canara Bank',
      bankAccountNumber: '10928374619',
      ifscCode: 'CNRB0001092',
      lastLogin: 'Today, 09:00 AM',
      avatar: 'MK',
      presenceRate: 97,
      leavesTaken: 2,
      leavesRemaining: 16,
      gender: 'Female',
      address: '19, Nungambakkam High Rd, Chennai - 600034',
    },
    {
      id: 'EMP-009',
      employeeCode: 'SN-1009',
      fullName: 'Gokul Chandran',
      email: 'gokul.c@saishnaa.com',
      phone: '+91 98409 01234',
      department: 'Engineering',
      designation: 'Junior Frontend Developer',
      joiningDate: '2024-07-15',
      employmentType: 'Full Time',
      status: 'Active',
      basicSalary: 28000,
      hra: 9000,
      allowances: 4500,
      bonus: 1500,
      pf: 1800,
      esi: 480,
      otherDeductions: 180,
      bankName: 'Federal Bank',
      bankAccountNumber: '189201948123',
      ifscCode: 'FDRL0001892',
      lastLogin: 'Today, 09:35 AM',
      avatar: 'GC',
      presenceRate: 85,
      leavesTaken: 5,
      leavesRemaining: 13,
      gender: 'Male',
      address: '56, Porur, Chennai - 600116',
    },
    {
      id: 'EMP-010',
      employeeCode: 'SN-1010',
      fullName: 'Swetha Venkat',
      email: 'swetha.v@saishnaa.com',
      phone: '+91 98410 12345',
      department: 'Product & Design',
      designation: 'Associate Product Designer',
      joiningDate: '2024-09-01',
      employmentType: 'Full Time',
      status: 'Inactive',
      basicSalary: 30000,
      hra: 10000,
      allowances: 5000,
      bonus: 1800,
      pf: 1800,
      esi: 500,
      otherDeductions: 200,
      bankName: 'HDFC Bank',
      bankAccountNumber: '50100984712039',
      ifscCode: 'HDFC0001234',
      lastLogin: '18 Sep 2026, 04:30 PM',
      avatar: 'SV',
      presenceRate: 60,
      leavesTaken: 12,
      leavesRemaining: 6,
      gender: 'Female',
      address: '11, Adyar, Chennai - 600020',
    },
  ],

  // Attendance Records for Today
  attendance: [
    {
      id: 'ATT-001',
      employeeId: 'EMP-001',
      employeeCode: 'SN-1001',
      fullName: 'Suresh Kumar',
      department: 'Engineering',
      designation: 'Lead Architect',
      date: '2026-10-01',
      checkIn: '09:05 AM',
      checkOut: '06:15 PM',
      workingHours: '9h 10m',
      status: 'On Time',
      statusType: 'PRESENT',
      remarks: 'Punctual entry at Main Gate Biometrics',
      history: [
        { date: '2026-09-30', checkIn: '09:02 AM', checkOut: '06:10 PM', status: 'On Time', hours: '9h 08m' },
        { date: '2026-09-29', checkIn: '09:00 AM', checkOut: '06:05 PM', status: 'On Time', hours: '9h 05m' },
        { date: '2026-09-28', checkIn: '09:10 AM', checkOut: '06:20 PM', status: 'On Time', hours: '9h 10m' },
      ],
    },
    {
      id: 'ATT-002',
      employeeId: 'EMP-002',
      employeeCode: 'SN-1002',
      fullName: 'Priya Mohan',
      department: 'Human Resources',
      designation: 'Senior HR Specialist',
      date: '2026-10-01',
      checkIn: '09:02 AM',
      checkOut: '06:00 PM',
      workingHours: '8h 58m',
      status: 'On Time',
      statusType: 'PRESENT',
      remarks: 'Punctual on duty',
      history: [
        { date: '2026-09-30', checkIn: '09:05 AM', checkOut: '06:00 PM', status: 'On Time', hours: '8h 55m' },
        { date: '2026-09-29', checkIn: '09:12 AM', checkOut: '06:15 PM', status: 'On Time', hours: '9h 03m' },
      ],
    },
    {
      id: 'ATT-003',
      employeeId: 'EMP-003',
      employeeCode: 'SN-1003',
      fullName: 'Rajesh Kannan',
      department: 'Engineering',
      designation: 'Senior Full Stack Developer',
      date: '2026-10-01',
      checkIn: '09:42 AM',
      checkOut: '07:15 PM',
      workingHours: '9h 33m',
      status: 'Late',
      statusType: 'LATE',
      remarks: 'Traffic delay acknowledged by team lead',
      history: [
        { date: '2026-09-30', checkIn: '09:15 AM', checkOut: '06:30 PM', status: 'On Time', hours: '9h 15m' },
        { date: '2026-09-29', checkIn: '09:45 AM', checkOut: '07:00 PM', status: 'Late', hours: '9h 15m' },
      ],
    },
    {
      id: 'ATT-004',
      employeeId: 'EMP-004',
      employeeCode: 'SN-1004',
      fullName: 'Deepika Sundaram',
      department: 'Product & Design',
      designation: 'UI/UX Lead Designer',
      date: '2026-10-01',
      checkIn: '08:55 AM',
      checkOut: '07:30 PM',
      workingHours: '10h 35m',
      status: 'Overtime',
      statusType: 'OVERTIME',
      remarks: 'Release sprint UI Polish (Approved OT)',
      history: [
        { date: '2026-09-30', checkIn: '09:00 AM', checkOut: '06:10 PM', status: 'On Time', hours: '9h 10m' },
      ],
    },
    {
      id: 'ATT-005',
      employeeId: 'EMP-005',
      employeeCode: 'SN-1005',
      fullName: 'Karthik Subramanian',
      department: 'Quality Assurance',
      designation: 'QA Automation Engineer',
      date: '2026-10-01',
      checkIn: '09:14 AM',
      checkOut: '06:15 PM',
      workingHours: '9h 01m',
      status: 'On Time',
      statusType: 'PRESENT',
      remarks: 'Regular attendance recorded',
      history: [
        { date: '2026-09-30', checkIn: '09:10 AM', checkOut: '06:15 PM', status: 'On Time', hours: '9h 05m' },
      ],
    },
    {
      id: 'ATT-006',
      employeeId: 'EMP-006',
      employeeCode: 'SN-1006',
      fullName: 'Ananya Ramesh',
      department: 'Marketing & Sales',
      designation: 'Growth Marketing Manager',
      date: '2026-10-01',
      checkIn: '--',
      checkOut: '--',
      workingHours: '0h 00m',
      status: 'Absence',
      statusType: 'ABSENT',
      remarks: 'Uninformed absence - follow up needed',
      history: [
        { date: '2026-09-30', checkIn: '09:12 AM', checkOut: '06:00 PM', status: 'On Time', hours: '8h 48m' },
      ],
    },
    {
      id: 'ATT-007',
      employeeId: 'EMP-007',
      employeeCode: 'SN-1007',
      fullName: 'Vijay Narayanan',
      department: 'Operations',
      designation: 'Operations Coordinator',
      date: '2026-10-01',
      checkIn: '09:08 AM',
      checkOut: '06:05 PM',
      workingHours: '8h 57m',
      status: 'On Time',
      statusType: 'PRESENT',
      remarks: 'Floor audit completed on schedule',
      history: [
        { date: '2026-09-30', checkIn: '09:05 AM', checkOut: '06:10 PM', status: 'On Time', hours: '9h 05m' },
      ],
    },
    {
      id: 'ATT-008',
      employeeId: 'EMP-008',
      employeeCode: 'SN-1008',
      fullName: 'Meera Krishnan',
      department: 'Finance & Accounts',
      designation: 'Accounts Executive',
      date: '2026-10-01',
      checkIn: '08:58 AM',
      checkOut: '06:02 PM',
      workingHours: '9h 04m',
      status: 'On Time',
      statusType: 'PRESENT',
      remarks: 'Month-end reconciliation active',
      history: [
        { date: '2026-09-30', checkIn: '09:00 AM', checkOut: '06:00 PM', status: 'On Time', hours: '9h 00m' },
      ],
    },
    {
      id: 'ATT-009',
      employeeId: 'EMP-009',
      employeeCode: 'SN-1009',
      fullName: 'Gokul Chandran',
      department: 'Engineering',
      designation: 'Junior Frontend Developer',
      date: '2026-10-01',
      checkIn: '09:15 AM',
      checkOut: '01:30 PM',
      workingHours: '4h 15m',
      status: 'Half Day',
      statusType: 'HALF_DAY',
      remarks: 'Approved half-day medical appointment',
      history: [
        { date: '2026-09-30', checkIn: '09:15 AM', checkOut: '06:20 PM', status: 'On Time', hours: '9h 05m' },
      ],
    },
    {
      id: 'ATT-010',
      employeeId: 'EMP-010',
      employeeCode: 'SN-1010',
      fullName: 'Swetha Venkat',
      department: 'Product & Design',
      designation: 'Associate Product Designer',
      date: '2026-10-01',
      checkIn: '--',
      checkOut: '--',
      workingHours: '0h 00m',
      status: 'On Leave',
      statusType: 'LEAVE',
      remarks: 'Casual leave approved (Family function)',
      history: [
        { date: '2026-09-30', checkIn: '--', checkOut: '--', status: 'On Leave', hours: '0h 00m' },
      ],
    },
  ],

  // Payroll Lifecycle Calendar
  payrollCalendar: [
    {
      id: 'CYC-2026-10',
      period: 'October 2026',
      monthYear: '2026-10',
      processingDate: '2026-10-28',
      approvalDate: '2026-10-30',
      paymentDate: '2026-11-01',
      status: 'In Progress',
      totalEmployees: 9,
      estimatedPayroll: 456200,
      nextPaymentDays: 'In 31 Days',
      paymentAccount: 'HDFC Corporate Current A/C (...8892)',
      bankConnection: 'Active (Direct NEFT/RTGS Gateway)',
      payslipGeneration: 'Queued (Auto on Payment)',
      taxDeduction: 'Estimated TDS ₹18,400',
    },
    {
      id: 'CYC-2026-09',
      period: 'September 2026',
      monthYear: '2026-09',
      processingDate: '2026-09-28',
      approvalDate: '2026-09-29',
      paymentDate: '2026-10-01',
      status: 'Completed',
      totalEmployees: 9,
      estimatedPayroll: 456200,
      nextPaymentDays: 'Paid Today',
      paymentAccount: 'HDFC Corporate Current A/C (...8892)',
      bankConnection: 'Active (Direct NEFT/RTGS Gateway)',
      payslipGeneration: '9/9 Generated',
      taxDeduction: 'TDS Deposited ₹18,400',
    },
    {
      id: 'CYC-2026-08',
      period: 'August 2026',
      monthYear: '2026-08',
      processingDate: '2026-08-28',
      approvalDate: '2026-08-29',
      paymentDate: '2026-09-01',
      status: 'Completed',
      totalEmployees: 9,
      estimatedPayroll: 452800,
      nextPaymentDays: 'Completed',
      paymentAccount: 'HDFC Corporate Current A/C (...8892)',
      bankConnection: 'Active',
      payslipGeneration: 'Completed',
      taxDeduction: 'Complied',
    },
    {
      id: 'CYC-2026-11',
      period: 'November 2026',
      monthYear: '2026-11',
      processingDate: '2026-11-27',
      approvalDate: '2026-11-29',
      paymentDate: '2026-12-01',
      status: 'Pending',
      totalEmployees: 9,
      estimatedPayroll: 456200,
      nextPaymentDays: 'In 61 Days',
      paymentAccount: 'HDFC Corporate Current A/C (...8892)',
      bankConnection: 'Active',
      payslipGeneration: 'Scheduled',
      taxDeduction: 'Scheduled',
    },
  ],

  // Requests & Approvals
  requests: [
    {
      id: 'REQ-101',
      employeeId: 'EMP-003',
      employeeName: 'Rajesh Kannan',
      employeeCode: 'SN-1003',
      department: 'Engineering',
      type: 'Leave',
      subType: 'Casual Leave (CL)',
      dates: '05 Oct 2026 - 06 Oct 2026 (2 Days)',
      reason: 'Attending cousin wedding in Madurai. Handover given to Suresh.',
      submittedAt: 'Today, 08:30 AM',
      status: 'Pending',
      balance: '12 CL left',
      managerNotes: 'Recommended by Team Lead.',
    },
    {
      id: 'REQ-102',
      employeeId: 'EMP-004',
      employeeName: 'Deepika Sundaram',
      employeeCode: 'SN-1004',
      department: 'Product & Design',
      type: 'Work From Home',
      subType: 'Remote Work',
      dates: '03 Oct 2026 (1 Day)',
      reason: 'Home internet fiber maintenance scheduled by broadband provider.',
      submittedAt: 'Yesterday, 04:15 PM',
      status: 'Approved',
      balance: 'Available quota: 3 WFH/month',
      managerNotes: 'Approved for design sprint delivery.',
    },
    {
      id: 'REQ-103',
      employeeId: 'EMP-007',
      employeeName: 'Vijay Narayanan',
      employeeCode: 'SN-1007',
      department: 'Operations',
      type: 'On-Duty',
      subType: 'Client Site Visit',
      dates: '02 Oct 2026 (Full Day)',
      reason: 'On-site equipment check and hardware vendor meeting in Guindy industrial park.',
      submittedAt: 'Yesterday, 02:40 PM',
      status: 'Pending',
      balance: 'OD Allowance: 5 days/mo',
      managerNotes: 'Meeting with external logistics vendor confirmed.',
    },
    {
      id: 'REQ-104',
      employeeId: 'EMP-009',
      employeeName: 'Gokul Chandran',
      employeeCode: 'SN-1009',
      department: 'Engineering',
      type: 'Attendance Correction',
      subType: 'Punch In Missing',
      dates: '29 Sep 2026',
      reason: 'Biometric reader timeout during morning peak rush. Checked in at 09:10 AM with receptionist manual log.',
      submittedAt: '30 Sep 2026, 10:00 AM',
      status: 'Approved',
      balance: 'N/A',
      managerNotes: 'Verified with CCTV reception register.',
    },
    {
      id: 'REQ-105',
      employeeId: 'EMP-005',
      employeeName: 'Karthik Subramanian',
      employeeCode: 'SN-1005',
      department: 'Quality Assurance',
      type: 'Permission',
      subType: 'Early Exit Permission',
      dates: '01 Oct 2026 (04:30 PM - 06:30 PM)',
      reason: 'Need to visit school parent-teacher meeting for child.',
      submittedAt: 'Today, 09:20 AM',
      status: 'Pending',
      balance: 'Remaining permissions: 2 hrs',
      managerNotes: 'Task handover ready.',
    },
    {
      id: 'REQ-106',
      employeeId: 'EMP-006',
      employeeName: 'Ananya Ramesh',
      employeeCode: 'SN-1006',
      department: 'Marketing & Sales',
      type: 'Leave',
      subType: 'Sick Leave (SL)',
      dates: '24 Sep 2026 (1 Day)',
      reason: 'Fever and viral cold. Medical certificate attached.',
      submittedAt: '24 Sep 2026, 08:00 AM',
      status: 'Approved',
      balance: '10 SL left',
      managerNotes: 'Approved with medical prescription.',
    },
    {
      id: 'REQ-107',
      employeeId: 'EMP-001',
      employeeName: 'Suresh Kumar',
      employeeCode: 'SN-1001',
      department: 'Engineering',
      type: 'Leave',
      subType: 'Privilege Leave (PL)',
      dates: '12 Sep 2026 (1 Day)',
      reason: 'Personal registration work at sub-registrar office.',
      submittedAt: '10 Sep 2026, 11:30 AM',
      status: 'Rejected',
      balance: '15 PL left',
      managerNotes: 'Critical client milestone was scheduled on this date.',
    },
  ],

  // Tax & Compliance Records
  taxCompliance: [
    {
      id: 'TAX-001',
      employeeId: 'EMP-001',
      employeeName: 'Suresh Kumar',
      employeeCode: 'SN-1001',
      salary: 100000,
      taxType: 'TDS (Section 192)',
      deductionAmount: 7500,
      filingStatus: 'Paid',
      dueDate: '2026-10-07',
      challanNo: 'CHL-HDFC-9921',
      pan: 'ABCPS1234F',
    },
    {
      id: 'TAX-002',
      employeeId: 'EMP-002',
      employeeName: 'Priya Mohan',
      employeeCode: 'SN-1002',
      salary: 64000,
      taxType: 'Provident Fund (EPF)',
      deductionAmount: 3600,
      filingStatus: 'Paid',
      dueDate: '2026-10-15',
      challanNo: 'ECR-EPFO-7782',
      pan: 'BMOPM4321K',
    },
    {
      id: 'TAX-003',
      employeeId: 'EMP-003',
      employeeName: 'Rajesh Kannan',
      employeeCode: 'SN-1003',
      salary: 74000,
      taxType: 'TDS (Section 192)',
      deductionAmount: 4200,
      filingStatus: 'Paid',
      dueDate: '2026-10-07',
      challanNo: 'CHL-HDFC-9922',
      pan: 'CRKPK9876Q',
    },
    {
      id: 'TAX-004',
      employeeId: 'EMP-004',
      employeeName: 'Deepika Sundaram',
      employeeCode: 'SN-1004',
      salary: 70000,
      taxType: 'Employees State Insurance (ESIC)',
      deductionAmount: 1360,
      filingStatus: 'Pending',
      dueDate: '2026-10-15',
      challanNo: 'Pending Challan Gen',
      pan: 'DPSDK5512L',
    },
    {
      id: 'TAX-005',
      employeeId: 'EMP-005',
      employeeName: 'Karthik Subramanian',
      employeeCode: 'SN-1005',
      salary: 54500,
      taxType: 'Professional Tax (PT)',
      deductionAmount: 1250,
      filingStatus: 'Paid',
      dueDate: '2026-10-10',
      challanNo: 'CHN-CORP-4401',
      pan: 'SKPKS8842T',
    },
    {
      id: 'TAX-006',
      employeeId: 'EMP-006',
      employeeName: 'Ananya Ramesh',
      employeeCode: 'SN-1006',
      salary: 61000,
      taxType: 'Provident Fund (EPF)',
      deductionAmount: 3600,
      filingStatus: 'Paid',
      dueDate: '2026-10-15',
      challanNo: 'ECR-EPFO-7783',
      pan: 'ARPAR2291M',
    },
    {
      id: 'TAX-007',
      employeeId: 'EMP-007',
      employeeName: 'Vijay Narayanan',
      employeeCode: 'SN-1007',
      salary: 47500,
      taxType: 'Employees State Insurance (ESIC)',
      deductionAmount: 1080,
      filingStatus: 'Overdue',
      dueDate: '2026-09-25',
      challanNo: 'Overdue Penal Notice',
      pan: 'VNPVN6631R',
    },
    {
      id: 'TAX-008',
      employeeId: 'EMP-008',
      employeeName: 'Meera Krishnan',
      employeeCode: 'SN-1008',
      salary: 50500,
      taxType: 'Professional Tax (PT)',
      deductionAmount: 1250,
      filingStatus: 'Paid',
      dueDate: '2026-10-10',
      challanNo: 'CHN-CORP-4402',
      pan: 'MKPMK7712E',
    },
  ],

  // Company Holiday Calendar
  holidays: [
    { id: 'HOL-01', name: 'Gandhi Jayanti', date: '2026-10-02', day: 'Friday', type: 'Mandatory', description: 'National Holiday' },
    { id: 'HOL-02', name: 'Ayudha Pooja / Vijaya Dasami', date: '2026-10-20', day: 'Tuesday', type: 'Mandatory', description: 'Festive Holiday' },
    { id: 'HOL-03', name: 'Deepavali', date: '2026-11-08', day: 'Sunday', type: 'Mandatory', description: 'Festival of Lights' },
    { id: 'HOL-04', name: 'Christmas Day', date: '2026-12-25', day: 'Friday', type: 'Mandatory', description: 'Christmas Celebration' },
    { id: 'HOL-05', name: 'New Year Day', date: '2027-01-01', day: 'Friday', type: 'Mandatory', description: 'New Year Kickoff' },
    { id: 'HOL-06', name: 'Pongal / Makar Sankranti', date: '2027-01-14', day: 'Thursday', type: 'Mandatory', description: 'Harvest Festival' },
    { id: 'HOL-07', name: 'Republic Day', date: '2027-01-26', day: 'Tuesday', type: 'Mandatory', description: 'National Holiday' },
    { id: 'HOL-08', name: 'Annual Founder Day', date: '2027-02-18', day: 'Thursday', type: 'Optional', description: 'Saishnaa Corporate Foundation' },
  ],

  // System and Admin Settings
  settings: {
    adminName: 'Sathish Kumar',
    adminEmail: 'admin@saishnaa.com',
    adminPhone: '+91 98400 11223',
    adminDesignation: 'System Super Administrator',
    adminDepartment: 'Administration',
    adminPhoto: '',
    companyName: 'Saishnaa',
    companySubtitle: 'Software Solutions Private Limited',
    companyTagline: 'Empowering Bright Futures.',
    companyAddress: 'Tek Meadows, OMR, Sholinganallur, Chennai - 600119',
    companyGst: '33AAECS9182K1Z8',
    companyPan: 'AAECS9182K',
    companyPhone: '+91 44 4890 2200',
    emailAlertsEnabled: true,
    attendanceDailyDigest: true,
    payrollCutoffAlert: true,
    autoApproveWFH: false,
    security2FA: false,
  },

  // Assigned Tasks & Status Tracking
  tasks: [
    {
      id: 'TSK-101',
      taskCode: 'TASK-1001',
      title: 'Migrate Database to PostgreSQL 16',
      description: 'Execute schema migrations, optimize primary indexes, and perform connection pooling benchmark.',
      assignedToId: 'EMP-001',
      assignedToName: 'Suresh Kumar',
      department: 'Engineering',
      priority: 'High',
      status: 'In Progress',
      dueDate: '2026-10-15',
      assignedDate: '2026-10-01',
      estimatedHours: 16,
      completedHours: 8,
      tags: ['Database', 'PostgreSQL', 'Architecture'],
      notes: 'Ensure rollback scripts are tested before the scheduled maintenance window.'
    },
    {
      id: 'TSK-102',
      taskCode: 'TASK-1002',
      title: 'Quarterly Appraisal Cycle & Self-Evaluation Rollout',
      description: 'Collect employee self-evaluations, schedule manager 1-on-1 reviews, and calibrate ratings.',
      assignedToId: 'EMP-002',
      assignedToName: 'Priya Mohan',
      department: 'Human Resources',
      priority: 'Medium',
      status: 'In Progress',
      dueDate: '2026-10-20',
      assignedDate: '2026-10-01',
      estimatedHours: 24,
      completedHours: 14,
      tags: ['HR', 'Appraisal', 'Q3'],
      notes: 'Coordinate with department leads regarding band distribution.'
    },
    {
      id: 'TSK-103',
      taskCode: 'TASK-1003',
      title: 'Biometric Attendance Device Webhook Integration',
      description: 'Connect hardware biometric devices to automatic attendance sync daemon with retry queues.',
      assignedToId: 'EMP-003',
      assignedToName: 'Rajesh Kannan',
      department: 'Engineering',
      priority: 'High',
      status: 'Pending',
      dueDate: '2026-10-08',
      assignedDate: '2026-10-01',
      estimatedHours: 12,
      completedHours: 0,
      tags: ['Biometric', 'API', 'Webhook'],
      notes: 'Hardware vendor SDK v4.2 testing on staging instance first.'
    },
    {
      id: 'TSK-104',
      taskCode: 'TASK-1004',
      title: 'Client Demo Wireframes & Interactive Prototype',
      description: 'Design mobile and desktop dashboard flows for the incoming fintech enterprise client.',
      assignedToId: 'EMP-004',
      assignedToName: 'Ananya Sharma',
      department: 'Design',
      priority: 'High',
      status: 'Completed',
      dueDate: '2026-10-05',
      assignedDate: '2026-09-28',
      estimatedHours: 20,
      completedHours: 20,
      tags: ['Figma', 'UI/UX', 'Prototype'],
      notes: 'Client approved initial screens. Exported high-res spec for dev handoff.'
    },
    {
      id: 'TSK-105',
      taskCode: 'TASK-1005',
      title: 'FY2026 Q3 GST & Tax Compliance Filing Audit',
      description: 'Verify all purchase and sales invoices against GSTR-2B and ensure challans are cleared.',
      assignedToId: 'EMP-005',
      assignedToName: 'Karthik Venkat',
      department: 'Finance',
      priority: 'Medium',
      status: 'In Review',
      dueDate: '2026-10-18',
      assignedDate: '2026-10-01',
      estimatedHours: 18,
      completedHours: 15,
      tags: ['Finance', 'Tax', 'Audit'],
      notes: 'Submitted draft computation to CA for final verification.'
    },
    {
      id: 'TSK-106',
      taskCode: 'TASK-1006',
      title: 'Automated CI/CD Kubernetes Deployment Pipeline',
      description: 'Configure GitHub Actions workflow with Docker image build, scan, and Helm release.',
      assignedToId: 'EMP-006',
      assignedToName: 'Deepa Sundaram',
      department: 'Engineering',
      priority: 'Medium',
      status: 'In Progress',
      dueDate: '2026-10-25',
      assignedDate: '2026-10-02',
      estimatedHours: 16,
      completedHours: 6,
      tags: ['DevOps', 'CI/CD', 'Kubernetes'],
      notes: 'Using ArgoCD for GitOps synchronization.'
    },
    {
      id: 'TSK-107',
      taskCode: 'TASK-1007',
      title: 'Corporate Security Audit & Pen-Testing Remediation',
      description: 'Address finding in annual ISO 27001 vulnerability scan regarding session timeouts.',
      assignedToId: 'EMP-007',
      assignedToName: 'Vijay Narayanan',
      department: 'Operations',
      priority: 'Low',
      status: 'Pending',
      dueDate: '2026-10-30',
      assignedDate: '2026-10-02',
      estimatedHours: 10,
      completedHours: 0,
      tags: ['Security', 'Compliance', 'Audit'],
      notes: 'Scheduled call with external auditor on Friday.'
    },
    {
      id: 'TSK-108',
      taskCode: 'TASK-1008',
      title: 'Product Feature Backlog Prioritization Survey',
      description: 'Synthesize feedback from top enterprise accounts and prepare feature backlog ranking.',
      assignedToId: 'EMP-008',
      assignedToName: 'Meera Krishnan',
      department: 'Product',
      priority: 'Medium',
      status: 'Completed',
      dueDate: '2026-10-03',
      assignedDate: '2026-09-25',
      estimatedHours: 15,
      completedHours: 15,
      tags: ['Product', 'Roadmap', 'Survey'],
      notes: 'Executive presentation deck completed and sent to stakeholders.'
    }
  ],
};

const INITIAL_DATA = {
  ...DEMO_DATA,
  employees: [],
  attendance: [],
  payrollCalendar: [],
  requests: [],
  taxCompliance: [],
  holidays: [],
  tasks: [],
};

class AdminStore {
  constructor() {
    this.data = this.loadData();
  }

  loadData() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        const rawEmployees = parsed.employees ?? INITIAL_DATA.employees;
        const normalizedEmployees = rawEmployees.map((e) => ({
          ...e,
          password: e.password || 'Emp@Saishnaa2026!',
          role: e.role || (e.department === 'Human Resources' ? 'HR' : 'EMPLOYEE'),
          accountStatus: e.status === 'Active' ? 'ACTIVE' : 'INACTIVE',
        }));

        return {
          ...INITIAL_DATA,
          ...parsed,
          employees: normalizedEmployees,
          attendance: parsed.attendance ?? INITIAL_DATA.attendance,
          payrollCalendar: parsed.payrollCalendar ?? INITIAL_DATA.payrollCalendar,
          tasks: parsed.tasks ?? INITIAL_DATA.tasks,
          requests: parsed.requests ?? INITIAL_DATA.requests,
          taxCompliance: parsed.taxCompliance ?? INITIAL_DATA.taxCompliance,
          holidays: parsed.holidays ?? INITIAL_DATA.holidays,
          settings: { ...INITIAL_DATA.settings, ...(parsed.settings || {}) },
        };
      }
    } catch (err) {
      console.warn('Failed to parse admin persistent store:', err);
    }
    let legacySettings = {};
    let hasLegacyStorage = false;
    for (const legacyStorageKey of LEGACY_STORAGE_KEYS) {
      const legacyStored = localStorage.getItem(legacyStorageKey);
      if (!legacyStored) continue;
      hasLegacyStorage = true;
      try {
        Object.assign(legacySettings, JSON.parse(legacyStored).settings || {});
      } catch (err) {
        console.warn('Failed to read saved administrator settings during clean start:', err);
      }
    }
    const retainedSettings = { ...legacySettings };
    delete retainedSettings.workStartTime;
    delete retainedSettings.workEndTime;
    delete retainedSettings.gracePeriodMinutes;
    delete retainedSettings.halfDayHoursThreshold;
    const cleanData = {
      ...INITIAL_DATA,
      settings: { ...INITIAL_DATA.settings, ...retainedSettings },
    };
    if (this.persist(cleanData) && hasLegacyStorage) {
      LEGACY_STORAGE_KEYS.forEach((legacyStorageKey) => localStorage.removeItem(legacyStorageKey));
    }
    return JSON.parse(JSON.stringify(cleanData));
  }

  persist(newData) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
      // Notify any listeners across tabs or components
      window.dispatchEvent(new CustomEvent('saishnaa_store_updated', { detail: newData }));
      return true;
    } catch (err) {
      console.error('Failed to write to localStorage:', err);
      return false;
    }
  }

  save() {
    this.persist(this.data);
  }

  /* ------------------- AUTHENTICATION ------------------- */
  authenticate(identifier, password) {
    if (!identifier || !password) return null;
    const cleanId = identifier.trim().toLowerCase();
    const cleanIdUpper = identifier.trim().toUpperCase();
    const cleanPass = password.trim();

    // 1. Admin Login verification
    const isAdminId =
      cleanId === 'admin@saishnaa.com' ||
      cleanId === 'admin' ||
      cleanIdUpper === 'ADMIN-01' ||
      cleanIdUpper === 'EMP001';

    if (isAdminId) {
      if (
        cleanPass === 'Admin@Saishnaa2026!'
      ) {
        return {
          id: 'admin-01',
          email: 'admin@saishnaa.com',
          role: 'ADMIN',
          accountStatus: 'ACTIVE',
          employee: {
            id: 'EMP-001',
            employeeCode: 'ADMIN-01',
            fullName: 'Sathish Kumar',
            email: 'admin@saishnaa.com',
            department: 'Management',
            designation: 'Super Administrator',
            basicSalary: 85000,
          },
        };
      } else {
        const err = new Error('Incorrect password for Administrator account.');
        err.status = 401;
        throw err;
      }
    }

    // 2. Search in registered employees (by email, employee code, or id)
    const emp = this.data.employees.find(
      (e) =>
        (e.email && e.email.trim().toLowerCase() === cleanId) ||
        (e.employeeCode && e.employeeCode.trim().toUpperCase() === cleanIdUpper) ||
        (e.id && e.id.trim().toUpperCase() === cleanIdUpper)
    );

    if (!emp) {
      return null;
    }

    if (emp.status === 'Inactive' || emp.accountStatus === 'INACTIVE') {
      const err = new Error(`Account for ${emp.fullName} (${emp.employeeCode}) is currently Inactive. Please contact your Administrator.`);
      err.status = 403;
      throw err;
    }

    // Password verification: matches custom employee password, default password, or generic dev passwords
    const validPassword = emp.password || '';
    const isPasswordValid =
      cleanPass === validPassword ||
      cleanPass === 'Emp@Saishnaa2026!' ||
      cleanPass === 'password123' ||
      cleanPass === 'Password@123';

    if (!isPasswordValid) {
      const err = new Error(`Incorrect password for ${emp.fullName} (${emp.employeeCode}). Please check your password or use default Emp@Saishnaa2026!`);
      err.status = 401;
      throw err;
    }

    // Update lastLogin timestamp in employee record
    emp.lastLogin = 'Today, ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    this.save();

    return {
      id: emp.id,
      email: emp.email,
      role: emp.role || (emp.department === 'Human Resources' ? 'HR' : 'EMPLOYEE'),
      accountStatus: 'ACTIVE',
      employee: {
        id: emp.id,
        employeeCode: emp.employeeCode,
        fullName: emp.fullName,
        email: emp.email,
        phone: emp.phone,
        department: emp.department,
        designation: emp.designation,
        basicSalary: emp.basicSalary,
        joiningDate: emp.joiningDate,
        employmentType: emp.employmentType,
        avatar: emp.avatar,
        status: emp.status,
      },
    };
  }

  /* ------------------- EMPLOYEES ------------------- */
  getEmployees() {
    return [...this.data.employees];
  }

  getEmployeeById(id) {
    return this.data.employees.find((e) => e.id === id || e.employeeCode === id);
  }

  addEmployee(empData) {
    const nextCodeNumber = this.data.employees.length + 1001;
    const newEmp = {
      id: `EMP-${String(this.data.employees.length + 1).padStart(3, '0')}`,
      employeeCode: empData.employeeCode || `SN-${nextCodeNumber}`,
      fullName: empData.fullName || 'New Employee',
      email: empData.email || `emp${nextCodeNumber}@saishnaa.com`,
      phone: empData.phone || '',
      department: empData.department || 'Engineering',
      designation: empData.designation || 'Specialist',
      joiningDate: empData.joiningDate || new Date().toISOString().split('T')[0],
      employmentType: empData.employmentType || 'Full Time',
      status: empData.status || 'Active',
      basicSalary: Number(empData.basicSalary) || 0,
      hra: Number(empData.hra) || 0,
      allowances: Number(empData.allowances) || 0,
      bonus: Number(empData.bonus) || 0,
      pf: Number(empData.pf) || 0,
      esi: Number(empData.esi) || 0,
      otherDeductions: Number(empData.otherDeductions) || 0,
      bankName: empData.bankName || '',
      bankAccountNumber: empData.bankAccountNumber || '',
      ifscCode: empData.ifscCode || '',
      lastLogin: 'Never logged in',
      avatar: (empData.fullName || 'NE')
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2),
      presenceRate: 0,
      leavesTaken: 0,
      leavesRemaining: 0,
      gender: empData.gender || '',
      address: empData.address || '',
      // Portal Authentication Credentials:
      password: empData.password || '',
      role: empData.role || (empData.department === 'Human Resources' ? 'HR' : 'EMPLOYEE'),
      accountStatus: empData.status === 'Active' ? 'ACTIVE' : 'INACTIVE',
    };

    this.data.employees.unshift(newEmp);

    this.save();
    return newEmp;
  }

  updateEmployee(id, updates) {
    const idx = this.data.employees.findIndex((e) => e.id === id || e.employeeCode === id);
    if (idx !== -1) {
      this.data.employees[idx] = {
        ...this.data.employees[idx],
        ...updates,
        basicSalary: Number(updates.basicSalary ?? this.data.employees[idx].basicSalary),
        hra: Number(updates.hra ?? this.data.employees[idx].hra),
        allowances: Number(updates.allowances ?? this.data.employees[idx].allowances),
        bonus: Number(updates.bonus ?? this.data.employees[idx].bonus),
      };

      // Sync name / dept in attendance and requests
      const updated = this.data.employees[idx];
      this.data.attendance.forEach((att) => {
        if (att.employeeId === updated.id || att.employeeCode === updated.employeeCode) {
          att.fullName = updated.fullName;
          att.department = updated.department;
          att.designation = updated.designation;
        }
      });

      this.save();
      return this.data.employees[idx];
    }
    return null;
  }

  deleteEmployee(id) {
    this.data.employees = this.data.employees.filter((e) => e.id !== id && e.employeeCode !== id);
    this.data.attendance = this.data.attendance.filter((a) => a.employeeId !== id);
    this.save();
    return true;
  }

  /* ------------------- ATTENDANCE ------------------- */
  getAttendance(date) {
    if (!date) return [...this.data.attendance];
    return this.data.attendance.filter((a) => a.date === date);
  }

  addAttendance(record) {
    const employee = this.getEmployeeById(record.employeeId);
    if (!employee) return null;
    if (this.data.attendance.some((item) => item.employeeId === employee.id && item.date === record.date)) {
      return null;
    }

    const newRecord = {
      id: `ATT-${Date.now()}`,
      employeeId: employee.id,
      employeeCode: employee.employeeCode,
      fullName: employee.fullName,
      department: employee.department,
      designation: employee.designation,
      date: record.date,
      checkIn: record.checkIn || '',
      checkOut: record.checkOut || '',
      workingHours: '',
      status: record.status,
      statusType: record.status === 'Present' ? 'PRESENT' : record.status.toUpperCase().replaceAll(' ', '_'),
      remarks: record.remarks || '',
      history: [],
    };
    this.data.attendance.unshift(newRecord);
    return this.updateAttendance(newRecord.id, {
      checkIn: newRecord.checkIn,
      checkOut: newRecord.checkOut,
      status: newRecord.status,
      remarks: newRecord.remarks,
    });
  }

  updateAttendance(id, updates) {
    const idx = this.data.attendance.findIndex((a) => a.id === id);
    if (idx !== -1) {
      // Auto recalculate working hours if checkIn and checkOut exist
      let workingHours = this.data.attendance[idx].workingHours;
      if (updates.checkIn && updates.checkOut && updates.checkIn !== '--' && updates.checkOut !== '--') {
        try {
          const [inH, inM] = updates.checkIn.replace(/[^0-9:]/g, '').split(':').map(Number);
          const [outH, outM] = updates.checkOut.replace(/[^0-9:]/g, '').split(':').map(Number);
          if (!isNaN(inH) && !isNaN(outH)) {
            let totalMins = (outH * 60 + (outM || 0)) - (inH * 60 + (inM || 0));
            if (totalMins < 0) totalMins += 24 * 60; // next day wrap
            const h = Math.floor(totalMins / 60);
            const m = totalMins % 60;
            workingHours = `${h}h ${String(m).padStart(2, '0')}m`;
          }
        } catch (e) {
          // keep original
        }
      }

      this.data.attendance[idx] = {
        ...this.data.attendance[idx],
        ...updates,
        workingHours,
      };
      this.save();
      return this.data.attendance[idx];
    }
    return null;
  }

  /* ------------------- PAYROLL & PAYSLIPS ------------------- */
  getPayrollData() {
    // Computes payroll table derived from employees with calculation rules
    return this.data.employees.map((emp) => {
      const basic = Number(emp.basicSalary) || 0;
      const hra = Number(emp.hra) || 0;
      const allowances = Number(emp.allowances) || 0;
      const bonus = Number(emp.bonus) || 0;
      const pf = Number(emp.pf) || 0;
      const esi = Number(emp.esi) || 0;
      const otherDeductions = Number(emp.otherDeductions) || 0;

      const grossSalary = basic + hra + allowances + bonus;
      const totalDeductions = pf + esi + otherDeductions;
      const netSalary = grossSalary - totalDeductions;

      return {
        id: `PAY-${emp.id}`,
        employeeId: emp.id,
        employeeCode: emp.employeeCode,
        fullName: emp.fullName,
        position: emp.designation,
        department: emp.department,
        basicSalary: basic,
        hra,
        allowances,
        bonus,
        pf,
        esi,
        otherDeductions,
        grossSalary,
        totalDeductions,
        netSalary,
        paymentStatus: emp.paymentStatus || 'Pending',
        bankName: emp.bankName,
        bankAccountNumber: emp.bankAccountNumber,
        ifscCode: emp.ifscCode,
        paymentDate: emp.paymentDate || '',
      };
    });
  }

  processPayroll(all = true, targetEmpId = null) {
    this.data.employees = this.data.employees.map((emp) => {
      if (all || emp.id === targetEmpId) {
        return {
          ...emp,
          paymentStatus: 'Processed',
          paymentDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        };
      }
      return emp;
    });

    // Also mark active payroll calendar cycle as in progress or completed
    if (this.data.payrollCalendar.length > 0) {
      this.data.payrollCalendar[0].status = 'Completed';
      this.data.payrollCalendar[0].nextPaymentDays = 'Paid Today';
    }

    this.save();
    return true;
  }

  /* ------------------- PAYROLL CALENDAR ------------------- */
  getPayrollCalendar() {
    return [...this.data.payrollCalendar];
  }

  updateCycleStatus(id, newStatus) {
    const cycle = this.data.payrollCalendar.find((c) => c.id === id);
    if (cycle) {
      cycle.status = newStatus;
      this.save();
      return cycle;
    }
    return null;
  }

  /* ------------------- REQUESTS & APPROVALS ------------------- */
  getRequests() {
    return [...this.data.requests];
  }

  updateRequestStatus(id, newStatus, adminNotes = '') {
    const req = this.data.requests.find((r) => r.id === id);
    if (req) {
      req.status = newStatus;
      if (adminNotes) {
        req.managerNotes = adminNotes;
      }
      this.save();
      return req;
    }
    return null;
  }

  /* ------------------- TAX & COMPLIANCE ------------------- */
  getTaxCompliance() {
    return [...this.data.taxCompliance];
  }

  updateTaxStatus(id, newStatus) {
    const tax = this.data.taxCompliance.find((t) => t.id === id);
    if (tax) {
      tax.filingStatus = newStatus;
      if (newStatus === 'Paid') {
        tax.challanNo = `CHL-${Date.now().toString().slice(-6)}`;
      }
      this.save();
      return tax;
    }
    return null;
  }

  /* ------------------- HOLIDAYS ------------------- */
  getHolidays() {
    return [...this.data.holidays];
  }

  addHoliday(holiday) {
    const newHol = {
      id: `HOL-${Date.now()}`,
      name: holiday.name || 'Company Holiday',
      date: holiday.date || new Date().toISOString().split('T')[0],
      day: holiday.day || 'Monday',
      type: holiday.type || 'Mandatory',
      description: holiday.description || 'Declared company holiday',
    };
    this.data.holidays.push(newHol);
    this.save();
    return newHol;
  }

  updateHoliday(id, updates) {
    const idx = this.data.holidays.findIndex((h) => h.id === id);
    if (idx !== -1) {
      this.data.holidays[idx] = { ...this.data.holidays[idx], ...updates };
      this.save();
      return this.data.holidays[idx];
    }
    return null;
  }

  deleteHoliday(id) {
    this.data.holidays = this.data.holidays.filter((h) => h.id !== id);
    this.save();
    return true;
  }

  /* ------------------- TASKS & ASSIGNMENTS ------------------- */
  getTasks() {
    return [...(this.data.tasks || [])];
  }

  getTaskById(id) {
    return (this.data.tasks || []).find((t) => t.id === id) || null;
  }

  addTask(task) {
    if (!this.data.tasks) this.data.tasks = [];
    const count = this.data.tasks.length + 1;
    const newTask = {
      id: `TSK-${Date.now()}`,
      taskCode: `TASK-${1000 + count}`,
      title: task.title || 'Untitled Task',
      description: task.description || '',
      assignedToId: task.assignedToId || '',
      assignedToName: task.assignedToName || 'Unassigned',
      department: task.department || 'Operations',
      priority: task.priority || 'Medium',
      status: task.status || 'Pending',
      dueDate: task.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      assignedDate: task.assignedDate || new Date().toISOString().split('T')[0],
      estimatedHours: Number(task.estimatedHours || 8),
      completedHours: Number(task.completedHours || 0),
      tags: Array.isArray(task.tags) ? task.tags : (task.tags ? task.tags.split(',').map(s => s.trim()) : ['General']),
      notes: task.notes || '',
    };
    this.data.tasks.unshift(newTask);
    this.save();
    return newTask;
  }

  updateTask(id, updates) {
    if (!this.data.tasks) return null;
    const idx = this.data.tasks.findIndex((t) => t.id === id);
    if (idx !== -1) {
      this.data.tasks[idx] = { ...this.data.tasks[idx], ...updates };
      this.save();
      return this.data.tasks[idx];
    }
    return null;
  }

  updateTaskStatus(id, newStatus) {
    if (!this.data.tasks) return null;
    const task = this.data.tasks.find((t) => t.id === id);
    if (task) {
      task.status = newStatus;
      if (newStatus === 'Completed' && Number(task.completedHours) === 0) {
        task.completedHours = task.estimatedHours;
      }
      this.save();
      return task;
    }
    return null;
  }

  deleteTask(id) {
    if (!this.data.tasks) return false;
    this.data.tasks = this.data.tasks.filter((t) => t.id !== id);
    this.save();
    return true;
  }

  /* ------------------- SETTINGS ------------------- */
  getSettings() {
    return { ...this.data.settings };
  }

  updateSettings(updates) {
    this.data.settings = { ...this.data.settings, ...updates };
    this.save();
    window.dispatchEvent(new Event('saishnaa-settings-updated'));
    return { ...this.data.settings };
  }
}

// Global Singleton
export const adminStore = new AdminStore();
export default adminStore;
