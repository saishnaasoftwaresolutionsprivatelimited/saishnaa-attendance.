import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  FileEdit,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  X,
  History,
} from 'lucide-react';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(utc);
dayjs.extend(timezone);

const OFFICE_TIMEZONE = 'Asia/Kolkata';

function toOfficeTimestamp(attendanceDate, time) {
  return dayjs
    .tz(`${attendanceDate}T${time}:00`, OFFICE_TIMEZONE)
    .toISOString();
}

function formatOfficeTime(timestamp) {
  return dayjs(timestamp).tz(OFFICE_TIMEZONE).format('hh:mm A');
}

export default function ApplyCorrection() {
  const [corrections, setCorrections] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    attendanceDate: dayjs().subtract(1, 'day').format('YYYY-MM-DD'),
    correctionType: 'CHECK_IN',
    requestedCheckInTime: '09:00',
    requestedCheckOutTime: '18:00',
    reason: '',
  });

  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  useEffect(() => {
    fetchCorrections();
  }, []);

  async function fetchCorrections() {
    try {
      setLoading(true);
      const res = await api.get('/attendance/corrections/me');
      if (res.success) {
        setCorrections(res.data || []);
      }
    } catch (err) {
      console.error('Fetch corrections error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmitCorrection(e) {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');
    try {
      setFormLoading(true);

      const payload = {
        attendanceDate: formData.attendanceDate,
        correctionType: formData.correctionType,
        reason: formData.reason,
      };

      if (formData.correctionType === 'CHECK_IN' || formData.correctionType === 'BOTH') {
        payload.requestedCheckInAt = toOfficeTimestamp(
          formData.attendanceDate,
          formData.requestedCheckInTime
        );
      }
      if (formData.correctionType === 'CHECK_OUT' || formData.correctionType === 'BOTH') {
        payload.requestedCheckOutAt = toOfficeTimestamp(
          formData.attendanceDate,
          formData.requestedCheckOutTime
        );
      }

      const res = await api.post('/attendance/corrections', payload);
      if (res.success) {
        setFormSuccess('Correction request submitted successfully! Awaiting review.');
        setModalOpen(false);
        await fetchCorrections();
      }
    } catch (err) {
      setFormError(err.message || 'Failed to submit correction request.');
    } finally {
      setFormLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">
            Attendance Correction Requests
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Request rectifications for forgotten check-in/check-out punches or biometric browser glitches
          </p>
        </div>

        <button
          onClick={() => {
            setFormError('');
            setModalOpen(true);
          }}
          className="corp-btn-primary text-xs py-2.5 px-4"
        >
          <Plus className="w-4 h-4" />
          <span>Request Correction</span>
        </button>
      </div>

      {/* Submitted Corrections Table */}
      <div className="corp-card overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            My Submitted Punch Rectifications
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Attendance Date</th>
                <th className="py-3 px-4">Correction Type</th>
                <th className="py-3 px-4">Requested Punch</th>
                <th className="py-3 px-4">Reason</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Reviewer Remark</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Loading your correction requests...
                  </td>
                </tr>
              ) : corrections.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    No attendance correction requests submitted.
                  </td>
                </tr>
              ) : (
                corrections.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">
                      {dayjs(r.attendanceDate).format('DD MMM YYYY (ddd)')}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-700">
                      {r.correctionType.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-900">
                      {r.requestedCheckInAt && `In: ${formatOfficeTime(r.requestedCheckInAt)}`}
                      {r.requestedCheckInAt && r.requestedCheckOutAt && ' | '}
                      {r.requestedCheckOutAt && `Out: ${formatOfficeTime(r.requestedCheckOutAt)}`}
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate text-slate-600" title={r.reason}>
                      {r.reason}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`corp-badge ${
                          r.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px] italic">
                      {r.reviewerComments || '--'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-extrabold text-[#20266D]">
                  Request Attendance Correction
                </h3>
                <p className="text-xs text-slate-500">
                  Submit accurate punch times for HR and management review
                </p>
              </div>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmitCorrection} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Work Date
                  </label>
                  <input
                    type="date"
                    required
                    max={dayjs().format('YYYY-MM-DD')}
                    value={formData.attendanceDate}
                    onChange={(e) => setFormData({ ...formData, attendanceDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Correction Type
                  </label>
                  <select
                    value={formData.correctionType}
                    onChange={(e) => setFormData({ ...formData, correctionType: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  >
                    <option value="CHECK_IN">Missed Check-In Punch</option>
                    <option value="CHECK_OUT">Missed Check-Out Punch</option>
                    <option value="BOTH">Both Punches (Full Day)</option>
                  </select>
                </div>
              </div>

              {(formData.correctionType === 'CHECK_IN' || formData.correctionType === 'BOTH') && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Actual Check-In Time
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.requestedCheckInTime}
                    onChange={(e) => setFormData({ ...formData, requestedCheckInTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm font-mono"
                  />
                </div>
              )}

              {(formData.correctionType === 'CHECK_OUT' || formData.correctionType === 'BOTH') && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Actual Check-Out Time
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.requestedCheckOutTime}
                    onChange={(e) => setFormData({ ...formData, requestedCheckOutTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Reason for Rectification
                </label>
                <textarea
                  required
                  rows={3}
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="Provide detailed justification (e.g. client emergency call, power outage, technical glitch)..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button type="submit" disabled={formLoading} className="corp-btn-primary text-xs">
                  {formLoading ? 'Submitting...' : 'Submit Correction'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
