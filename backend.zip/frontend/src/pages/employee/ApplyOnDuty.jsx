import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  Briefcase,
  MapPin,
  Calendar,
  Clock,
  Send,
  CheckCircle2,
  AlertTriangle,
  History,
  Info,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function ApplyOnDuty() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [formData, setFormData] = useState({
    odDate: dayjs().format('YYYY-MM-DD'),
    startTime: '',
    endTime: '',
    location: '',
    purpose: '',
    description: '',
  });

  const purposes = [
    'Client Meetings',
    'Official Business Travel',
    'Company Projects',
    'Field Work',
    'Training Programs',
    'Official External Meetings',
    'Other Approved Company Work',
  ];

  useEffect(() => {
    fetchHistory();
  }, []);

  async function fetchHistory() {
    try {
      setLoading(true);
      const res = await api.get('/on-duty/me');
      if (res.success) {
        setHistory(res.data || []);
      }
    } catch (err) {
      console.error('Error fetching OD history:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    try {
      setSubmitting(true);
      const res = await api.post('/on-duty/apply', formData);
      if (res.success) {
        setSuccessMsg('On-Duty application submitted successfully for HR/Admin approval.');
        setFormData({
          odDate: dayjs().format('YYYY-MM-DD'),
          startTime: '',
          endTime: '',
          location: '',
          purpose: '',
          description: '',
        });
        await fetchHistory();
      }
    } catch (err) {
      setError(err.message || 'Failed to submit On-Duty request.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">On-Duty (OD) Management</h1>
          <p className="text-xs text-slate-500 mt-1">
            Apply for approved client visits, field assignments, official travel, or external conferences
          </p>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50/70 border border-blue-200/80 rounded-2xl p-4 flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#2563EB] flex items-center justify-center flex-shrink-0 mt-0.5">
          <Info className="w-4 h-4" />
        </div>
        <div className="text-xs text-blue-900 leading-relaxed">
          <strong>Official OD Policy:</strong> Approved full-day On-Duty counts as an authorized payable working day and will <strong>not consume your Casual Leave (CL) balance</strong>. Partial-day OD will be synthesized with your biometric office check-in.
        </div>
      </div>

      {/* Main Form and History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
            <Briefcase className="w-4 h-4 text-[#2563EB]" />
            New On-Duty Application
          </h2>

          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                On-Duty Date *
              </label>
              <input
                type="date"
                required
                value={formData.odDate}
                onChange={(e) => setFormData({ ...formData, odDate: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Start Time *
                </label>
                <input
                  type="time"
                  required
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  End Time *
                </label>
                <input
                  type="time"
                  required
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Purpose / Category *
              </label>
              <select
                required
                value={formData.purpose}
                onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none"
              >
                <option value="">Select a purpose</option>
                {purposes.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Destination / Client Location *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g. Client Office - Cyber Vale, Chennai"
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none"
                />
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Task Description & Expected Deliverables *
              </label>
              <textarea
                required
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Details of client meeting, system deployment, or official audit"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-[#20266D] to-[#2563EB] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg disabled:opacity-50 transition flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              {submitting ? 'Submitting Application...' : 'Submit On-Duty Request'}
            </button>
          </form>
        </div>

        {/* History Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
              <History className="w-4 h-4 text-emerald-500" />
              On-Duty Applications History
            </h2>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-6 h-6 border-2 border-[#2563EB] border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : history.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-xs">
                No On-Duty requests filed yet.
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {history.map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-800">
                        {dayjs(req.odDate).format('DD MMM YYYY (ddd)')}
                      </span>
                      <span
                        className={`corp-badge text-[10px] font-bold ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : req.status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 mt-1 font-medium">
                      {req.purpose} • <span className="text-slate-500">{req.location}</span>
                    </div>

                    <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                      <Clock className="w-3 h-3 text-[#2563EB]" />
                      <span>{req.startTime} - {req.endTime}</span>
                    </div>

                    <p className="text-xs text-slate-600 mt-2 italic bg-white p-2 rounded-lg border border-slate-100">
                      "{req.description}"
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
