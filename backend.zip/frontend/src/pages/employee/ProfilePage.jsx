import React, { useRef, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';
import {
  User,
  Lock,
  Camera,
  CheckCircle2,
  AlertCircle,
  Trash2,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const emp = user?.employee || {};
  const photoInputRef = useRef(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [photoLoading, setPhotoLoading] = useState(false);
  const [photoError, setPhotoError] = useState('');

  // Password rules
  const hasMin = newPassword.length >= 8;
  const hasUpper = /[A-Z]/.test(newPassword);
  const hasLower = /[a-z]/.test(newPassword);
  const hasNumber = /[0-9]/.test(newPassword);
  const hasSpecial = /[^A-Za-z0-9]/.test(newPassword);
  const passwordsMatch = newPassword && newPassword === confirmPassword;
  const isValid = hasMin && hasUpper && hasLower && hasNumber && hasSpecial && passwordsMatch;

  async function handleProfilePhotoChange(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    setPhotoError('');
    if (!file) return;

    const allowedTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      setPhotoError('Choose a PNG, JPEG, or WebP image.');
      return;
    }
    if (file.size > 1024 * 1024) {
      setPhotoError('Profile photos must be 1 MB or smaller.');
      return;
    }

    try {
      setPhotoLoading(true);
      const photoData = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') resolve(reader.result);
          else reject(new Error('Unable to read the selected photo.'));
        };
        reader.onerror = () => reject(new Error('Unable to read the selected photo.'));
        reader.readAsDataURL(file);
      });
      const response = await api.patch('/employees/me/profile-photo', { profilePhoto: photoData });
      if (!response.success) throw new Error(response.message || 'Unable to save profile photo.');
      await refreshUser();
    } catch (error) {
      setPhotoError(error.message || 'Unable to save profile photo.');
    } finally {
      setPhotoLoading(false);
    }
  }

  async function handleRemoveProfilePhoto() {
    setPhotoError('');
    try {
      setPhotoLoading(true);
      const response = await api.patch('/employees/me/profile-photo', { profilePhoto: null });
      if (!response.success) throw new Error(response.message || 'Unable to remove profile photo.');
      await refreshUser();
    } catch (error) {
      setPhotoError(error.message || 'Unable to remove profile photo.');
    } finally {
      setPhotoLoading(false);
    }
  }

  async function handleChangePassword(e) {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!passwordsMatch) {
      setErrorMsg('New passwords do not match.');
      return;
    }

    try {
      setLoading(true);
      const res = await api.post('/auth/change-password', {
        currentPassword,
        newPassword,
      });
      if (res.success) {
        setSuccessMsg('Your account password has been updated successfully!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      }
    } catch (err) {
      setErrorMsg(err.message || 'Failed to update password.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs">
        <h1 className="text-xl sm:text-2xl font-bold text-[#17324D] tracking-tight">
          My Profile & Account Security
        </h1>
        <p className="text-xs text-[#64748B] mt-1">
          Review your employment credentials and manage your account security credentials.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Personal & Employment Info */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-[#DCE7EC] shadow-xs p-6 border-t-4 border-t-[#183B56]">
            <div className="flex items-center gap-4 pb-6 border-b border-[#DCE7EC]">
              <div className="relative w-16 h-16 shrink-0">
                {emp.profilePhoto ? (
                  <img
                    src={emp.profilePhoto}
                    alt={`${emp.fullName || 'Employee'} profile`}
                    className="w-16 h-16 rounded-2xl object-cover border border-[#DCE7EC]"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-[#183B56] flex items-center justify-center text-white text-2xl font-bold shadow-xs">
                    {emp.fullName?.charAt(0) || user?.email?.charAt(0).toUpperCase()}
                  </div>
                )}
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleProfilePhotoChange}
                  className="hidden"
                  aria-label="Choose profile photo"
                />
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  disabled={photoLoading}
                  title="Upload profile photo"
                  aria-label="Upload profile photo"
                  className="absolute -right-2 -bottom-2 flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-[#018ABE] text-white shadow-sm hover:bg-[#087BA5] disabled:opacity-60"
                >
                  <Camera className="h-4 w-4" />
                </button>
              </div>
              <div>
                <h2 className="text-lg font-bold text-[#17324D]">{emp.fullName}</h2>
                <div className="text-xs text-[#64748B] font-mono mt-0.5">{emp.employeeCode}</div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#E6F7F6] text-[#159A93] border border-[#A2E3E0]">
                    {user?.role}
                  </span>
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#E8F8F5] text-[#159A73] border border-[#A3E5D4]">
                    {user?.accountStatus}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3 pt-3 text-[11px]">
              <span className="text-[#64748B]">PNG, JPEG, or WebP · Max 1 MB</span>
              {emp.profilePhoto && (
                <button
                  type="button"
                  onClick={handleRemoveProfilePhoto}
                  disabled={photoLoading}
                  className="inline-flex items-center gap-1 font-semibold text-[#64748B] hover:text-rose-600 disabled:opacity-60"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remove photo
                </button>
              )}
              {photoLoading && <span className="text-[#018ABE]">Saving photo…</span>}
              {photoError && <span role="alert" className="text-rose-600">{photoError}</span>}
            </div>

            {/* Employment Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6 text-xs">
              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Corporate Email
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">{emp.email || user?.email}</div>
              </div>

              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Mobile Phone
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">{emp.phone || '—'}</div>
              </div>

              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Department
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">{emp.department?.name || emp.department || 'Unassigned'}</div>
              </div>

              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Designation
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">{emp.designation?.title || emp.designation || 'Unassigned'}</div>
              </div>

              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Office Location
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">{emp.branch?.name || emp.branch || 'Chennai HQ'}</div>
              </div>

              <div className="p-3.5 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC]">
                <span className="text-[#64748B] font-semibold uppercase tracking-wider text-[10px] block">
                  Date of Joining
                </span>
                <div className="text-sm font-semibold text-[#17324D] mt-1">
                  {emp.joiningDate ? dayjs(emp.joiningDate).format('DD MMMM YYYY') : '—'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Change Password */}
        <div className="bg-white rounded-2xl border border-[#DCE7EC] shadow-xs p-6 border-t-4 border-t-[#159A93]">
          <h3 className="text-sm font-bold text-[#17324D] flex items-center gap-2 mb-1">
            <Lock className="w-4 h-4 text-[#159A93]" />
            Change Password
          </h3>
          <p className="text-xs text-[#64748B] mb-4">
            Protect your account credentials with Argon2id encryption.
          </p>

          {successMsg && (
            <div className="mb-4 p-3 rounded-xl bg-[#E8F8F5] text-[#159A73] text-xs border border-[#A3E5D4] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-[#FDF2E9] text-[#D95C64] text-xs border border-[#F5B7B1] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#17324D] mb-1">
                Current Password
              </label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter existing password"
                className="w-full px-3 py-2 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl text-xs font-medium text-[#17324D] focus:outline-none focus:ring-1 focus:ring-[#159A93]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#17324D] mb-1">
                New Password
              </label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new strong password"
                className="w-full px-3 py-2 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl text-xs font-medium text-[#17324D] focus:outline-none focus:ring-1 focus:ring-[#159A93]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#17324D] mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full px-3 py-2 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl text-xs font-medium text-[#17324D] focus:outline-none focus:ring-1 focus:ring-[#159A93]"
              />
            </div>

            <div className="bg-[#F4F8FA] p-3 rounded-xl border border-[#DCE7EC] space-y-1 text-[10px]">
              <div className={hasMin ? 'text-[#159A73] font-semibold' : 'text-[#64748B]'}>
                {hasMin ? '✓' : '○'} Minimum 8 characters
              </div>
              <div className={hasUpper && hasLower ? 'text-[#159A73] font-semibold' : 'text-[#64748B]'}>
                {hasUpper && hasLower ? '✓' : '○'} Upper & lower case
              </div>
              <div className={hasNumber && hasSpecial ? 'text-[#159A73] font-semibold' : 'text-[#64748B]'}>
                {hasNumber && hasSpecial ? '✓' : '○'} Number & symbol
              </div>
              <div className={passwordsMatch ? 'text-[#159A73] font-semibold' : 'text-[#64748B]'}>
                {passwordsMatch ? '✓' : '○'} Passwords match
              </div>
            </div>

            <button
              type="submit"
              disabled={!isValid || loading}
              className="w-full px-4 py-2.5 bg-[#183B56] hover:bg-[#245A78] text-white rounded-xl text-xs font-semibold disabled:opacity-50 transition-colors shadow-xs"
            >
              {loading ? 'Updating Password...' : 'Update Password'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
