import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  FileCheck2,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  X,
  XCircle,
  History,
  TrendingUp,
  Info,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function ApplyLeave() {
  const [types, setTypes] = useState([]);
  const [balances, setBalances] = useState([]);
  const [requests, setRequests] = useState([]);
  const [clLedger, setClLedger] = useState([]);
  const [loading, setLoading] = useState(true);

  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    leaveTypeId: '',
    startDate: dayjs().add(1, 'day').format('YYYY-MM-DD'),
    endDate: dayjs().add(1, 'day').format('YYYY-MM-DD'),
    daysCount: 1,
    isHalfDay: false,
    halfDayType: 'FIRST_HALF',
    reason: '',
  });

  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      const [typesRes, leavesRes] = await Promise.all([
        api.get('/leave/types'),
        api.get('/leave/me'),
      ]);

      if (typesRes.success) {
        setTypes(typesRes.data || []);
        if (typesRes.data?.[0]) {
          setFormData((prev) => ({ ...prev, leaveTypeId: typesRes.data[0].id }));
        }
      }

      if (leavesRes.success) {
        setRequests(leavesRes.data.requests || []);
        setBalances(leavesRes.data.balances || []);
        setClLedger(leavesRes.data.clLedger || []);
      }
    } catch (err) {
      console.error('Load leaves data error:', err);
    } finally {
      setLoading(false);
    }
  }

  // Calculate days difference automatically
  function handleDateChange(field, val) {
    const updated = { ...formData, [field]: val };
    if (updated.startDate && updated.endDate) {
      const diff = dayjs(updated.endDate).diff(dayjs(updated.startDate), 'day') + 1;
      updated.daysCount = Math.max(1, diff);
    }
    setFormData(updated);
  }

  async function handleApplyLeave(e) {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');
    try {
      setFormLoading(true);
      const res = await api.post('/leave', formData);
      if (res.success) {
        setFormSuccess('Leave application submitted successfully!');
        setModalOpen(false);
        await loadData();
      }
    } catch (err) {
      setFormError(err.message || 'Failed to submit leave application.');
    } finally {
      setFormLoading(false);
    }
  }

  async function handleCancelLeave(id) {
    if (!window.confirm('Are you sure you want to cancel this pending leave request?')) return;
    try {
      const res = await api.patch(`/leave/${id}/cancel`);
      if (res.success) {
        await loadData();
      }
    } catch (err) {
      alert(err.message || 'Failed to cancel leave.');
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">Leave Management</h1>
          <p className="text-xs text-slate-500 mt-1">
            Apply for planned time-off and track your remaining annual leave entitlement
          </p>
        </div>

        <button
          onClick={() => {
            setFormError('');
            setModalOpen(true);
          }}
          className="corp-btn-primary text-xs py-2.5 px-4"
        >
          <Plus className="w-4 h-4" />
          <span>Apply For Leave</span>
        </button>
      </div>

      {/* Quota Balances */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {balances.map((b) => (
          <div key={b.id} className="corp-card p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">{b.leaveType.name}</span>
              <span className="corp-badge bg-blue-50 text-blue-700 text-[10px] font-mono">
                {b.leaveType.code}
              </span>
            </div>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-900">{b.remainingDays}</span>
              <span className="text-xs text-slate-400">/ {b.totalAllocated} days</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">
              Used: {b.usedDays}d • Pending: {b.pendingDays}d
            </div>
          </div>
        ))}
      </div>

      {/* Casual Leave (CL) Monthly Carry-Forward Ledger */}
      <div className="corp-card overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <History className="w-4 h-4 text-[#2563EB]" />
              Casual Leave (CL) Monthly Carry-Forward Ledger
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Rule: 1.0 CL is credited on the 1st of each calendar month. Unused CL automatically carries forward without expiry.
            </p>
          </div>
          <span className="corp-badge bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
            Auto Carry-Forward Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-4">Month / Period</th>
                <th className="py-2.5 px-4 text-center">Opening Balance</th>
                <th className="py-2.5 px-4 text-center">Monthly Credit</th>
                <th className="py-2.5 px-4 text-center">Leaves Used</th>
                <th className="py-2.5 px-4 text-center">Carry-Forward Closing</th>
                <th className="py-2.5 px-4">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {clLedger.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-400 font-sans">
                    CL ledger active. Monthly carry-forwards will be recorded upon monthly payroll cycles.
                  </td>
                </tr>
              ) : (
                clLedger.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-slate-800 font-sans">
                      {dayjs(row.monthYear + '-01').format('MMMM YYYY')}
                    </td>
                    <td className="py-2.5 px-4 text-center text-slate-600 font-semibold">
                      {row.openingBalance}d
                    </td>
                    <td className="py-2.5 px-4 text-center text-emerald-600 font-bold">
                      +{row.creditedDays}d
                    </td>
                    <td className="py-2.5 px-4 text-center text-rose-600 font-semibold">
                      {row.usedDays > 0 ? `-${row.usedDays}d` : '0d'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-bold text-[#20266D]">
                      <span className="inline-block px-2 py-0.5 rounded-md bg-blue-50 text-[#2563EB] border border-blue-200">
                        {row.closingBalance}d
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-500 font-sans text-[11px]">
                      {row.remarks || 'Automated monthly carry forward'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* My Submitted Requests */}
      <div className="corp-card overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            My Submitted Leave Applications
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Leave Type</th>
                <th className="py-3 px-4">Dates</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4">Reason</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Loading your leave requests...
                  </td>
                </tr>
              ) : requests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    You have not applied for any leave requests yet.
                  </td>
                </tr>
              ) : (
                requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-800">{r.leaveType.name}</td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-700">
                      {dayjs(r.startDate).format('DD MMM')} to {dayjs(r.endDate).format('DD MMM YYYY')}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {r.daysCount} {r.daysCount === 1 ? 'day' : 'days'} {r.isHalfDay && '(Half Day)'}
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate text-slate-600" title={r.reason}>
                      {r.reason}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`corp-badge ${
                          r.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : r.status === 'CANCELLED'
                            ? 'bg-slate-100 text-slate-500 border border-slate-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {r.status === 'PENDING' && (
                        <button
                          onClick={() => handleCancelLeave(r.id)}
                          className="text-xs font-semibold text-rose-600 hover:text-rose-800 hover:underline"
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Apply Leave Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-extrabold text-[#20266D]">Apply for Leave</h3>
                <p className="text-xs text-slate-500">Submit formal time-off application for HR approval</p>
              </div>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {formError}
              </div>
            )}

            <form onSubmit={handleApplyLeave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Leave Type</label>
                <select
                  required
                  value={formData.leaveTypeId}
                  onChange={(e) => setFormData({ ...formData, leaveTypeId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                >
                  {types.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.code}) - Quota: {t.annualQuota} days
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={formData.startDate}
                    onChange={(e) => handleDateChange('startDate', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={formData.endDate}
                    onChange={(e) => handleDateChange('endDate', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.isHalfDay}
                    onChange={(e) =>
                      setFormData({ ...formData, isHalfDay: e.target.checked, daysCount: e.target.checked ? 0.5 : 1 })
                    }
                    className="rounded text-[#20266D]"
                  />
                  <span>Half-Day Leave</span>
                </label>

                {formData.isHalfDay && (
                  <select
                    value={formData.halfDayType}
                    onChange={(e) => setFormData({ ...formData, halfDayType: e.target.value })}
                    className="px-2 py-1 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="FIRST_HALF">First Half (Morning)</option>
                    <option value="SECOND_HALF">Second Half (Afternoon)</option>
                  </select>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Reason for Absence
                </label>
                <textarea
                  required
                  rows={3}
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="Explain the reason for requesting this leave..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button type="submit" disabled={formLoading} className="corp-btn-primary text-xs">
                  {formLoading ? 'Submitting...' : 'Submit Leave Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
