import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  FileCheck2,
  Clock,
  Briefcase,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Filter,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function ApplicationHistory() {
  const [tab, setTab] = useState('ALL'); // 'ALL' | 'LEAVE' | 'PERMISSION' | 'OD'
  const [leaves, setLeaves] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [odList, setOdList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAll();
  }, []);

  async function fetchAll() {
    try {
      setLoading(true);
      const [leaveRes, permRes, odRes] = await Promise.all([
        api.get('/leaves/my-leaves'),
        api.get('/permissions/me'),
        api.get('/on-duty/me'),
      ]);

      if (leaveRes.success) setLeaves(leaveRes.data || []);
      if (permRes.success) setPermissions(permRes.data || []);
      if (odRes.success) setOdList(odRes.data || []);
    } catch (err) {
      console.error('Error fetching applications history:', err);
    } finally {
      setLoading(false);
    }
  }

  // Combine and sort by date descending
  const combined = [
    ...leaves.map((l) => ({
      id: `leave-${l.id}`,
      type: 'LEAVE',
      title: `${l.leaveType?.name || 'Leave'} (${l.totalDays} day${l.totalDays > 1 ? 's' : ''})`,
      dateDisplay: `${dayjs(l.startDate).format('DD MMM YYYY')} - ${dayjs(l.endDate).format('DD MMM YYYY')}`,
      sortDate: l.startDate,
      reason: l.reason,
      status: l.status,
      badgeColor: 'amber',
    })),
    ...permissions.map((p) => ({
      id: `perm-${p.id}`,
      type: 'PERMISSION',
      title: `1-Hour Permission (${p.startTime} - ${p.endTime})`,
      dateDisplay: dayjs(p.date).format('DD MMM YYYY'),
      sortDate: p.date,
      reason: p.reason,
      status: p.status,
      badgeColor: 'blue',
    })),
    ...odList.map((o) => ({
      id: `od-${o.id}`,
      type: 'ON_DUTY',
      title: `On-Duty: ${o.purpose} (${o.location})`,
      dateDisplay: dayjs(o.odDate).format('DD MMM YYYY'),
      sortDate: o.odDate,
      reason: o.description,
      status: o.status,
      badgeColor: 'indigo',
    })),
  ].sort((a, b) => new Date(b.sortDate) - new Date(a.sortDate));

  const filtered = combined.filter((item) => {
    if (tab === 'ALL') return true;
    return item.type === tab;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">Application History</h1>
          <p className="text-xs text-slate-500 mt-1">
            Consolidated ledger of your submitted Leaves, Permissions, and On-Duty requests
          </p>
        </div>

        {/* Tab filters */}
        <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-xl text-xs font-semibold">
          {[
            { key: 'ALL', label: 'All Requests' },
            { key: 'LEAVE', label: 'Leaves' },
            { key: 'PERMISSION', label: '1-Hr Permission' },
            { key: 'ON_DUTY', label: 'On-Duty' },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-3 py-1.5 rounded-lg transition ${
                tab === t.key
                  ? 'bg-white text-[#20266D] shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <div className="w-8 h-8 border-4 border-[#2563EB] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-xs">
            No applications found in this category.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filtered.map((item) => (
              <div key={item.id} className="p-5 hover:bg-slate-50/70 transition flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="flex items-start gap-3.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      item.type === 'LEAVE'
                        ? 'bg-amber-50 text-amber-600 border border-amber-200'
                        : item.type === 'PERMISSION'
                        ? 'bg-blue-50 text-blue-600 border border-blue-200'
                        : 'bg-indigo-50 text-indigo-600 border border-indigo-200'
                    }`}
                  >
                    {item.type === 'LEAVE' ? (
                      <Calendar className="w-5 h-5" />
                    ) : item.type === 'PERMISSION' ? (
                      <Clock className="w-5 h-5" />
                    ) : (
                      <Briefcase className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-800">{item.title}</span>
                      <span className="text-[10px] uppercase font-bold text-slate-400">• {item.type}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">{item.dateDisplay}</div>
                    <p className="text-xs text-slate-600 mt-1 italic">"{item.reason}"</p>
                  </div>
                </div>

                <div className="sm:self-center">
                  <span
                    className={`corp-badge text-[11px] font-bold ${
                      item.status === 'APPROVED'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : item.status === 'REJECTED'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
