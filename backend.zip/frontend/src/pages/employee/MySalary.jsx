import React, { useState, useEffect, useMemo } from 'react';
import api from '../../services/api';
import {
  IndianRupee,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Info,
  CreditCard,
  Briefcase,
  Layers,
  ChevronRight,
  TrendingUp,
  ShieldAlert,
  Wallet,
  Building2,
  QrCode,
  FileText,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import dayjs from 'dayjs';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';

dayjs.extend(isSameOrBefore);
dayjs.extend(isSameOrAfter);

export default function MySalary() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(dayjs().month() + 1);
  const [selectedYear, setSelectedYear] = useState(dayjs().year());

  useEffect(() => {
    fetchSalaryBreakdown();
  }, [selectedMonth, selectedYear]);

  async function fetchSalaryBreakdown() {
    try {
      setLoading(true);
      const res = await api.get(`/salary/my-salary?month=${selectedMonth}&year=${selectedYear}`);
      if (res.success) {
        setData(res.data);
      }
    } catch (err) {
      console.error('Error fetching salary:', err);
    } finally {
      setLoading(false);
    }
  }

  const formatCurrency = (val) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2,
    }).format(val || 0);

  const { config, monthSummary, dailyBreakdown, salaryConfig } = data || {};

  // Current date reference
  const today = dayjs();
  const isCurrentMonth = selectedYear === today.year() && selectedMonth === today.month() + 1;
  const isPastMonth = dayjs(`${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`).isBefore(
    today.startOf('month')
  );

  // Filter daily breakdown: only from joining date up to today (or end of month for past months)
  const visibleRows = useMemo(() => {
    if (!dailyBreakdown || dailyBreakdown.length === 0) return [];

    return dailyBreakdown.filter((row) => {
      // Hide pre-employment dates
      if (row.status === 'NOT_EMPLOYED') return false;

      const rowDate = dayjs(row.date);

      // If joiningDate exists, filter out earlier dates
      if (config?.joiningDate && rowDate.isBefore(dayjs(config.joiningDate), 'day')) {
        return false;
      }

      // Hide future dates
      if (isCurrentMonth && rowDate.isAfter(today, 'day')) {
        return false;
      }
      if (!isPastMonth && !isCurrentMonth && rowDate.isAfter(today, 'day')) {
        return false;
      }

      // Hide scheduled rows
      if (row.status === 'SCHEDULED' || row.status === 'FUTURE') return false;

      return true;
    });
  }, [dailyBreakdown, isCurrentMonth, isPastMonth, today, config?.joiningDate]);

  // Strict calculation up to today
  const metricsTillToday = useMemo(() => {
    const dailyRate = monthSummary?.dailySalary || config?.dailySalary || (config?.monthlySalary ? config.monthlySalary / 30 : 0);

    // Sum earned from visible rows
    let earned = 0;
    let presentCount = 0;
    let paidLeaveCount = 0;
    let paidHolidaysCount = 0;
    let lopDaysCount = 0;
    let halfDayLopCount = 0;

    visibleRows.forEach((row) => {
      earned += Number(row.daySalary || 0);

      const st = row.status;
      if (st === 'PRESENT') {
        presentCount += 1;
      } else if (st === 'HALF_DAY') {
        presentCount += 0.5;
        halfDayLopCount += 0.5;
      } else if (st === 'LEAVE') {
        paidLeaveCount += 1;
      } else if (st === 'HOLIDAY') {
        paidHolidaysCount += 1;
      } else if (st === 'ABSENT' || st === 'INCOMPLETE') {
        lopDaysCount += 1;
      }
    });

    const netEarnedTillToday = earned;

    return {
      dailyRate,
      earnedTillToday: earned,
      deductionsTillToday: 0,
      netEarnedTillToday,
      presentDays: presentCount,
      paidLeaveDays: paidLeaveCount,
      paidHolidays: paidHolidaysCount,
      lopDays: lopDaysCount,
      halfDayLop: halfDayLopCount,
    };
  }, [visibleRows, monthSummary, config]);

  // Payment method resolver
  const paymentMethod = (config?.salaryPaymentMethod || salaryConfig?.paymentMethod || '').toUpperCase();
  const upiId = config?.upiId || salaryConfig?.upiId;
  const bankName = config?.bankName || salaryConfig?.bankName;
  const accountNumber = config?.bankAccountNumber || salaryConfig?.accountNumber;
  const ifscCode = config?.ifscCode || salaryConfig?.ifscCode;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-4 border-[#159A93] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#17324D] tracking-tight">My Salary</h1>
          <p className="text-xs text-[#64748B] mt-1">
            View your current salary, attendance-based earnings and payslips.
          </p>
        </div>

        {/* Month / Year Filter & Payslips Quick Link */}
        <div className="flex items-center gap-3">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="px-3 py-2 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl text-xs font-semibold text-[#17324D] focus:outline-none focus:ring-1 focus:ring-[#159A93]"
          >
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {dayjs().month(i).format('MMMM')}
              </option>
            ))}
          </select>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="px-3 py-2 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl text-xs font-semibold text-[#17324D] focus:outline-none focus:ring-1 focus:ring-[#159A93]"
          >
            {[2025, 2026, 2027].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <Link
            to="/employee/payslips"
            className="px-3 py-2 bg-[#183B56] hover:bg-[#245A78] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Payslips</span>
          </Link>
        </div>
      </div>

      {/* Top 5 Stat Cards (Strictly Up to Today) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* 1. Monthly Salary */}
        <div className="bg-white p-4 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
            Monthly Salary
          </span>
          <div className="text-xl font-bold text-[#17324D] mt-2">
            {formatCurrency(config?.monthlySalary)}
          </div>
          <span className="text-[11px] text-[#64748B] mt-1 block">
            Base Monthly Fixed
          </span>
        </div>

        {/* 2. Daily Rate */}
        <div className="bg-white p-4 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
            Daily Rate
          </span>
          <div className="text-xl font-bold text-[#159A93] mt-2">
            {formatCurrency(metricsTillToday.dailyRate)}
          </div>
          <span className="text-[11px] text-[#64748B] mt-1 block">
            Based on 30 days calculation
          </span>
        </div>

        {/* 3. Earned Till Today */}
        <div className="bg-white p-4 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
            Earned Till Today
          </span>
          <div className="text-xl font-bold text-[#159A73] mt-2">
            {formatCurrency(metricsTillToday.earnedTillToday)}
          </div>
          <span className="text-[11px] text-[#64748B] mt-1 block">
            {visibleRows.length} days accounted
          </span>
        </div>

        {/* 4. Deductions Till Today */}
        <div className="bg-white p-4 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
            Deductions Till Today
          </span>
          <div className="text-xl font-bold text-[#D95C64] mt-2">
            {formatCurrency(metricsTillToday.deductionsTillToday)}
          </div>
          <span className="text-[11px] text-[#64748B] mt-1 block">
            No shift-based penalties
          </span>
        </div>

        {/* 5. Net Earned Till Today */}
        <div className="bg-[#183B56] p-4 rounded-2xl text-white shadow-xs flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-[#DCE7EC] uppercase tracking-wider">
            Net Earned Till Today
          </span>
          <div className="text-xl font-bold text-white mt-2">
            {formatCurrency(metricsTillToday.netEarnedTillToday)}
          </div>
          <span className="text-[11px] text-[#25B6A8] mt-1 block">
            Payable as of today
          </span>
        </div>
      </div>

      {/* Salary Details & Payment Information Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Salary Details Section (2 cols on lg) */}
        <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#DCE7EC]">
            <h2 className="text-sm font-bold text-[#17324D] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#159A93]" />
              Salary Details
            </h2>
            <span className="text-xs text-[#64748B]">
              Calculated strictly up to today
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-xs">
            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA]">
              <span className="text-[#64748B]">Present Days</span>
              <span className="font-semibold text-[#17324D]">{metricsTillToday.presentDays}</span>
            </div>

            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA]">
              <span className="text-[#64748B]">Paid Leave</span>
              <span className="font-semibold text-[#159A93]">{metricsTillToday.paidLeaveDays}</span>
            </div>

            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA]">
              <span className="text-[#64748B]">Paid Holidays</span>
              <span className="font-semibold text-[#17324D]">{metricsTillToday.paidHolidays}</span>
            </div>

            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA]">
              <span className="text-[#64748B]">LOP Days</span>
              <span className="font-semibold text-[#D95C64]">{metricsTillToday.lopDays}</span>
            </div>

            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA]">
              <span className="text-[#64748B]">Half-Day LOP</span>
              <span className="font-semibold text-[#D99A2B]">{metricsTillToday.halfDayLop}</span>
            </div>

            <div className="flex justify-between items-center py-2 border-b border-[#F4F8FA] font-bold text-[#159A73]">
              <span>Net Earned</span>
              <span>{formatCurrency(metricsTillToday.netEarnedTillToday)}</span>
            </div>
          </div>
        </div>

        {/* Payment Information Card (Dynamic based on payment method) */}
        <div className="bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-[#DCE7EC]">
              <CreditCard className="w-4 h-4 text-[#159A93]" />
              <h2 className="text-sm font-bold text-[#17324D]">Payment Information</h2>
            </div>

            <div className="mt-4 space-y-3.5 text-xs">
              {paymentMethod === 'UPI' && (
                <div>
                  <span className="text-[#64748B] block text-[10px] uppercase font-semibold">UPI ID</span>
                  <div className="flex items-center gap-2 mt-1">
                    <QrCode className="w-4 h-4 text-[#159A93]" />
                    <span className="font-semibold text-[#17324D] text-sm font-mono">{upiId || 'Not registered'}</span>
                  </div>
                </div>
              )}

              {paymentMethod === 'CASH' && (
                <div>
                  <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Payment Mode</span>
                  <div className="flex items-center gap-2 mt-1">
                    <Wallet className="w-4 h-4 text-[#159A73]" />
                    <span className="font-semibold text-[#17324D] text-sm">Cash Payment</span>
                  </div>
                </div>
              )}

              {paymentMethod === 'BANK_TRANSFER' && (
                <>
                  <div>
                    <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Bank Name</span>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Building2 className="w-3.5 h-3.5 text-[#159A93]" />
                      <span className="font-semibold text-[#17324D]">{bankName || 'Not registered'}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Account Number</span>
                    <span className="font-semibold text-[#17324D] font-mono block mt-1">
                      {accountNumber
                        ? `•••• •••• ${accountNumber.slice(-4)}`
                        : 'Not registered'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#64748B] block text-[10px] uppercase font-semibold">IFSC Code</span>
                    <span className="font-semibold text-[#17324D] font-mono block mt-1">{ifscCode || 'Not registered'}</span>
                  </div>
                </>
              )}
              {!paymentMethod && (
                <p className="text-xs text-[#64748B]">Payment details have not been provided.</p>
              )}
            </div>
          </div>

          <div className="mt-4 p-3 bg-[#F4F8FA] rounded-xl border border-[#DCE7EC] text-[11px] text-[#64748B]">
            Salary payment timing is managed by your administrator.
          </div>
        </div>
      </div>

      {/* Daily Attendance & Salary Log Table */}
      <div className="bg-white rounded-2xl border border-[#DCE7EC] shadow-xs overflow-hidden">
        <div className="p-5 border-b border-[#DCE7EC] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-[#17324D]">Daily Attendance & Salary Log</h3>
            <p className="text-xs text-[#64748B] mt-0.5">
              Day-by-day calculation from employee joining date up to today
            </p>
          </div>
          <span className="text-xs font-semibold text-[#64748B] bg-[#F4F8FA] px-3 py-1.5 rounded-lg border border-[#DCE7EC]">
            {visibleRows.length} Days Displayed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F4F8FA] border-b border-[#DCE7EC] text-[#64748B] uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-5 py-3">Date</th>
                <th className="px-4 py-3">Day</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Check-In</th>
                <th className="px-4 py-3">Check-Out</th>
                <th className="px-5 py-3 text-right">Earned (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE7EC]">
              {visibleRows.length > 0 ? (
                visibleRows.map((row, idx) => {
                  const dayName = dayjs(row.date).format('dddd');
                  const formattedDate = dayjs(row.date).format('DD MMM YYYY');

                  // Status badge matching exact palette:
                  // Present: Soft Teal / Green
                  // Late: Yellow / Amber
                  // Half Day: Orange
                  // Sunday: Muted Gray
                  // Holiday: Soft Blue
                  // Absent: Soft Red
                  // Leave: Teal
                  // On-Duty: Purple
                  const st = row.status;
                  let badgeClasses = 'bg-[#F4F8FA] text-[#64748B] border-[#DCE7EC]';
                  let displayStatus = st?.replace('_', ' ');

                  if (st === 'PRESENT') {
                    badgeClasses = 'bg-[#E8F8F5] text-[#159A73] border-[#A3E5D4]';
                    displayStatus = 'Present';
                  } else if (st === 'LATE') {
                    badgeClasses = 'bg-[#FEF9E7] text-[#D99A2B] border-[#FAD7A0]';
                    displayStatus = 'Late';
                  } else if (st === 'HALF_DAY') {
                    badgeClasses = 'bg-[#FFF4E6] text-[#E67E22] border-[#FCD5B5]';
                    displayStatus = 'Half Day';
                  } else if (st === 'WEEKLY_OFF') {
                    badgeClasses = 'bg-[#F1F5F9] text-[#64748B] border-[#CBD5E1]';
                    displayStatus = 'Sunday';
                  } else if (st === 'HOLIDAY') {
                    badgeClasses = 'bg-[#EBF5FB] text-[#2980B9] border-[#AED6F1]';
                    displayStatus = 'Holiday';
                  } else if (st === 'ABSENT' || st === 'INCOMPLETE') {
                    badgeClasses = 'bg-[#FDF2E9] text-[#D95C64] border-[#F5B7B1]';
                    displayStatus = st === 'INCOMPLETE' ? 'Incomplete Punch' : 'Absent';
                  } else if (st === 'LEAVE') {
                    badgeClasses = 'bg-[#E6F7F6] text-[#159A93] border-[#A2E3E0]';
                    displayStatus = 'Leave';
                  } else if (st === 'ON_DUTY') {
                    badgeClasses = 'bg-[#F4ECF7] text-[#8E44AD] border-[#D7BDE2]';
                    displayStatus = 'On-Duty';
                  }

                  return (
                    <tr key={idx} className="hover:bg-[#F4F8FA]/70 transition-colors">
                      <td className="px-5 py-3.5 font-medium text-[#17324D] whitespace-nowrap">
                        {formattedDate}
                      </td>
                      <td className="px-4 py-3.5 text-[#64748B] whitespace-nowrap">
                        {dayName}
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span className={`inline-block px-2.5 py-1 rounded-md text-[11px] font-semibold border ${badgeClasses}`}>
                          {displayStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[#64748B] whitespace-nowrap">
                        {row.checkInTime || '—'}
                      </td>
                      <td className="px-4 py-3.5 font-mono text-[#64748B] whitespace-nowrap">
                        {row.checkOutTime || '—'}
                      </td>
                      <td className="px-5 py-3.5 font-bold text-[#17324D] whitespace-nowrap text-right">
                        {formatCurrency(row.daySalary)}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-[#64748B]">
                    No attendance records found for this period.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
