import React, { useState, useEffect, useMemo } from 'react';
import { adminStore } from '../../services/adminStore';
import { useAuth } from '../../context/AuthContext';
import {
  CheckSquare,
  Clock,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Hourglass,
  Tag,
  Search,
  Filter,
  ArrowRight,
  TrendingUp,
  User,
} from 'lucide-react';

export default function EmployeeTasksPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  const [toastMsg, setToastMsg] = useState('');

  // Current logged in employee identity
  const currentEmpName = user?.employee?.fullName || 'Suresh Kumar';
  const currentEmpId = user?.employee?.id || 'EMP-001';

  useEffect(() => {
    loadMyTasks();
    const handleStoreUpdate = () => loadMyTasks();
    window.addEventListener('saishnaa_store_updated', handleStoreUpdate);
    return () => window.removeEventListener('saishnaa_store_updated', handleStoreUpdate);
  }, [currentEmpName, currentEmpId]);

  function loadMyTasks() {
    const allTasks = adminStore.getTasks();
    // Filter tasks assigned to this employee, or display all demo tasks if no strict match
    const myTasks = allTasks.filter(
      (t) =>
        t.assignedToId === currentEmpId ||
        t.assignedToName.toLowerCase().includes(currentEmpName.toLowerCase()) ||
        currentEmpName.toLowerCase().includes(t.assignedToName.toLowerCase())
    );

    // Fallback if none assigned specifically: show tasks for demonstration
    const activeList = myTasks.length > 0 ? myTasks : allTasks;
    setTasks(activeList);

    if (activeList.length > 0 && !selectedTask) {
      setSelectedTask(activeList[0]);
    } else if (selectedTask) {
      const refreshed = activeList.find((t) => t.id === selectedTask.id);
      if (refreshed) setSelectedTask(refreshed);
    }
  }

  function showToast(msg) {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  }

  // Handle Employee updating task status
  function handleStatusUpdate(taskId, newStatus) {
    const updated = adminStore.updateTaskStatus(taskId, newStatus);
    if (updated) {
      loadMyTasks();
      showToast(`Task status updated to "${newStatus}"! Admin has been notified.`);
    }
  }

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch =
        t.title.toLowerCase().includes(search.toLowerCase()) ||
        t.taskCode.toLowerCase().includes(search.toLowerCase()) ||
        (t.tags && t.tags.some((tag) => tag.toLowerCase().includes(search.toLowerCase())));
      const matchStatus = statusFilter === 'ALL' || t.status.toUpperCase() === statusFilter.toUpperCase();
      const matchPriority = priorityFilter === 'ALL' || t.priority.toUpperCase() === priorityFilter.toUpperCase();
      return matchSearch && matchStatus && matchPriority;
    });
  }, [tasks, search, statusFilter, priorityFilter]);

  const totalTasks = tasks.length;
  const inProgressCount = tasks.filter((t) => t.status === 'In Progress').length;
  const pendingCount = tasks.filter((t) => t.status === 'Pending').length;
  const completedCount = tasks.filter((t) => t.status === 'Completed').length;

  const getPriorityBadge = (priority) => {
    switch (priority?.toUpperCase()) {
      case 'URGENT':
      case 'HIGH':
        return 'bg-[#FEE2E2] text-[#991B1B] border-[#FCA5A5]';
      case 'MEDIUM':
        return 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]';
      case 'LOW':
      default:
        return 'bg-[#F1F5F9] text-[#475569] border-[#CBD5E1]';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Completed':
        return 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
      case 'In Progress':
        return 'bg-[#DBEAFE] text-[#1E40AF] border-[#93C5FD]';
      case 'In Review':
        return 'bg-[#F3E8FF] text-[#6B21A8] border-[#D8B4FE]';
      case 'Pending':
      default:
        return 'bg-[#FEF9EE] text-[#B45309] border-[#FDE68A]';
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-[#2563EB]" />
            My Assigned Tasks
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track work assigned to you by administrators, update progress milestones, and submit deliverables.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-xl text-xs font-bold text-blue-800">
          <User className="w-3.5 h-3.5 text-blue-600" />
          <span>{currentEmpName}</span>
        </div>
      </div>

      {/* 2. SUMMARY KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">Total Tasks</p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">{totalTasks}</h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Assigned by Admin</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB]">
            <CheckSquare className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#FEF9EE] border border-[#FDE68A] text-[#92400E] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#92400E]/80 uppercase tracking-wider">In Progress</p>
            <h3 className="text-2xl font-black mt-1 text-[#92400E]">{inProgressCount}</h3>
            <p className="text-[11px] text-[#92400E]/70 mt-0.5">Active Deliverables</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#FDE68A] flex items-center justify-center text-[#D97706]">
            <Hourglass className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#FFF7ED] border border-[#FFEDD5] text-[#9A3412] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#9A3412]/80 uppercase tracking-wider">Pending Start</p>
            <h3 className="text-2xl font-black mt-1 text-[#9A3412]">{pendingCount}</h3>
            <p className="text-[11px] text-[#9A3412]/70 mt-0.5">Not Yet Begun</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#FFEDD5] flex items-center justify-center text-[#EA580C]">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">Completed</p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{completedCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Ready for Review</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A]">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. SEARCH & FILTERS */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by title, code, or tag..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-blue-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="In Review">In Review</option>
            <option value="Completed">Completed</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>

        <div className="text-xs font-bold text-slate-500">
          Showing <span className="text-slate-900 font-black">{filteredTasks.length}</span> Tasks
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Table */}
        <div className="lg:col-span-7 xl:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Assigned Tasks
            </h3>
            <span className="text-[11px] text-slate-500">Click to inspect and update status</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Task Title</th>
                  <th className="py-3 px-3">Priority</th>
                  <th className="py-3 px-3">Due Date</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-4 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      No tasks currently assigned matching your filters.
                    </td>
                  </tr>
                ) : (
                  filteredTasks.map((t) => {
                    const isSelected = selectedTask?.id === t.id;
                    return (
                      <tr
                        key={t.id}
                        onClick={() => setSelectedTask(t)}
                        className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                          isSelected ? 'bg-blue-50/70 font-semibold' : ''
                        }`}
                      >
                        <td className="py-3 px-4">
                          <div className="max-w-[240px]">
                            <p className="font-bold text-slate-900 truncate">{t.title}</p>
                            <span className="text-[10px] text-slate-400 font-mono">{t.taskCode}</span>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold border ${getPriorityBadge(
                              t.priority
                            )}`}
                          >
                            {t.priority}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-mono text-slate-700">
                          {t.dueDate}
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(
                              t.status
                            )}`}
                          >
                            {t.status}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right">
                          {t.status === 'Pending' && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleStatusUpdate(t.id, 'In Progress');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] transition-colors"
                            >
                              Start
                            </button>
                          )}
                          {t.status === 'In Progress' && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleStatusUpdate(t.id, 'Completed');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition-colors"
                            >
                              Complete
                            </button>
                          )}
                          {t.status === 'Completed' && (
                            <span className="text-[11px] text-emerald-700 font-bold">Done ✓</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel */}
        <div className="lg:col-span-5 xl:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 sticky top-20">
          <div className="pb-3 border-b border-slate-100">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Task Details
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">
              {selectedTask ? selectedTask.taskCode : 'Select a Task'}
            </h3>
          </div>

          {selectedTask ? (
            <div className="space-y-4 text-xs">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900 leading-snug">
                  {selectedTask.title}
                </h4>
                <p className="text-slate-600 text-xs leading-relaxed mt-1">
                  {selectedTask.description || 'No additional instructions.'}
                </p>
              </div>

              {/* Status Update Actions */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Update Progress
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['In Progress', 'In Review', 'Completed'].map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => handleStatusUpdate(selectedTask.id, st)}
                      className={`px-2 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer ${
                        selectedTask.status === st
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 gap-2.5 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Priority</span>
                  <span
                    className={`inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold border ${getPriorityBadge(
                      selectedTask.priority
                    )}`}
                  >
                    {selectedTask.priority}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Due Date</span>
                  <span className="font-mono font-bold text-slate-800 block mt-0.5">
                    {selectedTask.dueDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Est. Effort</span>
                  <span className="font-mono font-bold text-slate-800 block mt-0.5">
                    {selectedTask.estimatedHours} Hours
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Current Status</span>
                  <span className="font-bold text-blue-700 block mt-0.5">
                    {selectedTask.status}
                  </span>
                </div>
              </div>

              {/* Tags */}
              {selectedTask.tags && selectedTask.tags.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Domain Tags
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedTask.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-semibold"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Admin Note */}
              {selectedTask.notes && (
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-amber-900 text-[11px] leading-relaxed">
                  <p className="font-bold text-[10px] uppercase text-amber-800 mb-0.5">
                    Instructions from Admin
                  </p>
                  {selectedTask.notes}
                </div>
              )}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs">
              Select any task from the table to view details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
