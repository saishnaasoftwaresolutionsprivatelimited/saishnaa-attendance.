import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { Clock, Filter, Calendar, FileEdit } from 'lucide-react';
import { Link } from 'react-router-dom';
import dayjs from 'dayjs';

export default function MyAttendance() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(dayjs().startOf('month').format('YYYY-MM-DD'));
  const [endDate, setEndDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    fetchHistory();
  }, [startDate, endDate, statusFilter]);

  async function fetchHistory() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (statusFilter) params.append('status', statusFilter);

      const res = await api.get(`/attendance/me?${params.toString()}`);

      if (res?.success) {
        setRecords(res.data.records || []);
      }
    } catch (err) {
      console.error('Fetch my attendance error:', err);
    } finally {
      setLoading(false);
    }
  }

  const renderStatusBadge = (r) => {
    const classification = r.attendanceClassification;
    let badgeClasses = 'bg-[#F4F8FA] text-[#64748B] border-[#DCE7EC]';
    let text = classification?.replace('_', ' ');

    if (classification === 'PRESENT' || classification === 'PUNCTUAL_PRESENT') {
      badgeClasses = 'bg-[#E8F8F5] text-[#159A73] border-[#A3E5D4]';
      text = 'Present';
    } else if (classification === 'HALF_DAY') {
      badgeClasses = 'bg-[#FFF4E6] text-[#E67E22] border-[#FCD5B5]';
      text = 'Half Day';
    } else if (classification === 'ON_LEAVE') {
      badgeClasses = 'bg-[#E6F7F6] text-[#159A93] border-[#A2E3E0]';
      text = 'Leave';
    } else if (classification === 'ABSENT') {
      badgeClasses = 'bg-[#FDF2E9] text-[#D95C64] border-[#F5B7B1]';
      text = 'Absent';
    }

    return (
      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${badgeClasses}`}>
        {text}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#17324D] tracking-tight">Attendance Log</h1>
          <p className="text-xs text-[#64748B] mt-1">
            Review your attendance punches, breaks, and recorded work duration.
          </p>
        </div>

        {/* Date Filter */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl px-2.5 py-1.5 text-xs">
            <span className="text-[#64748B]">From:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-transparent font-semibold text-[#17324D] focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl px-2.5 py-1.5 text-xs">
            <span className="text-[#64748B]">To:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-transparent font-semibold text-[#17324D] focus:outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="py-1.5 px-3 text-xs bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl focus:outline-none text-[#17324D] font-semibold"
          >
            <option value="">All Statuses</option>
            <option value="PRESENT">Present</option>
            <option value="HALF_DAY">Half Day</option>
            <option value="ON_LEAVE">On Leave</option>
          </select>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-2xl border border-[#DCE7EC] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F4F8FA] border-b border-[#DCE7EC] text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
              <tr>
                <th className="py-3 px-5">Date</th>
                <th className="py-3 px-4">Check-In</th>
                <th className="py-3 px-4">Break</th>
                <th className="py-3 px-4">Check-Out</th>
                <th className="py-3 px-4">Work Hours</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE7EC]">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#64748B]">
                    Loading attendance records...
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#64748B]">
                    No attendance records found for this period.
                  </td>
                </tr>
              ) : (
                records.map((r) => {
                  const netHours =
                    r.netWorkMinutes > 0
                      ? `${Math.floor(r.netWorkMinutes / 60)}h ${r.netWorkMinutes % 60}m`
                      : '—';

                  return (
                    <tr key={r.id} className="hover:bg-[#F4F8FA]/70 transition-colors">
                      <td className="py-3.5 px-5 font-semibold text-[#17324D] whitespace-nowrap">
                        {dayjs(r.workDate).format('DD MMM YYYY (ddd)')}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-medium text-[#17324D] whitespace-nowrap">
                        {r.checkInAt ? dayjs(r.checkInAt).format('hh:mm A') : '—'}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[#64748B] whitespace-nowrap">
                        {r.totalBreakMinutes > 0 ? `${r.totalBreakMinutes}m` : '0m'}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[#17324D] whitespace-nowrap">
                        {r.checkOutAt ? dayjs(r.checkOutAt).format('hh:mm A') : '—'}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-[#183B56] whitespace-nowrap">
                        {netHours}
                      </td>
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {renderStatusBadge(r)}
                      </td>
                      <td className="py-3.5 px-5 text-right whitespace-nowrap">
                        <Link
                          to={`/employee/corrections?date=${r.workDate}`}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#159A93] hover:text-[#245A78]"
                        >
                          <FileEdit className="w-3.5 h-3.5" />
                          <span>Correction</span>
                        </Link>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
