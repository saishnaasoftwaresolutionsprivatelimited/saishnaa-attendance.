import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { generatePayslipPDF } from '../../utils/pdfGenerator';
import {
  FileText,
  Download,
  Eye,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building2,
  X,
  CreditCard,
  IndianRupee,
  ShieldCheck,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function MyPayslips() {
  const [payslips, setPayslips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPayslip, setSelectedPayslip] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);
  const [companyBranding, setCompanyBranding] = useState({
    companyName: 'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED',
    tagline: 'Official Monthly Employee Payslip',
  });

  useEffect(() => {
    fetchPayslips();
    fetchCompanyBranding();
  }, []);

  async function fetchCompanyBranding() {
    try {
      const res = await api.get('/payroll/company-branding');
      if (res.success && res.data) {
        setCompanyBranding(res.data);
      }
    } catch (err) {
      // Keep default
    }
  }

  async function fetchPayslips() {
    try {
      setLoading(true);
      const res = await api.get('/payroll/my-payslips');
      if (res.success) {
        setPayslips(res.data || []);
      }
    } catch (err) {
      console.error('Error fetching payslips:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleDownloadPdf(calcId, payslipNum) {
    try {
      setDownloadingId(calcId);
      const response = await fetch(`/api/payroll/payslips/${calcId}/download`, {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to download PDF from server');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${payslipNum || 'Payslip'}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.warn('Backend download failed, generating client-side payslip PDF:', err);
      const targetSlip = payslips.find(p => p.id === calcId) || selectedPayslip;
      if (targetSlip) {
        generatePayslipPDF(targetSlip, targetSlip.month || 'October 2026');
      }
    } finally {
      setDownloadingId(null);
    }
  }

  const formatCurrency = (val) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2,
    }).format(val || 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-[#DCE7EC] shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#17324D] tracking-tight">My Payslips</h1>
          <p className="text-xs text-[#64748B] mt-1">
            Access, view, and securely download your official corporate salary slips.
          </p>
        </div>
      </div>

      {/* Payslips Table */}
      <div className="bg-white rounded-2xl border border-[#DCE7EC] shadow-xs overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <div className="w-8 h-8 border-4 border-[#159A93] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : payslips.length === 0 ? (
          <div className="text-center py-16 px-4">
            <div className="w-16 h-16 rounded-2xl bg-[#F4F8FA] text-[#159A93] border border-[#DCE7EC] flex items-center justify-center mx-auto mb-3">
              <FileText className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-[#17324D]">No Payslips Generated Yet</h3>
            <p className="text-xs text-[#64748B] max-w-sm mx-auto mt-1">
              Your monthly payslips will be published here once processed and approved by Corporate HR & Finance.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F4F8FA] border-b border-[#DCE7EC] text-[#64748B] uppercase tracking-wider font-semibold">
                <tr>
                  <th className="px-5 py-3">Payslip No.</th>
                  <th className="px-4 py-3">Payroll Month</th>
                  <th className="px-4 py-3">Gross Salary</th>
                  <th className="px-4 py-3">Total Deductions</th>
                  <th className="px-4 py-3">Net Pay</th>
                  <th className="px-4 py-3">Payment Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DCE7EC]">
                {payslips.map((ps) => (
                  <tr key={ps.id} className="hover:bg-[#F4F8FA]/70 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-semibold text-[#183B56] whitespace-nowrap">
                      {ps.payslipNumber}
                    </td>
                    <td className="px-4 py-3.5 font-medium text-[#17324D] whitespace-nowrap">
                      {dayjs(`${ps.monthYear || '2026-09'}-01`).format('MMMM YYYY')}
                    </td>
                    <td className="px-4 py-3.5 font-semibold text-[#17324D] whitespace-nowrap">
                      {formatCurrency(ps.grossEarnings ?? ps.grossSalary ?? ps.monthlySalary)}
                    </td>
                    <td className="px-4 py-3.5 font-semibold text-[#D95C64] whitespace-nowrap">
                      {formatCurrency(ps.totalDeductions)}
                    </td>
                    <td className="px-4 py-3.5 font-bold text-[#159A73] whitespace-nowrap">
                      {formatCurrency(ps.netSalary)}
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                          (ps.status || ps.paymentStatus) === 'PAID'
                            ? 'bg-[#E8F8F5] text-[#159A73] border-[#A3E5D4]'
                            : (ps.status || ps.paymentStatus) === 'ADMIN_APPROVED'
                            ? 'bg-[#EBF5FB] text-[#2980B9] border-[#AED6F1]'
                            : 'bg-[#FEF9E7] text-[#D99A2B] border-[#FAD7A0]'
                        }`}
                      >
                        {(ps.status || ps.paymentStatus)?.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right whitespace-nowrap space-x-2">
                      <button
                        onClick={() => setSelectedPayslip(ps)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8FA] hover:bg-[#DCE7EC]/50 text-[#17324D] rounded-lg text-xs font-semibold border border-[#DCE7EC] transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#159A93]" />
                        View
                      </button>
                      <button
                        onClick={() => handleDownloadPdf(ps.id, ps.payslipNumber)}
                        disabled={downloadingId === ps.id}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183B56] hover:bg-[#245A78] text-white rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
                      >
                        <Download className="w-3.5 h-3.5" />
                        {downloadingId === ps.id ? 'Generating...' : 'PDF'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Payslip View Modal */}
      {selectedPayslip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-6 sm:p-8 border border-[#DCE7EC] my-8 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between pb-4 border-b border-[#DCE7EC]">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#183B56] flex items-center justify-center text-white font-extrabold text-xl">
                  {companyBranding.companyName ? companyBranding.companyName.charAt(0) : 'S'}
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#17324D]">
                    {companyBranding.companyName || 'SAISHNAA SOFTWARE SOLUTIONS PVT LTD'}
                  </h3>
                  <p className="text-[11px] text-[#64748B]">
                    {companyBranding.tagline || 'Official Monthly Employee Payslip'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPayslip(null)}
                className="text-[#64748B] hover:text-[#17324D] p-1.5 rounded-lg hover:bg-[#F4F8FA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Payslip Metadata */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-[#DCE7EC] text-xs">
              <div>
                <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Payslip Number</span>
                <span className="font-mono font-semibold text-[#17324D]">{selectedPayslip.payslipNumber}</span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Payroll Period</span>
                <span className="font-semibold text-[#17324D]">
                  {dayjs(`${selectedPayslip.monthYear || '2026-09'}-01`).format('MMMM YYYY')}
                </span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Payment Status</span>
                <span className="font-semibold text-[#159A73]">
                  {selectedPayslip.status || selectedPayslip.paymentStatus}
                </span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px] uppercase font-semibold">Payment Date</span>
                <span className="font-semibold text-[#17324D]">
                  {selectedPayslip.paymentDate ? dayjs(selectedPayslip.paymentDate).format('DD MMM YYYY') : 'Pending Release'}
                </span>
              </div>
            </div>

            {/* Attendance Days Summary */}
            <div className="bg-[#F4F8FA] border border-[#DCE7EC] rounded-xl p-4 my-4 grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs">
              <div>
                <span className="text-[#64748B] block text-[10px]">Present</span>
                <span className="font-bold text-[#17324D]">{selectedPayslip.presentDays}</span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px]">Scheduled</span>
                <span className="font-bold text-[#183B56]">{selectedPayslip.scheduledDays || 0}</span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px]">Half Days</span>
                <span className="font-bold text-[#17324D]">{selectedPayslip.halfDays}</span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px]">Paid Leave</span>
                <span className="font-bold text-[#159A93]">{selectedPayslip.paidLeaveDays}</span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px]">On-Duty</span>
                <span className="font-bold text-[#17324D]">
                  {selectedPayslip.approvedOdDays ?? selectedPayslip.odDays ?? 0}
                </span>
              </div>
              <div>
                <span className="text-[#64748B] block text-[10px]">Payable Days</span>
                <span className="font-bold text-[#159A73]">{selectedPayslip.payableDays}</span>
              </div>
            </div>

            {/* Earnings vs Deductions Table */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 my-4 text-xs">
              <div className="border border-[#DCE7EC] rounded-xl p-4 space-y-2">
                <h4 className="font-bold text-[#159A73] border-b border-[#DCE7EC] pb-2 text-[11px] uppercase tracking-wider">
                  Earnings (INR)
                </h4>
                <div className="flex justify-between py-1 border-b border-[#F4F8FA]">
                  <span className="text-[#64748B]">Base Monthly Salary</span>
                  <span className="font-semibold text-[#17324D]">{formatCurrency(selectedPayslip.monthlySalary || selectedPayslip.baseSalary)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F4F8FA]">
                  <span className="text-[#64748B]">Calculated Earned Basic</span>
                  <span className="font-semibold text-[#17324D]">{formatCurrency(selectedPayslip.grossEarnings ?? selectedPayslip.grossSalary)}</span>
                </div>
                <div className="flex justify-between pt-2 font-bold text-[#159A73]">
                  <span>Gross Earnings</span>
                  <span>{formatCurrency(selectedPayslip.grossEarnings ?? selectedPayslip.grossSalary)}</span>
                </div>
              </div>

              <div className="border border-[#DCE7EC] rounded-xl p-4 space-y-2">
                <h4 className="font-bold text-[#D95C64] border-b border-[#DCE7EC] pb-2 text-[11px] uppercase tracking-wider">
                  Deductions (INR)
                </h4>
                <div className="flex justify-between py-1 border-b border-[#F4F8FA]">
                  <span className="text-[#64748B]">Absent / Incomplete</span>
                  <span className="font-semibold text-[#D95C64]">
                    {formatCurrency(selectedPayslip.absenceDeductions ?? selectedPayslip.absentDays * selectedPayslip.dailySalary)}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F4F8FA]">
                  <span className="text-[#64748B]">Unpaid Leave</span>
                  <span className="font-semibold text-[#D95C64]">
                    {formatCurrency(selectedPayslip.unpaidLeaveDeductions ?? selectedPayslip.unpaidLeaveDays * selectedPayslip.dailySalary)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 font-bold text-[#D95C64]">
                  <span>Total Deductions</span>
                  <span>{formatCurrency(selectedPayslip.totalDeductions)}</span>
                </div>
              </div>
            </div>

            {/* Net Payout Banner */}
            <div className="bg-[#183B56] text-white rounded-xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-semibold text-[#DCE7EC]">Total Net Disbursed Salary</span>
                <div className="text-2xl font-bold">{formatCurrency(selectedPayslip.netSalary)}</div>
              </div>
              <button
                onClick={() => handleDownloadPdf(selectedPayslip.id, selectedPayslip.payslipNumber)}
                className="px-4 py-2 bg-white text-[#183B56] hover:bg-[#F4F8FA] rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Download className="w-4 h-4 text-[#159A93]" />
                Download PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
