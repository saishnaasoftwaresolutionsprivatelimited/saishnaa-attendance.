import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock,
  Coffee,
  CheckCircle2,
  AlertCircle,
  PartyPopper,
  Sparkles,
  Briefcase,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function AttendanceCalendar() {
  const [currentDate, setCurrentDate] = useState(dayjs());
  const [recordsMap, setRecordsMap] = useState({});
  const [holidaysMap, setHolidaysMap] = useState({});
  const [selectedDayData, setSelectedDayData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMonthRecords();
  }, [currentDate]);

  async function fetchMonthRecords() {
    try {
      setLoading(true);
      const startOfMonth = currentDate.startOf('month').format('YYYY-MM-DD');
      const endOfMonth = currentDate.endOf('month').format('YYYY-MM-DD');

      const [attRes, holRes] = await Promise.all([
        api.get(`/attendance/me?startDate=${startOfMonth}&endDate=${endOfMonth}&limit=35`).catch(() => ({ data: { records: [] } })),
        api.get('/holidays').catch(() => ({ data: [] })),
      ]);

      if (attRes.success || attRes.data) {
        const rMap = {};
        (attRes.data?.records || []).forEach((r) => {
          rMap[r.workDate] = r;
        });
        setRecordsMap(rMap);
      }

      if (holRes.success || Array.isArray(holRes.data)) {
        const hMap = {};
        (holRes.data || []).forEach((h) => {
          hMap[h.date] = h;
        });
        setHolidaysMap(hMap);
      }
    } catch (err) {
      console.error('Fetch calendar error:', err);
    } finally {
      setLoading(false);
    }
  }

  function prevMonth() {
    setCurrentDate(currentDate.subtract(1, 'month'));
    setSelectedDayData(null);
  }

  function nextMonth() {
    setCurrentDate(currentDate.add(1, 'month'));
    setSelectedDayData(null);
  }

  // Generate calendar days
  const startDayOfMonth = currentDate.startOf('month');
  const daysInMonth = currentDate.daysInMonth();
  const startDayOfWeek = startDayOfMonth.day(); // 0 = Sun, 1 = Mon ...

  const calendarDays = [];
  // Blank cells before month starts
  for (let i = 0; i < startDayOfWeek; i++) {
    calendarDays.push(null);
  }
  // Days of month
  for (let d = 1; d <= daysInMonth; d++) {
    const dayDate = startDayOfMonth.date(d);
    calendarDays.push(dayDate);
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">Attendance Calendar</h1>
          <p className="text-xs text-slate-500 mt-1">
            Month-at-a-glance schedule with public holidays and verified office attendance
          </p>
        </div>

        {/* Month Navigation */}
        <div className="flex items-center gap-3">
          <button onClick={prevMonth} className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 transition">
            <ChevronLeft className="w-4 h-4 text-slate-700" />
          </button>
          <div className="font-extrabold text-sm sm:text-base text-slate-900 w-40 text-center">
            {currentDate.format('MMMM YYYY')}
          </div>
          <button onClick={nextMonth} className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 transition">
            <ChevronRight className="w-4 h-4 text-slate-700" />
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="corp-card p-4 flex flex-wrap items-center justify-between gap-3 text-xs font-medium">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
          <span className="text-slate-700 font-semibold">Present</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-purple-500"></span>
          <span className="text-slate-700 font-semibold">Half Day</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-blue-500"></span>
          <span className="text-slate-700 font-semibold">Approved Leave</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-rose-500"></span>
          <span className="text-rose-700 font-bold">Public Holiday (Off)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-teal-600 ring-2 ring-teal-200"></span>
          <span className="text-teal-800 font-bold">Worked on Holiday</span>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="corp-card p-5">
        <div className="grid grid-cols-7 gap-2 mb-2 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">
          <div className="text-rose-500 font-extrabold">Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {calendarDays.map((day, idx) => {
            if (!day) {
              return <div key={`empty-${idx}`} className="h-24 bg-slate-50/50 rounded-xl"></div>;
            }

            const dateStr = day.format('YYYY-MM-DD');
            const record = recordsMap[dateStr];
            const holiday = holidaysMap[dateStr];
            const isToday = day.isSame(dayjs(), 'day');

            let badgeClass = 'bg-white border-slate-200 text-slate-800';
            let statusDot = null;
            let displayTitle = null;
            let displaySub = null;
            const hasAttendedOnHoliday = Boolean(holiday && record && record.checkInAt);

            if (holiday) {
              if (hasAttendedOnHoliday) {
                // Employee logged in on a public holiday - dynamically adapted!
                badgeClass = 'bg-gradient-to-br from-teal-50 to-emerald-50 border-teal-400 text-teal-950 ring-1 ring-teal-300';
                statusDot = 'bg-teal-500';
                displayTitle = record.checkInAt ? dayjs(record.checkInAt).format('hh:mm A') : '--';
                displaySub = (
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black text-teal-700 uppercase tracking-tight">Worked on Holiday</span>
                    <span className="text-[8px] font-medium text-slate-600 truncate">{holiday.name}</span>
                  </div>
                );
              } else {
                // Public holiday - employee did not log in (Standard Paid Holiday)
                badgeClass = 'bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 border-rose-300 text-rose-950';
                statusDot = 'bg-rose-500';
                displayTitle = <span className="font-bold text-rose-800 truncate block">🎉 {holiday.name}</span>;
                displaySub = <span className="text-[8px] font-extrabold text-rose-600 uppercase tracking-wider">Public Holiday</span>;
              }
            } else if (record) {
              if (record.attendanceClassification === 'PRESENT') {
                badgeClass = 'bg-emerald-50/80 border-emerald-300 text-emerald-900';
                statusDot = 'bg-emerald-500';
              } else if (record.attendanceClassification === 'HALF_DAY') {
                badgeClass = 'bg-purple-50/80 border-purple-300 text-purple-900';
                statusDot = 'bg-purple-500';
              } else if (record.attendanceClassification === 'ON_LEAVE') {
                badgeClass = 'bg-blue-50/80 border-blue-300 text-blue-900';
                statusDot = 'bg-blue-500';
              }
              displayTitle = record.checkInAt ? dayjs(record.checkInAt).format('hh:mm A') : '--';
              displaySub = (
                <span className="text-[9px] font-bold truncate opacity-90">
                  {record.attendanceClassification}
                </span>
              );
            } else {
              displaySub = <span className="text-[9px] text-slate-400">--</span>;
            }

            return (
              <div
                key={dateStr}
                onClick={() =>
                  setSelectedDayData({
                    day,
                    dateStr,
                    record,
                    holiday,
                    hasAttendedOnHoliday,
                  })
                }
                className={`h-24 p-2 rounded-xl border flex flex-col justify-between transition-all cursor-pointer ${badgeClass} ${
                  isToday ? 'ring-2 ring-[#2563EB]' : ''
                } hover:shadow-md hover:scale-[1.01]`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-black ${isToday ? 'text-[#2563EB]' : ''}`}>
                    {day.date()}
                  </span>
                  <div className="flex items-center gap-1">
                    {holiday && !hasAttendedOnHoliday && <span className="text-[10px]" title={holiday.name}>🎉</span>}
                    {hasAttendedOnHoliday && <Sparkles className="w-3 h-3 text-teal-600 animate-pulse" />}
                    {statusDot && <span className={`w-2 h-2 rounded-full ${statusDot}`}></span>}
                  </div>
                </div>

                <div className="text-[10px] space-y-0.5 min-w-0">
                  {displayTitle && <div className="font-mono font-semibold truncate">{displayTitle}</div>}
                  {displaySub}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Day Inspection Modal/Drawer */}
      {selectedDayData && (
        <div className="corp-card p-5 border-l-4 border-l-[#2563EB] animate-fade-in flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="text-sm font-bold text-slate-800">
                Details for {selectedDayData.day.format('dddd, DD MMMM YYYY')}
              </h4>
              {selectedDayData.holiday && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 flex items-center gap-1">
                  <span>🎉</span> {selectedDayData.holiday.name} (Public Holiday)
                </span>
              )}
              {selectedDayData.hasAttendedOnHoliday && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-teal-100 text-teal-800 border border-teal-300">
                  Duty Completed on Holiday
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
              {selectedDayData.record ? (
                <>
                  <div>
                    <span className="text-slate-400">Check In:</span>{' '}
                    <span className="font-mono font-bold text-slate-800">
                      {selectedDayData.record.checkInAt
                        ? dayjs(selectedDayData.record.checkInAt).format('hh:mm A')
                        : '--'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Check Out:</span>{' '}
                    <span className="font-mono font-bold text-slate-800">
                      {selectedDayData.record.checkOutAt
                        ? dayjs(selectedDayData.record.checkOutAt).format('hh:mm A')
                        : 'Active / Pending'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Net Work:</span>{' '}
                    <span className="font-bold text-[#20266D]">
                      {Math.floor(selectedDayData.record.netWorkMinutes / 60)}h{' '}
                      {selectedDayData.record.netWorkMinutes % 60}m
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Attendance Status:</span>{' '}
                    <span className="corp-badge bg-blue-100 text-blue-900 text-[10px] font-bold">
                      {selectedDayData.hasAttendedOnHoliday
                        ? 'WORKED ON HOLIDAY'
                        : selectedDayData.record.attendanceClassification}
                    </span>
                  </div>
                </>
              ) : selectedDayData.holiday ? (
                <div className="text-xs font-semibold text-rose-700 bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-200">
                  Official Public Holiday closure. Full paid off granted with no login required.
                </div>
              ) : (
                <div className="text-xs text-slate-400 italic">No attendance records for this date.</div>
              )}
            </div>
          </div>

          <button
            onClick={() => setSelectedDayData(null)}
            className="text-slate-400 hover:text-slate-700 p-2 rounded-lg hover:bg-slate-100 self-start sm:self-center"
            title="Close details"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
