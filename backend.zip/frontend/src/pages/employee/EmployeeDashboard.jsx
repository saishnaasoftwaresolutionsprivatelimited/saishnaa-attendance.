import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { getCurrentAttendanceLocation } from '../../utils/attendanceLocation';
import {
  Clock,
  Coffee,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Briefcase,
  ArrowRight,
  TrendingUp,
  Sparkles,
  RefreshCw,
  LogOut,
  CalendarDays,
  ShieldAlert,
  ChevronRight,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function EmployeeDashboard() {
  const { user, role } = useAuth();
  const portalBase = role === 'HR' ? '/hr' : '/employee';

  const [todayData, setTodayData] = useState(null);
  const [salaryData, setSalaryData] = useState(null);
  const [permStatus, setPermStatus] = useState(null);
  const [holidays, setHolidays] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [liveSeconds, setLiveSeconds] = useState(0);

  useEffect(() => {
    fetchAllDashboardData();
  }, []);

  // Live timer tick if working - continuously synchronized to real clock
  useEffect(() => {
    let timer;
    const att = todayData?.attendance;
    if (att?.workSessionStatus === 'WORKING' && att?.checkInAt) {
      const checkInTime = dayjs(att.checkInAt);
      const breakSecs =
        att.breakRecords?.length > 0
          ? att.breakRecords.reduce(
              (sum, b) =>
                b.breakStartAt && b.breakEndAt
                  ? sum + dayjs(b.breakEndAt).diff(dayjs(b.breakStartAt), 'second')
                  : sum,
              0
            )
          : (att.totalBreakMinutes || 0) * 60;

      const syncTimer = () => {
        const currentElapsedSecs = Math.max(0, dayjs().diff(checkInTime, 'second') - breakSecs);
        setLiveSeconds(currentElapsedSecs);
      };

      syncTimer();
      timer = setInterval(syncTimer, 1000);
    }
    return () => clearInterval(timer);
  }, [
    todayData?.attendance?.workSessionStatus,
    todayData?.attendance?.checkInAt,
    todayData?.attendance?.totalBreakMinutes,
    todayData?.attendance?.breakRecords,
  ]);

  async function fetchAllDashboardData() {
    try {
      setLoading(true);
      const currentMonth = dayjs().month() + 1;
      const currentYear = dayjs().year();

      const [todayRes, salaryRes, permRes, holRes] = await Promise.all([
        api.get('/attendance/today').catch(() => ({ success: false })),
        api.get(`/salary/my-salary?month=${currentMonth}&year=${currentYear}`).catch(() => ({ success: false })),
        api.get('/permissions/status').catch(() => ({ success: false })),
        api.get(`/holidays?year=${currentYear}`).catch(() => ({ success: false })),
      ]);

      if (todayRes?.success) {
        setTodayData(todayRes.data);
        const att = todayRes.data?.attendance;
        if (att?.checkInAt && att.workSessionStatus === 'WORKING') {
          const breakSecs =
            att.breakRecords?.length > 0
              ? att.breakRecords.reduce(
                  (sum, b) =>
                    b.breakStartAt && b.breakEndAt
                      ? sum + dayjs(b.breakEndAt).diff(dayjs(b.breakStartAt), 'second')
                      : sum,
                  0
                )
              : (att.totalBreakMinutes || 0) * 60;
          const exactSecs =
            todayRes.data.liveElapsedSeconds !== undefined
              ? todayRes.data.liveElapsedSeconds
              : Math.max(0, dayjs().diff(dayjs(att.checkInAt), 'second') - breakSecs);
          setLiveSeconds(exactSecs);
        } else if (todayRes.data?.liveElapsedSeconds !== undefined) {
          setLiveSeconds(todayRes.data.liveElapsedSeconds);
        }
      }

      if (salaryRes?.success) {
        setSalaryData(salaryRes.data);
      }
      if (permRes?.success) {
        setPermStatus(permRes.data);
      }
      if (holRes?.success) {
        setHolidays(holRes.data || []);
      }
    } catch (err) {
      console.error('Fetch dashboard data error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleCheckIn() {
    try {
      setActionLoading(true);
      setMessage(null);
      setErrorMessage(null);
      const location = await getCurrentAttendanceLocation();
      const res = await api.post('/attendance/check-in', location);
      setMessage(res.message);
      await fetchAllDashboardData();
    } catch (err) {
      setErrorMessage(err.message || 'Check-in failed.');
    } finally {
      setActionLoading(false);
    }
  }

  async function handleStartBreak() {
    try {
      setActionLoading(true);
      setMessage(null);
      setErrorMessage(null);
      const res = await api.post('/attendance/break-start', {});
      setMessage(res.message);
      await fetchAllDashboardData();
    } catch (err) {
      setErrorMessage(err.message || 'Start break failed.');
    } finally {
      setActionLoading(false);
    }
  }

  async function handleEndBreak() {
    try {
      setActionLoading(true);
      setMessage(null);
      setErrorMessage(null);
      const res = await api.post('/attendance/break-end', {});
      setMessage(res.message);
      await fetchAllDashboardData();
    } catch (err) {
      setErrorMessage(err.message || 'End break failed.');
    } finally {
      setActionLoading(false);
    }
  }

  async function handleCheckOut() {
    if (!window.confirm('Are you sure you want to end your workday and check out?')) {
      return;
    }
    try {
      setActionLoading(true);
      setMessage(null);
      setErrorMessage(null);
      const location = await getCurrentAttendanceLocation();
      const res = await api.post('/attendance/check-out', location);
      setMessage(res.message);
      await fetchAllDashboardData();
    } catch (err) {
      setErrorMessage(err.message || 'Check-out failed.');
    } finally {
      setActionLoading(false);
    }
  }

  const attendance = todayData?.attendance || null;
  const leaveBalances = todayData?.leaveBalances || [];
  const recentRecords = todayData?.recentRecords || [];
  const sessionStatus = attendance?.workSessionStatus || 'NOT_CHECKED_IN';

  const formatTimer = (totalSecs) => {
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const formatCurrency = (val) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val || 0);

  // Dynamic CL Balance from API
  const clBalance = leaveBalances.find((b) => b.leaveType?.code === 'CL')?.remainingDays ?? 0;

  // Next Upcoming Holiday
  const todayStr = dayjs().format('YYYY-MM-DD');
  const nextHoliday = holidays.find((h) => h.date >= todayStr);

  // Compute Salary strictly up to today (no future projections)
  const monthlySalary = salaryData?.config?.monthlySalary || 0;
  const dailyRate = salaryData?.monthSummary?.dailySalary || Math.round((monthlySalary / 30) * 100) / 100;
  const earnedTillToday = salaryData?.dailyBreakdown
    ? salaryData.dailyBreakdown
        .filter((r) => r.date <= todayStr && r.status !== 'NOT_EMPLOYED')
        .reduce((sum, r) => sum + (r.daySalary || 0), 0)
    : salaryData?.monthSummary?.grossEarnings || 0;

  return (
    <div className="employee-dashboard space-y-6">
      {/* 1. TOP WELCOME SECTION */}
      <div className="bg-[#018ABE] rounded-2xl p-6 sm:p-8 border border-[#018ABE] flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 bg-[#FAFFA3] text-[#123B50] px-3 py-1.5 rounded-full text-[11px] font-bold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Employee Self-Service</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome, {user?.employee?.fullName || 'Employee'}
          </h1>
          <div className="flex flex-wrap items-center gap-2.5 mt-3 text-xs text-[#D6EBEE] font-medium">
            <span className="font-semibold text-[#123B50] bg-[#FAFFA3] px-2 py-1 rounded-md">
              {user?.employee?.employeeCode || 'EMP'}
            </span>
            <span>•</span>
            <span>{user?.employee?.designation || 'Staff'}</span>
            <span>•</span>
            <span>{user?.employee?.department || 'Operations'}</span>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-xl bg-[#FAFFA3] px-4 py-3 text-[#123B50] md:min-w-52">
          {user?.employee?.profilePhoto ? (
            <img
              src={user.employee.profilePhoto}
              alt={`${user.employee.fullName || 'Employee'} profile`}
              className="h-11 w-11 rounded-full border border-[#97CADB] object-cover"
            />
          ) : (
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#97CADB] text-lg font-extrabold text-[#123B50]">
              {(user?.employee?.fullName || 'E').charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider">Today</p>
            <p className="mt-0.5 text-sm font-bold">{dayjs().format('ddd, DD MMM YYYY')}</p>
          </div>
        </div>
      </div>

      {/* Notifications / Alerts */}
      {message && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2.5 shadow-sm">
          <CheckCircle2 className="w-4 h-4 text-[#159A73] flex-shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-[#D95C64] text-xs font-semibold flex items-center gap-2.5 shadow-sm">
          <AlertCircle className="w-4 h-4 text-[#D95C64] flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* 2. TODAY'S ATTENDANCE — PRIMARY CARD */}
      <div className="bg-white rounded-2xl p-6 border border-[#97CADB] shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-5 border-b border-[#D6EBEE]">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#17324D]">Today's Attendance</h2>
              <span
                className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${
                  sessionStatus === 'WORKING'
                    ? 'bg-[#D6EBEE] border-[#97CADB] text-[#018ABE]'
                    : sessionStatus === 'ON_BREAK'
                    ? 'bg-[#FAFFA3] border-[#FEF968] text-[#123B50]'
                    : sessionStatus === 'CHECKED_OUT'
                    ? 'bg-slate-100 border-slate-200 text-slate-600'
                    : 'bg-[#D6EBEE] border-[#97CADB] text-[#245A78]'
                }`}
              >
                {sessionStatus === 'WORKING'
                  ? 'Session Active'
                  : sessionStatus === 'ON_BREAK'
                  ? 'On Break'
                  : sessionStatus === 'CHECKED_OUT'
                  ? 'Checked Out'
                  : 'Not Checked In'}
              </span>
            </div>
            <p className="text-xs text-[#64748B] mt-0.5">
              {dayjs().format('dddd, DD MMMM YYYY')}
            </p>
          </div>

          {/* Quick Refresh */}
          <button
            onClick={fetchAllDashboardData}
            disabled={loading}
            className="text-xs text-[#426B7A] hover:text-[#018ABE] flex items-center gap-1.5 font-medium transition-colors cursor-pointer self-start sm:self-auto"
            title="Refresh Attendance Status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#018ABE]' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        {/* 4 Attendance Metrics in Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-5 border-b border-[#D6EBEE]">
          <div>
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Check-In
            </span>
            <span className="text-base sm:text-lg font-bold text-[#123B50] mt-1 font-mono block">
              {attendance?.checkInAt ? dayjs(attendance.checkInAt).format('hh:mm A') : '—'}
            </span>
          </div>

          <div>
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Check-Out
            </span>
            <span className="text-base sm:text-lg font-bold text-[#123B50] mt-1 font-mono block">
              {attendance?.checkOutAt ? dayjs(attendance.checkOutAt).format('hh:mm A') : '—'}
            </span>
          </div>

          <div>
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Break
            </span>
            <span className="text-base sm:text-lg font-bold text-[#123B50] mt-1 font-mono block">
              {attendance?.totalBreakMinutes ? `${attendance.totalBreakMinutes} mins` : '0 mins'}
            </span>
          </div>

          <div>
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Net Working Hours
            </span>
            <span className="text-base sm:text-lg font-bold text-[#018ABE] mt-1 font-mono block">
              {sessionStatus === 'WORKING'
                ? formatTimer(liveSeconds)
                : attendance?.netWorkMinutes
                ? `${Math.floor(attendance.netWorkMinutes / 60)}h ${attendance.netWorkMinutes % 60}m`
                : '—'}
            </span>
          </div>
        </div>

        {/* Attendance Action Buttons */}
        <div className="pt-5 flex flex-wrap items-center gap-3">
          {sessionStatus === 'NOT_CHECKED_IN' && (
            <button
              onClick={handleCheckIn}
              disabled={actionLoading}
              className="px-6 py-2.5 rounded-xl bg-[#018ABE] hover:bg-[#0177A5] text-white text-sm font-semibold transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Clock className="w-4 h-4" />
              <span>{actionLoading ? 'Processing...' : 'Check In'}</span>
            </button>
          )}

          {sessionStatus === 'WORKING' && (
            <>
              <button
                onClick={handleStartBreak}
                disabled={actionLoading}
                className="px-5 py-2.5 rounded-xl bg-[#FEF968] hover:bg-[#FAFFA3] text-[#123B50] border border-[#FEF968] text-sm font-semibold transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Coffee className="w-4 h-4 text-[#123B50]" />
                <span>{actionLoading ? 'Processing...' : 'Start Break'}</span>
              </button>

              <button
                onClick={handleCheckOut}
                disabled={actionLoading}
                className="px-6 py-2.5 rounded-xl bg-[#018ABE] hover:bg-[#0177A5] text-white text-sm font-semibold transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <LogOut className="w-4 h-4" />
                <span>{actionLoading ? 'Processing...' : 'Check Out'}</span>
              </button>
            </>
          )}

          {sessionStatus === 'ON_BREAK' && (
            <button
              onClick={handleEndBreak}
              disabled={actionLoading}
              className="px-6 py-2.5 rounded-xl bg-[#018ABE] hover:bg-[#0177A5] text-white text-sm font-semibold transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Coffee className="w-4 h-4" />
              <span>{actionLoading ? 'Processing...' : 'End Break'}</span>
            </button>
          )}

          {sessionStatus === 'CHECKED_OUT' && (
            <div className="flex items-center gap-2 text-xs font-semibold text-[#159A73] bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-xl">
              <CheckCircle2 className="w-4 h-4" />
              <span>Work session completed for today. Thank you!</span>
            </div>
          )}
        </div>
      </div>

      {/* 3. MONTHLY SUMMARY (EXACTLY 5 COMPACT CARDS) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-bold text-[#64748B] uppercase tracking-wider">
            Monthly Summary ({dayjs().format('MMMM YYYY')})
          </h2>
          <Link
            to={`${portalBase}/attendance`}
            className="text-xs font-semibold text-[#018ABE] hover:underline flex items-center gap-1"
          >
            Attendance Log <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Card 1: Present Days */}
          <div className="bg-white p-4 rounded-xl border border-[#97CADB] shadow-sm">
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Present Days
            </span>
            <div className="text-xl sm:text-2xl font-bold text-[#17324D] mt-1">
              {salaryData?.monthSummary?.presentDays ?? 0}
            </div>
            <span className="text-[10px] text-[#64748B] mt-0.5 block">
              This month
            </span>
          </div>

          {/* Card 3: CL Balance */}
          <div className="bg-white p-4 rounded-xl border border-[#97CADB] shadow-sm">
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              CL Balance
            </span>
            <div className="text-xl sm:text-2xl font-bold text-[#17324D] mt-1">
              {clBalance} Days
            </div>
            <span className="text-[10px] text-[#159A73] font-medium mt-0.5 block">
              Casual leave available
            </span>
          </div>

          {/* Card 4: Permission Status */}
          <div className="bg-white p-4 rounded-xl border border-[#97CADB] shadow-sm">
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Permission
            </span>
            <div className="text-base sm:text-lg font-bold text-[#17324D] mt-1 truncate">
              {permStatus?.isPermissionEligible ? 'Available' : 'Not Available'}
            </div>
            <span className="text-[10px] text-[#64748B] mt-0.5 block truncate">
              Monthly permission status
            </span>
          </div>

          {/* Card 5: Next Holiday */}
          <div className="bg-[#FAFFA3] p-4 rounded-xl border border-[#FEF968] col-span-2 sm:col-span-1">
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider block">
              Next Holiday
            </span>
            <div className="text-sm font-bold text-[#17324D] mt-1 truncate">
              {nextHoliday?.name || 'No upcoming'}
            </div>
            <span className="text-[10px] text-[#159A93] font-semibold mt-0.5 block">
              {nextHoliday?.date ? dayjs(nextHoliday.date).format('DD MMM') : '—'}
            </span>
          </div>
        </div>
      </div>

      {/* 4. SALARY SUMMARY (COMPACT & CLEAN, NO FUTURE PROJECTIONS) */}
      <div className="bg-white rounded-2xl p-5 border border-[#97CADB] shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider block">
              Salary Summary
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-8 mt-2">
              <div>
                <span className="text-[11px] text-[#64748B] block">Monthly Salary</span>
                <span className="text-base font-bold text-[#17324D]">
                  {formatCurrency(monthlySalary)}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-[#64748B] block">Daily Rate</span>
                <span className="text-base font-bold text-[#17324D]">
                  {formatCurrency(dailyRate)}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-[#64748B] block">Earned Till Today</span>
                <span className="text-base font-bold text-[#159A73]">
                  {formatCurrency(earnedTillToday)}
                </span>
              </div>
            </div>
          </div>

          <Link
            to={`${portalBase}/salary`}
            className="px-4 py-2 rounded-xl bg-[#D6EBEE] hover:bg-[#97CADB] text-[#123B50] border border-[#97CADB] text-xs font-bold transition-colors flex items-center justify-center gap-1.5 self-start sm:self-auto"
          >
            <span>View Salary Details</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* 5. RECENT ACTIVITY PREVIEW */}
      {recentRecords.length > 0 && (
        <div className="bg-white rounded-2xl border border-[#97CADB] shadow-sm overflow-hidden">
          <div className="p-4 border-b border-[#DCE7EC] flex items-center justify-between">
            <h3 className="text-xs font-bold text-[#17324D] uppercase tracking-wider">
              Recent Attendance History
            </h3>
            <Link
              to={`${portalBase}/attendance`}
              className="text-xs font-semibold text-[#018ABE] hover:underline"
            >
              View Full History
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#D6EBEE] border-b border-[#97CADB] text-[10px] font-bold text-[#426B7A] uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Check-In</th>
                  <th className="py-2.5 px-4">Check-Out</th>
                  <th className="py-2.5 px-4">Net Hours</th>
                  <th className="py-2.5 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DCE7EC]">
                {recentRecords.slice(0, 5).map((r) => (
                  <tr key={r.id} className="hover:bg-[#D6EBEE]/50 transition-colors">
                    <td className="py-2.5 px-4 font-semibold text-[#17324D]">
                      {dayjs(r.workDate).format('DD MMM YYYY (ddd)')}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-[#64748B]">
                      {r.checkInAt ? dayjs(r.checkInAt).format('hh:mm A') : '—'}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-[#64748B]">
                      {r.checkOutAt ? dayjs(r.checkOutAt).format('hh:mm A') : '—'}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-[#183B56]">
                      {r.netWorkMinutes > 0
                        ? `${Math.floor(r.netWorkMinutes / 60)}h ${r.netWorkMinutes % 60}m`
                        : '—'}
                    </td>
                    <td className="py-2.5 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                          r.attendanceClassification === 'PRESENT'
                            ? 'bg-emerald-50 text-[#159A73] border-emerald-200'
                            : r.attendanceClassification === 'HALF_DAY'
                            ? 'bg-orange-50 text-orange-600 border-orange-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {r.attendanceClassification?.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
