import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ShieldAlert,
  Send,
  Info,
  History,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function ApplyPermission() {
  const [statusData, setStatusData] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [formData, setFormData] = useState({
    date: dayjs().format('YYYY-MM-DD'),
    startTime: '',
    endTime: '',
    reason: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      const [statusRes, historyRes] = await Promise.all([
        api.get('/permissions/status'),
        api.get('/permissions/me'),
      ]);

      if (statusRes.success) {
        setStatusData(statusRes.data);
      }
      if (historyRes.success) {
        setHistory(historyRes.data || []);
      }
    } catch (err) {
      console.error('Error loading permission data:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!statusData?.isPermissionEligible) {
      setError(statusData?.restrictionReason || 'Permission requests are not available at this time.');
      return;
    }

    const start = dayjs(`${formData.date} ${formData.startTime}`);
    const end = dayjs(`${formData.date} ${formData.endTime}`);
    const durationMinutes = end.diff(start, 'minute');
    if (!Number.isFinite(durationMinutes) || durationMinutes <= 0 || durationMinutes > 60) {
      setError('Choose a valid time range of up to 60 minutes.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await api.post('/permissions/apply', {
        permissionDate: formData.date,
        startTime: formData.startTime,
        endTime: formData.endTime,
        durationMinutes,
        reason: formData.reason,
      });
      if (res.success) {
        setSuccessMsg('Your permission request has been submitted for HR/Admin approval.');
        setFormData({
          date: dayjs().format('YYYY-MM-DD'),
          startTime: '',
          endTime: '',
          reason: '',
        });
        await loadData();
      }
    } catch (err) {
      setError(err.message || 'Failed to submit permission request.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-4 border-[#2563EB] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const isEligible = statusData?.isPermissionEligible;
  const maxPermissions = statusData?.maxPermissionAllowance ?? 1;
  const remainingPermissions = statusData?.remainingPermissionAllowances ?? maxPermissions;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">Permission Requests</h1>
          <p className="text-xs text-slate-500 mt-1">
            Request up to 60 minutes away from work for personal or business needs.
          </p>
        </div>
      </div>

      {/* Monthly permission availability */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div
          className={`p-5 rounded-2xl border shadow-sm ${
            isEligible
              ? 'bg-emerald-50/60 border-emerald-200'
              : 'bg-rose-50/60 border-rose-200'
          }`}
        >
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Monthly Permission Requests
          </span>
          <div className="flex items-center gap-2 mt-1">
            {isEligible ? (
              <>
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <span className="text-xl font-extrabold text-emerald-700">{remainingPermissions} available</span>
              </>
            ) : (
              <>
                <XCircle className="w-6 h-6 text-rose-600" />
                <span className="text-xl font-extrabold text-rose-700">Unavailable</span>
              </>
            )}
          </div>
          <span className="text-[11px] text-slate-600 block mt-2">
            {isEligible
              ? `${maxPermissions - remainingPermissions} used of ${maxPermissions}; admin approval required`
              : statusData?.restrictionReason || 'Monthly permission allowance unavailable'}
          </span>
        </div>
      </div>

      {/* Critical Policy Banner if NOT eligible */}
      {!isEligible && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-5 text-rose-900 shadow-sm">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-extrabold text-sm text-rose-900">
                Permission Application Disabled
              </h3>
              <p className="text-xs text-rose-800 font-semibold mt-1">
                {statusData?.restrictionReason || 'Your monthly permission allowance is not available.'}
              </p>
              <p className="text-[11px] text-rose-700 mt-2">
                Pending requests reserve an allowance until approved or rejected.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Application Form & History Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Application Form */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
            <Clock className="w-4 h-4 text-[#2563EB]" />
            Request Permission
          </h2>

          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Permission Date *
              </label>
              <input
                type="date"
                required
                disabled={!isEligible}
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none disabled:bg-slate-100 disabled:cursor-not-allowed"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Start Time *
                </label>
                <input
                  type="time"
                  required
                  disabled={!isEligible}
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none disabled:bg-slate-100 disabled:cursor-not-allowed"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  End Time (Max 60 min) *
                </label>
                <input
                  type="time"
                  required
                  disabled={!isEligible}
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none disabled:bg-slate-100 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Reason / Justification *
              </label>
              <textarea
                required
                rows={3}
                disabled={!isEligible}
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                placeholder="Briefly explain why you need permission"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2563EB] outline-none disabled:bg-slate-100 disabled:cursor-not-allowed resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={!isEligible || submitting}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-[#20266D] to-[#2563EB] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              {submitting ? 'Submitting Application...' : 'Submit Permission Request'}
            </button>
          </form>
        </div>

        {/* Recent Permissions Log */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
              <History className="w-4 h-4 text-emerald-500" />
              Permission Request History
            </h2>

            {history.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-xs">
                No permission requests recorded yet.
              </div>
            ) : (
              <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                {history.map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-800">
                        {dayjs(req.date).format('DD MMM YYYY (ddd)')}
                      </span>
                      <span
                        className={`corp-badge text-[10px] font-bold ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : req.status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                      <Clock className="w-3 h-3 text-[#2563EB]" />
                      <span>{req.startTime} - {req.endTime}</span>
                      <span>({req.durationMinutes || 60} mins)</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-2 italic bg-white p-2 rounded-lg border border-slate-100">
                      "{req.reason}"
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4 p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-[11px] text-blue-900 leading-relaxed">
            <Info className="w-3.5 h-3.5 inline mr-1 text-[#2563EB]" />
            Approved permissions are recorded for administrator review.
          </div>
        </div>
      </div>
    </div>
  );
}
