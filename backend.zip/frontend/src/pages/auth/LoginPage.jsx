import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';
import {
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
} from 'lucide-react';

export default function LoginPage() {
  const { login, logout } = useAuth();
  const navigate = useNavigate();

  // Selected Login Portal: 'ADMIN' | 'HR' | 'EMPLOYEE'
  const [portalRole, setPortalRole] = useState('ADMIN');

  const [identifier, setIdentifier] = useState('admin@saishnaa.com');
  const [password, setPassword] = useState('Admin@Saishnaa2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Forgot Password Modal State
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState('');
  const [forgotError, setForgotError] = useState('');
  const [devResetToken, setDevResetToken] = useState('');

  // Role selection handler
  function handleSelectRole(role) {
    setPortalRole(role);
    setErrorMessage('');
    if (role === 'ADMIN') {
      setIdentifier('admin@saishnaa.com');
      setPassword('Admin@Saishnaa2026!');
    } else if (role === 'HR') {
      setIdentifier('hr@saishnaa.com');
      setPassword('Hr@Saishnaa2026!');
    } else {
      setIdentifier('');
      setPassword('');
    }
  }

  function handleFillCredentials(role) {
    handleSelectRole(role);
  }

  async function handleLogin(e) {
    e.preventDefault();
    setErrorMessage('');

    if (!identifier.trim() || !password) {
      setErrorMessage('Login ID and password are required.');
      return;
    }

    try {
      setLoading(true);
      const user = await login(identifier.trim(), password, rememberMe);

      // Portal Role Validation with friendly directions
      if (portalRole === 'ADMIN' && user.role !== 'ADMIN') {
        await logout();
        setErrorMessage('This account is registered as Employee. Please switch to the Employee Portal tab above.');
        return;
      }
      if (portalRole === 'HR' && user.role !== 'HR' && user.role !== 'ADMIN') {
        await logout();
        setErrorMessage('This account is not authorized for the HR Portal.');
        return;
      }
      if (portalRole === 'EMPLOYEE' && user.role !== 'EMPLOYEE') {
        await logout();
        setErrorMessage('This account is not registered as an Employee. Please sign in through its assigned portal.');
        return;
      }

      // Role-authorized redirects
      if (user.role === 'ADMIN') {
        navigate('/admin/dashboard');
      } else if (user.role === 'HR') {
        navigate('/hr/my-dashboard');
      } else {
        navigate('/employee/dashboard');
      }
    } catch (err) {
      setErrorMessage(err.message || 'Invalid credentials. Please verify your email/employee code and password.');
    } finally {
      setLoading(false);
    }
  }

  async function handleForgotPassword(e) {
    e.preventDefault();
    setForgotSuccess('');
    setForgotError('');
    setDevResetToken('');

    if (!forgotEmail.trim()) {
      setForgotError('Please enter your registered corporate email.');
      return;
    }

    try {
      setForgotLoading(true);
      const res = await api.post('/auth/forgot-password', { email: forgotEmail.trim() });
      setForgotSuccess(res.message || 'Password reset link dispatched if account exists.');
      if (res.data?.devResetToken) {
        setDevResetToken(res.data.devResetToken);
      }
    } catch (err) {
      setForgotError(err.message || 'Failed to dispatch reset link.');
    } finally {
      setForgotLoading(false);
    }
  }

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 lg:p-8 font-sans selection:bg-[#D9531E] selection:text-white bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(7, 24, 40, 0.72) 0%, rgba(7, 28, 46, 0.65) 50%, rgba(5, 17, 30, 0.82) 100%), url('/assets/meeting-table-bg.png')`,
      }}
    >
      {/* Centered Split Card (Matching Reference UI Design) */}
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-white/20 grid grid-cols-1 md:grid-cols-2 min-h-[580px] z-10 backdrop-blur-xs">
        {/* LEFT COLUMN: Attendance Calendar & Schedule Illustration */}
        <div className="relative hidden md:flex flex-col items-center justify-center bg-gradient-to-br from-blue-50/70 via-sky-50/40 to-indigo-50/50 p-8 lg:p-10 border-r border-slate-100 overflow-hidden">
          <div className="w-full max-w-sm flex items-center justify-center py-2">
            <img
              src="/assets/attendance-schedule-illustration.png"
              alt="Saishnaa Attendance Management System"
              className="w-full h-auto max-h-[350px] object-contain drop-shadow-md transition-transform duration-300 hover:scale-[1.02]"
            />
          </div>
          <div className="mt-4 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 border border-teal-200/60 text-[#075E59] font-bold text-xs tracking-wide">
              <span className="w-2 h-2 rounded-full bg-[#18B8B2] animate-pulse"></span>
              Smart Attendance & Workforce Management
            </div>
            <p className="text-xs text-slate-500 mt-2 max-w-xs mx-auto leading-relaxed">
              Real-time attendance, leave management, and payroll tracking.
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN: Sign In Form */}
        <div className="p-6 sm:p-10 lg:p-12 flex flex-col justify-between bg-white">
          <div>
            {/* Top Branding Header - Separate row, ZERO overlap */}
            <div className="flex items-center gap-2.5 mb-5">
              <img
                src="/assets/saishnaa-logo.png"
                alt="Saishnaa Software Solutions"
                className="h-15 w-auto object-contain items-center justify-center"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling.style.display = 'flex';
                }}
              />
              <div className="hidden w-8 h-8 rounded-lg bg-[#D9531E] items-center justify-center font-black text-white text-base">
                S
              </div>
            </div>

            {/* Title & Subtitle */}
            <div className="mb-4">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Sign into your account
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                Enter your credentials to access your workplace portal.
              </p>
            </div>

            {/* Quick Role Switcher Segmented Control */}
            <div className="mb-5 p-1 bg-slate-100 rounded-xl">
              <div className="grid grid-cols-3 gap-1 text-[11px] font-semibold">
                <button
                  type="button"
                  onClick={() => handleFillCredentials('ADMIN')}
                  className={`py-1.5 rounded-lg transition-all cursor-pointer text-center ${
                    portalRole === 'ADMIN'
                      ? 'bg-white text-slate-900 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Admin
                </button>
                <button
                  type="button"
                  onClick={() => handleFillCredentials('HR')}
                  className={`py-1.5 rounded-lg transition-all cursor-pointer text-center ${
                    portalRole === 'HR'
                      ? 'bg-white text-slate-900 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  HR
                </button>
                <button
                  type="button"
                  onClick={() => handleFillCredentials('EMPLOYEE')}
                  className={`py-1.5 rounded-lg transition-all cursor-pointer text-center ${
                    portalRole === 'EMPLOYEE'
                      ? 'bg-white text-slate-900 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Employee
                </button>
              </div>
            </div>

            {/* Error Message Box */}
            {errorMessage && (
              <div className="mb-5 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs font-medium flex items-start gap-2 animate-shake">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Sign-in Form */}
            <form onSubmit={handleLogin} className="space-y-4">
              {/* Email Address or Employee Code */}
              <div>
                <label
                  htmlFor="login-email"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  {portalRole === 'EMPLOYEE' ? 'Email Address or Employee Code' : 'Email address'}
                </label>
                <input
                  id="login-email"
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={
                    portalRole === 'ADMIN'
                      ? 'admin@saishnaa.com'
                      : portalRole === 'HR'
                      ? 'hr@saishnaa.com'
                      : 'Enter your registered email or employee code'
                  }
                  className="w-full h-11 px-3.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all font-normal"
                />
                {portalRole === 'EMPLOYEE' && (
                  <p className="text-[10px] text-slate-400 mt-1">
                    Use the login details issued when Admin or HR created your employee account.
                  </p>
                )}
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="login-password"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setForgotModalOpen(true)}
                    className="text-xs text-slate-500 hover:text-slate-900 transition-colors font-medium cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-11 pl-3.5 pr-10 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all font-normal"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-700 focus:outline-none cursor-pointer"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center gap-2 pt-0.5">
                <input
                  type="checkbox"
                  id="rememberMe"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 accent-slate-900 rounded cursor-pointer"
                />
                <label
                  htmlFor="rememberMe"
                  className="text-xs text-slate-600 cursor-pointer select-none font-medium"
                >
                  Remember Me
                </label>
              </div>

              {/* Solid Black "Login" Button matching reference image */}
              <div className="pt-2">
                <button
                  type="submit"
                  id="login-submit-button"
                  disabled={loading}
                  className="w-full h-11 bg-slate-900 hover:bg-black text-white font-bold text-sm rounded-lg transition-all duration-150 shadow-sm hover:shadow active:scale-[0.99] disabled:opacity-60 cursor-pointer flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Logging in...</span>
                    </div>
                  ) : (
                    <span>Login</span>
                  )}
                </button>
              </div>

              {/* Administrator Managed Account Notice */}
              <div className="text-center pt-2">
                <p className="text-xs text-slate-500">
                  Need account access?{' '}
                  <span className="text-slate-900 font-semibold">
                    Contact System Administrator
                  </span>
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Account creation and deactivation are managed by Administrator only.
                </p>
              </div>
            </form>
          </div>

          {/* Footer Note matching reference card bottom */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            <span>© 2026 Saishnaa Software</span>
            <div className="flex items-center gap-2">
              <span className="hover:text-slate-600 cursor-pointer">Terms of use</span>
              <span>•</span>
              <span className="hover:text-slate-600 cursor-pointer">Privacy policy</span>
            </div>
          </div>
        </div>
      </div>

      {/* FORGOT PASSWORD MODAL */}
      {forgotModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-white/20 text-white rounded-2xl max-w-md w-full p-6 shadow-2xl overflow-hidden backdrop-blur-xl">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#D9531E]/20 text-[#D9531E] flex items-center justify-center border border-[#D9531E]/40">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Reset Account Access</h4>
                  <p className="text-xs text-white/70">Provide your registered corporate email</p>
                </div>
              </div>
              <button
                onClick={() => setForgotModalOpen(false)}
                className="text-white/60 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {forgotError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-950/80 text-rose-200 text-xs font-medium border border-rose-500/40">
                {forgotError}
              </div>
            )}

            {forgotSuccess && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-950/80 text-emerald-200 text-xs font-medium border border-emerald-500/40 break-all">
                {forgotSuccess}
              </div>
            )}

            {devResetToken && (
              <div className="mb-4 p-3.5 rounded-lg bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs space-y-2">
                <div className="font-bold flex items-center gap-1.5 text-amber-300">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Password Reset Link (Local System)</span>
                </div>
                <div className="p-2 bg-black/40 rounded border border-white/15 font-mono text-[11px] break-all text-white select-all">
                  {window.location.origin}/reset-password?token={devResetToken}
                </div>
                <a
                  href={`/reset-password?token=${devResetToken}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#D9531E] text-white rounded font-bold text-xs hover:bg-[#C24412] transition shadow-xs cursor-pointer"
                >
                  <span>Open Reset Password Page →</span>
                </a>
              </div>
            )}

            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-white/90 mb-1.5">
                  Corporate Email
                </label>
                <input
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="name@saishnaa.com"
                  className="w-full px-3.5 py-2.5 bg-white text-slate-900 rounded-lg text-xs sm:text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#D9531E]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setForgotModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-white/80 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="px-5 py-2 rounded-lg bg-[#D9531E] hover:bg-[#C24412] text-white text-xs font-bold shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {forgotLoading ? 'Dispatching...' : 'Send Reset Link'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
