import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import AppFooter from '../../components/AppFooter';
import { ShieldCheck, Lock, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

export default function ActivateAccountPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') || '';

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Password requirement checks
  const hasMinLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);
  const passwordsMatch = password && password === confirmPassword;
  const isFormValid =
    hasMinLength && hasUpper && hasLower && hasNumber && hasSpecial && passwordsMatch && token;

  async function handleActivate(e) {
    e.preventDefault();
    setErrorMessage('');
    if (!token) {
      setErrorMessage('Missing activation token. Please request a new link from HR.');
      return;
    }
    if (!passwordsMatch) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    try {
      setLoading(true);
      const res = await api.post('/auth/activate', { token, password });
      setSuccessMessage(
        res.message || 'Account activated successfully! Redirecting to login portal...'
      );
      setTimeout(() => {
        navigate('/login');
      }, 2500);
    } catch (err) {
      setErrorMessage(err.message || 'Activation failed. The link may have expired.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col sm:px-6 lg:px-8">
      <div className="flex-1 w-full flex flex-col justify-center py-12">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center mb-5">
          <img
            src="/assets/saishnaa-logo.png"
            alt="Saishnaa Software Solutions"
            className="h-16 w-auto max-w-[320px] object-contain drop-shadow-sm"
          />
        </div>
        <h2 className="text-center text-xl font-extrabold text-[#20266D] tracking-tight uppercase">
          Account Activation Portal
        </h2>
        <p className="mt-1 text-center text-xs font-bold text-[#3563E9] uppercase tracking-widest">
          Smart Office Attendance & Payroll System
        </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white shadow-[0_15px_35px_-5px_rgba(32,38,109,0.10),0_4px_10px_-2px_rgba(0,0,0,0.03)] rounded-2xl border border-slate-200/90 overflow-hidden">
          <div className="h-1.5 w-full bg-gradient-to-r from-[#20266D] via-[#3563E9] to-[#37B086]"></div>
          <div className="py-8 px-6 sm:px-10">
          {successMessage ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-800">Account Activated!</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{successMessage}</p>
            </div>
          ) : (
            <form className="space-y-5" onSubmit={handleActivate}>
              {errorMessage && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Set Your New Password
                </label>
                <div className="relative rounded-xl shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter strong password"
                    className="block w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Confirm Password
                </label>
                <div className="relative rounded-xl shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="block w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                  />
                </div>
              </div>

              {/* Password checklist */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 text-[11px]">
                <div className="font-bold text-slate-700 mb-1">Security Criteria:</div>
                <div className={`flex items-center gap-1.5 ${hasMinLength ? 'text-emerald-600 font-semibold' : 'text-slate-400'}`}>
                  <span>{hasMinLength ? '✓' : '○'}</span> At least 8 characters
                </div>
                <div className={`flex items-center gap-1.5 ${hasUpper && hasLower ? 'text-emerald-600 font-semibold' : 'text-slate-400'}`}>
                  <span>{hasUpper && hasLower ? '✓' : '○'}</span> Uppercase & lowercase letters
                </div>
                <div className={`flex items-center gap-1.5 ${hasNumber && hasSpecial ? 'text-emerald-600 font-semibold' : 'text-slate-400'}`}>
                  <span>{hasNumber && hasSpecial ? '✓' : '○'}</span> Number & special symbol (@#$%!)
                </div>
                <div className={`flex items-center gap-1.5 ${passwordsMatch ? 'text-emerald-600 font-semibold' : 'text-slate-400'}`}>
                  <span>{passwordsMatch ? '✓' : '○'}</span> Passwords match
                </div>
              </div>

              <button
                type="submit"
                disabled={!isFormValid || loading}
                className="w-full corp-btn-primary py-3 text-sm font-bold"
              >
                {loading ? 'Activating Account...' : 'Set Password & Activate'}
              </button>
            </form>
          )}
          </div>
        </div>
        </div>
      </div>

      <AppFooter />
    </div>
  );
}
