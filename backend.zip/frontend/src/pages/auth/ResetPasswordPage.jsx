import React, { useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import api from '../../services/api';
import AppFooter from '../../components/AppFooter';
import { Lock, CheckCircle2, AlertCircle, ArrowRight, Eye, EyeOff } from 'lucide-react';

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') || '';

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Password requirement checks
  const hasMinLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);
  const passwordsMatch = password && password === confirmPassword;
  const isFormValid =
    hasMinLength && hasUpper && hasLower && hasNumber && hasSpecial && passwordsMatch && token;

  async function handleResetPassword(e) {
    e.preventDefault();
    setErrorMessage('');

    if (!token) {
      setErrorMessage('Missing password reset token. Please request a new link from the login page.');
      return;
    }
    if (!passwordsMatch) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (!hasMinLength || !hasUpper || !hasLower || !hasNumber || !hasSpecial) {
      setErrorMessage('Please satisfy all corporate password complexity requirements.');
      return;
    }

    try {
      setLoading(true);
      const res = await api.post('/auth/reset-password', { token, password });
      setSuccessMessage(
        res.message || 'Password reset successfully! Redirecting to login portal...'
      );
      setTimeout(() => {
        navigate('/login');
      }, 2500);
    } catch (err) {
      setErrorMessage(err.message || 'Password reset failed. The link may be invalid or expired.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col sm:px-6 lg:px-8">
      <div className="flex-1 w-full flex flex-col justify-center py-12">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center mb-5">
          <img
            src="/assets/saishnaa-logo.png"
            alt="Saishnaa Logo"
            className="h-10 w-auto object-contain"
            onError={(e) => {
              e.target.style.display = 'none';
            }}
          />
        </div>
        <h2 className="text-center text-2xl font-black text-[#20266D] tracking-tight">
          Reset Account Password
        </h2>
        <p className="mt-1 text-center text-xs text-slate-500">
          Set a secure permanent password to regain account access
        </p>
        </div>

        <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xl border border-slate-200/80 rounded-3xl sm:px-10 relative overflow-hidden">
          {/* Top Corporate Accent Bar */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#20266D] via-[#3563E9] to-[#37B086]"></div>

          {errorMessage && (
            <div className="mb-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {!token ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto border border-amber-200">
                <Lock className="w-6 h-6" />
              </div>
              <p className="text-xs text-slate-600">
                No reset token provided. Please use the "Forgot Password" link on the login page to request a valid link.
              </p>
              <Link
                to="/login"
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#20266D] text-white rounded-xl text-xs font-bold hover:bg-[#151a4f] transition"
              >
                Return to Login
              </Link>
            </div>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter new strong password"
                    className="w-full px-3.5 py-2.5 bg-slate-50/70 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3563E9] focus:bg-white pr-10 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Confirm New Password
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full px-3.5 py-2.5 bg-slate-50/70 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3563E9] focus:bg-white font-mono"
                />
              </div>

              {/* Security Checklist */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-[11px]">
                <div className="text-slate-500 font-bold uppercase tracking-wider text-[10px] mb-1">
                  Password Complexity Criteria
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                  <span className={hasMinLength ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ 8+ Characters
                  </span>
                  <span className={hasUpper ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ Uppercase Letter (A-Z)
                  </span>
                  <span className={hasLower ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ Lowercase Letter (a-z)
                  </span>
                  <span className={hasNumber ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ Number (0-9)
                  </span>
                  <span className={hasSpecial ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ Special Character (!@#$)
                  </span>
                  <span className={passwordsMatch ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                    ✓ Passwords Match
                  </span>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !isFormValid}
                className="w-full py-2.5 px-4 bg-gradient-to-r from-[#20266D] to-[#3563E9] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
              >
                {loading ? (
                  <span>Updating Password...</span>
                ) : (
                  <>
                    <span>Confirm & Reset Password</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>

              <div className="text-center pt-2">
                <Link to="/login" className="text-xs text-slate-500 hover:text-[#20266D] font-medium">
                  ← Back to Login
                </Link>
              </div>
            </form>
          )}
        </div>
        </div>
      </div>

      <AppFooter />
    </div>
  );
}
