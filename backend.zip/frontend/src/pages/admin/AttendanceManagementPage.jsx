import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  CalendarCheck,
  UserCheck,
  UserX,
  Search,
  Filter,
  Calendar,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  X,
  Download,
  Plus,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function AttendanceManagementPage() {
  const [attendance, setAttendance] = useState([]);
  const [selectedDate, setSelectedDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Master-Detail selected attendance record
  const [selectedRecord, setSelectedRecord] = useState(null);

  // Edit Attendance Modal
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [newRecord, setNewRecord] = useState({
    employeeId: '',
    checkIn: '',
    checkOut: '',
    status: 'Present',
    remarks: '',
  });
  const [editFormData, setEditFormData] = useState({
    id: '',
    fullName: '',
    employeeCode: '',
    department: '',
    checkIn: '',
    checkOut: '',
    status: 'Present',
    remarks: '',
  });

  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadAttendance();
    window.addEventListener('saishnaa_store_updated', loadAttendance);
    return () => window.removeEventListener('saishnaa_store_updated', loadAttendance);
  }, [selectedDate]);

  function loadAttendance() {
    const list = adminStore.getAttendance(selectedDate);
    setAttendance(list);
    setSelectedRecord(list.find((a) => a.id === selectedRecord?.id) || list[0] || null);
  }

  // Summary Metrics
  const presentCount = attendance.filter((a) => a.status === 'Present' || a.status === 'On Time').length;
  const absentCount = attendance.filter((a) => a.status === 'Absence' || a.status === 'Absent').length;
  const leaveCount = attendance.filter((a) => a.status === 'On Leave' || a.status === 'Half Day').length;

  // Filtered attendance list
  const filteredAttendance = attendance.filter((row) => {
    const matchesSearch =
      row.fullName.toLowerCase().includes(search.toLowerCase()) ||
      row.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
      row.department.toLowerCase().includes(search.toLowerCase());
    const matchesDept = selectedDept === 'ALL' || row.department === selectedDept;
    const matchesStatus =
      selectedStatus === 'ALL' ||
      (selectedStatus === 'PRESENT' && (row.status === 'Present' || row.status === 'On Time')) ||
      (selectedStatus === 'ABSENT' && (row.status === 'Absence' || row.status === 'Absent')) ||
      (selectedStatus === 'LEAVE' && (row.status === 'On Leave' || row.status === 'Half Day'));
    return matchesSearch && matchesDept && matchesStatus;
  });

  function handleOpenEdit(rec, e) {
    if (e) e.stopPropagation();
    setEditFormData({
      id: rec.id,
      fullName: rec.fullName,
      employeeCode: rec.employeeCode,
      department: rec.department,
      checkIn: rec.checkIn === '--' ? '' : rec.checkIn,
      checkOut: rec.checkOut === '--' ? '' : rec.checkOut,
      status: rec.status,
      remarks: rec.remarks || '',
    });
    setEditModalOpen(true);
  }

  function handleSaveEdit(e) {
    e.preventDefault();
    const updated = adminStore.updateAttendance(editFormData.id, {
      checkIn: editFormData.checkIn,
      checkOut: editFormData.checkOut,
      status: editFormData.status,
      remarks: editFormData.remarks,
    });

    if (updated) {
      setSelectedRecord(updated);
      setToastMsg(`Attendance updated for ${updated.fullName}! Working hours recalculated.`);
      setEditModalOpen(false);
      setTimeout(() => setToastMsg(''), 4000);
    }
  }

  function handleOpenAdd() {
    setEmployees(adminStore.getEmployees());
    setNewRecord({ employeeId: '', checkIn: '', checkOut: '', status: 'Present', remarks: '' });
    setAddModalOpen(true);
  }

  function handleSaveNewRecord(e) {
    e.preventDefault();
    const added = adminStore.addAttendance({ ...newRecord, date: selectedDate });
    if (!added) {
      setToastMsg('This employee already has an attendance record for the selected date.');
      setTimeout(() => setToastMsg(''), 4000);
      return;
    }
    setSelectedRecord(added);
    setAddModalOpen(false);
    setToastMsg(`Attendance recorded for ${added.fullName}.`);
    setTimeout(() => setToastMsg(''), 4000);
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarCheck className="w-6 h-6 text-[#16A34A]" />
            Attendance Management Log
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Record actual check-in and check-out times, review attendance, and make manual corrections.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleOpenAdd}
            disabled={adminStore.getEmployees().length === 0}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] disabled:opacity-50 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Record Attendance
          </button>
        </div>
      </div>

      {/* 2. SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Present Card - Pastel Green */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">Present</p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{presentCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Recorded attendance</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Absent Card - Pastel Pink */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">Absent</p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">{absentCount}</h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">Unexcused & Leaves</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <UserX className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">On Leave / Half Day</p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">{leaveCount}</h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Recorded leave statuses</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* 3. SEARCH & FILTERS BAR */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search employee, ID, department..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Date Picker */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700">
            <Calendar className="w-3.5 h-3.5 text-[#16A34A]" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent focus:outline-none text-xs font-medium text-slate-800 cursor-pointer"
            />
          </div>

          {/* Department Filter */}
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Departments</option>
            <option value="Engineering">Engineering</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Product & Design">Product & Design</option>
            <option value="Quality Assurance">Quality Assurance</option>
            <option value="Marketing & Sales">Marketing & Sales</option>
            <option value="Finance & Accounts">Finance & Accounts</option>
            <option value="Operations">Operations</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Statuses</option>
            <option value="PRESENT">Present</option>
            <option value="ABSENT">Absence</option>
            <option value="LEAVE">On Leave / Half Day</option>
          </select>
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Attendance Table */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Attendance Register</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredAttendance.length} records for {selectedDate}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Check-In</th>
                  <th className="py-3 px-4">Check-Out</th>
                  <th className="py-3 px-4">Work Hours</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAttendance.map((row) => {
                  const isSelected = selectedRecord?.id === row.id;

                  // Color-coded badges for regular attendance statuses.
                  let badgeClass = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
                  if (row.status === 'Absence' || row.status === 'Absent') {
                    badgeClass = 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]';
                  } else if (row.status === 'Half Day' || row.status === 'On Leave') {
                    badgeClass = 'bg-[#EFF6FF] text-[#1E40AF] border-[#BFDBFE]';
                  }

                  return (
                    <tr
                      key={row.id}
                      onClick={() => setSelectedRecord(row)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {row.fullName}
                        <span className="block text-[10px] text-slate-400 font-mono font-normal">
                          {row.employeeCode} · {row.department}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{row.date}</td>
                      <td className="py-3.5 px-4 font-mono font-medium text-slate-800">
                        {row.checkIn}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-medium text-slate-800">
                        {row.checkOut}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">{row.workingHours}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}
                        >
                          {row.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => handleOpenEdit(row, e)}
                          className="px-2.5 py-1 text-xs font-bold text-[#16A34A] hover:bg-[#DCFCE7] rounded-lg transition-colors inline-flex items-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" />
                          Edit
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Employee Attendance Metrics & Logs */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Attendance Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedRecord ? selectedRecord.fullName : 'Select an employee'}
              </h3>
            </div>
            {selectedRecord && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-md border bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]">
                {selectedRecord.status}
              </span>
            )}
          </div>

          {selectedRecord ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Position:</span>
                  <span className="font-semibold text-slate-800">{selectedRecord.designation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Department:</span>
                  <span className="font-semibold text-slate-800">{selectedRecord.department}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee Code:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedRecord.employeeCode}
                  </span>
                </div>
              </div>

              {/* Punch Timings & Calculated Hours */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Check-In Time:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedRecord.checkIn}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Check-Out Time:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedRecord.checkOut}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-100 pt-2">
                  <span className="text-slate-700 font-bold">Working Duration:</span>
                  <span className="font-bold text-[#16A34A]">{selectedRecord.workingHours}</span>
                </div>
                <div className="pt-1">
                  <span className="text-[10px] text-slate-400 block font-bold">Remarks:</span>
                  <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded border border-slate-100 mt-0.5">
                    {selectedRecord.remarks || 'Standard biometric record logged.'}
                  </p>
                </div>
              </div>

              {/* Attendance History */}
              <div className="space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Past Days Punch History
                </p>
                <div className="space-y-1.5">
                  {(selectedRecord.history && selectedRecord.history.length > 0
                    ? selectedRecord.history
                    : [
                        { date: 'Yesterday', checkIn: '09:05 AM', checkOut: '06:10 PM', hours: '9h 05m' },
                        { date: '2 days ago', checkIn: '09:12 AM', checkOut: '06:15 PM', hours: '9h 03m' },
                      ]
                  ).map((h, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between text-[11px]"
                    >
                      <span className="font-medium text-slate-700">{h.date}</span>
                      <span className="font-mono text-slate-500">
                        {h.checkIn} - {h.checkOut}
                      </span>
                      <span className="font-bold text-[#16A34A]">{h.hours}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Edit Attendance Button */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => handleOpenEdit(selectedRecord)}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center text-xs flex items-center justify-center gap-1.5"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit Attendance Record
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click an employee row to view attendance details.
            </p>
          )}
        </div>
      </div>

      {/* EDIT ATTENDANCE MODAL (RECALCULATES WORKING HOURS AUTOMATICALLY) */}
      {addModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-4">Record Attendance</h3>
            <form onSubmit={handleSaveNewRecord} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Employee *</label>
                <select
                  required
                  value={newRecord.employeeId}
                  onChange={(e) => setNewRecord({ ...newRecord, employeeId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                >
                  <option value="">Select employee</option>
                  {employees.map((employee) => (
                    <option key={employee.id} value={employee.id}>
                      {employee.fullName} ({employee.employeeCode})
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Check-In</label>
                  <input
                    type="time"
                    value={newRecord.checkIn}
                    onChange={(e) => setNewRecord({ ...newRecord, checkIn: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Check-Out</label>
                  <input
                    type="time"
                    value={newRecord.checkOut}
                    onChange={(e) => setNewRecord({ ...newRecord, checkOut: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Attendance Status *</label>
                <select
                  value={newRecord.status}
                  onChange={(e) => setNewRecord({ ...newRecord, status: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                >
                  <option value="Present">Present</option>
                  <option value="Half Day">Half Day</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Absence">Absent</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Notes</label>
                <textarea
                  rows="3"
                  value={newRecord.remarks}
                  onChange={(e) => setNewRecord({ ...newRecord, remarks: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button type="button" onClick={() => setAddModalOpen(false)} className="px-4 py-2 rounded-xl text-slate-600 font-bold hover:bg-slate-100">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D]">
                  Save Attendance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {editModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-[#16A34A]" />
                Edit Attendance Record
              </h3>
              <button
                onClick={() => setEditModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 pt-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-800">{editFormData.fullName}</p>
                <p className="text-[11px] text-slate-500">
                  {editFormData.employeeCode} · {editFormData.department}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Check-In Time *</label>
                  <input
                    type="text"
                    required
                    placeholder="09:00 AM"
                    value={editFormData.checkIn}
                    onChange={(e) => setEditFormData({ ...editFormData, checkIn: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Check-Out Time *</label>
                  <input
                    type="text"
                    required
                    placeholder="06:00 PM"
                    value={editFormData.checkOut}
                    onChange={(e) => setEditFormData({ ...editFormData, checkOut: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Attendance Status *</label>
                <select
                  value={editFormData.status}
                  onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                >
                  <option value="Present">Present</option>
                  <option value="Half Day">Half Day</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Absence">Absence</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Correction Remarks</label>
                <textarea
                  rows="3"
                  placeholder="Reason for manual modification (e.g. Biometric gate error verified by HR)"
                  value={editFormData.remarks}
                  onChange={(e) => setEditFormData({ ...editFormData, remarks: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors shadow-xs"
                >
                  Save & Recalculate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
