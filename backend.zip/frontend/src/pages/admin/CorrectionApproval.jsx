import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  FileEdit,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  AlertCircle,
  X,
  History,
  ShieldCheck,
} from 'lucide-react';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(utc);
dayjs.extend(timezone);

const OFFICE_TIMEZONE = 'Asia/Kolkata';
const formatOfficeTime = (timestamp) =>
  dayjs(timestamp).tz(OFFICE_TIMEZONE).format('hh:mm A');

export default function CorrectionApproval() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('PENDING');

  const [compareModalOpen, setCompareModalOpen] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [decisionStatus, setDecisionStatus] = useState('APPROVED');
  const [comments, setComments] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState('');

  useEffect(() => {
    fetchCorrections();
  }, [statusFilter]);

  async function fetchCorrections() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (statusFilter) params.append('status', statusFilter);

      const res = await api.get(`/attendance/corrections/admin?${params.toString()}`);
      if (res.success) {
        setRequests(res.data.requests || []);
      }
    } catch (err) {
      console.error('Fetch corrections error:', err);
    } finally {
      setLoading(false);
    }
  }

  function openCompareModal(request, status = 'APPROVED') {
    setSelectedRequest(request);
    setDecisionStatus(status);
    setComments('');
    setActionError('');
    setCompareModalOpen(true);
  }

  async function handleDecisionSubmit(e) {
    e.preventDefault();
    setActionError('');
    try {
      setActionLoading(true);
      const res = await api.patch(
        `/attendance/corrections/admin/${selectedRequest.id}/decision`,
        {
          status: decisionStatus,
          reviewerComments: comments,
        }
      );
      if (res.success) {
        setCompareModalOpen(false);
        await fetchCorrections();
      }
    } catch (err) {
      setActionError(err.message || 'Failed to apply decision.');
    } finally {
      setActionLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">
            Attendance Correction Queue
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Compare and approve employee punch rectifications with full audit trail history
          </p>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-1">
          <button
            onClick={() => setStatusFilter('PENDING')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'PENDING'
                ? 'bg-[#20266D] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setStatusFilter('APPROVED')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'APPROVED'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Approved
          </button>
          <button
            onClick={() => setStatusFilter('REJECTED')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'REJECTED'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Rejected
          </button>
          <button
            onClick={() => setStatusFilter('')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === ''
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All
          </button>
        </div>
      </div>

      {/* Corrections Table */}
      <div className="corp-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Attendance Date</th>
                <th className="py-3 px-4">Correction Type</th>
                <th className="py-3 px-4">Reason Given</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Review Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Loading correction queue...
                  </td>
                </tr>
              ) : requests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    No correction requests found matching filter.
                  </td>
                </tr>
              ) : (
                requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Employee */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{r.employee?.fullName}</div>
                      <div className="text-[11px] font-mono text-slate-500">
                        {r.employee?.employeeCode} • {r.employee?.department?.name}
                      </div>
                    </td>

                    {/* Attendance Date */}
                    <td className="py-3 px-4 font-mono font-medium text-slate-800">
                      {dayjs(r.attendanceDate).format('DD MMM YYYY')}
                    </td>

                    {/* Type */}
                    <td className="py-3 px-4">
                      <span className="corp-badge bg-blue-50 text-blue-700 font-semibold">
                        {r.correctionType.replace('_', ' ')}
                      </span>
                    </td>

                    {/* Reason */}
                    <td className="py-3 px-4 max-w-xs">
                      <div className="text-slate-700 truncate" title={r.reason}>
                        {r.reason}
                      </div>
                      {r.reviewerComments && (
                        <div className="text-[10px] text-slate-400 italic mt-0.5">
                          Remark: "{r.reviewerComments}"
                        </div>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`corp-badge ${
                          r.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      {r.status === 'PENDING' ? (
                        <button
                          onClick={() => openCompareModal(r, 'APPROVED')}
                          className="corp-btn-primary text-xs py-1.5 px-3"
                        >
                          <span>Compare & Decide</span>
                        </button>
                      ) : (
                        <span className="text-[11px] font-mono text-slate-400">
                          {r.reviewedAt ? dayjs(r.reviewedAt).format('DD MMM, hh:mm A') : 'Decided'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Side-by-Side Comparison Modal */}
      {compareModalOpen && selectedRequest && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-extrabold text-[#20266D]">
                  Compare Attendance Values
                </h3>
                <p className="text-xs text-slate-500">
                  Employee: {selectedRequest.employee?.fullName} ({selectedRequest.employee?.employeeCode})
                </p>
              </div>
              <button
                onClick={() => setCompareModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {actionError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {actionError}
              </div>
            )}

            {/* Side-by-Side Table Comparison */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              {/* Original Punches */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Original Logged Values
                </div>
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400">Check-In:</span>
                    <div className="font-mono font-bold text-slate-800">
                      {selectedRequest.originalCheckInAt
                        ? formatOfficeTime(selectedRequest.originalCheckInAt)
                        : 'Missing / No punch'}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">Check-Out:</span>
                    <div className="font-mono font-bold text-slate-800">
                      {selectedRequest.originalCheckOutAt
                        ? formatOfficeTime(selectedRequest.originalCheckOutAt)
                        : 'Missing / No punch'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Requested Punches */}
              <div className="bg-blue-50/60 p-4 rounded-xl border border-blue-200">
                <div className="text-xs font-bold text-[#2563EB] uppercase tracking-wider mb-2">
                  Requested Values
                </div>
                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-blue-500">Check-In:</span>
                    <div className="font-mono font-bold text-blue-900">
                      {selectedRequest.requestedCheckInAt
                        ? formatOfficeTime(selectedRequest.requestedCheckInAt)
                        : 'Unchanged'}
                    </div>
                  </div>
                  <div>
                    <span className="text-blue-500">Check-Out:</span>
                    <div className="font-mono font-bold text-blue-900">
                      {selectedRequest.requestedCheckOutAt
                        ? formatOfficeTime(selectedRequest.requestedCheckOutAt)
                        : 'Unchanged'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Employee Justification */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-xs mb-4">
              <span className="font-bold text-slate-700">Reason submitted:</span>
              <p className="text-slate-600 mt-1 leading-relaxed">{selectedRequest.reason}</p>
            </div>

            <form onSubmit={handleDecisionSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Decision
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-emerald-700">
                    <input
                      type="radio"
                      name="decision"
                      value="APPROVED"
                      checked={decisionStatus === 'APPROVED'}
                      onChange={() => setDecisionStatus('APPROVED')}
                      className="text-emerald-600"
                    />
                    <span>Approve & Recalculate Attendance</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-rose-700">
                    <input
                      type="radio"
                      name="decision"
                      value="REJECTED"
                      checked={decisionStatus === 'REJECTED'}
                      onChange={() => setDecisionStatus('REJECTED')}
                      className="text-rose-600"
                    />
                    <span>Reject Request</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Auditor Remarks (Optional)
                </label>
                <textarea
                  rows={2}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Audit justification for approving or rejecting this correction..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCompareModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md ${
                    decisionStatus === 'APPROVED'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {actionLoading ? 'Applying...' : `Confirm ${decisionStatus}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
