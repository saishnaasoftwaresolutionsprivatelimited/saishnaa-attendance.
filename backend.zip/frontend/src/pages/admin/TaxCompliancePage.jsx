import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  Download,
  Calendar,
  IndianRupee,
  FileText,
  User,
  Building,
} from 'lucide-react';

export default function TaxCompliancePage() {
  const [taxes, setTaxes] = useState([]);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [selectedTax, setSelectedTax] = useState(null);
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadData();
    window.addEventListener('saishnaa_store_updated', loadData);
    return () => window.removeEventListener('saishnaa_store_updated', loadData);
  }, []);

  function loadData() {
    const list = adminStore.getTaxCompliance();
    setTaxes(list);
    if (list.length > 0 && !selectedTax) {
      setSelectedTax(list[0]);
    } else if (selectedTax) {
      const updated = list.find((t) => t.id === selectedTax.id);
      if (updated) setSelectedTax(updated);
    }
  }

  function handleUpdateStatus(id, newStatus) {
    adminStore.updateTaxStatus(id, newStatus);
    setToastMsg(`Tax filing marked as ${newStatus}!`);
    setTimeout(() => setToastMsg(''), 4000);
  }

  // Summary Metrics
  const totalDeductions = taxes.reduce((acc, t) => acc + (t.deductionAmount || 0), 0);
  const filedCount = taxes.filter((t) => t.filingStatus === 'Paid').length;
  const pendingCount = taxes.filter((t) => t.filingStatus === 'Pending').length;
  const overdueCount = taxes.filter((t) => t.filingStatus === 'Overdue').length;

  // Filtered List
  const filteredTaxes = taxes.filter((t) => {
    const matchesSearch =
      t.employeeName.toLowerCase().includes(search.toLowerCase()) ||
      t.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
      t.taxType.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === 'ALL' || t.taxType.includes(filterType);
    const matchesStatus = filterStatus === 'ALL' || t.filingStatus === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#16A34A]" />
            Tax & Statutory Compliance
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Monitor EPFO (PF), ESIC, Professional Tax, and Income Tax (TDS Section 192) remittances.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              setToastMsg('Generated Form 24Q quarterly summary sheet!');
              setTimeout(() => setToastMsg(''), 4000);
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Download Challan Summary
          </button>
        </div>
      </div>

      {/* 2. SUMMARY CARDS (PASTEL CARDS - FLAT ACCENTS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Filed */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Tax Filed
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{filedCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Challans Verified & Deposited</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Pending Filings */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Pending Filings
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">{pendingCount}</h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Due before 15th of Month</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Overdue Taxes */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">
              Overdue Filings
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">{overdueCount}</h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">Requires Immediate Remittance</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        {/* Total Deductions */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Total Tax Deductions
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">
              ₹{totalDeductions.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">Monthly Statutory Pool</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <IndianRupee className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. SEARCH & FILTERS BAR */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by employee name, code, or tax type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Tax Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Tax Types</option>
            <option value="TDS">TDS (Income Tax)</option>
            <option value="EPF">Provident Fund (EPF)</option>
            <option value="ESIC">ESIC</option>
            <option value="PT">Professional Tax</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Statuses</option>
            <option value="Paid">Paid</option>
            <option value="Pending">Pending</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Table of Tax Items */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Employee Statutory & Tax Ledger</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredTaxes.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Monthly Salary</th>
                  <th className="py-3 px-4">Deduction</th>
                  <th className="py-3 px-4">Tax Type</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTaxes.map((tax) => {
                  const isSelected = selectedTax?.id === tax.id;
                  let badgeClass = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
                  if (tax.filingStatus === 'Pending') {
                    badgeClass = 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]';
                  } else if (tax.filingStatus === 'Overdue') {
                    badgeClass = 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]';
                  }

                  return (
                    <tr
                      key={tax.id}
                      onClick={() => setSelectedTax(tax)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {tax.employeeName}
                        <span className="block text-[10px] text-slate-400 font-mono font-normal">
                          {tax.employeeCode}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-800">
                        ₹{tax.salary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-[#16A34A]">
                        ₹{tax.deductionAmount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">{tax.taxType}</td>
                      <td className="py-3.5 px-4 text-slate-600">{tax.dueDate}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}
                        >
                          {tax.filingStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedTax(tax);
                          }}
                          className="px-2.5 py-1 text-xs font-bold text-[#16A34A] hover:bg-[#DCFCE7] rounded-lg transition-colors"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Selected Tax Item */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Tax Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedTax ? selectedTax.employeeName : 'Select an employee'}
              </h3>
            </div>
            {selectedTax && (
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  selectedTax.filingStatus === 'Paid'
                    ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                    : selectedTax.filingStatus === 'Pending'
                    ? 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                    : 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]'
                }`}
              >
                {selectedTax.filingStatus}
              </span>
            )}
          </div>

          {selectedTax ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee Code:</span>
                  <span className="font-mono font-bold text-slate-800">{selectedTax.employeeCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">PAN Number:</span>
                  <span className="font-mono font-bold text-slate-800">{selectedTax.pan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Monthly Gross Salary:</span>
                  <span className="font-mono font-bold text-slate-800">
                    ₹{selectedTax.salary.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-2">
                  <span className="text-slate-700 font-bold">Deduction Withheld:</span>
                  <span className="font-mono font-bold text-[#16A34A] text-sm">
                    ₹{selectedTax.deductionAmount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Tax / Scheme Category:</span>
                  <span className="font-bold text-slate-800">{selectedTax.taxType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Filing Challan Ref:</span>
                  <span className="font-mono font-semibold text-slate-800">{selectedTax.challanNo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Remittance Cutoff Date:</span>
                  <span className="font-semibold text-slate-800">{selectedTax.dueDate}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Update Compliance Status
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleUpdateStatus(selectedTax.id, 'Paid')}
                    className="w-full py-2 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center"
                  >
                    Mark as Paid / Filed
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedTax.id, 'Pending')}
                    className="w-full py-2 px-3 rounded-xl border border-[#FCD34D] bg-[#FEF9C3] text-[#854D0E] font-bold hover:bg-[#FEF08A] transition-colors text-center"
                  >
                    Mark Pending
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click an employee row to view tax details.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
