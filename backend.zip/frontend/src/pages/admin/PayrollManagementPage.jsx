import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  CreditCard,
  IndianRupee,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Download,
  Building,
  DollarSign,
  TrendingUp,
  Percent,
  RefreshCw,
  Send,
  AlertCircle,
  FileText,
} from 'lucide-react';

export default function PayrollManagementPage() {
  const [payrollItems, setPayrollItems] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState('October 2026');
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Master-Detail selected payroll item
  const [selectedItem, setSelectedItem] = useState(null);

  const [processing, setProcessing] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadPayrollData();
    window.addEventListener('saishnaa_store_updated', loadPayrollData);
    return () => window.removeEventListener('saishnaa_store_updated', loadPayrollData);
  }, []);

  function loadPayrollData() {
    const list = adminStore.getPayrollData();
    setPayrollItems(list);
    if (list.length > 0 && !selectedItem) {
      setSelectedItem(list[0]);
    } else if (selectedItem) {
      const updated = list.find((p) => p.id === selectedItem.id);
      if (updated) setSelectedItem(updated);
    }
  }

  // Summary Metrics
  const totalPayrollGross = payrollItems.reduce((acc, p) => acc + (p.grossSalary || 0), 0);
  const totalNetSalary = payrollItems.reduce((acc, p) => acc + (p.netSalary || 0), 0);
  const totalBonuses = payrollItems.reduce((acc, p) => acc + (p.bonus || 0), 0);
  const totalDeductions = payrollItems.reduce((acc, p) => acc + (p.totalDeductions || 0), 0);

  // Filtered List
  const filteredItems = payrollItems.filter((item) => {
    const matchesSearch =
      item.fullName.toLowerCase().includes(search.toLowerCase()) ||
      item.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
      item.department.toLowerCase().includes(search.toLowerCase());
    const matchesDept = selectedDept === 'ALL' || item.department === selectedDept;
    const matchesStatus = selectedStatus === 'ALL' || item.paymentStatus === selectedStatus;
    return matchesSearch && matchesDept && matchesStatus;
  });

  function handleProcessPayroll() {
    setProcessing(true);
    setTimeout(() => {
      adminStore.processPayroll(true);
      setProcessing(false);
      setToastMsg('Payroll successfully processed and credited for all employees!');
      setTimeout(() => setToastMsg(''), 4000);
    }, 700);
  }

  function handleCreditIndividual(empId) {
    adminStore.processPayroll(false, empId);
    setToastMsg(`Salary credited for employee ${empId}!`);
    setTimeout(() => setToastMsg(''), 4000);
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-[#16A34A]" />
            Monthly Payroll Processing
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Calculate salary, review bonuses and deductions, and record salary payments.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleProcessPayroll}
            disabled={processing}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            {processing ? 'Processing...' : 'Process Payroll / Credit Salary'}
          </button>
        </div>
      </div>

      {/* 2. SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Payroll Processed */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Payroll Processed
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">
              ₹{totalNetSalary.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Net Disbursable for {selectedMonth}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <IndianRupee className="w-5 h-5" />
          </div>
        </div>

        {/* Bonuses */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Bonuses
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">
              ₹{totalBonuses.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Recorded employee bonuses</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Deductions & Taxes */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">
              Deductions & Taxes
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">
              ₹{totalDeductions.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">EPF + ESIC + Withholding TDS</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <Percent className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. CALCULATION FORMULA BANNER */}
      <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs flex flex-wrap items-center justify-between gap-3 text-slate-700">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-900 uppercase tracking-wide">Salary Formula:</span>
          <span className="bg-white border border-slate-200 px-2 py-1 rounded-lg text-slate-800">
            <strong>Gross</strong> = Basic + HRA + Allowances + Bonus
          </span>
          <span className="text-slate-400">|</span>
          <span className="bg-white border border-slate-200 px-2 py-1 rounded-lg text-slate-800">
            <strong>Deductions</strong> = PF + ESI + Other
          </span>
          <span className="text-slate-400">|</span>
          <span className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-2 py-1 rounded-lg font-bold">
            <strong>Net Salary</strong> = Gross - Deductions
          </span>
        </div>

        <select
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#16A34A]"
        >
          <option value="October 2026">October 2026 Cycle</option>
          <option value="September 2026">September 2026 Cycle</option>
          <option value="August 2026">August 2026 Cycle</option>
        </select>
      </div>

      {/* 4. SEARCH & FILTERS BAR */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search employee, position, department..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Departments</option>
            <option value="Engineering">Engineering</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Product & Design">Product & Design</option>
            <option value="Quality Assurance">Quality Assurance</option>
            <option value="Marketing & Sales">Marketing & Sales</option>
            <option value="Finance & Accounts">Finance & Accounts</option>
            <option value="Operations">Operations</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Payment Statuses</option>
            <option value="Processed">Processed</option>
            <option value="Pending">Pending</option>
          </select>
        </div>
      </div>

      {/* 5. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Payroll Activities Table */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Payroll Activities</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredItems.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Position</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Gross Salary</th>
                  <th className="py-3 px-4">Deductions</th>
                  <th className="py-3 px-4">Net Salary</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredItems.map((item) => {
                  const isSelected = selectedItem?.id === item.id;
                  const isProcessed = item.paymentStatus === 'Processed';

                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {item.fullName}
                        <span className="block text-[10px] text-slate-400 font-mono font-normal">
                          {item.employeeCode}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">{item.position}</td>
                      <td className="py-3.5 px-4 text-slate-600">{item.department}</td>
                      <td className="py-3.5 px-4 font-mono text-slate-700">
                        ₹{item.grossSalary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-rose-600">
                        -₹{item.totalDeductions.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-[#16A34A]">
                        ₹{item.netSalary.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                            isProcessed
                              ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                              : 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                          }`}
                        >
                          {item.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCreditIndividual(item.employeeId);
                          }}
                          disabled={isProcessed}
                          className="px-2.5 py-1 text-xs font-bold text-[#16A34A] hover:bg-[#DCFCE7] rounded-lg transition-colors disabled:opacity-40"
                        >
                          {isProcessed ? 'Credited' : 'Credit'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Salary Breakdown, Bank Details & History */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Salary Breakdown Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedItem ? selectedItem.fullName : 'Select an employee'}
              </h3>
            </div>
            {selectedItem && (
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  selectedItem.paymentStatus === 'Processed'
                    ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                    : 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                }`}
              >
                {selectedItem.paymentStatus}
              </span>
            )}
          </div>

          {selectedItem ? (
            <div className="space-y-4 text-xs">
              {/* Earnings Components */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[11px] font-bold text-slate-800 block uppercase tracking-wider">
                  Earnings Breakdown
                </span>
                <div className="flex justify-between">
                  <span className="text-slate-500">Basic Pay:</span>
                  <span className="font-mono text-slate-800">
                    ₹{selectedItem.basicSalary.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">House Rent Allowance (HRA):</span>
                  <span className="font-mono text-slate-800">
                    ₹{selectedItem.hra.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Special Allowances:</span>
                  <span className="font-mono text-slate-800">
                    ₹{selectedItem.allowances.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Performance Bonus:</span>
                  <span className="font-mono font-bold text-[#16A34A]">
                    ₹{selectedItem.bonus.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-1.5 font-bold">
                  <span className="text-slate-800">Gross Earnings:</span>
                  <span className="font-mono text-slate-900">
                    ₹{selectedItem.grossSalary.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Deductions Components */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[11px] font-bold text-slate-800 block uppercase tracking-wider">
                  Deductions Breakdown
                </span>
                <div className="flex justify-between">
                  <span className="text-slate-500">Provident Fund (EPF):</span>
                  <span className="font-mono text-rose-600">
                    -₹{selectedItem.pf.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee State Insurance (ESIC):</span>
                  <span className="font-mono text-rose-600">
                    -₹{selectedItem.esi.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Professional Tax / Other:</span>
                  <span className="font-mono text-rose-600">
                    -₹{selectedItem.otherDeductions.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-1.5 font-bold">
                  <span className="text-slate-800">Total Deductions:</span>
                  <span className="font-mono text-rose-600">
                    -₹{selectedItem.totalDeductions.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Final Net Pay Highlight Card */}
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-emerald-800 uppercase block">
                    Take Home Net Salary
                  </span>
                  <span className="text-lg font-black text-emerald-950 font-mono">
                    ₹{selectedItem.netSalary.toLocaleString('en-IN')}
                  </span>
                </div>
                <span className="text-[11px] font-bold text-emerald-800 bg-white px-2 py-1 rounded-lg border border-emerald-200">
                  {selectedItem.paymentStatus}
                </span>
              </div>

              {/* Bank Details */}
              <div className="p-3 rounded-xl border border-slate-200 space-y-1.5">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">
                  Disbursement Bank Account
                </span>
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-[#16A34A]" />
                  {selectedItem.bankName || 'HDFC Bank'}
                </p>
                <div className="flex justify-between text-slate-600">
                  <span>A/C Number:</span>
                  <span className="font-mono font-medium">
                    {selectedItem.bankAccountNumber || '50100234981122'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>IFSC Code:</span>
                  <span className="font-mono font-medium">{selectedItem.ifscCode}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => handleCreditIndividual(selectedItem.employeeId)}
                  disabled={selectedItem.paymentStatus === 'Processed'}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center text-xs disabled:opacity-40"
                >
                  {selectedItem.paymentStatus === 'Processed'
                    ? 'Salary Disbursed'
                    : 'Disburse & Credit Salary'}
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click an employee row to view salary breakdown.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}