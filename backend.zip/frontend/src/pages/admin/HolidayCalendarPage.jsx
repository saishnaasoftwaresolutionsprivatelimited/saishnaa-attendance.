import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  Gift,
  Calendar,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  Search,
  Sparkles,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function HolidayCalendarPage() {
  const [holidays, setHolidays] = useState([]);
  const [currentDate, setCurrentDate] = useState(dayjs('2026-10-01'));
  const [selectedHoliday, setSelectedHoliday] = useState(null);

  // Add / Edit Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    date: dayjs().format('YYYY-MM-DD'),
    day: 'Friday',
    type: 'Mandatory',
    description: '',
  });

  // Delete Confirm Modal
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [holidayToDelete, setHolidayToDelete] = useState(null);

  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadHolidays();
    window.addEventListener('saishnaa_store_updated', loadHolidays);
    return () => window.removeEventListener('saishnaa_store_updated', loadHolidays);
  }, []);

  function loadHolidays() {
    const list = adminStore.getHolidays();
    setHolidays(list);
    if (list.length > 0 && !selectedHoliday) {
      setSelectedHoliday(list[0]);
    } else if (selectedHoliday) {
      const updated = list.find((h) => h.id === selectedHoliday.id);
      if (updated) setSelectedHoliday(updated);
    }
  }

  // Summary Metrics
  const totalHolidays = holidays.length;
  const mandatoryCount = holidays.filter((h) => h.type === 'Mandatory').length;
  const optionalCount = holidays.filter((h) => h.type === 'Optional').length;

  function handleOpenAdd() {
    setIsEditing(false);
    setFormData({
      id: '',
      name: '',
      date: currentDate.format('YYYY-MM-DD'),
      day: currentDate.format('dddd'),
      type: 'Mandatory',
      description: 'Declared corporate holiday',
    });
    setModalOpen(true);
  }

  function handleOpenEdit(hol, e) {
    if (e) e.stopPropagation();
    setIsEditing(true);
    setFormData({
      id: hol.id,
      name: hol.name,
      date: hol.date,
      day: hol.day,
      type: hol.type,
      description: hol.description || '',
    });
    setModalOpen(true);
  }

  function handleSave(e) {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const chosenDay = dayjs(formData.date).format('dddd');
    if (isEditing) {
      adminStore.updateHoliday(formData.id, { ...formData, day: chosenDay });
      setToastMsg(`Holiday "${formData.name}" updated!`);
    } else {
      const created = adminStore.addHoliday({ ...formData, day: chosenDay });
      setSelectedHoliday(created);
      setToastMsg(`Holiday "${created.name}" added to company calendar!`);
    }

    setModalOpen(false);
    setTimeout(() => setToastMsg(''), 4000);
  }

  function handleDeleteClick(hol, e) {
    if (e) e.stopPropagation();
    setHolidayToDelete(hol);
    setDeleteConfirmOpen(true);
  }

  function confirmDelete() {
    if (holidayToDelete) {
      adminStore.deleteHoliday(holidayToDelete.id);
      setToastMsg(`Holiday "${holidayToDelete.name}" deleted.`);
      setDeleteConfirmOpen(false);
      setHolidayToDelete(null);
      setTimeout(() => setToastMsg(''), 4000);
    }
  }

  // Calendar Grid calculation for current month
  const startOfMonth = currentDate.startOf('month');
  const daysInMonth = currentDate.daysInMonth();
  const startDayOfWeek = startOfMonth.day(); // 0 is Sunday
  const daysArray = [];

  // Padding blanks before month start
  for (let i = 0; i < startDayOfWeek; i++) {
    daysArray.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    daysArray.push(currentDate.date(d));
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Gift className="w-6 h-6 text-[#16A34A]" />
            Company Holiday Calendar
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Publish official gazetted holidays, mandatory closures, and optional festive leaves.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Company Holiday
        </button>
      </div>

      {/* 2. SUMMARY CARDS (Top 3 KPI Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Holidays */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Holidays
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{totalHolidays}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Declared in Calendar</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* Mandatory Holidays */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Mandatory Holidays
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">{mandatoryCount}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">Paid Office Closures</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <Gift className="w-5 h-5" />
          </div>
        </div>

        {/* Optional / Restricted */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Optional / Restricted
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">{optionalCount}</h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Floating Festival Quotas</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. INTERACTIVE MONTHLY CALENDAR GRID */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900">
              {currentDate.format('MMMM YYYY')}
            </h3>
            <span className="text-xs font-bold text-[#16A34A] bg-[#DCFCE7] px-2.5 py-0.5 rounded-lg">
              Corporate Calendar
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentDate(currentDate.subtract(1, 'month'))}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentDate(dayjs('2026-10-01'))}
              className="px-2.5 py-1 text-xs font-bold rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700"
            >
              Today
            </button>
            <button
              onClick={() => setCurrentDate(currentDate.add(1, 'month'))}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1.5 text-center text-xs font-bold text-slate-500 pb-2 border-b border-slate-100">
          <span>Sun</span>
          <span>Mon</span>
          <span>Tue</span>
          <span>Wed</span>
          <span>Thu</span>
          <span>Fri</span>
          <span>Sat</span>
        </div>

        {/* Dates Grid with Holiday Highlights */}
        <div className="grid grid-cols-7 gap-1.5 pt-2">
          {daysArray.map((dayItem, index) => {
            if (!dayItem) {
              return <div key={`empty-${index}`} className="h-16 bg-slate-50/50 rounded-xl" />;
            }

            const formattedDate = dayItem.format('YYYY-MM-DD');
            const matchingHoliday = holidays.find((h) => h.date === formattedDate);
            const isToday = formattedDate === dayjs().format('YYYY-MM-DD');

            return (
              <div
                key={formattedDate}
                onClick={() => matchingHoliday && setSelectedHoliday(matchingHoliday)}
                className={`h-16 p-2 rounded-xl border transition-all text-xs flex flex-col justify-between ${
                  matchingHoliday
                    ? 'bg-emerald-50 border-[#86EFAC] cursor-pointer shadow-xs hover:bg-emerald-100/70'
                    : isToday
                    ? 'bg-blue-50/50 border-blue-200'
                    : 'bg-white border-slate-100 hover:border-slate-200'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span
                    className={`font-bold ${
                      isToday
                        ? 'w-5 h-5 rounded-full bg-[#16A34A] text-white flex items-center justify-center text-[10px]'
                        : matchingHoliday
                        ? 'text-[#16A34A]'
                        : 'text-slate-700'
                    }`}
                  >
                    {dayItem.date()}
                  </span>
                  {matchingHoliday && (
                    <span className="w-2 h-2 rounded-full bg-[#16A34A] flex-shrink-0" />
                  )}
                </div>

                {matchingHoliday && (
                  <p className="text-[10px] font-bold text-[#15803D] truncate leading-tight">
                    {matchingHoliday.name}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Holiday List Table */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Declared Holidays List</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {holidays.length} registered holidays
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Holiday Name</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Day</th>
                  <th className="py-3 px-4 text-center">Type</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {holidays.map((hol) => {
                  const isSelected = selectedHoliday?.id === hol.id;
                  const isMandatory = hol.type === 'Mandatory';

                  return (
                    <tr
                      key={hol.id}
                      onClick={() => setSelectedHoliday(hol)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                        <Gift className="w-3.5 h-3.5 text-[#16A34A]" />
                        {hol.name}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-mono">{hol.date}</td>
                      <td className="py-3.5 px-4 text-slate-600">{hol.day}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                            isMandatory
                              ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                              : 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                          }`}
                        >
                          {hol.type}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={(e) => handleOpenEdit(hol, e)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-[#16A34A] hover:bg-slate-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteClick(hol, e)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Holiday Details */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Holiday Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedHoliday ? selectedHoliday.name : 'Select a holiday'}
              </h3>
            </div>
            {selectedHoliday && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-md border bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]">
                {selectedHoliday.type}
              </span>
            )}
          </div>

          {selectedHoliday ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Date:</span>
                  <span className="font-mono font-bold text-slate-800">{selectedHoliday.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Day of the Week:</span>
                  <span className="font-bold text-slate-800">{selectedHoliday.day}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Classification:</span>
                  <span className="font-medium text-slate-800">{selectedHoliday.type} Holiday</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  Description & Impact
                </span>
                <p className="text-slate-700 leading-relaxed">
                  {selectedHoliday.description ||
                    'All office operations remain closed. Biometric attendance calculation is marked non-working holiday.'}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  onClick={(e) => handleOpenEdit(selectedHoliday, e)}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-100 text-slate-800 font-bold hover:bg-slate-200 transition-colors text-center text-xs"
                >
                  Edit Holiday
                </button>
                <button
                  onClick={(e) => handleDeleteClick(selectedHoliday, e)}
                  className="py-2 px-3 rounded-xl bg-rose-50 text-rose-600 font-bold hover:bg-rose-100 transition-colors text-center text-xs"
                >
                  Delete
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click a holiday to view details.
            </p>
          )}
        </div>
      </div>

      {/* ADD / EDIT HOLIDAY MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Gift className="w-5 h-5 text-[#16A34A]" />
                {isEditing ? 'Edit Company Holiday' : 'Add New Company Holiday'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Holiday Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Deepavali"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Holiday Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Holiday Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                  >
                    <option value="Mandatory">Mandatory</option>
                    <option value="Optional">Optional</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Notes / Description</label>
                <textarea
                  rows="2"
                  placeholder="e.g. Festival of Lights celebration"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors shadow-xs"
                >
                  {isEditing ? 'Save Changes' : 'Publish Holiday'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 text-xs animate-in fade-in">
            <div className="flex items-center gap-2.5 text-rose-600 mb-2">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <h3 className="text-sm font-bold">Remove Holiday</h3>
            </div>
            <p className="text-slate-600 mt-2">
              Are you sure you want to remove <strong>{holidayToDelete?.name}</strong> from the
              corporate calendar?
            </p>
            <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => setDeleteConfirmOpen(false)}
                className="px-3.5 py-1.5 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-1.5 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-colors"
              >
                Yes, Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
