import React, { useState, useEffect, useMemo } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  CheckSquare,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  User,
  AlertCircle,
  CheckCircle2,
  Hourglass,
  MoreVertical,
  Trash2,
  Edit,
  Tag,
  Briefcase,
  ChevronRight,
  TrendingUp,
  X,
  Building
} from 'lucide-react';

export default function TaskManagementPage() {
  const [tasks, setTasks] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  // New task form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    assignedToId: '',
    priority: 'Medium',
    status: 'Pending',
    dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    estimatedHours: 8,
    tags: '',
    notes: '',
  });

  // Load from persistent adminStore
  useEffect(() => {
    loadData();
    const handleUpdate = () => loadData();
    window.addEventListener('saishnaa_store_updated', handleUpdate);
    return () => window.removeEventListener('saishnaa_store_updated', handleUpdate);
  }, []);

  function loadData() {
    const taskList = adminStore.getTasks();
    const empList = adminStore.getEmployees();
    setTasks(taskList);
    setEmployees(empList);
    if (taskList.length > 0 && !selectedTask) {
      setSelectedTask(taskList[0]);
    } else if (selectedTask) {
      const refreshed = taskList.find((t) => t.id === selectedTask.id);
      if (refreshed) setSelectedTask(refreshed);
    }
  }

  function showToast(msg) {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  }

  // Filtered tasks
  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch =
        t.title.toLowerCase().includes(search.toLowerCase()) ||
        t.assignedToName.toLowerCase().includes(search.toLowerCase()) ||
        t.taskCode.toLowerCase().includes(search.toLowerCase()) ||
        (t.tags && t.tags.some((tag) => tag.toLowerCase().includes(search.toLowerCase())));

      const matchStatus = statusFilter === 'ALL' || t.status.toUpperCase() === statusFilter.toUpperCase();
      const matchPriority = priorityFilter === 'ALL' || t.priority.toUpperCase() === priorityFilter.toUpperCase();
      const matchDept = departmentFilter === 'ALL' || t.department === departmentFilter;

      return matchSearch && matchStatus && matchPriority && matchDept;
    });
  }, [tasks, search, statusFilter, priorityFilter, departmentFilter]);

  // Statistics
  const totalTasks = tasks.length;
  const inProgressCount = tasks.filter((t) => t.status === 'In Progress').length;
  const pendingCount = tasks.filter((t) => t.status === 'Pending').length;
  const completedCount = tasks.filter((t) => t.status === 'Completed').length;

  // Handle Quick Status Change
  function handleStatusChange(taskId, newStatus) {
    const updated = adminStore.updateTaskStatus(taskId, newStatus);
    if (updated) {
      loadData();
      showToast(`Task status updated to "${newStatus}"! Saved permanently.`);
    }
  }

  // Handle Delete Task
  function handleDeleteTask(taskId) {
    if (window.confirm('Are you sure you want to delete this task? This action is permanent.')) {
      adminStore.deleteTask(taskId);
      loadData();
      if (selectedTask?.id === taskId) {
        setSelectedTask(tasks.find((t) => t.id !== taskId) || null);
      }
      showToast('Task removed successfully.');
    }
  }

  // Handle Create Task Submit
  function handleCreateSubmit(e) {
    e.preventDefault();
    if (!formData.title.trim()) {
      alert('Please enter a task title');
      return;
    }

    const assignedEmp = employees.find((emp) => emp.id === formData.assignedToId);

    const newTask = adminStore.addTask({
      title: formData.title,
      description: formData.description,
      assignedToId: formData.assignedToId,
      assignedToName: assignedEmp ? assignedEmp.fullName : 'Unassigned',
      department: assignedEmp ? assignedEmp.department : 'Engineering',
      priority: formData.priority,
      status: formData.status,
      dueDate: formData.dueDate,
      estimatedHours: Number(formData.estimatedHours || 8),
      completedHours: 0,
      tags: formData.tags,
      notes: formData.notes,
    });

    loadData();
    setSelectedTask(newTask);
    setIsCreateModalOpen(false);
    setFormData({
      title: '',
      description: '',
      assignedToId: '',
      priority: 'Medium',
      status: 'Pending',
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      estimatedHours: 8,
      tags: '',
      notes: '',
    });
    showToast(`Task "${newTask.title}" assigned permanently!`);
  }

  // Helper for priority badges (Flat colors, No gradients)
  const getPriorityBadge = (priority) => {
    switch (priority?.toUpperCase()) {
      case 'URGENT':
      case 'HIGH':
        return 'bg-[#FEE2E2] text-[#991B1B] border-[#FCA5A5]';
      case 'MEDIUM':
        return 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]';
      case 'LOW':
      default:
        return 'bg-[#F1F5F9] text-[#475569] border-[#CBD5E1]';
    }
  };

  // Helper for status badges
  const getStatusBadge = (status) => {
    switch (status) {
      case 'Completed':
        return 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
      case 'In Progress':
        return 'bg-[#DBEAFE] text-[#1E40AF] border-[#93C5FD]';
      case 'In Review':
        return 'bg-[#F3E8FF] text-[#6B21A8] border-[#D8B4FE]';
      case 'Overdue':
        return 'bg-[#FEE2E2] text-[#B91C1C] border-[#FCA5A5]';
      case 'Pending':
      default:
        return 'bg-[#FEF9EE] text-[#B45309] border-[#FDE68A]';
    }
  };

  const departments = ['Engineering', 'Human Resources', 'Design', 'Finance', 'Operations', 'Product'];

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-[#16A34A]" />
            Employee Tasks & Status Tracking
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Assign deliverables to staff members, monitor milestone execution, and verify task completion status.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#16A34A] hover:bg-[#15803D] text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Assign New Task
          </button>
        </div>
      </div>

      {/* 2. SUMMARY KPI CARDS (Pastel flat cards matching the system theme) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Tasks */}
        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">Total Tasks Assigned</p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">{totalTasks}</h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Active Sprint & Backlog</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <CheckSquare className="w-5 h-5" />
          </div>
        </div>

        {/* In Progress */}
        <div className="p-4 rounded-2xl bg-[#FEF9EE] border border-[#FDE68A] text-[#92400E] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#92400E]/80 uppercase tracking-wider">In Progress</p>
            <h3 className="text-2xl font-black mt-1 text-[#92400E]">{inProgressCount}</h3>
            <p className="text-[11px] text-[#92400E]/70 mt-0.5">Under Active Execution</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE68A] flex items-center justify-center text-[#D97706] shadow-xs">
            <Hourglass className="w-5 h-5" />
          </div>
        </div>

        {/* Pending */}
        <div className="p-4 rounded-2xl bg-[#FFF7ED] border border-[#FFEDD5] text-[#9A3412] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#9A3412]/80 uppercase tracking-wider">Pending Assignment</p>
            <h3 className="text-2xl font-black mt-1 text-[#9A3412]">{pendingCount}</h3>
            <p className="text-[11px] text-[#9A3412]/70 mt-0.5">Awaiting Staff Kickoff</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FFEDD5] flex items-center justify-center text-[#EA580C] shadow-xs">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Completed */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between shadow-xs">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">Completed Deliverables</p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{completedCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Verified & Signed Off</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. SEARCH & FILTERS BAR */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by title, code, tag, or employee..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-[#16A34A]"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="In Review">In Review</option>
            <option value="Completed">Completed</option>
          </select>

          {/* Priority Filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Department Filter */}
          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        <div className="text-xs font-bold text-slate-500">
          Showing <span className="text-slate-900 font-black">{filteredTasks.length}</span> of {totalTasks} Tasks
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Task Table (7 or 8 cols) */}
        <div className="lg:col-span-7 xl:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Assigned Task Register
            </h3>
            <span className="text-[11px] text-slate-500">Click any row to inspect & edit</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Task Deliverable</th>
                  <th className="py-3 px-3">Assigned Staff</th>
                  <th className="py-3 px-3">Priority</th>
                  <th className="py-3 px-3">Due Date</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-4 text-right">Quick Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No tasks match your filter criteria.
                    </td>
                  </tr>
                ) : (
                  filteredTasks.map((t) => {
                    const isSelected = selectedTask?.id === t.id;
                    return (
                      <tr
                        key={t.id}
                        onClick={() => setSelectedTask(t)}
                        className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                          isSelected ? 'bg-emerald-50/70 font-semibold' : ''
                        }`}
                      >
                        <td className="py-3 px-4">
                          <div className="max-w-[200px]">
                            <p className="font-bold text-slate-900 truncate">{t.title}</p>
                            <span className="text-[10px] text-slate-400 font-mono">{t.taskCode}</span>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-[#16A34A] text-white flex items-center justify-center font-bold text-[10px] flex-shrink-0">
                              {t.assignedToName?.charAt(0) || 'U'}
                            </div>
                            <div className="truncate max-w-[110px]">
                              <p className="font-medium text-slate-800 truncate">{t.assignedToName}</p>
                              <span className="text-[10px] text-slate-400">{t.department}</span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold border ${getPriorityBadge(
                              t.priority
                            )}`}
                          >
                            {t.priority}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-mono text-slate-700">
                          {t.dueDate}
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(
                              t.status
                            )}`}
                          >
                            {t.status}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <select
                            value={t.status}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => {
                              e.stopPropagation();
                              handleStatusChange(t.id, e.target.value);
                            }}
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-[11px] font-bold text-slate-700 focus:outline-none focus:border-[#16A34A] cursor-pointer"
                          >
                            <option value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="In Review">In Review</option>
                            <option value="Completed">Completed</option>
                          </select>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Task Inspector & Actions (5 or 4 cols) */}
        <div className="lg:col-span-5 xl:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 sticky top-20">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Task Inspector Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedTask ? selectedTask.taskCode : 'Select a Task'}
              </h3>
            </div>
            {selectedTask && (
              <button
                onClick={() => handleDeleteTask(selectedTask.id)}
                className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                title="Delete Task"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>

          {selectedTask ? (
            <div className="space-y-4 text-xs">
              {/* Title & Description */}
              <div className="space-y-1">
                <h4 className="font-extrabold text-sm text-slate-900 leading-snug">
                  {selectedTask.title}
                </h4>
                <p className="text-slate-600 text-xs leading-relaxed mt-1">
                  {selectedTask.description || 'No detailed instructions provided.'}
                </p>
              </div>

              {/* Status Quick Buttons */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Update Task Status
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Pending', 'In Progress', 'In Review', 'Completed'].map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => handleStatusChange(selectedTask.id, st)}
                      className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer ${
                        selectedTask.status === st
                          ? 'bg-[#16A34A] text-white border-[#16A34A] shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Assigned Staff Card */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Assigned Employee
                </span>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-[#16A34A] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    {selectedTask.assignedToName?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 text-xs">{selectedTask.assignedToName}</p>
                    <p className="text-[10px] text-slate-500">
                      {selectedTask.department} • Assigned {selectedTask.assignedDate}
                    </p>
                  </div>
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 gap-2.5 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Priority</span>
                  <span
                    className={`inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold border ${getPriorityBadge(
                      selectedTask.priority
                    )}`}
                  >
                    {selectedTask.priority}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Due Date</span>
                  <span className="font-mono font-bold text-slate-800 block mt-0.5">
                    {selectedTask.dueDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Est. Effort</span>
                  <span className="font-mono font-bold text-slate-800 block mt-0.5">
                    {selectedTask.estimatedHours} Hours
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-semibold">Completed</span>
                  <span className="font-mono font-bold text-emerald-700 block mt-0.5">
                    {selectedTask.completedHours} Hours
                  </span>
                </div>
              </div>

              {/* Tags */}
              {selectedTask.tags && selectedTask.tags.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Domain Tags
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedTask.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-semibold"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Internal Notes */}
              {selectedTask.notes && (
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-amber-900 text-[11px] leading-relaxed">
                  <p className="font-bold text-[10px] uppercase text-amber-800 mb-0.5">Admin Note</p>
                  {selectedTask.notes}
                </div>
              )}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs">
              Select any task from the table to view details.
            </div>
          )}
        </div>
      </div>

      {/* CREATE / ASSIGN TASK MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-4 my-8 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <CheckSquare className="w-5 h-5 text-[#16A34A]" />
                <h3 className="text-base font-bold text-slate-900">Assign New Employee Task</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Task Deliverable Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Upgrade payment gateway SDK v3"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Description & Requirements</label>
                <textarea
                  rows={3}
                  placeholder="Outline key deliverables, testing steps, and acceptance criteria..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Assign to Employee *</label>
                  <select
                    required
                    value={formData.assignedToId}
                    onChange={(e) => setFormData({ ...formData, assignedToId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none font-semibold"
                  >
                    <option value="">Select Employee...</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.fullName} ({emp.department})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Priority</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none font-semibold"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Due Date</label>
                  <input
                    type="date"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Estimated Hours</label>
                  <input
                    type="number"
                    min="1"
                    max="200"
                    value={formData.estimatedHours}
                    onChange={(e) => setFormData({ ...formData, estimatedHours: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Backend, API, Security"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Admin Notes / Remarks</label>
                <input
                  type="text"
                  placeholder="Optional internal reminder..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-[#16A34A] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#16A34A] hover:bg-[#15803D] text-white rounded-xl font-bold transition-all shadow-xs"
                >
                  Assign Task Permanently
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
