import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import {
  Layers,
  Plus,
  Clock,
  Coffee,
  CheckCircle2,
  Moon,
  Sun,
  Users,
  AlertCircle,
  X,
  Edit2,
  Calendar,
  Lock,
  ShieldCheck,
} from 'lucide-react';

export default function ShiftManagement() {
  const { role } = useAuth();
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedShift, setSelectedShift] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    startTime: '09:00',
    endTime: '18:00',
    gracePeriodMinutes: 10,
    breakDurationMinutes: 60,
    requiredWorkMinutes: 480,
    isOvernight: false,
    weeklyOffDays: ['SUNDAY'],
    overtimeEnabled: true,
  });

  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');

  useEffect(() => {
    fetchShifts();
  }, []);

  async function fetchShifts() {
    try {
      setLoading(true);
      const res = await api.get('/shifts');
      if (res.success) {
        setShifts(res.data || []);
      }
    } catch (err) {
      console.error('Fetch shifts error:', err);
    } finally {
      setLoading(false);
    }
  }

  function openCreateModal() {
    setIsEditing(false);
    setSelectedShift(null);
    setFormData({
      name: '',
      startTime: '09:00',
      endTime: '18:00',
      gracePeriodMinutes: 10,
      breakDurationMinutes: 60,
      requiredWorkMinutes: 480,
      isOvernight: false,
      weeklyOffDays: ['SUNDAY'],
      overtimeEnabled: true,
    });
    setFormError('');
    setModalOpen(true);
  }

  function openEditModal(shift) {
    setIsEditing(true);
    setSelectedShift(shift);
    setFormData({
      name: shift.name,
      startTime: shift.startTime,
      endTime: shift.endTime,
      gracePeriodMinutes: shift.gracePeriodMinutes,
      breakDurationMinutes: shift.breakDurationMinutes,
      requiredWorkMinutes: shift.requiredWorkMinutes,
      isOvernight: shift.isOvernight,
      weeklyOffDays: Array.isArray(shift.weeklyOffDays) ? shift.weeklyOffDays : ['SUNDAY'],
      overtimeEnabled: shift.overtimeEnabled,
    });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSaveShift(e) {
    e.preventDefault();
    setFormError('');
    try {
      setFormLoading(true);
      if (isEditing) {
        await api.patch(`/shifts/${selectedShift.id}`, formData);
      } else {
        await api.post('/shifts', formData);
      }
      setModalOpen(false);
      await fetchShifts();
    } catch (err) {
      setFormError(err.message || 'Failed to save shift.');
    } finally {
      setFormLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">
              {role === 'ADMIN' ? 'Shift Policy & Timings Governance' : 'Shift Rosters & Timings'}
            </h1>
            <span
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                role === 'ADMIN'
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-emerald-50 text-emerald-900 border-emerald-300'
              }`}
            >
              {role === 'ADMIN' ? 'Executive Policy Control' : 'HR Staff Roster Mode'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {role === 'ADMIN'
              ? 'Configure company shift timings, grace windows, overnight rules, and weekly off policies.'
              : 'View company shift timings and allocated staff headcounts. (Shift policy creation & modifications are governed by Executive Admin).'}
          </p>
        </div>

        {role === 'ADMIN' ? (
          <button onClick={openCreateModal} className="corp-btn-primary text-xs py-2.5 px-4">
            <Plus className="w-4 h-4" />
            <span>Create New Shift</span>
          </button>
        ) : (
          <div className="px-3.5 py-2 bg-slate-50 border border-slate-200 text-slate-600 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Policy Managed by Administrator</span>
          </div>
        )}
      </div>

      {/* Shifts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">Loading shifts...</div>
        ) : (
          shifts.map((s) => (
            <div key={s.id} className="corp-card p-5 relative overflow-hidden flex flex-col justify-between">
              {s.isOvernight && (
                <div className="absolute top-0 right-0 bg-indigo-900 text-indigo-100 text-[10px] font-bold px-3 py-1 rounded-bl-xl flex items-center gap-1">
                  <Moon className="w-3 h-3" />
                  <span>Overnight Shift</span>
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center font-bold">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-800">{s.name}</h3>
                    <div className="text-[11px] text-slate-500">
                      {(s.weeklyOffDays || []).join(', ')} Off
                    </div>
                  </div>
                </div>

                <div className="my-4 p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Timing:</span>
                    <span className="font-mono font-bold text-slate-900">
                      {s.startTime} - {s.endTime}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Grace Window:</span>
                    <span className="font-semibold text-amber-600">{s.gracePeriodMinutes} mins</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Scheduled Break:</span>
                    <span className="font-semibold text-slate-700">{s.breakDurationMinutes} mins</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-medium">Net Required:</span>
                    <span className="font-bold text-[#20266D]">
                      {Math.floor(s.requiredWorkMinutes / 60)}h {s.requiredWorkMinutes % 60}m
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>{s.activeEmployeesCount} Active Staff</span>
                </div>

                {role === 'ADMIN' ? (
                  <button
                    onClick={() => openEditModal(s)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                    title="Edit Shift Configuration"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1 border border-slate-200">
                    <Lock className="w-2.5 h-2.5 text-slate-400" />
                    <span>Fixed Policy</span>
                  </span>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Shift Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-extrabold text-[#20266D]">
                  {isEditing ? 'Configure Shift' : 'Create New Shift'}
                </h3>
                <p className="text-xs text-slate-500">Define working parameters and policies</p>
              </div>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveShift} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Shift Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Afternoon Support Shift"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Start Time (24h)
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.startTime}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    End Time (24h)
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Grace (Mins)
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.gracePeriodMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, gracePeriodMinutes: parseInt(e.target.value, 10) })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Break (Mins)
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.breakDurationMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, breakDurationMinutes: parseInt(e.target.value, 10) })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Required (Mins)
                  </label>
                  <input
                    type="number"
                    min="60"
                    required
                    value={formData.requiredWorkMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, requiredWorkMinutes: parseInt(e.target.value, 10) })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.isOvernight}
                    onChange={(e) => setFormData({ ...formData, isOvernight: e.target.checked })}
                    className="rounded text-[#20266D]"
                  />
                  <span>Overnight shift (crosses midnight)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.overtimeEnabled}
                    onChange={(e) => setFormData({ ...formData, overtimeEnabled: e.target.checked })}
                    className="rounded text-[#20266D]"
                  />
                  <span>Eligible for overtime</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button type="submit" disabled={formLoading} className="corp-btn-primary text-xs">
                  {formLoading ? 'Saving...' : 'Save Shift'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
