import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { adminStore } from '../../services/adminStore';
import {
  Users,
  UserCheck,
  UserX,
  CalendarCheck,
  CreditCard,
  Receipt,
  FileCheck2,
  TrendingUp,
  AlertCircle,
  Plus,
  ArrowRight,
  CheckCircle2,
  Calendar,
  Sparkles,
  Search,
  Building,
  Bell,
  Check,
  X,
  FileText,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import dayjs from 'dayjs';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [payrollItems, setPayrollItems] = useState([]);
  const [payrollCalendar, setPayrollCalendar] = useState([]);
  const [requests, setRequests] = useState([]);
  const [selectedFeedEmp, setSelectedFeedEmp] = useState(null);
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadDashboardData();
    window.addEventListener('saishnaa_store_updated', loadDashboardData);
    return () => window.removeEventListener('saishnaa_store_updated', loadDashboardData);
  }, []);

  function loadDashboardData() {
    const empList = adminStore.getEmployees();
    const attList = adminStore.getAttendance(dayjs().format('YYYY-MM-DD'));
    const payList = adminStore.getPayrollData();
    const cal = adminStore.getPayrollCalendar();
    const reqs = adminStore.getRequests();

    setEmployees(empList);
    setAttendance(attList);
    setPayrollItems(payList);
    setPayrollCalendar(cal);
    setRequests(reqs);

    if (attList.length > 0 && !selectedFeedEmp) {
      setSelectedFeedEmp(attList[0]);
    }
  }

  // KPI Calculations
  const totalEmployees = employees.length;
  const presentCount = attendance.filter((a) => a.status === 'Present' || a.status === 'On Time').length;
  const absentCount = attendance.filter((a) => a.status === 'Absent' || a.status === 'Absence').length;
  const onLeaveCount = attendance.filter((a) => ['On Leave', 'Leave', 'Half Day'].includes(a.status)).length;

  const payrollProcessedAmount = payrollItems
    .filter((item) => item.paymentStatus === 'Processed')
    .reduce((total, item) => total + item.netSalary, 0);
  const expenseData = Object.values(
    payrollItems.reduce((totals, item) => {
      const department = item.department || 'Unassigned';
      totals[department] = totals[department] || { name: department, amount: 0 };
      totals[department].amount += item.grossSalary;
      return totals;
    }, {})
  );

  const attendanceDistribution = [
    { name: 'Present / On Time', value: presentCount, color: '#16A34A' },
    { name: 'On Leave', value: onLeaveCount, color: '#3B82F6' },
    { name: 'Absent', value: absentCount, color: '#F43F5E' },
  ].filter((entry) => entry.value > 0);

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER & QUICK ACTIONS */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            Admin Dashboard Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Manage employee records, attendance, and payroll from one place.
          </p>
        </div>

        {/* Quick Action Buttons placed near the top */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => navigate('/admin/employees')}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            Add Employee
          </button>
          <button
            onClick={() => navigate('/admin/payroll')}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-800 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-xs"
          >
            <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
            Process Payroll
          </button>
          <button
            onClick={() => navigate('/admin/payslips')}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-800 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-xs"
          >
            <Receipt className="w-3.5 h-3.5 text-blue-600" />
            View Payslips
          </button>
        </div>
      </div>

      {/* 2. SUMMARY KPI CARDS (PASTEL CARDS - FLAT COLORS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Employees - Pastel Green */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Employees
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{totalEmployees}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Employees registered</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Present Today - Pastel Mint/Aqua */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Present Today
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">{presentCount}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">
              Attendance records for today
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Absent / Leave - Pastel Pink/Rose */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">
              Absent & On Leave
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">
              {absentCount + onLeaveCount}
            </h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">
              {absentCount} Uninformed | {onLeaveCount} Approved Leave
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <UserX className="w-5 h-5" />
          </div>
        </div>

        {/* Payroll Processed - Pastel Blue */}
        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">
              Payroll Processed
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">
              ₹{payrollProcessedAmount.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Confirmed salary payments</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. CHARTS SECTION (CENTER EXPENSES & ATTENDANCE SUMMARY) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left/Center: Payroll Expenses Breakdown Chart */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Department Payroll Expenses Breakdown
              </h3>
              <p className="text-xs text-slate-500">
                Monthly distribution of basic CTC, allowances & statutory contributions.
              </p>
            </div>
            <span className="text-xs font-bold text-[#16A34A] bg-[#DCFCE7] px-2.5 py-1 rounded-lg">
              Live Payroll Data
            </span>
          </div>

          {expenseData.length > 0 ? (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={expenseData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748B' }} />
                <Tooltip
                  formatter={(val) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Expenditure']}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '12px',
                    borderColor: '#E2E8F0',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="amount" fill="#16A34A" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400">
              Payroll data will appear after employees are registered.
            </div>
          )}
        </div>

        {/* Center-Right: Attendance Distribution Pie Chart */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Today's Attendance Status</h3>
              <p className="text-xs text-slate-500">Biometric punch-in distribution</p>
            </div>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
              {dayjs().format('DD MMM')}
            </span>
          </div>

          {attendanceDistribution.length > 0 ? (
          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {attendanceDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend
                  formatter={(val) => <span className="text-xs text-slate-700">{val}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          ) : (
            <div className="h-56 flex items-center justify-center text-sm text-slate-400">
              No attendance records for today.
            </div>
          )}
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL LAYOUT) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Content: Recent Attendance & Payroll Activities */}
        <div className="lg:col-span-8 space-y-6">
          {/* Recent Biometric Attendance Records */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Recent Attendance Logs</h3>
                <p className="text-xs text-slate-500">Click any row to inspect employee punch details.</p>
              </div>
              <button
                onClick={() => navigate('/admin/attendance')}
                className="text-xs font-bold text-[#16A34A] hover:underline flex items-center gap-1"
              >
                View Full Attendance <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                    <th className="py-3 px-4">Employee</th>
                    <th className="py-3 px-4">Check-In</th>
                    <th className="py-3 px-4">Check-Out</th>
                    <th className="py-3 px-4">Work Hours</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {attendance.slice(0, 6).map((record) => {
                    const isSelected = selectedFeedEmp?.id === record.id;
                    let badgeClass = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
                    if (record.status === 'Late') {
                      badgeClass = 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]';
                    } else if (record.status === 'Absence') {
                      badgeClass = 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]';
                    } else if (record.status === 'Half Day' || record.status === 'On Leave') {
                      badgeClass = 'bg-[#EFF6FF] text-[#1E40AF] border-[#BFDBFE]';
                    }

                    return (
                      <tr
                        key={record.id}
                        onClick={() => setSelectedFeedEmp(record)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-3 px-4">
                          <span className="font-bold text-slate-900 block">{record.fullName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {record.employeeCode} · {record.department}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700">{record.checkIn}</td>
                        <td className="py-3 px-4 font-mono text-slate-700">{record.checkOut}</td>
                        <td className="py-3 px-4 text-slate-700 font-medium">{record.workingHours}</td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}
                          >
                            {record.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedFeedEmp(record);
                            }}
                            className="px-2.5 py-1 text-xs font-bold text-[#16A34A] hover:bg-[#DCFCE7] rounded-lg transition-colors"
                          >
                            Inspect
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Announcements & Payroll Governance Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#16A34A]" />
                  Company Announcements
                </h4>
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                  Admin Notice
                </span>
              </div>
              <p className="text-xs text-slate-800 font-bold">Gandhi Jayanti Office Closure</p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Tomorrow (02 Oct 2026) is declared a statutory public holiday. Biometric attendance
                and payroll credit calculations are marked exempt.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                  Pending Approvals
                </h4>
                <button
                  onClick={() => navigate('/admin/requests')}
                  className="text-[10px] text-blue-600 font-bold hover:underline"
                >
                  View All
                </button>
              </div>
              <p className="text-xs text-slate-800 font-bold">
                {requests.filter((r) => r.status === 'Pending').length} Requests Awaiting Review
              </p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Includes leave, biometric punch correction, and permission applications pending
                decision.
              </p>
            </div>
          </div>
        </div>

        {/* Right Section / Detail Panel: Live Attendance Details & Shortcuts */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Live Attendance Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedFeedEmp ? selectedFeedEmp.fullName : 'Select an employee'}
              </h3>
            </div>
            {selectedFeedEmp && (
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#DCFCE7] text-[#15803D] border border-[#86EFAC]">
                {selectedFeedEmp.status}
              </span>
            )}
          </div>

          {selectedFeedEmp ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee Code:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedFeedEmp.employeeCode}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Department:</span>
                  <span className="font-semibold text-slate-800">{selectedFeedEmp.department}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Designation:</span>
                  <span className="font-semibold text-slate-800">{selectedFeedEmp.designation}</span>
                </div>
              </div>

              {/* Punch Timings */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl border border-slate-200 bg-white">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Check-In Time
                  </span>
                  <span className="text-sm font-mono font-bold text-[#16A34A] mt-0.5 block">
                    {selectedFeedEmp.checkIn}
                  </span>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 bg-white">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">
                    Check-Out Time
                  </span>
                  <span className="text-sm font-mono font-bold text-slate-800 mt-0.5 block">
                    {selectedFeedEmp.checkOut}
                  </span>
                </div>
              </div>

              {/* Working Hours & Remarks */}
              <div className="p-3 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Recorded Working Hours:</span>
                  <span className="font-bold text-slate-800">{selectedFeedEmp.workingHours}</span>
                </div>
                <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                  {selectedFeedEmp.remarks || 'Standard biometric record logged.'}
                </p>
              </div>

              {/* Quick Navigation Shortcuts */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Employee Shortcuts
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => navigate('/admin/employees')}
                    className="w-full py-2 px-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 font-bold hover:bg-slate-100 transition-colors text-center text-xs"
                  >
                    View 360° Profile
                  </button>
                  <button
                    onClick={() => navigate('/admin/attendance')}
                    className="w-full py-2 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center text-xs"
                  >
                    Edit Attendance
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Click an employee from the table to see real-time punch info.
            </p>
          )}
        </div>
      </div>

    </div>
  );
}
