import React, { useEffect, useMemo, useState } from 'react';
import api from '../../services/api';
import {
  Search,
  Edit2,
  X,
  IndianRupee,
  Users,
  Calculator,
  WalletCards,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function SalaryConfigurationPage() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [selectedEmp, setSelectedEmp] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  /*
   * Some values are intentionally retained even though they are no longer
   * displayed in the simplified Salary Configuration UI.
   *
   * This preserves compatibility with the existing salary API.
   */
  const [formData, setFormData] = useState({
    monthlySalary: '',
    salaryEffectiveDate: dayjs().format('YYYY-MM-DD'),
    salaryCalculationMethod: 'CALENDAR_DAYS',
    customDivisor: 30,

    lateAllowanceMonthly: 0,
    permissionAllowanceMonthly: 0,
    clRemainingDays: 0,

    salaryPaymentMethod: 'BANK_TRANSFER',
    bankName: '',
    bankAccountNumber: '',
    ifscCode: '',
    accountHolderName: '',
  });

  useEffect(() => {
    fetchEmployeesWithSalary();
  }, []);

  async function fetchEmployeesWithSalary() {
    try {
      setLoading(true);

      const res = await api.get('/employees');

      if (res.success) {
        const regularEmployees = (res.data.employees || []).filter(
          (emp) =>
            emp.user?.role !== 'ADMIN' &&
            emp.employeeCode !== 'EMP001'
        );

        setEmployees(regularEmployees);
      }
    } catch (err) {
      console.error('Error fetching employees:', err);
      setError('Unable to load employee salary details.');
    } finally {
      setLoading(false);
    }
  }

  async function handleOpenConfig(emp) {
    setSelectedEmp(emp);
    setError('');
    setSuccess('');

    try {
      const res = await api.get(`/salary/config/${emp.id}`);

      if (res.success && res.data) {
        const c = res.data;

        setFormData({
          monthlySalary:
            c.monthlySalary ??
            emp.salaryConfig?.monthlySalary ??
            '',

          /*
           * Existing configured effective date is preserved.
           * For first-time configuration, employee joining date is used.
           */
          salaryEffectiveDate:
            c.salaryEffectiveDate
              ? dayjs(c.salaryEffectiveDate).format('YYYY-MM-DD')
              : c.effectiveDate
              ? dayjs(c.effectiveDate).format('YYYY-MM-DD')
              : emp.joiningDate
              ? dayjs(emp.joiningDate).format('YYYY-MM-DD')
              : dayjs().format('YYYY-MM-DD'),

          salaryCalculationMethod:
            c.salaryCalculationMethod ||
            c.calculationMethod ||
            'CALENDAR_DAYS',

          customDivisor: c.customDivisor || 30,

          lateAllowanceMonthly:
            c.lateAllowanceMonthly ??
            c.lateAttendanceAllowance ??
            0,

          permissionAllowanceMonthly:
            c.permissionAllowanceMonthly ??
            c.permissionAllowancePerMonth ??
            0,

          clRemainingDays:
            c.clRemainingDays ??
            emp.clRemainingDays ??
            0,

          salaryPaymentMethod:
            c.salaryPaymentMethod ||
            c.paymentMethod ||
            'BANK_TRANSFER',

          bankName: c.bankName || '',

          bankAccountNumber:
            c.bankAccountNumber ||
            c.accountNumber ||
            '',

          ifscCode: c.ifscCode || '',

          accountHolderName:
            c.accountHolderName ||
            emp.fullName,
        });
      } else {
        setFormData({
          monthlySalary:
            emp.salaryConfig?.monthlySalary ??
            '',

          // First salary eligibility starts from joining date.
          salaryEffectiveDate: emp.joiningDate
            ? dayjs(emp.joiningDate).format('YYYY-MM-DD')
            : dayjs().format('YYYY-MM-DD'),

          salaryCalculationMethod:
            emp.salaryConfig?.salaryCalculationMethod ||
            emp.salaryConfig?.calculationMethod ||
            'CALENDAR_DAYS',

          customDivisor:
            emp.salaryConfig?.customDivisor ||
            30,

          lateAllowanceMonthly:
            emp.salaryConfig?.lateAllowanceMonthly ??
            emp.salaryConfig?.lateAttendanceAllowance ??
            0,

          permissionAllowanceMonthly:
            emp.salaryConfig?.permissionAllowanceMonthly ??
            emp.salaryConfig?.permissionAllowancePerMonth ??
            0,

          clRemainingDays:
            emp.clRemainingDays ??
            emp.salaryConfig?.clRemainingDays ??
            0,

          salaryPaymentMethod:
            emp.salaryConfig?.salaryPaymentMethod ||
            'BANK_TRANSFER',

          bankName:
            emp.salaryConfig?.bankName ||
            '',

          bankAccountNumber:
            emp.salaryConfig?.bankAccountNumber ||
            '',

          ifscCode:
            emp.salaryConfig?.ifscCode ||
            '',

          accountHolderName:
            emp.fullName,
        });
      }
    } catch (err) {
      console.error('Error getting salary config:', err);

      /*
       * Even if an employee does not yet have a salary config,
       * allow the Admin to create one.
       */
      setFormData({
        monthlySalary:
          emp.salaryConfig?.monthlySalary ??
          '',

        salaryEffectiveDate: emp.joiningDate
          ? dayjs(emp.joiningDate).format('YYYY-MM-DD')
          : dayjs().format('YYYY-MM-DD'),

        salaryCalculationMethod:
          emp.salaryConfig?.salaryCalculationMethod ||
          emp.salaryConfig?.calculationMethod ||
          'CALENDAR_DAYS',

        customDivisor:
          emp.salaryConfig?.customDivisor ||
          30,

        lateAllowanceMonthly:
          emp.salaryConfig?.lateAllowanceMonthly ??
          emp.salaryConfig?.lateAttendanceAllowance ??
          0,

        permissionAllowanceMonthly:
          emp.salaryConfig?.permissionAllowanceMonthly ??
          emp.salaryConfig?.permissionAllowancePerMonth ??
          0,

        clRemainingDays:
          emp.clRemainingDays ??
          emp.salaryConfig?.clRemainingDays ??
          0,

        salaryPaymentMethod:
          emp.salaryConfig?.salaryPaymentMethod ||
          'BANK_TRANSFER',

        bankName:
          emp.salaryConfig?.bankName ||
          '',

        bankAccountNumber:
          emp.salaryConfig?.bankAccountNumber ||
          '',

        ifscCode:
          emp.salaryConfig?.ifscCode ||
          '',

        accountHolderName:
          emp.fullName,
      });
    }

    setModalOpen(true);
  }

  async function handleSaveConfig(e) {
    e.preventDefault();

    if (!selectedEmp) return;

    setError('');
    setSuccess('');

    try {
      setSaving(true);

      const res = await api.put(
        `/salary/config/${selectedEmp.id}`,
        {
          monthlySalary: Number(formData.monthlySalary),

          salaryEffectiveDate:
            formData.salaryEffectiveDate,

          salaryCalculationMethod:
            formData.salaryCalculationMethod,

          customDivisor:
            Number(formData.customDivisor),

          /*
           * Existing API-compatible fields are retained.
           * They are simply not exposed in this simplified UI.
           */
          lateAllowanceMonthly:
            Number(formData.lateAllowanceMonthly),

          permissionAllowanceMonthly:
            Number(formData.permissionAllowanceMonthly),

          clRemainingDays:
            Number(formData.clRemainingDays),

          salaryPaymentMethod:
            formData.salaryPaymentMethod,

          bankName:
            formData.bankName,

          bankAccountNumber:
            formData.bankAccountNumber,

          ifscCode:
            formData.ifscCode,

          accountHolderName:
            formData.accountHolderName,
        }
      );

      if (res.success) {
        setSuccess(
          `Salary for ${selectedEmp.fullName} updated successfully.`
        );

        setModalOpen(false);

        await fetchEmployeesWithSalary();
      }
    } catch (err) {
      setError(
        err.message ||
          'Failed to update salary configuration.'
      );
    } finally {
      setSaving(false);
    }
  }

  const formatCurrency = (value, decimals = 0) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(Number(value) || 0);

  const getMethodDetails = (salaryConfig = {}) => {
    const method =
      salaryConfig.salaryCalculationMethod ||
      salaryConfig.calculationMethod ||
      'CALENDAR_DAYS';

    let divisor = 30;
    let label = '30 Calendar Days';

    if (method === 'FIXED_26') {
      divisor = 26;
      label = '26 Working Days';
    }

    if (method === 'SCHEDULED_DAYS') {
      divisor = 26;
      label = 'Scheduled Days';
    }

    if (method === 'CUSTOM_DIVISOR') {
      divisor =
        Number(salaryConfig.customDivisor) ||
        30;

      label = `${divisor} Day Divisor`;
    }

    return {
      method,
      divisor,
      label,
    };
  };

  const filtered = employees.filter((employee) => {
    const keyword = search.trim().toLowerCase();

    if (!keyword) return true;

    return (
      employee.fullName
        ?.toLowerCase()
        .includes(keyword) ||
      employee.employeeCode
        ?.toLowerCase()
        .includes(keyword) ||
      employee.department?.name
        ?.toLowerCase()
        .includes(keyword)
    );
  });

  const totalMonthlyBase = useMemo(
    () =>
      employees.reduce(
        (sum, employee) =>
          sum +
          Number(
            employee.salaryConfig?.monthlySalary ??
              0
          ),
        0
      ),
    [employees]
  );

  const configuredEmployees = useMemo(
    () =>
      employees.filter(
        (employee) => employee.salaryConfig
      ).length,
    [employees]
  );

  /*
   * Modal live calculation
   */
  const liveSalary =
    Number(formData.monthlySalary) || 0;

  let liveDivisor = 30;

  if (
    formData.salaryCalculationMethod ===
    'FIXED_26'
  ) {
    liveDivisor = 26;
  } else if (
    formData.salaryCalculationMethod ===
    'CUSTOM_DIVISOR'
  ) {
    liveDivisor =
      Number(formData.customDivisor) || 30;
  } else if (
    formData.salaryCalculationMethod ===
    'SCHEDULED_DAYS'
  ) {
    liveDivisor = 26;
  }

  const liveDailyRate =
    liveSalary /
    (liveDivisor > 0 ? liveDivisor : 30);

  return (
    <div className="space-y-4">
      {/* ================= HEADER ================= */}

      <div className="bg-white border border-[#D8E9EA] rounded-2xl px-5 py-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-[#173B57]">
              Salary Configuration
            </h1>

            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Manage employee salary and calculation
              settings.
            </p>
          </div>

          <div className="relative w-full lg:w-[280px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />

            <input
              type="text"
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              placeholder="Search employee..."
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-[#D6E6E7] rounded-xl text-xs text-slate-700 outline-none focus:ring-2 focus:ring-[#20BBB8]/20 focus:border-[#20BBB8]"
            />
          </div>
        </div>
      </div>

      {/* ================= SUCCESS ================= */}

      {success && (
        <div className="px-4 py-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          {success}
        </div>
      )}

      {/* ================= SUMMARY ================= */}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <SummaryCard
          icon={Users}
          label="Employees Configured"
          value={`${configuredEmployees} / ${employees.length}`}
          description="Salary profiles"
        />

        <SummaryCard
          icon={IndianRupee}
          label="Monthly Payroll Base"
          value={formatCurrency(totalMonthlyBase)}
          description="Configured base salary"
        />

        <SummaryCard
          icon={Calculator}
          label="Standard Salary Method"
          value="30 Days"
          description="Monthly salary divisor"
        />
      </div>

      {/* ================= SALARY TABLE ================= */}

      <div className="bg-white border border-[#D8E7E8] rounded-2xl shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E3EEEE] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-[#173B57]">
              Employee Salary Details
            </h2>

            <p className="text-[11px] text-slate-400 mt-0.5">
              Current salary configuration for active
              employees
            </p>
          </div>

          <span className="text-xs font-semibold text-[#08756F] bg-[#EAF8F7] border border-[#CBECEA] px-3 py-1 rounded-full w-fit">
            {filtered.length}{' '}
            {filtered.length === 1
              ? 'Employee'
              : 'Employees'}
          </span>
        </div>

        {loading ? (
          <div className="min-h-[260px] flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-[#20BBB8] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />

            <p className="text-sm font-semibold text-slate-500">
              No employees found
            </p>

            <p className="text-xs text-slate-400 mt-1">
              Try another employee name or code.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[850px]">
              <thead className="bg-[#F7FAFA] border-b border-[#E1ECEC]">
                <tr className="text-[10px] uppercase tracking-[0.08em] text-slate-500 font-bold">
                  <th className="px-5 py-3">
                    Employee
                  </th>

                  <th className="px-4 py-3">
                    Department
                  </th>

                  <th className="px-4 py-3">
                    Monthly Salary
                  </th>

                  <th className="px-4 py-3">
                    Daily Rate
                  </th>

                  <th className="px-4 py-3">
                    Salary Method
                  </th>

                  <th className="px-5 py-3 text-right">
                    Action
                  </th>
                </tr>
              </thead>

              <tbody className="divide-y divide-[#EDF3F3]">
                {filtered.map((employee) => {
                  const baseSalary =
                    Number(
                      employee.salaryConfig
                        ?.monthlySalary ?? 0
                    ) || 0;

                  const methodDetails =
                    getMethodDetails(
                      employee.salaryConfig
                    );

                  const dailyRate =
                    baseSalary /
                    methodDetails.divisor;

                  return (
                    <tr
                      key={employee.id}
                      className="hover:bg-[#F8FCFC] transition-colors"
                    >
                      {/* EMPLOYEE */}

                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-[#E6F6F5] text-[#08756F] flex items-center justify-center font-bold text-xs flex-shrink-0">
                            {employee.fullName
                              ?.charAt(0)
                              ?.toUpperCase() || 'E'}
                          </div>

                          <div>
                            <div className="font-bold text-slate-800 text-[12px]">
                              {employee.fullName}
                            </div>

                            <div className="text-[10px] text-slate-400 mt-0.5">
                              {employee.employeeCode}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* DEPARTMENT */}

                      <td className="px-4 py-4 text-slate-600 font-medium">
                        {employee.department?.name ||
                          'General Operations'}
                      </td>

                      {/* MONTHLY SALARY */}

                      <td className="px-4 py-4">
                        <div className="font-extrabold text-[#173B57] text-sm">
                          {formatCurrency(baseSalary)}
                        </div>
                      </td>

                      {/* DAILY RATE */}

                      <td className="px-4 py-4">
                        <div className="font-bold text-[#08756F]">
                          {formatCurrency(
                            dailyRate,
                            2
                          )}
                        </div>

                        <div className="text-[10px] text-slate-400 mt-0.5">
                          per day
                        </div>
                      </td>

                      {/* METHOD */}

                      <td className="px-4 py-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg bg-[#EAF8F7] border border-[#C7EBE8] text-[#08756F] font-semibold text-[10px]">
                          {methodDetails.label}
                        </span>
                      </td>

                      {/* ACTION */}

                      <td className="px-5 py-4 text-right">
                        <button
                          onClick={() =>
                            handleOpenConfig(employee)
                          }
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#EAF8F7] hover:bg-[#DDF3F1] text-[#08756F] border border-[#C7EBE8] rounded-xl text-xs font-bold transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          Configure
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ================= MODAL ================= */}

      {modalOpen && selectedEmp && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-[520px] rounded-2xl shadow-2xl border border-[#DCE9EA] overflow-hidden">
            {/* MODAL HEADER */}

            <div className="px-5 py-4 border-b border-[#E3EEEE] flex items-start justify-between bg-[#F4F8F9]">
              <div>
                <h3 className="text-base font-bold text-[#173B57]">
                  Configure Salary
                </h3>

                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs font-semibold text-slate-700">
                    {selectedEmp.fullName}
                  </span>

                  <span className="text-slate-300">
                    •
                  </span>

                  <span className="text-[11px] text-slate-500">
                    {selectedEmp.employeeCode}
                  </span>
                </div>

                <p className="text-[10px] text-slate-400 mt-0.5">
                  {selectedEmp.department?.name ||
                    'General Operations'}
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  setModalOpen(false)
                }
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-white rounded-xl transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {error && (
              <div className="mx-5 mt-4 px-3 py-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />

                {error}
              </div>
            )}

            <form
              onSubmit={handleSaveConfig}
              className="p-5"
            >
              <div className="space-y-4">
                {/* MONTHLY SALARY */}

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Monthly Salary
                  </label>

                  <div className="relative">
                    <IndianRupee className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />

                    <input
                      type="number"
                      required
                      min={0}
                      value={
                        formData.monthlySalary
                      }
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          monthlySalary:
                            e.target.value,
                        })
                      }
                      className="w-full pl-9 pr-4 py-3 rounded-xl border border-[#D5E5E6] bg-white text-sm font-bold text-[#173B57] outline-none focus:border-[#20BBB8] focus:ring-2 focus:ring-[#20BBB8]/15"
                    />
                  </div>
                </div>

                {/* CALCULATION METHOD */}

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Salary Calculation
                  </label>

                  <select
                    value={
                      formData.salaryCalculationMethod
                    }
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        salaryCalculationMethod:
                          e.target.value,
                      })
                    }
                    className="w-full px-3.5 py-3 rounded-xl border border-[#D5E5E6] bg-white text-xs font-semibold text-slate-700 outline-none focus:border-[#20BBB8] focus:ring-2 focus:ring-[#20BBB8]/15"
                  >
                    <option value="CALENDAR_DAYS">
                      30 Calendar Days
                    </option>

                    <option value="FIXED_26">
                      Fixed 26 Working Days
                    </option>

                    <option value="SCHEDULED_DAYS">
                      Scheduled Working Days
                    </option>

                    <option value="CUSTOM_DIVISOR">
                      Custom Divisor
                    </option>
                  </select>
                </div>

                {/* CUSTOM DIVISOR */}

                {formData.salaryCalculationMethod ===
                  'CUSTOM_DIVISOR' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Custom Divisor Days
                    </label>

                    <input
                      type="number"
                      min={1}
                      max={365}
                      required
                      value={
                        formData.customDivisor
                      }
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          customDivisor:
                            e.target.value,
                        })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-[#D5E5E6] text-sm font-bold text-slate-700 outline-none focus:border-[#20BBB8] focus:ring-2 focus:ring-[#20BBB8]/15"
                    />
                  </div>
                )}

                {/* DAILY SALARY PREVIEW */}

                <div className="bg-[#F2FAF9] border border-[#CFE9E7] rounded-xl px-4 py-4">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-[#08756F]">
                        Daily Salary
                      </div>

                      <div className="text-xl font-extrabold text-[#173B57] mt-1">
                        {formatCurrency(
                          liveDailyRate,
                          2
                        )}
                      </div>

                      <div className="text-[10px] text-slate-500 mt-1">
                        Monthly salary ÷{' '}
                        {liveDivisor} days
                      </div>
                    </div>

                    <div className="w-11 h-11 rounded-xl bg-white border border-[#D4EAE8] flex items-center justify-center">
                      <Calculator className="w-5 h-5 text-[#08756F]" />
                    </div>
                  </div>
                </div>

                {/* JOINING INFO */}

                {selectedEmp.joiningDate && (
                  <div className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <WalletCards className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />

                    <p className="text-[10px] leading-5 text-slate-500">
                      Initial salary eligibility is
                      based on employee joining date:{' '}
                      <span className="font-bold text-slate-700">
                        {dayjs(
                          selectedEmp.joiningDate
                        ).format('DD MMM YYYY')}
                      </span>
                    </p>
                  </div>
                )}
              </div>

              {/* ACTIONS */}

              <div className="flex items-center justify-end gap-2 mt-5 pt-4 border-t border-[#E5EEEE]">
                <button
                  type="button"
                  onClick={() =>
                    setModalOpen(false)
                  }
                  className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-600 hover:bg-slate-50 transition"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl bg-[#08756F] hover:bg-[#06655F] text-white text-xs font-bold shadow-sm transition disabled:opacity-50"
                >
                  {saving
                    ? 'Saving...'
                    : 'Save Salary'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

/* =====================================================
   SUMMARY CARD
===================================================== */

function SummaryCard({
  icon: Icon,
  label,
  value,
  description,
}) {
  return (
    <div className="bg-white border border-[#D8E7E8] rounded-2xl px-4 py-3.5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-[10px] uppercase tracking-[0.08em] font-bold text-slate-400">
            {label}
          </div>

          <div className="text-lg font-extrabold text-[#173B57] mt-1">
            {value}
          </div>

          <div className="text-[10px] text-slate-400 mt-0.5">
            {description}
          </div>
        </div>

        <div className="w-10 h-10 rounded-xl bg-[#EAF8F7] border border-[#D0ECE9] flex items-center justify-center flex-shrink-0">
          <Icon className="w-4.5 h-4.5 text-[#08756F]" />
        </div>
      </div>
    </div>
  );
}