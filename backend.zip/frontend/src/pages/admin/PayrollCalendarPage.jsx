import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  Calendar,
  CreditCard,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building,
  ArrowRight,
  ShieldCheck,
  FileText,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Plus,
  ChevronRight,
  Send,
  Lock,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function PayrollCalendarPage() {
  const [cycles, setCycles] = useState([]);
  const [selectedCycle, setSelectedCycle] = useState(null);
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadData();
    window.addEventListener('saishnaa_store_updated', loadData);
    return () => window.removeEventListener('saishnaa_store_updated', loadData);
  }, []);

  function loadData() {
    const list = adminStore.getPayrollCalendar();
    setCycles(list);
    if (list.length > 0 && !selectedCycle) {
      setSelectedCycle(list[0]);
    } else if (selectedCycle) {
      const updated = list.find((c) => c.id === selectedCycle.id);
      if (updated) setSelectedCycle(updated);
    }
  }

  function handleAdvanceStatus(cycleId, nextStatus) {
    adminStore.updateCycleStatus(cycleId, nextStatus);
    setToastMsg(`Payroll cycle updated to ${nextStatus}!`);
    setTimeout(() => setToastMsg(''), 4000);
  }

  // Summary counts
  const totalCycles = cycles.length;
  const completedCount = cycles.filter((c) => c.status === 'Completed').length;
  const inProgressCount = cycles.filter((c) => c.status === 'In Progress').length;
  const pendingCount = cycles.filter((c) => c.status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Calendar className="w-6 h-6 text-[#16A34A]" />
            Payroll Calendar & Lifecycle
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track, schedule, and execute the end-to-end monthly salary lifecycle and statutory filings.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => handleAdvanceStatus(selectedCycle?.id, 'Completed')}
            disabled={!selectedCycle || selectedCycle.status === 'Completed'}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] disabled:opacity-50 transition-colors shadow-xs"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Approve & Finalize Cycle
          </button>
        </div>
      </div>

      {/* 2. SUMMARY CARDS (PASTEL CARDS - FLAT ACCENTS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Cycles */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Cycles
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{totalCycles}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">FY 2026-27 Schedules</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* Completed Cycles */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Completed Cycles
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">{completedCount}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">Fully Disbursed & Complied</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* In Progress Cycle */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              In Progress
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">{inProgressCount}</h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Active Monthly Processing</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Pending Cycles */}
        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">
              Upcoming Scheduled
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">{pendingCount}</h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Automated Reminders</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. WORKFLOW ROADMAP (Flat Solid Accent) */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
          Saishnaa Payroll Lifecycle Flow
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {[
            { step: '1', title: 'Salary Configuration', desc: 'CTC & Allowances' },
            { step: '2', title: 'Payroll Processing', desc: 'Attendance & salary review' },
            { step: '3', title: 'Admin Approval', desc: 'Verification & Sign-off' },
            { step: '4', title: 'Salary Payment', desc: 'Direct Bank NEFT/RTGS' },
            { step: '5', title: 'Payslip Generation', desc: 'PDFs & Tax Deductions' },
          ].map((item, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs"
            >
              <div className="w-6 h-6 rounded-full bg-[#16A34A] text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                {item.step}
              </div>
              <div className="min-w-0">
                <p className="font-bold text-slate-800 truncate">{item.title}</p>
                <p className="text-[10px] text-slate-500 truncate">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL LAYOUT) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Table: Payroll Lifecycle Schedules */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Payroll Lifecycles</h3>
              <p className="text-xs text-slate-500">
                Select a cycle to view banking connections and execute transitions.
              </p>
            </div>
            <span className="text-xs font-bold text-[#16A34A] bg-[#DCFCE7] px-2.5 py-1 rounded-lg">
              FY 2026-27 Active
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Period</th>
                  <th className="py-3 px-4">Processing Date</th>
                  <th className="py-3 px-4">Approval Date</th>
                  <th className="py-3 px-4">Payment Date</th>
                  <th className="py-3 px-4">Est. Payout</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {cycles.map((cycle) => {
                  const isSelected = selectedCycle?.id === cycle.id;
                  let badgeClass = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
                  if (cycle.status === 'In Progress') {
                    badgeClass = 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]';
                  } else if (cycle.status === 'Pending') {
                    badgeClass = 'bg-[#EFF6FF] text-[#1E40AF] border-[#BFDBFE]';
                  }

                  return (
                    <tr
                      key={cycle.id}
                      onClick={() => setSelectedCycle(cycle)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-[#16A34A]" />
                        {cycle.period}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">{cycle.processingDate}</td>
                      <td className="py-3.5 px-4 text-slate-700">{cycle.approvalDate}</td>
                      <td className="py-3.5 px-4 text-slate-700">{cycle.paymentDate}</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        ₹{cycle.estimatedPayroll.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}
                        >
                          {cycle.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCycle(cycle);
                          }}
                          className="px-2.5 py-1 text-xs font-bold text-[#16A34A] hover:bg-[#DCFCE7] rounded-lg transition-colors"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Selected Cycle Deep Inspection */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Cycle Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mt-0.5">
                {selectedCycle ? selectedCycle.period : 'Select a cycle'}
              </h3>
            </div>
            {selectedCycle && (
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  selectedCycle.status === 'Completed'
                    ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                    : selectedCycle.status === 'In Progress'
                    ? 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                    : 'bg-[#EFF6FF] text-[#1E40AF] border-[#BFDBFE]'
                }`}
              >
                {selectedCycle.status}
              </span>
            )}
          </div>

          {selectedCycle ? (
            <div className="space-y-4 text-xs">
              {/* Financial Metrics */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Estimated Total Payroll:</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    ₹{selectedCycle.estimatedPayroll.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Employees Covered:</span>
                  <span className="font-bold text-slate-800">{selectedCycle.totalEmployees} Active Staff</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Next Payment Window:</span>
                  <span className="font-bold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded">
                    {selectedCycle.nextPaymentDays}
                  </span>
                </div>
              </div>

              {/* Banking & Disbursal Connection */}
              <div className="space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Payment Account & Gateway
                </p>
                <div className="p-3 rounded-xl border border-slate-200 bg-white space-y-1.5">
                  <p className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-[#16A34A]" />
                    {selectedCycle.paymentAccount}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Direct Corporate Banking Integration: <span className="text-emerald-700 font-bold">{selectedCycle.bankConnection}</span>
                  </p>
                </div>
              </div>

              {/* Payslip & Statutory Filing Breakdown */}
              <div className="space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Payslip & Statutory Compliance
                </p>
                <div className="p-3 rounded-xl border border-slate-200 bg-white space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Payslip Status:</span>
                    <span className="font-bold text-slate-800">{selectedCycle.payslipGeneration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Tax & Deduction:</span>
                    <span className="font-bold text-slate-800">{selectedCycle.taxDeduction}</span>
                  </div>
                </div>
              </div>

              {/* State Transition Actions */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Cycle Management Actions
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleAdvanceStatus(selectedCycle.id, 'In Progress')}
                    className="w-full py-2 px-3 rounded-xl border border-[#FCD34D] bg-[#FEF9C3] text-[#854D0E] font-bold hover:bg-[#FEF08A] transition-colors text-center"
                  >
                    Set In Progress
                  </button>
                  <button
                    onClick={() => handleAdvanceStatus(selectedCycle.id, 'Completed')}
                    className="w-full py-2 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center"
                  >
                    Mark Completed
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click on a cycle in the table to inspect details.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
