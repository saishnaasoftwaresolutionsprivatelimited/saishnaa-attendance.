import React, { useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { History, LogIn, LogOut, RefreshCw, Search, ShieldCheck } from 'lucide-react';
import api from '../../services/api';

const actionLabels = {
  USER_LOGIN: 'Signed in',
  USER_LOGOUT: 'Signed out',
  EMPLOYEE_REGISTERED: 'Registered employee',
  EMPLOYEE_UPDATED: 'Updated employee',
  EMPLOYEE_STATUS_CHANGED: 'Changed employee status',
  ACCOUNT_ACCESS_RESET: 'Reset account access',
  SHIFT_ASSIGNED: 'Assigned shift',
  SALARY_CONFIGURATION_UPDATED: 'Updated salary configuration',
  PAYROLL_CALCULATED: 'Calculated payroll',
  PAYROLL_CALCULATION_OVERRIDE: 'Adjusted payroll calculation',
};

export default function AuditTrailPage() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [role, setRole] = useState('HR');
  const [search, setSearch] = useState('');

  async function loadLogs() {
    try {
      setLoading(true);
      setError('');
      const params = new URLSearchParams({ role, limit: '100' });
      if (search.trim()) params.set('search', search.trim());
      const res = await api.get(`/audit?${params.toString()}`);
      setLogs(res.data?.auditLogs || []);
    } catch (err) {
      setError(err.message || 'Unable to load the audit trail.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadLogs(); }, [role]);

  return (
    <div className="space-y-5">
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#20266D]" />
            <h1 className="text-xl font-extrabold text-[#20266D]">User Activity Audit Trail</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">Admin-only history of HR sign-ins, sign-outs, and privileged workforce or payroll actions.</p>
        </div>
        <button onClick={loadLogs} className="px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-2 hover:bg-slate-50">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row gap-3">
          <form onSubmit={(e) => { e.preventDefault(); loadLogs(); }} className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search action, email, employee, or entity..." className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-[#3563E9]" />
          </form>
          <select value={role} onChange={(e) => setRole(e.target.value)} className="px-3 py-2 text-xs font-bold border border-slate-200 rounded-xl bg-slate-50">
            <option value="HR">HR Activity</option>
            <option value="EMPLOYEE">Employee Activity</option>
            <option value="ALL">All Users</option>
          </select>
        </div>

        {error && <div className="m-4 p-3 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl">{error}</div>}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3">Date & Time</th>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Activity</th>
                <th className="px-4 py-3">Entity</th>
                <th className="px-4 py-3">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={5} className="py-12 text-center text-slate-400">Loading audit activity...</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={5} className="py-12 text-center text-slate-400">No matching activity has been recorded yet.</td></tr>
              ) : logs.map((log) => {
                const Icon = log.action === 'USER_LOGIN' ? LogIn : log.action === 'USER_LOGOUT' ? LogOut : History;
                return (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="px-5 py-3 whitespace-nowrap font-medium text-slate-700">{dayjs(log.createdAt).format('DD MMM YYYY, hh:mm:ss A')}</td>
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900">{log.user?.employee?.fullName || log.user?.email || 'System'}</div>
                      <div className="text-[10px] text-slate-400">{log.user?.employee?.employeeCode || log.user?.role || 'SYSTEM'} · {log.user?.email || 'Automated process'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 font-bold text-[#20266D]"><Icon className="w-3.5 h-3.5" />{actionLabels[log.action] || log.action.replaceAll('_', ' ')}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{log.entityType}{log.entityId ? ` · ${log.entityId.slice(0, 10)}` : ''}</td>
                    <td className="px-4 py-3 font-mono text-[10px] text-slate-500">{log.ipAddress || '--'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
