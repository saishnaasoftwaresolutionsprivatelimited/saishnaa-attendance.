import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  Users,
  UserCheck,
  UserX,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  Building,
  Briefcase,
  Phone,
  Mail,
  Calendar,
  CreditCard,
  ShieldCheck,
  Clock,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import dayjs from 'dayjs';

function mapServerEmployee(employee) {
  const employmentTypes = {
    FULL_TIME: 'Full Time',
    PART_TIME: 'Part Time',
    CONTRACT: 'Contract',
    INTERN: 'Internship',
  };
  return {
    ...employee,
    department: employee.department?.name || '',
    departmentId: employee.departmentId || '',
    designation: employee.designation?.title || '',
    designationId: employee.designationId || '',
    branch: employee.branch?.name || '',
    branchId: employee.branchId || '',
    joiningDate: employee.joiningDate ? dayjs(employee.joiningDate).format('YYYY-MM-DD') : '',
    employmentType: employmentTypes[employee.employmentType] || employee.employmentType || 'Full Time',
    basicSalary: employee.salaryConfig?.monthlySalary ?? '',
    bankAccountNumber: employee.salaryConfig?.accountNumber || '',
    bankName: employee.salaryConfig?.bankName || '',
    ifscCode: employee.salaryConfig?.ifscCode || '',
    status: employee.employeeStatus === 'ACTIVE' ? 'Active' : 'Inactive',
    accountStatus: employee.user?.accountStatus || employee.accountStatus || '',
    role: employee.user?.role || employee.role || 'EMPLOYEE',
    password: '',
  };
}

export default function EmployeeManagement() {
  const [employees, setEmployees] = useState([]);
  const [metadata, setMetadata] = useState({ departments: [], designations: [], branches: [] });
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Master-Detail selected employee
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [detailTab, setDetailTab] = useState('PERSONAL'); // 'PERSONAL' | 'ATTENDANCE' | 'PAYROLL'

  // Add / Edit Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordInModal, setShowPasswordInModal] = useState(false);
  const [createdAccountModal, setCreatedAccountModal] = useState(null);
  const [formData, setFormData] = useState({
    id: '',
    employeeCode: '',
    fullName: '',
    email: '',
    phone: '',
    department: '',
    departmentId: '',
    designation: '',
    designationId: '',
    branch: '',
    branchId: '',
    joiningDate: '',
    employmentType: 'Full Time',
    basicSalary: '',
    bankName: '',
    bankAccountNumber: '',
    ifscCode: '',
    status: 'Active',
    gender: '',
    address: '',
    role: 'EMPLOYEE',
    password: '',
  });

  // Delete Confirmation Dialog
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [empToDelete, setEmpToDelete] = useState(null);

  const [toastMsg, setToastMsg] = useState('');
  const [toastIsError, setToastIsError] = useState(false);

  useEffect(() => {
    loadEmployees();
  }, []);

  async function loadEmployees() {
    try {
      const [employeeResponse, metadataResponse] = await Promise.all([
        api.get('/employees'),
        api.get('/employees/metadata'),
      ]);
      if (!employeeResponse.success || !metadataResponse.success) {
        throw new Error(employeeResponse.message || metadataResponse.message || 'Unable to load employee records.');
      }
      const list = (employeeResponse.data?.employees || []).map(mapServerEmployee);
      setEmployees(list);
      setMetadata(metadataResponse.data || { departments: [], designations: [], branches: [] });
      setSelectedEmployee((current) => list.find((employee) => employee.id === current?.id) || list[0] || null);
    } catch (error) {
      setEmployees([]);
      setSelectedEmployee(null);
      setMetadata({ departments: [], designations: [], branches: [] });
      setToastIsError(true);
      setToastMsg(error.message || 'Unable to load employee records.');
    }
  }

  // Summary Metrics
  const totalCount = employees.length;
  const activeCount = employees.filter((e) => e.status === 'Active').length;
  const inactiveCount = employees.filter((e) => e.status === 'Inactive').length;

  // Filtered List
  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch =
      emp.fullName.toLowerCase().includes(search.toLowerCase()) ||
      emp.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
      (emp.department || '').toLowerCase().includes(search.toLowerCase()) ||
      (emp.designation || '').toLowerCase().includes(search.toLowerCase());
    const matchesDept = selectedDept === 'ALL' || emp.department === selectedDept;
    const matchesStatus = selectedStatus === 'ALL' || emp.status === selectedStatus;
    return matchesSearch && matchesDept && matchesStatus;
  });

  function handleOpenAdd() {
    setIsEditing(false);
    setShowPasswordInModal(false);
    setFormData({
      id: '',
      employeeCode: '',
      fullName: '',
      email: '',
      phone: '',
      department: '',
      departmentId: '',
      designation: '',
      designationId: '',
      branch: '',
      branchId: '',
      joiningDate: '',
      employmentType: 'Full Time',
      basicSalary: '',
      bankName: '',
      bankAccountNumber: '',
      ifscCode: '',
      status: 'Active',
      gender: '',
      address: '',
      role: 'EMPLOYEE',
      password: '',
    });
    setModalOpen(true);
  }

  function handleOpenEdit(emp, e) {
    if (e) e.stopPropagation();
    setIsEditing(true);
    setShowPasswordInModal(false);
    setFormData({
      id: emp.id,
      employeeCode: emp.employeeCode,
      fullName: emp.fullName,
      email: emp.email,
      phone: emp.phone,
      department: emp.department,
      departmentId: emp.departmentId,
      designation: emp.designation,
      designationId: emp.designationId,
      branch: emp.branch,
      branchId: emp.branchId,
      joiningDate: emp.joiningDate,
      employmentType: emp.employmentType,
      basicSalary: emp.basicSalary,
      bankName: emp.bankName || '',
      bankAccountNumber: emp.bankAccountNumber,
      ifscCode: emp.ifscCode,
      status: emp.status,
      gender: emp.gender || '',
      address: emp.address || '',
      role: emp.role || (emp.department === 'Human Resources' ? 'HR' : 'EMPLOYEE'),
      password: emp.password || '',
    });
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.email.trim()) return;

    let employeeSaved = false;
    try {
      const employmentTypes = {
        'Full Time': 'FULL_TIME',
        'Part Time': 'PART_TIME',
        Contract: 'CONTRACT',
        Internship: 'INTERN',
      };
      const employeePayload = {
        employeeCode: formData.employeeCode || undefined,
        fullName: formData.fullName.trim(),
        email: formData.email.trim(),
        phone: formData.phone || null,
        departmentId: formData.departmentId,
        designationId: formData.designationId,
        branchId: formData.branchId,
        joiningDate: formData.joiningDate,
        employmentType: employmentTypes[formData.employmentType] || 'FULL_TIME',
        role: formData.role,
        address: formData.address || null,
      };
      let savedEmployee;
      if (isEditing) {
        const response = await api.patch(`/employees/${formData.id}`, employeePayload);
        if (!response.success) throw new Error(response.message || 'Unable to update employee.');
        savedEmployee = response.data;
        employeeSaved = true;
      } else {
        const createPayload = {
          ...employeePayload,
          temporaryPassword: formData.password,
          clRemainingDays: 0,
          lateAllowanceMonthly: 0,
          permissionAllowanceMonthly: 0,
          ...(formData.basicSalary !== '' && Number(formData.basicSalary) > 0
            ? {
                monthlySalary: Number(formData.basicSalary),
                salaryEffectiveDate: formData.joiningDate,
                paymentMethod: 'BANK_TRANSFER',
                bankName: formData.bankName || null,
                bankAccountNumber: formData.bankAccountNumber || null,
                ifscCode: formData.ifscCode || null,
              }
            : {}),
        };
        const response = await api.post('/employees', createPayload);
        if (!response.success) throw new Error(response.message || 'Unable to create employee.');
        savedEmployee = response.data.employee;
        employeeSaved = true;
        if (formData.status === 'Inactive') {
          const statusResponse = await api.patch(`/employees/${savedEmployee.id}/status`, { employeeStatus: 'INACTIVE' });
          if (!statusResponse.success) throw new Error(statusResponse.message || 'Employee was created but could not be deactivated.');
        }
        setCreatedAccountModal({
          ...mapServerEmployee(savedEmployee),
          role: formData.role,
          password: response.data.credentials.temporaryPassword,
        });
      }

      if (isEditing && formData.basicSalary !== '' && Number(formData.basicSalary) > 0) {
        const salaryResponse = await api.put(`/salary/config/${formData.id || savedEmployee.id}`, {
          monthlySalary: Number(formData.basicSalary),
          salaryEffectiveDate: formData.joiningDate,
          paymentMethod: 'BANK_TRANSFER',
          bankName: formData.bankName || null,
          bankAccountNumber: formData.bankAccountNumber || null,
          ifscCode: formData.ifscCode || null,
          lateAllowanceMonthly: 0,
          permissionAllowanceMonthly: 0,
        });
        if (!salaryResponse.success) throw new Error(salaryResponse.message || 'Employee saved, but salary details could not be saved.');
      }

      if (isEditing && (formData.status === 'Active') !== (savedEmployee.employeeStatus === 'ACTIVE')) {
        const statusResponse = await api.patch(`/employees/${formData.id}/status`, {
          employeeStatus: formData.status === 'Active' ? 'ACTIVE' : 'INACTIVE',
        });
        if (!statusResponse.success) throw new Error(statusResponse.message || 'Employee was saved but status could not be updated.');
      }

      setToastMsg(`Employee ${formData.fullName} ${isEditing ? 'updated' : 'registered'} successfully.`);
      setToastIsError(false);
      await loadEmployees();
      setModalOpen(false);
    } catch (error) {
      if (employeeSaved) await loadEmployees();
      setToastIsError(true);
      setToastMsg(error.message || 'Unable to save employee details.');
    }

    setTimeout(() => setToastMsg(''), 4000);
  }

  function handleDeleteClick(emp, e) {
    if (e) e.stopPropagation();
    setEmpToDelete(emp);
    setDeleteConfirmOpen(true);
  }

  async function confirmDelete() {
    if (empToDelete) {
      try {
        const response = await api.delete(`/employees/${empToDelete.id}`);
        if (!response.success) throw new Error(response.message || 'Unable to remove employee.');
        setToastMsg(`Employee ${empToDelete.fullName} removed.`);
        setToastIsError(false);
        setDeleteConfirmOpen(false);
        setEmpToDelete(null);
        await loadEmployees();
      } catch (error) {
        setToastIsError(true);
        setToastMsg(error.message || 'Unable to remove employee.');
      }
      setTimeout(() => setToastMsg(''), 4000);
    }
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className={`fixed bottom-5 right-5 z-50 ${toastIsError ? 'bg-rose-600' : 'bg-[#16A34A]'} text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in`}>
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-[#16A34A]" />
            Employee Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Master directory of all registered personnel, departmental mappings, CTC, and banking details.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Employee
        </button>
      </div>

      {/* 2. SUMMARY CARDS (Top 3 KPI Cards specified in requirements) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Employees */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Employees
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{totalCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Enrolled on System</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Active Employees */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Active Employees
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">{activeCount}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">On Active Payroll Duty</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Inactive Employees */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">
              Inactive Employees
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">{inactiveCount}</h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">Notice Period / Suspended</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <UserX className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. SEARCH & FILTERS BAR */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, ID, department, or designation..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Department Filter */}
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Departments</option>
            {[...new Set([...metadata.departments.map((department) => department.name), ...employees.map((employee) => employee.department).filter(Boolean)])]
              .sort((a, b) => a.localeCompare(b))
              .map((department) => <option key={department} value={department}>{department}</option>)}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Employee Table */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Employee List</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredEmployees.length} of {totalCount} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Position</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Joining Date</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEmployees.map((emp) => {
                  const isSelected = selectedEmployee?.id === emp.id;
                  const isActive = emp.status === 'Active';

                  return (
                    <tr
                      key={emp.id}
                      onClick={() => setSelectedEmployee(emp)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-[#16A34A] text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                            {emp.avatar || emp.fullName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 block">{emp.fullName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {emp.employeeCode}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">{emp.designation}</td>
                      <td className="py-3 px-4 text-slate-600">{emp.department}</td>
                      <td className="py-3 px-4 text-slate-600">{emp.joiningDate}</td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                            isActive
                              ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                              : 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]'
                          }`}
                        >
                          {emp.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={(e) => handleOpenEdit(emp, e)}
                            title="Edit Employee"
                            className="p-1.5 rounded-lg text-slate-500 hover:text-[#16A34A] hover:bg-slate-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteClick(emp, e)}
                            title="Delete Employee"
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Selected Employee Detailed View */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Employee Profile Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedEmployee ? selectedEmployee.fullName : 'Select an employee'}
              </h3>
            </div>
            {selectedEmployee && (
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  selectedEmployee.status === 'Active'
                    ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                    : 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]'
                }`}
              >
                {selectedEmployee.status}
              </span>
            )}
          </div>

          {selectedEmployee ? (
            <div className="space-y-4 text-xs">
              {/* Header Badge */}
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-12 h-12 rounded-xl bg-[#16A34A] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                  {selectedEmployee.avatar || selectedEmployee.fullName.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="font-bold text-slate-900 text-sm truncate">
                    {selectedEmployee.fullName}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">
                    {selectedEmployee.designation} · {selectedEmployee.department}
                  </p>
                  <p className="text-[10px] text-emerald-700 font-mono mt-0.5">
                    {selectedEmployee.employeeCode}
                  </p>
                </div>
              </div>

              {/* Navigation Tabs inside Detail Panel */}
              <div className="flex border-b border-slate-200 text-xs font-bold">
                <button
                  onClick={() => setDetailTab('PERSONAL')}
                  className={`py-2 px-3 border-b-2 transition-colors ${
                    detailTab === 'PERSONAL'
                      ? 'border-[#16A34A] text-[#16A34A]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Personal Info
                </button>
                <button
                  onClick={() => setDetailTab('ATTENDANCE')}
                  className={`py-2 px-3 border-b-2 transition-colors ${
                    detailTab === 'ATTENDANCE'
                      ? 'border-[#16A34A] text-[#16A34A]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Attendance History
                </button>
                <button
                  onClick={() => setDetailTab('PAYROLL')}
                  className={`py-2 px-3 border-b-2 transition-colors ${
                    detailTab === 'PAYROLL'
                      ? 'border-[#16A34A] text-[#16A34A]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Payroll History
                </button>
              </div>

              {/* Tab 1: Personal Information */}
              {detailTab === 'PERSONAL' && (
                <div className="space-y-2.5">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Email:</span>
                    <span className="font-medium text-slate-800">{selectedEmployee.email}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Phone:</span>
                    <span className="font-medium text-slate-800">{selectedEmployee.phone}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Joining Date:</span>
                    <span className="font-medium text-slate-800">{selectedEmployee.joiningDate}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Employment Type:</span>
                    <span className="font-medium text-slate-800">{selectedEmployee.employmentType}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Monthly Basic Salary:</span>
                    <span className="font-mono font-bold text-[#16A34A]">
                      ₹{Number(selectedEmployee.basicSalary || 0).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Bank Account:</span>
                    <span className="font-mono text-slate-800">
                      {selectedEmployee.bankAccountNumber || 'Not Linked'}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">IFSC Code:</span>
                    <span className="font-mono text-slate-800">{selectedEmployee.ifscCode}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Last System Login:</span>
                    <span className="text-slate-700">{selectedEmployee.lastLogin}</span>
                    <span className="text-slate-700">{selectedEmployee.lastLogin || 'Never'}</span>
                  </div>

                  {/* Portal Login Credentials Inspection Box */}
                  <div className="mt-3.5 p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                        Portal Login Access
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-blue-100 text-blue-800">
                        {selectedEmployee.role || 'EMPLOYEE'}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-[11px] pt-1">
                      <span className="text-slate-500">Login Email:</span>
                      <span className="font-mono font-bold text-slate-800 select-all">{selectedEmployee.email}</span>
                    </div>

                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-500">Employee Code:</span>
                      <span className="font-mono font-bold text-slate-800 select-all">{selectedEmployee.employeeCode}</span>
                    </div>

                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-500">Portal Password:</span>
                      <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-blue-200 select-all">
                        Managed securely; cannot be viewed
                      </span>
                    </div>

                    <div className="pt-1.5 text-[10px] text-blue-700 font-medium border-t border-blue-100 flex items-center justify-between">
                      <span>Login Portal: /login (Employee tab)</span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(
                            `Saishnaa Employee Login:\nID: ${selectedEmployee.email} (or ${selectedEmployee.employeeCode})\nUse the temporary password provided at account creation.\nURL: ${window.location.origin}/login`
                          );
                          setToastIsError(false);
                          setToastMsg(`Login credentials copied for ${selectedEmployee.fullName}!`);
                          setTimeout(() => setToastMsg(''), 3000);
                        }}
                        className="text-blue-800 hover:text-blue-950 font-bold underline cursor-pointer"
                      >
                        Copy Login Info
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Attendance History */}
              {detailTab === 'ATTENDANCE' && (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-emerald-800 uppercase">
                        Presence Rate
                      </p>
                      <p className="text-lg font-black text-emerald-900">
                        {selectedEmployee.presenceRate ?? '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-emerald-800 uppercase">Leaves Left</p>
                      <p className="text-lg font-black text-emerald-900">
                        {selectedEmployee.leavesRemaining ?? '—'}{selectedEmployee.leavesRemaining === undefined ? '' : ' Days'}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold text-slate-700">Recent Attendance Logs</p>
                    <p className="text-xs text-slate-400 py-3 text-center">Attendance records are available in Attendance Management.</p>
                  </div>
                </div>
              )}

              {/* Tab 3: Payroll History */}
              {detailTab === 'PAYROLL' && (
                <div className="space-y-3">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Basic Pay:</span>
                      <span className="font-mono font-bold text-slate-900">
                        {selectedEmployee.basicSalary === '' ? '—' : `₹${Number(selectedEmployee.basicSalary).toLocaleString('en-IN')}`}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">HRA & Allowances:</span>
                      <span className="font-mono text-slate-900">
                        —
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-slate-200 pt-1">
                      <span className="text-slate-700 font-bold">Net Pay:</span>
                      <span className="font-mono font-black text-[#16A34A] text-sm">
                        —
                      </span>
                    </div>
                  </div>
                  <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex justify-between items-center">
                    <span>Payroll status</span>
                    <span className="font-bold">See employee Payslips after payroll processing</span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  onClick={(e) => handleOpenEdit(selectedEmployee, e)}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-100 text-slate-800 font-bold hover:bg-slate-200 transition-colors text-center text-xs"
                >
                  Edit Information
                </button>
                <button
                  onClick={(e) => handleDeleteClick(selectedEmployee, e)}
                  className="py-2 px-3 rounded-xl bg-rose-50 text-rose-600 font-bold hover:bg-rose-100 transition-colors text-center text-xs"
                >
                  Delete
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click an employee row to view profile.
            </p>
          )}
        </div>
      </div>

      {/* ADD / EDIT EMPLOYEE MODAL (ALL REQUIRED FIELDS) */}
      {modalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-[#16A34A]" />
                {isEditing ? 'Edit Employee Details' : 'Register New Employee'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 pt-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Employee Code</label>
                  <input
                    type="text"
                    value={formData.employeeCode}
                    onChange={(e) => setFormData({ ...formData, employeeCode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter full name"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="name@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter phone number"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department *</label>
                  <select
                    required
                    value={formData.departmentId}
                    onChange={(e) => setFormData({ ...formData, departmentId: e.target.value, designationId: '' })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                  >
                    <option value="">Select department</option>
                    {metadata.departments.map((department) => (
                      <option key={department.id} value={department.id}>{department.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Designation *</label>
                  <select
                    required
                    value={formData.designationId}
                    onChange={(e) => setFormData({ ...formData, designationId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  >
                    <option value="">Select designation</option>
                    {metadata.designations
                      .filter((designation) => !designation.departmentId || designation.departmentId === formData.departmentId)
                      .map((designation) => (
                        <option key={designation.id} value={designation.id}>{designation.title}</option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Joining Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.joiningDate}
                    onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Office Location *</label>
                  <select
                    required
                    value={formData.branchId}
                    onChange={(e) => setFormData({ ...formData, branchId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                  >
                    <option value="">Select office</option>
                    {metadata.branches.map((branch) => (
                      <option key={branch.id} value={branch.id}>{branch.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Employment Type</label>
                  <select
                    value={formData.employmentType}
                    onChange={(e) => setFormData({ ...formData, employmentType: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                  >
                    <option value="Full Time">Full Time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Monthly Basic CTC (₹)</label>
                  <input
                    type="number"
                    value={formData.basicSalary}
                    onChange={(e) => setFormData({ ...formData, basicSalary: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Employment Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Bank Account Number</label>
                  <input
                    type="text"
                    placeholder="Enter bank account number"
                    value={formData.bankAccountNumber}
                    onChange={(e) => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Bank IFSC Code</label>
                  <input
                    type="text"
                    placeholder="Enter IFSC code"
                    value={formData.ifscCode}
                    onChange={(e) => setFormData({ ...formData, ifscCode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>
              </div>

              {/* PORTAL ACCESS & LOGIN CREDENTIALS SECTION */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
                    <span className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                      Portal Login & Access Credentials
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">Used to sign in at /login</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Portal Access Role *</label>
                    <select
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] bg-white font-medium"
                    >
                      <option value="EMPLOYEE">Employee (Standard Portal Access)</option>
                      <option value="HR">HR Specialist / Manager</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-bold text-slate-700">Account Password {isEditing ? '' : '*'}</label>
                      <button
                        type="button"
                        onClick={() => {
                          const randPass = `Emp@${Math.floor(1000 + Math.random() * 9000)}!`;
                          setFormData({ ...formData, password: randPass });
                        }}
                        hidden={isEditing}
                        className="text-[10px] text-blue-600 hover:text-blue-800 font-bold underline"
                      >
                        Auto-generate
                      </button>
                    </div>
                    {isEditing ? (
                      <p className="text-[10px] text-slate-500">Existing passwords are not viewable or editable here.</p>
                    ) : (
                      <div className="relative">
                        <input
                          type={showPasswordInModal ? 'text' : 'password'}
                          required
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          placeholder="Create a password"
                          className="w-full px-3 py-2 pr-10 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPasswordInModal(!showPasswordInModal)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                        >
                          {showPasswordInModal ? 'Hide' : 'Show'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">
                  💡 Note: The employee will be able to log in using <strong>either</strong> their email (
                  <span className="font-mono text-slate-700">{formData.email || 'email'}</span>) or Employee Code (
                  <span className="font-mono text-slate-700">{formData.employeeCode || 'assigned after registration'}</span>) and this password.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors shadow-xs"
                >
                  {isEditing ? 'Save Changes' : 'Register Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ACCOUNT CREATED CREDENTIALS CONFIRMATION MODAL */}
      {createdAccountModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-200 animate-in fade-in">
            <div className="flex items-center gap-3 mb-4 pb-3 border-b border-emerald-100">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Employee Login Created!</h3>
                <p className="text-xs text-slate-500">Account is active and ready for login immediately.</p>
              </div>
            </div>

            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2.5 text-xs mb-5">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-semibold">Employee Name:</span>
                <span className="font-bold text-slate-900">{createdAccountModal.fullName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-semibold">Employee Code:</span>
                <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-emerald-200 select-all">
                  {createdAccountModal.employeeCode}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-semibold">Login Email:</span>
                <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-emerald-200 select-all">
                  {createdAccountModal.email}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-semibold">Login Password:</span>
                <span className="font-mono font-black text-emerald-800 bg-white px-2 py-0.5 rounded border border-emerald-200 select-all">
                  {createdAccountModal.password}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-semibold">Portal Tab:</span>
                <span className="font-bold text-slate-800">
                  {createdAccountModal.role === 'HR' ? 'HR Portal' : 'Employee Portal'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(
                    `Saishnaa Login Credentials:\nName: ${createdAccountModal.fullName}\nLogin ID / Email: ${createdAccountModal.email}\nEmployee Code: ${createdAccountModal.employeeCode}\nPassword: ${createdAccountModal.password}\nPortal URL: ${window.location.origin}/login (Select ${createdAccountModal.role === 'HR' ? 'HR' : 'Employee'} Tab)`
                  );
                  setToastIsError(false);
                  setToastMsg('Credentials copied to clipboard!');
                  setTimeout(() => setToastMsg(''), 3000);
                }}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition-colors"
              >
                Copy Credentials
              </button>
              <button
                type="button"
                onClick={() => setCreatedAccountModal(null)}
                className="flex-1 py-2.5 px-4 bg-[#16A34A] hover:bg-[#15803D] text-white font-bold rounded-xl text-xs transition-colors shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 text-xs animate-in fade-in">
            <div className="flex items-center gap-2.5 text-rose-600 mb-2">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <h3 className="text-sm font-bold">Confirm Delete Employee</h3>
            </div>
            <p className="text-slate-600 mt-2">
              Are you sure you want to remove <strong>{empToDelete?.fullName}</strong> (
              {empToDelete?.employeeCode})? This action will remove their payroll and attendance
              records.
            </p>
            <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => setDeleteConfirmOpen(false)}
                className="px-3.5 py-1.5 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-1.5 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-colors"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}