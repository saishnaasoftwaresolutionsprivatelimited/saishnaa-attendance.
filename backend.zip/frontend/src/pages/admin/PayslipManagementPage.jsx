import React, { useState, useEffect, useMemo } from 'react';
import api from '../../services/api';
import { generatePayslipPDF } from '../../utils/pdfGenerator';
import {
  FileText,
  IndianRupee,
  Download,
  Printer,
  Search,
  Filter,
  Calendar,
  Building,
  CheckCircle2,
  Clock,
  ChevronRight,
  TrendingUp,
  Receipt,
  User,
  ShieldCheck,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function PayslipManagementPage() {
  const [selectedMonth, setSelectedMonth] = useState(dayjs().month() + 1);
  const [selectedYear, setSelectedYear] = useState(dayjs().year());
  const [search, setSearch] = useState('');
  const [calculations, setCalculations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPayslip, setSelectedPayslip] = useState(null);

  useEffect(() => {
    fetchPayslipData();
  }, [selectedMonth, selectedYear]);

  async function fetchPayslipData() {
    try {
      setLoading(true);
      const res = await api.get(`/payroll/periods?year=${selectedYear}`);
      if (res.success && res.data) {
        const targetMonthYear = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}`;
        const period = res.data.find(p => p.monthYear === targetMonthYear || (p.year === selectedYear && p.month === selectedMonth));
        if (period && period.calculations) {
          setCalculations(period.calculations);
          if (period.calculations.length > 0) {
            setSelectedPayslip(period.calculations[0]);
          } else {
            setSelectedPayslip(null);
          }
        } else {
          setCalculations([]);
          setSelectedPayslip(null);
        }
      } else {
        setCalculations([]);
        setSelectedPayslip(null);
      }
    } catch (err) {
      console.error('Fetch payslip error:', err);
    } finally {
      setLoading(false);
    }
  }

  const filtered = useMemo(() => {
    return calculations.filter(c => {
      const name = c.employee?.fullName || '';
      const code = c.employee?.employeeCode || '';
      return name.toLowerCase().includes(search.toLowerCase()) || code.toLowerCase().includes(search.toLowerCase());
    });
  }, [calculations, search]);

  const totalGenerated = calculations.length;
  const totalBonuses = calculations.reduce((acc, c) => acc + Number(c.bonusAmount || 0), 0);
  const totalDeductions = calculations.reduce((acc, c) => acc + Number(c.totalDeductions || 0), 0);
  const totalNetPaid = calculations.reduce((acc, c) => acc + Number(c.netSalary || 0), 0);

  function handlePrint() {
    window.print();
  }

  function handleDownloadPDF(slip) {
    const target = slip && slip.id ? slip : selectedPayslip;
    if (!target) return;
    const monthStr = `${dayjs().month(selectedMonth - 1).format('MMMM')} ${selectedYear}`;
    generatePayslipPDF(target, monthStr);
  }

  return (
    <div className="space-y-5">
      {/* 1. PAGE HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white border border-[#D0E4E8] rounded-2xl px-6 py-4 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-[#183D48]">Employee Payslips</h1>
          <p className="text-xs text-[#217E93] mt-0.5 font-medium">
            Manage salary receipts, inspect breakdown components, and export employee payslips.
          </p>
        </div>

        {/* Month Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#F4F8F9] border border-[#D0E4E8] rounded-xl px-3 py-1.5 text-xs font-semibold text-[#183D48]">
            <Calendar className="w-3.5 h-3.5 text-[#27A9BF]" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="bg-transparent outline-none cursor-pointer"
            >
              {[
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
              ].map((m, idx) => (
                <option key={m} value={idx + 1}>{m}</option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="bg-transparent outline-none cursor-pointer"
            >
              {[2025, 2026, 2027].map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 2. SUMMARY CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Generated (Ice Aqua) */}
        <div className="bg-white border border-[#D0E4E8] rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-[#E8F6F8] border border-[#B8E3EA] flex items-center justify-center text-[#217E93]">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#1D4F5E] bg-[#E8F6F8] border border-[#B8E3EA] px-2 py-0.5 rounded-full">
              Receipts
            </span>
          </div>
          <div className="mt-3">
            <p className="text-[11px] font-semibold text-[#1D4F5E]">Payslips Generated</p>
            <h3 className="text-2xl font-extrabold text-[#183D48] leading-tight mt-0.5">
              {totalGenerated}
            </h3>
            <p className="text-[10px] text-[#217E93] mt-1 font-medium">All active employees</p>
          </div>
        </div>

        {/* Bonuses */}
        <div className="bg-white border border-[#D0E4E8] rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-[#F1F9E8] border border-[#C6E79A] flex items-center justify-center text-[#689F38]">
              <TrendingUp className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#2B4A15] bg-[#F1F9E8] border border-[#C6E79A] px-2 py-0.5 rounded-full">
              Incentives
            </span>
          </div>
          <div className="mt-3">
            <p className="text-[11px] font-semibold text-[#3E6920]">Bonuses</p>
            <h3 className="text-2xl font-extrabold text-[#2B4A15] leading-tight mt-0.5">
              ₹ {totalBonuses.toLocaleString('en-IN')}
            </h3>
            <p className="text-[10px] text-[#558B2F] mt-1 font-medium">Recorded employee bonuses</p>
          </div>
        </div>

        {/* Deductions (Coral Red) */}
        <div className="bg-white border border-[#D0E4E8] rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-[#FFF5F5] border border-[#FECACA] flex items-center justify-center text-[#DC2626]">
              <Receipt className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#991B1B] bg-[#FEE2E2] border border-[#FECACA] px-2 py-0.5 rounded-full">
              Statutory
            </span>
          </div>
          <div className="mt-3">
            <p className="text-[11px] font-semibold text-[#991B1B]">Total Deductions</p>
            <h3 className="text-2xl font-extrabold text-[#991B1B] leading-tight mt-0.5">
              ₹ {totalDeductions.toLocaleString('en-IN')}
            </h3>
            <p className="text-[10px] text-[#DC2626] mt-1 font-medium">PF, ESI & TDS withholdings</p>
          </div>
        </div>

        {/* Net Paid (Amber / Olive) */}
        <div className="bg-white border border-[#D0E4E8] rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-[#FEF9EE] border border-[#FDE68A] flex items-center justify-center text-[#D97706]">
              <IndianRupee className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#92400E] bg-[#FEF3C7] border border-[#FDE68A] px-2 py-0.5 rounded-full">
              Disbursed
            </span>
          </div>
          <div className="mt-3">
            <p className="text-[11px] font-semibold text-[#92400E]">Total Net Disbursed</p>
            <h3 className="text-2xl font-extrabold text-[#92400E] leading-tight mt-0.5">
              ₹ {totalNetPaid.toLocaleString('en-IN')}
            </h3>
            <p className="text-[10px] text-[#B45309] mt-1 font-medium">Credited to bank accounts</p>
          </div>
        </div>
      </div>

      {/* 3. MAIN CONTENT: MASTER-DETAIL SPLIT */}
      <div className="grid grid-cols-12 gap-5 items-start">
        {/* Left: Master Payslip List (7 cols) */}
        <div className="col-span-12 xl:col-span-7 bg-white border border-[#D0E4E8] rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#D0E4E8] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 max-w-sm">
              <Search className="w-4 h-4 text-[#217E93]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search employee by name or ID..."
                className="w-full bg-[#F4F8F9] border border-[#D0E4E8] rounded-xl px-3 py-1.5 text-xs text-[#183D48] focus:outline-none focus:bg-white"
              />
            </div>
            <span className="text-xs font-bold text-[#526B82]">
              {filtered.length} Payslips
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F4F8F9] border-b border-[#D0E4E8] text-[#526B82] font-semibold">
                <tr>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-3">Gross Salary</th>
                  <th className="py-3 px-3">Deductions</th>
                  <th className="py-3 px-3">Bonuses</th>
                  <th className="py-3 px-3">Net Salary</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E1EEF0]">
                {filtered.map((item) => {
                  const isSelected = selectedPayslip?.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedPayslip(item)}
                      className={`hover:bg-[#F4F8F9] transition-colors cursor-pointer ${
                        isSelected ? 'bg-[#E8F6F8]/60 font-semibold' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-[#27A9BF] text-white flex items-center justify-center font-bold text-[11px] shadow-xs flex-shrink-0">
                            {item.employee?.fullName?.charAt(0) || 'E'}
                          </div>
                          <div>
                            <p className="font-bold text-[#183D48] truncate max-w-[120px]">
                              {item.employee?.fullName}
                            </p>
                            <p className="text-[10px] text-[#526B82]">{item.employee?.employeeCode}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-mono text-[#183D48]">
                        ₹ {Number(item.grossSalary || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 font-mono text-[#DC2626]">
                        - ₹ {Number(item.totalDeductions || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 font-mono text-[#689F38]">
                        + ₹ {Number(item.bonusAmount || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-[#183D48]">
                        ₹ {Number(item.netSalary || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          item.status === 'PAID'
                            ? 'bg-[#F1F9E8] text-[#2B4A15] border border-[#C6E79A]'
                            : 'bg-[#FEF9EE] text-[#92400E] border border-[#FDE68A]'
                        }`}>
                          {item.status || 'CALCULATED'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadPDF(item);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#17A2B8] hover:bg-[#138496] text-white text-[11px] font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                          title="Download PDF for this employee"
                        >
                          <Download className="w-3 h-3" />
                          <span>PDF</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Master-Detail Payslip Inspection & Print Panel (5 cols) */}
        <div className="col-span-12 xl:col-span-5 bg-white border border-[#D0E4E8] rounded-2xl p-5 shadow-xs space-y-4 sticky top-20">
          <div className="flex items-center justify-between pb-3 border-b border-[#E1EEF0]">
            <div>
              <h3 className="text-sm font-bold text-[#183D48]">Payslip Document</h3>
              <p className="text-[10px] text-[#526B82]">Official Corporate Salary Slip</p>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handlePrint}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#D0E4E8] hover:bg-[#F4F8F9] text-xs font-semibold text-[#183D48] transition-colors cursor-pointer"
                title="Print Payslip"
              >
                <Printer className="w-3.5 h-3.5 text-[#217E93]" /> Print
              </button>
              <button
                onClick={() => handleDownloadPDF(selectedPayslip)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17A2B8] hover:bg-[#138496] text-white text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
                title="Download Official Payslip PDF"
              >
                <Download className="w-3.5 h-3.5" /> PDF
              </button>
            </div>
          </div>

          {selectedPayslip ? (
            <div className="space-y-4 text-xs">
              {/* Company Header */}
              <div className="p-3 bg-[#183D48] text-white rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-extrabold text-sm tracking-tight">SAISHNAA SOFTWARE SOLUTIONS</h4>
                    <p className="text-[10px] text-[#B8E3EA]">Private Limited • Chennai, India</p>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#27A9BF] text-white font-bold text-[9px]">
                    OFFICIAL
                  </span>
                </div>
              </div>

              {/* Employee & Period Details */}
              <div className="grid grid-cols-2 gap-2 p-3 bg-[#F4F8F9] border border-[#D0E4E8] rounded-xl text-[11px]">
                <div>
                  <span className="text-[#526B82] block text-[10px]">Employee Name</span>
                  <span className="font-bold text-[#183D48]">{selectedPayslip.employee?.fullName}</span>
                </div>
                <div>
                  <span className="text-[#526B82] block text-[10px]">Employee Code</span>
                  <span className="font-mono font-bold text-[#183D48]">{selectedPayslip.employee?.employeeCode}</span>
                </div>
                <div>
                  <span className="text-[#526B82] block text-[10px]">Designation</span>
                  <span className="font-semibold text-[#183D48]">{selectedPayslip.employee?.designation?.title || 'Engineer'}</span>
                </div>
                <div>
                  <span className="text-[#526B82] block text-[10px]">Pay Period</span>
                  <span className="font-semibold text-[#183D48]">{dayjs().month(selectedMonth - 1).format('MMMM')} {selectedYear}</span>
                </div>
              </div>

              {/* Earnings Breakdown */}
              <div>
                <p className="font-bold text-[#183D48] mb-1.5 uppercase text-[10px] tracking-wider text-[#217E93]">
                  Earnings Components
                </p>
                <div className="space-y-1.5 p-3 bg-[#F1F9E8] border border-[#C6E79A] rounded-xl">
                  <div className="flex justify-between">
                    <span className="text-[#3E6920]">Basic Salary:</span>
                    <span className="font-mono font-bold text-[#2B4A15]">₹ {Number(selectedPayslip.basicSalary || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#3E6920]">House Rent Allowance (HRA):</span>
                    <span className="font-mono font-bold text-[#2B4A15]">₹ {Number(selectedPayslip.hra || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#3E6920]">Special Allowances:</span>
                    <span className="font-mono font-bold text-[#2B4A15]">₹ {Number(selectedPayslip.allowances || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#3E6920]">Bonuses:</span>
                    <span className="font-mono font-bold text-[#2B4A15]">₹ {Number(selectedPayslip.bonusAmount || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between pt-1.5 border-t border-[#C6E79A] font-extrabold text-[#2B4A15]">
                    <span>Gross Earnings:</span>
                    <span className="font-mono">₹ {Number(selectedPayslip.grossSalary || 0).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Deductions Breakdown */}
              <div>
                <p className="font-bold text-[#183D48] mb-1.5 uppercase text-[10px] tracking-wider text-[#991B1B]">
                  Deductions & Withholdings
                </p>
                <div className="space-y-1.5 p-3 bg-[#FFF5F5] border border-[#FECACA] rounded-xl">
                  <div className="flex justify-between">
                    <span className="text-[#991B1B]">Provident Fund (PF):</span>
                    <span className="font-mono font-bold text-[#991B1B]">₹ {Number(selectedPayslip.pfDeduction || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#991B1B]">Employee State Insurance (ESI):</span>
                    <span className="font-mono font-bold text-[#991B1B]">₹ {Number(selectedPayslip.esiDeduction || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#991B1B]">Other Deductions / TDS:</span>
                    <span className="font-mono font-bold text-[#991B1B]">₹ {Number(selectedPayslip.otherDeductions || 0).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between pt-1.5 border-t border-[#FECACA] font-extrabold text-[#991B1B]">
                    <span>Total Deductions:</span>
                    <span className="font-mono">₹ {Number(selectedPayslip.totalDeductions || 0).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Net Take-Home Pay Pill */}
              <div className="p-3.5 bg-[#E8F6F8] border border-[#B8E3EA] rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-bold uppercase text-[#1D4F5E]">Final Net Take-Home Salary</p>
                  <p className="text-[10px] text-[#217E93]">Gross Earnings - Deductions</p>
                </div>
                <h4 className="text-xl font-extrabold text-[#183D48] font-mono">
                  ₹ {Number(selectedPayslip.netSalary || 0).toLocaleString('en-IN')}
                </h4>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-[#526B82]">
              Select a payslip from the list to preview and export.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
