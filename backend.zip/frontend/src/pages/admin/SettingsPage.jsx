import React, { useRef, useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  Settings,
  User,
  Lock,
  Bell,
  Building,
  ShieldCheck,
  CheckCircle2,
  Save,
  KeyRound,
  Mail,
  Phone,
  MapPin,
  RefreshCw,
  Camera,
  Trash2,
} from 'lucide-react';

export default function SettingsPage() {
  const [settings, setSettings] = useState(adminStore.getSettings());
  const [activeTab, setActiveTab] = useState('PROFILE'); // 'PROFILE' | 'SECURITY' | 'NOTIFICATIONS' | 'COMPANY'
  const [toastMsg, setToastMsg] = useState('');
  const photoInputRef = useRef(null);

  // Password Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    setSettings(adminStore.getSettings());
  }, []);

  function handleSaveProfile(e) {
    e.preventDefault();
    adminStore.updateSettings(settings);
    setToastMsg('Admin profile information saved successfully!');
    setTimeout(() => setToastMsg(''), 4000);
  }

  function handlePhotoChange(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setToastMsg('Choose a valid image file for the profile photo.');
      setTimeout(() => setToastMsg(''), 4000);
      return;
    }
    if (file.size > 1024 * 1024) {
      setToastMsg('Profile photos must be 1 MB or smaller.');
      setTimeout(() => setToastMsg(''), 4000);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        setToastMsg('Unable to read the selected profile photo.');
        setTimeout(() => setToastMsg(''), 4000);
        return;
      }
      setSettings((current) => ({ ...current, adminPhoto: reader.result }));
    };
    reader.onerror = () => {
      setToastMsg('Unable to read the selected profile photo.');
      setTimeout(() => setToastMsg(''), 4000);
    };
    reader.readAsDataURL(file);
  }

  function handlePasswordChange(e) {
    e.preventDefault();
    setPasswordError('');
    if (!currentPassword) {
      setPasswordError('Please provide your current password.');
      return;
    }
    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setToastMsg('Security password changed successfully!');
    setTimeout(() => setToastMsg(''), 4000);
  }

  function handleToggleNotification(key) {
    const updated = { ...settings, [key]: !settings[key] };
    setSettings(updated);
    adminStore.updateSettings(updated);
    setToastMsg('Notification preference updated.');
    setTimeout(() => setToastMsg(''), 3000);
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-[#16A34A]" />
            Settings & Administrator Profile
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Manage administrator details, company information, security credentials, and alert preferences.
          </p>
        </div>

        <button
          onClick={handleSaveProfile}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs"
        >
          <Save className="w-4 h-4" />
          Save All Changes
        </button>
      </div>

      {/* 2. SUMMARY CARDS (Pastel Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              System Status
            </p>
            <h3 className="text-xl font-black mt-1 text-[#065F46]">Online & Ready</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Settings saved on this device</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Email Notifications
            </p>
            <h3 className="text-xl font-black mt-1 text-[#854D0E]">
              {settings.emailAlertsEnabled ? 'Active' : 'Muted'}
            </h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Daily Attendance Digest</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <Bell className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">
              App Version
            </p>
            <h3 className="text-xl font-black mt-1 text-[#1E40AF]">v2.4 SaaS</h3>
            <p className="text-[11px] text-[#1E40AF]/70 mt-0.5">Enterprise Edition</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <Building className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. TABS SELECTOR */}
      <div className="flex border-b border-slate-200 text-xs font-bold gap-2">
        {[
          { id: 'PROFILE', label: 'Admin Profile', icon: User },
          { id: 'SECURITY', label: 'Change Password', icon: Lock },
          { id: 'NOTIFICATIONS', label: 'Notification Settings', icon: Bell },
          { id: 'COMPANY', label: 'Company & Work Rules', icon: Building },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 py-2.5 px-4 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-[#16A34A] text-[#16A34A]'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Tabbed Form Content */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
          {/* Tab 1: Profile Form */}
          {activeTab === 'PROFILE' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Administrator Identity</h3>

              <div className="flex flex-wrap items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="relative w-16 h-16 shrink-0">
                  {settings.adminPhoto ? (
                    <img
                      src={settings.adminPhoto}
                      alt={`${settings.adminName || 'Administrator'} profile`}
                      className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-[#16A34A] text-white flex items-center justify-center font-black text-2xl shadow-xs">
                      {settings.adminName?.charAt(0) || 'S'}
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="font-bold text-slate-900 text-sm">{settings.adminName || 'Administrator'}</h4>
                  <p className="text-slate-500 text-[11px]">{settings.adminDesignation || 'System Super Administrator'}</p>
                  <span className="inline-block mt-1 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                    Full Administrative Privileges
                  </span>
                </div>
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoChange}
                  className="hidden"
                  aria-label="Choose administrator profile photo"
                />
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => photoInputRef.current?.click()}
                    className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white border border-slate-200 text-slate-700 font-semibold hover:border-[#16A34A] hover:text-[#15803D] transition-colors"
                  >
                    <Camera className="w-4 h-4" />
                    {settings.adminPhoto ? 'Change photo' : 'Add photo'}
                  </button>
                  {settings.adminPhoto && (
                    <button
                      type="button"
                      onClick={() => setSettings({ ...settings, adminPhoto: '' })}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-rose-200 text-rose-600 font-semibold hover:bg-rose-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      Remove
                    </button>
                  )}
                </div>
                <p className="w-full text-[10px] text-slate-500 md:ml-20">
                  JPG, PNG, GIF or WEBP. Maximum file size: 1 MB.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Legal Name *</label>
                  <input
                    type="text"
                    required
                    value={settings.adminName}
                    onChange={(e) => setSettings({ ...settings, adminName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={settings.adminEmail}
                    onChange={(e) => setSettings({ ...settings, adminEmail: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={settings.adminPhone}
                    onChange={(e) => setSettings({ ...settings, adminPhone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Role / Designation</label>
                  <input
                    type="text"
                    value={settings.adminDesignation || ''}
                    onChange={(e) => setSettings({ ...settings, adminDesignation: e.target.value })}
                    placeholder="System Super Administrator"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department</label>
                  <input
                    type="text"
                    value={settings.adminDepartment || ''}
                    onChange={(e) => setSettings({ ...settings, adminDepartment: e.target.value })}
                    placeholder="Administration"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors"
                >
                  Save Profile Information
                </button>
              </div>
            </form>
          )}

          {/* Tab 2: Security & Password */}
          {activeTab === 'SECURITY' && (
            <form onSubmit={handlePasswordChange} className="space-y-4 text-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Change Account Password</h3>

              {passwordError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold text-[11px]">
                  {passwordError}
                </div>
              )}

              <div className="space-y-3 max-w-md">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Current Password *
                  </label>
                  <input
                    type="password"
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Password *</label>
                  <input
                    type="password"
                    required
                    placeholder="Min 6 characters"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Confirm New Password *
                  </label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors"
                >
                  Update Password
                </button>
              </div>
            </form>
          )}

          {/* Tab 3: Notifications */}
          {activeTab === 'NOTIFICATIONS' && (
            <div className="space-y-4 text-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Notification Preferences</h3>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-900">Email Notifications</p>
                    <p className="text-[11px] text-slate-500">
                      Receive administrative updates to {settings.adminEmail}
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.emailAlertsEnabled}
                    onChange={() => handleToggleNotification('emailAlertsEnabled')}
                    className="w-4 h-4 text-[#16A34A] rounded accent-[#16A34A] cursor-pointer"
                  />
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-900">Daily Attendance Digest</p>
                    <p className="text-[11px] text-slate-500">
                      Attendance summary for recorded absences and incomplete entries
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.attendanceDailyDigest}
                    onChange={() => handleToggleNotification('attendanceDailyDigest')}
                    className="w-4 h-4 text-[#16A34A] rounded accent-[#16A34A] cursor-pointer"
                  />
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-900">Payroll Cut-off Alerts</p>
                    <p className="text-[11px] text-slate-500">
                      Reminder on 25th of every month to reconcile biometric records
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.payrollCutoffAlert}
                    onChange={() => handleToggleNotification('payrollCutoffAlert')}
                    className="w-4 h-4 text-[#16A34A] rounded accent-[#16A34A] cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Tab 4: Company & Work Rules */}
          {activeTab === 'COMPANY' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2">Company Information</h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Company Primary Name (e.g. Saishnaa)</label>
                  <input
                    type="text"
                    value={settings.companyName || ''}
                    onChange={(e) => setSettings({ ...settings, companyName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-semibold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Company Subtitle / Entity Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Software Solutions Private Limited"
                    value={settings.companySubtitle || ''}
                    onChange={(e) => setSettings({ ...settings, companySubtitle: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Company Tagline</label>
                  <input
                    type="text"
                    placeholder="e.g. Empowering Bright Futures."
                    value={settings.companyTagline || ''}
                    onChange={(e) => setSettings({ ...settings, companyTagline: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">GSTIN Number</label>
                  <input
                    type="text"
                    value={settings.companyGst || ''}
                    onChange={(e) => setSettings({ ...settings, companyGst: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A] font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Custom Logo (Image URL or Base64)</label>
                  <input
                    type="text"
                    placeholder="https://... or leave empty to use default vector ribbon logo"
                    value={settings.companyLogo || ''}
                    onChange={(e) => setSettings({ ...settings, companyLogo: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                  />
                </div>

              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#16A34A] text-white rounded-xl font-bold hover:bg-[#15803D] transition-colors"
                >
                  Save Policy Configuration
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right Detail Panel: Account & Security Overview */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Account Overview Panel
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">Administrator Audit</h3>
          </div>

          <div className="space-y-3.5 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Active Session:</span>
                <span className="font-semibold text-slate-800">This browser</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5">
                <span className="text-slate-500">Data Synchronization:</span>
                <span className="font-bold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded">
                  Local Store Persistent
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
              <p className="font-bold text-slate-800">Permanent Storage Note</p>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                All records, employee profiles, attendance modifications, payroll runs, and settings
                permanently persist in your browser store. Refreshing the browser will preserve all
                your changes!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
