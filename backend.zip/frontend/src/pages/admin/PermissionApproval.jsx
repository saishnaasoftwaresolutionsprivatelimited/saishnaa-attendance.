import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Search,
  Filter,
  ShieldAlert,
  User,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function PermissionApproval() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [actionLoadingId, setActionLoadingId] = useState(null);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    fetchPermissions();
  }, [filterStatus]);

  async function fetchPermissions() {
    try {
      setLoading(true);
      const url = filterStatus === 'ALL' ? '/permissions/admin' : `/permissions/admin?status=${filterStatus}`;
      const res = await api.get(url);
      if (res.success) {
        setRequests(res.data || []);
      }
    } catch (err) {
      console.error('Error fetching admin permissions:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleDecision(id, status) {
    try {
      setActionLoadingId(id);
      setMessage(null);
      const res = await api.patch(`/permissions/admin/${id}/decision`, {
        status,
        comments: `Reviewed by HR/Admin on ${dayjs().format('DD-MMM-YYYY')}`,
      });

      if (res.success) {
        setMessage(`Permission request marked as ${status}.`);
        await fetchPermissions();
      }
    } catch (err) {
      alert(err.message || 'Failed to update permission request.');
    } finally {
      setActionLoadingId(null);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">
            Permission Approvals
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Review employee permission requests and record an approval decision.
          </p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-xl text-xs font-semibold">
          {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg transition ${
                filterStatus === st
                  ? 'bg-white text-[#20266D] shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {message && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{message}</span>
        </div>
      )}

      {/* Permissions List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <div className="w-8 h-8 border-4 border-[#2563EB] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : requests.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-xs">
            No permission applications found for this filter.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {requests.map((r) => (
              <div key={r.id} className="p-5 hover:bg-slate-50/70 transition flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#2563EB] flex items-center justify-center font-bold text-sm flex-shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-xs">{r.employee?.fullName}</span>
                      <span className="text-[11px] font-mono text-slate-400">({r.employee?.employeeCode})</span>
                      <span className="text-slate-300">•</span>
                      <span className="text-xs text-slate-500">{r.employee?.department?.name}</span>
                    </div>

                    <div className="text-xs text-slate-700 mt-1 flex flex-wrap items-center gap-3 font-medium">
                      <span>Date: <strong>{dayjs(r.date).format('DD MMM YYYY (ddd)')}</strong></span>
                      <span>•</span>
                      <span>Time: <strong>{r.startTime} - {r.endTime}</strong> ({r.durationMinutes || 60}m)</span>
                    </div>

                    <p className="text-xs text-slate-600 mt-1.5 italic bg-slate-50 p-2.5 rounded-lg border border-slate-200/60 max-w-xl">
                      "{r.reason}"
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end md:self-center">
                  <span
                    className={`corp-badge text-[10px] font-bold ${
                      r.status === 'APPROVED'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : r.status === 'REJECTED'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {r.status}
                  </span>

                  {r.status === 'PENDING' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDecision(r.id, 'APPROVED')}
                        disabled={actionLoadingId === r.id}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-sm disabled:opacity-50"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleDecision(r.id, 'REJECTED')}
                        disabled={actionLoadingId === r.id}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition shadow-sm disabled:opacity-50"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
