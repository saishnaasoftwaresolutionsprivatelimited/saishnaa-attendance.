import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  FileCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  Filter,
  User,
  Calendar,
  AlertCircle,
  X,
  MessageSquare,
  History,
  Edit2,
  Search,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import dayjs from 'dayjs';

export default function LeaveApproval() {
  const [activeTab, setActiveTab] = useState('REQUESTS'); // 'REQUESTS' | 'QUOTAS'
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('PENDING');

  // Balances & Quotas tab state
  const [balancesList, setBalancesList] = useState([]);
  const [balancesLoading, setBalancesLoading] = useState(false);
  const [balanceSearch, setBalanceSearch] = useState('');
  const [selectedLedgerEmp, setSelectedLedgerEmp] = useState(null);
  const [ledgerModalOpen, setLedgerModalOpen] = useState(false);

  // Adjustment modal state
  const [adjustModalOpen, setAdjustModalOpen] = useState(false);
  const [selectedAdjustEmp, setSelectedAdjustEmp] = useState(null);
  const [adjustForm, setAdjustForm] = useState({
    leaveTypeCode: 'CL',
    remainingDays: 1,
    totalAllocated: 1,
    reason: 'Monthly quota adjustment by Admin',
  });
  const [adjustSaving, setAdjustSaving] = useState(false);
  const [adjustError, setAdjustError] = useState('');
  const [adjustSuccess, setAdjustSuccess] = useState('');

  const [decisionModalOpen, setDecisionModalOpen] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [decisionStatus, setDecisionStatus] = useState('APPROVED');
  const [comments, setComments] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState('');

  useEffect(() => {
    if (activeTab === 'REQUESTS') {
      fetchRequests();
    } else {
      fetchAdminBalances();
    }
  }, [activeTab, statusFilter]);

  async function fetchRequests() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (statusFilter) params.append('status', statusFilter);

      const res = await api.get(`/leave/admin?${params.toString()}`);
      if (res.success) {
        setRequests(res.data.requests || []);
      }
    } catch (err) {
      console.error('Fetch leaves error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function fetchAdminBalances() {
    try {
      setBalancesLoading(true);
      const res = await api.get('/leave/admin/balances');
      if (res.success) {
        setBalancesList(res.data || []);
      }
    } catch (err) {
      console.error('Fetch balances error:', err);
    } finally {
      setBalancesLoading(false);
    }
  }

  function handleOpenAdjust(emp) {
    setSelectedAdjustEmp(emp);
    const cl = emp.leaveBalances?.find((b) => b.leaveType?.code === 'CL');
    setAdjustForm({
      leaveTypeCode: 'CL',
      remainingDays: cl?.remainingDays ?? 0,
      totalAllocated: cl?.totalAllocated ?? 0,
      reason: 'Monthly allocation / carry-forward update by Admin',
    });
    setAdjustError('');
    setAdjustSuccess('');
    setAdjustModalOpen(true);
  }

  async function handleSaveAdjustment(e) {
    e.preventDefault();
    if (!selectedAdjustEmp) return;
    try {
      setAdjustSaving(true);
      setAdjustError('');
      setAdjustSuccess('');
      const res = await api.put(`/leave/admin/balances/${selectedAdjustEmp.id}`, {
        leaveTypeCode: adjustForm.leaveTypeCode,
        remainingDays: Number(adjustForm.remainingDays),
        totalAllocated: Number(adjustForm.totalAllocated),
        reason: adjustForm.reason,
      });
      if (res.success) {
        setAdjustSuccess('Leave balance adjusted and recorded in ledger.');
        setTimeout(() => {
          setAdjustModalOpen(false);
          fetchAdminBalances();
        }, 1000);
      }
    } catch (err) {
      setAdjustError(err.message || 'Failed to update leave balance.');
    } finally {
      setAdjustSaving(false);
    }
  }

  function openDecisionModal(request, status) {
    setSelectedRequest(request);
    setDecisionStatus(status);
    setComments('');
    setActionError('');
    setDecisionModalOpen(true);
  }

  async function handleDecisionSubmit(e) {
    e.preventDefault();
    setActionError('');
    try {
      setActionLoading(true);
      const res = await api.patch(`/leave/admin/${selectedRequest.id}/decision`, {
        status: decisionStatus,
        reviewerComments: comments,
      });
      if (res.success) {
        setDecisionModalOpen(false);
        await fetchRequests();
      }
    } catch (err) {
      setActionError(err.message || 'Failed to submit decision.');
    } finally {
      setActionLoading(false);
    }
  }

  const filteredBalances = balancesList.filter(
    (e) =>
      e.fullName?.toLowerCase().includes(balanceSearch.toLowerCase()) ||
      e.employeeCode?.toLowerCase().includes(balanceSearch.toLowerCase()) ||
      e.department?.name?.toLowerCase().includes(balanceSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#20266D]">Leave Approvals & Workforce Quotas</h1>
          <p className="text-xs text-slate-500 mt-1">
            Review time-off requests, allocate annual quotas, and manage monthly CL carry-forward ledgers
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveTab('REQUESTS')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'REQUESTS'
                ? 'bg-[#20266D] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Leave Requests
          </button>
          <button
            onClick={() => setActiveTab('QUOTAS')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'QUOTAS'
                ? 'bg-[#20266D] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5 text-blue-400" />
            <span>CL Carryforward & Quotas</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: LEAVE REQUESTS ================= */}
      {activeTab === 'REQUESTS' && (
        <div className="space-y-4">
          {/* Status Filter */}
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-xs font-bold text-slate-700">Filter By Status:</span>
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-1">
              <button
                onClick={() => setStatusFilter('PENDING')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'PENDING'
                    ? 'bg-[#20266D] text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pending
              </button>
              <button
                onClick={() => setStatusFilter('APPROVED')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'APPROVED'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Approved
              </button>
              <button
                onClick={() => setStatusFilter('REJECTED')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'REJECTED'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Rejected
              </button>
              <button
                onClick={() => setStatusFilter('')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === ''
                    ? 'bg-slate-700 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
            </div>
          </div>

          {/* Requests Table */}
          <div className="corp-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Employee</th>
                    <th className="py-3 px-4">Leave Type</th>
                    <th className="py-3 px-4">Duration & Dates</th>
                    <th className="py-3 px-4">Reason</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400">
                        Loading leave requests...
                      </td>
                    </tr>
                  ) : requests.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400">
                        No {statusFilter ? statusFilter.toLowerCase() : ''} leave requests found.
                      </td>
                    </tr>
                  ) : (
                    requests.map((req) => (
                      <tr key={req.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Employee */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{req.employee?.fullName}</div>
                          <div className="text-[11px] text-slate-500 font-mono">
                            {req.employee?.employeeCode} • {req.employee?.department?.name}
                          </div>
                        </td>

                        {/* Leave Type */}
                        <td className="py-3 px-4">
                          <span className="corp-badge bg-blue-50 text-blue-700 font-semibold">
                            {req.leaveType?.name}
                          </span>
                        </td>

                        {/* Duration & Dates */}
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-800">
                            {req.daysCount} {req.daysCount === 1 ? 'day' : 'days'}{' '}
                            {req.isHalfDay && '(Half Day)'}
                          </div>
                          <div className="text-[11px] text-slate-500 font-mono">
                            {dayjs(req.startDate).format('DD MMM')} to {dayjs(req.endDate).format('DD MMM YYYY')}
                          </div>
                        </td>

                        {/* Reason */}
                        <td className="py-3 px-4 max-w-xs">
                          <div className="text-slate-700 truncate" title={req.reason}>
                            {req.reason}
                          </div>
                          {req.reviewerComments && (
                            <div className="text-[10px] text-slate-400 mt-0.5 italic">
                              Reviewer: "{req.reviewerComments}"
                            </div>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`corp-badge ${
                              req.status === 'APPROVED'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : req.status === 'REJECTED'
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}
                          >
                            {req.status}
                          </span>
                        </td>

                        {/* Decision Buttons */}
                        <td className="py-3 px-4 text-right">
                          {req.status === 'PENDING' ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => openDecisionModal(req, 'APPROVED')}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs transition-colors flex items-center gap-1"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => openDecisionModal(req, 'REJECTED')}
                                className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs transition-colors flex items-center gap-1"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-mono">
                              {req.reviewedAt ? dayjs(req.reviewedAt).format('DD MMM, hh:mm A') : 'Decided'}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: QUOTAS & CL CARRYFORWARD ================= */}
      {activeTab === 'QUOTAS' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <div>
              <h3 className="text-sm font-bold text-[#20266D]">Employee Leave Balances & CL Carry-Forward Ledgers</h3>
              <p className="text-[11px] text-slate-500">
                Rule: 1.0 CL is credited automatically each month. Unused CL is carried forward to subsequent months.
              </p>
            </div>
            <div className="relative">
              <input
                type="text"
                placeholder="Search employee or code..."
                value={balanceSearch}
                onChange={(e) => setBalanceSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs outline-none focus:ring-2 focus:ring-[#2563EB] w-56"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          <div className="corp-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/70 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Employee</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Casual Leave (CL) Balance</th>
                    <th className="py-3 px-4">Total Consumed</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {balancesLoading ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400">
                        Loading workforce balances...
                      </td>
                    </tr>
                  ) : filteredBalances.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400">
                        No employees found.
                      </td>
                    </tr>
                  ) : (
                    filteredBalances.map((emp) => {
                      const cl = emp.leaveBalances?.find((b) => b.leaveType?.code === 'CL');
                      const totalUsed = (emp.leaveBalances || []).reduce((acc, b) => acc + (b.usedDays || 0), 0);

                      return (
                        <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{emp.fullName}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{emp.employeeCode}</div>
                          </td>
                          <td className="py-3 px-4 text-slate-600 font-medium">
                            {emp.department?.name || 'General'}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-baseline gap-1.5">
                              <span className="text-sm font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg">
                                {cl?.remainingDays ?? 0} days
                              </span>
                              <span className="text-[10px] text-slate-400">/ {cl?.totalAllocated ?? 0} allocated</span>
                            </div>
                            <span className="text-[10px] text-slate-500 mt-0.5 block">
                              Used: {cl?.usedDays ?? 0}d • Pending: {cl?.pendingDays ?? 0}d
                            </span>
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-700">
                            {totalUsed} days
                          </td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <button
                              onClick={() => {
                                setSelectedLedgerEmp(emp);
                                setLedgerModalOpen(true);
                              }}
                              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#2563EB] rounded-lg text-xs font-bold transition inline-flex items-center gap-1"
                            >
                              <History className="w-3.5 h-3.5" />
                              <span>CL Ledger</span>
                            </button>
                            <button
                              onClick={() => handleOpenAdjust(emp)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition inline-flex items-center gap-1"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>Adjust</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CL Carryforward Ledger Modal */}
      {ledgerModalOpen && selectedLedgerEmp && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-extrabold text-[#20266D]">
                  Casual Leave (CL) Carry-Forward Ledger: {selectedLedgerEmp.fullName}
                </h3>
                <p className="text-xs text-slate-500 font-mono">Employee ID: {selectedLedgerEmp.employeeCode}</p>
              </div>
              <button onClick={() => setLedgerModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 max-h-[400px] overflow-y-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                  <tr>
                    <th className="py-2.5 px-3">Month</th>
                    <th className="py-2.5 px-3 text-center">Opening</th>
                    <th className="py-2.5 px-3 text-center">Credit</th>
                    <th className="py-2.5 px-3 text-center">Used</th>
                    <th className="py-2.5 px-3 text-center">Closing Balance</th>
                    <th className="py-2.5 px-3">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[11px]">
                  {(selectedLedgerEmp.leaveLedgers || []).filter((l) => l.leaveTypeCode === 'CL').length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400 font-sans">
                        No monthly ledger records yet. Carry-forwards generate during monthly payroll calculations.
                      </td>
                    </tr>
                  ) : (
                    (selectedLedgerEmp.leaveLedgers || [])
                      .filter((l) => l.leaveTypeCode === 'CL')
                      .map((ledger) => (
                        <tr key={ledger.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-bold text-slate-800 font-sans">
                            {dayjs(ledger.monthYear + '-01').format('MMM YYYY')}
                          </td>
                          <td className="py-2 px-3 text-center text-slate-600">{ledger.openingBalance}d</td>
                          <td className="py-2 px-3 text-center text-emerald-600 font-bold">+{ledger.creditedDays}d</td>
                          <td className="py-2 px-3 text-center text-rose-600 font-semibold">{ledger.usedDays > 0 ? `-${ledger.usedDays}d` : '0d'}</td>
                          <td className="py-2 px-3 text-center font-bold text-[#20266D]">
                            <span className="bg-blue-50 text-[#2563EB] px-2 py-0.5 rounded border border-blue-200">
                              {ledger.closingBalance}d
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-500 font-sans text-[10px]">{ledger.remarks}</td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setLedgerModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Adjust Leave Balance Modal */}
      {adjustModalOpen && selectedAdjustEmp && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-extrabold text-[#20266D]">
                Adjust Leave Balance: {selectedAdjustEmp.fullName}
              </h3>
              <button onClick={() => setAdjustModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {adjustError && (
              <div className="my-3 p-3 bg-rose-50 text-rose-700 text-xs rounded-xl border border-rose-200">
                {adjustError}
              </div>
            )}
            {adjustSuccess && (
              <div className="my-3 p-3 bg-emerald-50 text-emerald-800 text-xs rounded-xl border border-emerald-200">
                {adjustSuccess}
              </div>
            )}

            <form onSubmit={handleSaveAdjustment} className="space-y-4 mt-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Leave Type</label>
                <select
                  value={adjustForm.leaveTypeCode}
                  onChange={(e) => setAdjustForm({ ...adjustForm, leaveTypeCode: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs outline-none"
                >
                  <option value="CL">Casual Leave (CL)</option>
                  <option value="EL">Earned Leave (EL)</option>
                  <option value="ML">Marriage Leave (ML)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Remaining Days *</label>
                  <input
                    type="number"
                    step="0.5"
                    min={0}
                    max={100}
                    required
                    value={adjustForm.remainingDays}
                    onChange={(e) => setAdjustForm({ ...adjustForm, remainingDays: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Allocated</label>
                  <input
                    type="number"
                    step="0.5"
                    min={0}
                    max={100}
                    required
                    value={adjustForm.totalAllocated}
                    onChange={(e) => setAdjustForm({ ...adjustForm, totalAllocated: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Adjustment Reason / Notes</label>
                <input
                  type="text"
                  required
                  value={adjustForm.reason}
                  onChange={(e) => setAdjustForm({ ...adjustForm, reason: e.target.value })}
                  placeholder="e.g. Month-end carryforward reconciliation"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAdjustModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={adjustSaving}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#20266D] hover:bg-[#161A4E] text-white"
                >
                  {adjustSaving ? 'Saving...' : 'Save Allocation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Decision Modal */}
      {decisionModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-extrabold text-[#20266D] mb-1">
              {decisionStatus === 'APPROVED' ? 'Approve Leave Request' : 'Reject Leave Request'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Employee: {selectedRequest?.employee?.fullName} ({selectedRequest?.daysCount} days{' '}
              {selectedRequest?.leaveType?.name})
            </p>

            {actionError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {actionError}
              </div>
            )}

            <form onSubmit={handleDecisionSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Reviewer Comments (Optional)
                </label>
                <textarea
                  rows={3}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Add approval or rejection remarks for the employee..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDecisionModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md ${
                    decisionStatus === 'APPROVED'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {actionLoading ? 'Processing...' : `Confirm ${decisionStatus}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
