import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import { generateReportPDF } from '../../utils/pdfGenerator';
import {
  BarChart3,
  Download,
  Calendar,
  Filter,
  FileSpreadsheet,
  FileText,
  TrendingUp,
  Percent,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  Users,
  Search,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export default function ReportsPage() {
  const [activeReport, setActiveReport] = useState('ATTENDANCE'); // 'ATTENDANCE' | 'MONTHLY_ATTENDANCE' | 'PAYROLL' | 'SALARY' | 'PAYSLIP'
  const formatPeriod = (date) => new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' }).format(date);
  const [selectedMonth, setSelectedMonth] = useState(() => formatPeriod(new Date()));
  const reportPeriods = Array.from({ length: 12 }, (_, index) => {
    const date = new Date();
    date.setDate(1);
    date.setMonth(date.getMonth() - index);
    return formatPeriod(date);
  });
  const selectedYear = selectedMonth.split(' ').pop();
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [payrollItems, setPayrollItems] = useState([]);
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    const loadReportData = () => {
      setEmployees(adminStore.getEmployees());
      setAttendance(adminStore.getAttendance());
      setPayrollItems(adminStore.getPayrollData());
    };
    loadReportData();
    window.addEventListener('saishnaa_store_updated', loadReportData);
    return () => window.removeEventListener('saishnaa_store_updated', loadReportData);
  }, []);

  const processedPayroll = payrollItems.filter((item) => item.paymentStatus === 'Processed');
  const totalPayrollProcessed = processedPayroll.reduce((total, item) => total + item.netSalary, 0);
  const attendanceRecordCount = attendance.length;
  const payslipsIssued = processedPayroll.length;
  const departmentSalaryDistribution = Object.values(
    payrollItems.reduce((totals, item) => {
      const department = item.department || 'Unassigned';
      totals[department] = totals[department] || { name: department, salary: 0 };
      totals[department].salary += item.grossSalary;
      return totals;
    }, {})
  );
  const attendanceRateData = [
    {
      name: 'Present',
      value: attendance.filter((record) => record.status === 'Present' || record.status === 'On Time').length,
      color: '#16A34A',
    },
    {
      name: 'Excused Leave',
      value: attendance.filter((record) => record.status === 'On Leave' || record.status === 'Half Day').length,
      color: '#3B82F6',
    },
    {
      name: 'Unexcused Absence',
      value: attendance.filter((record) => record.status === 'Absence' || record.status === 'Absent').length,
      color: '#F43F5E',
    },
  ].filter((entry) => entry.value > 0);

  function getEmployeeAttendanceMetrics(employee) {
    const records = attendance.filter((record) =>
      record.employeeId === employee.id || record.employeeCode === employee.employeeCode
    );
    const present = records.filter((record) =>
      ['Present', 'On Time'].includes(record.status)
    ).length;
    return {
      recordCount: records.length,
      attendanceRate: records.length ? Math.round((present / records.length) * 100) : null,
    };
  }

  function handleExport(format) {
    const cols = ['Employee Name', 'Employee Code', 'Department', 'Designation', 'Basic Salary (₹)', 'Presence Rate (%)'];
    const rows = employees.map((emp) => {
      const metrics = getEmployeeAttendanceMetrics(emp);
      return [
        emp.fullName,
        emp.employeeCode,
        emp.department,
        emp.designation,
        `₹ ${Number(emp.basicSalary || 0).toLocaleString('en-IN')}`,
        metrics.attendanceRate === null ? '—' : `${metrics.attendanceRate}%`,
      ];
    });

    if (format === 'PDF') {
      generateReportPDF(activeReport, `${selectedMonth} ${selectedYear}`, cols, rows);
      setToastMsg(`Generated and downloaded ${activeReport} PDF successfully!`);
    } else {
      // Export as CSV/Excel
      const csvHeader = cols.join(',') + '\n';
      const csvBody = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
      const blob = new Blob([csvHeader + csvBody], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeReport}_${selectedMonth}_${selectedYear}.csv`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setToastMsg(`Downloaded ${activeReport} spreadsheet successfully!`);
    }
    setTimeout(() => setToastMsg(''), 4000);
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-[#16A34A]" />
            Reports & Workforce Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Workforce reporting from employee, attendance, and payroll records entered in this workspace.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => handleExport('Excel')}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            Export Excel
          </button>
          <button
            onClick={() => handleExport('PDF')}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#16A34A] text-white rounded-xl text-xs font-bold hover:bg-[#15803D] transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            Download PDF
          </button>
        </div>
      </div>

      {/* 2. SUMMARY CARDS (Top 4 KPI Cards: Total Payroll Processed, On-Time Rate, Payslips Issued, Error Rate) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Payroll Processed */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Total Payroll Processed
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">
              ₹{totalPayrollProcessed.toLocaleString('en-IN')}
            </h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Processed payroll records</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <IndianRupee className="w-5 h-5" />
          </div>
        </div>

        {/* Payroll On-Time Rate */}
        <div className="p-4 rounded-2xl bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#166534]/80 uppercase tracking-wider">
              Attendance Records
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#166534]">{attendanceRecordCount}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">Records for this workspace</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BBF7D0] flex items-center justify-center text-[#15803D] shadow-xs">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Payslips Issued */}
        <div className="p-4 rounded-2xl bg-[#EFF6FF] border border-[#BFDBFE] text-[#1E40AF] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#1E40AF]/80 uppercase tracking-wider">
              Payslips Issued
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#1E40AF]">{payslipsIssued}</h3>
            <p className="text-[11px] text-[#166534]/70 mt-0.5">Processed payroll records</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shadow-xs">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        {/* Payroll Error Rate */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Payroll Error Rate
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">—</h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">No reconciliation data available</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. REPORT TYPE SELECTOR BAR */}
      <div className="p-3 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'ATTENDANCE', label: 'Attendance Report' },
            { id: 'MONTHLY_ATTENDANCE', label: 'Monthly Attendance' },
            { id: 'PAYROLL', label: 'Monthly Payroll Report' },
            { id: 'SALARY', label: 'Employee Salary Report' },
            { id: 'PAYSLIP', label: 'Payslip Report' },
          ].map((rpt) => (
            <button
              key={rpt.id}
              onClick={() => setActiveReport(rpt.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                activeReport === rpt.id
                  ? 'bg-[#16A34A] text-white shadow-xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {rpt.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            {reportPeriods.map((period) => <option key={period} value={period}>{period}</option>)}
          </select>
        </div>
      </div>

      {/* 4. CHARTS SECTION (EXPENSE BREAKDOWN & DEPARTMENT DISTRIBUTION) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Department Salary Distribution */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Department Salary Distribution (₹)
              </h3>
              <p className="text-xs text-slate-500">Gross allocation per business unit</p>
            </div>
            <span className="text-xs font-bold text-[#16A34A] bg-[#DCFCE7] px-2.5 py-1 rounded-lg">
              Live Payroll Data
            </span>
          </div>

          {departmentSalaryDistribution.length > 0 ? (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={departmentSalaryDistribution}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748B' }} />
                <Tooltip
                  formatter={(val) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Salary Pool']}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '12px',
                    borderColor: '#E2E8F0',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="salary" fill="#16A34A" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400">
              Salary distribution will appear after employees are registered.
            </div>
          )}
        </div>

        {/* Attendance Compliance Rate */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Workforce Punctuality & Leave Mix</h3>
              <p className="text-xs text-slate-500">Overall adherence statistics</p>
            </div>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
              {selectedMonth}
            </span>
          </div>

          {attendanceRateData.length > 0 ? (
          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceRateData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {attendanceRateData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend
                  formatter={(val) => <span className="text-xs text-slate-700">{val}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          ) : (
            <div className="h-60 flex items-center justify-center text-sm text-slate-400">
              No attendance records are available for this report.
            </div>
          )}
        </div>
      </div>

      {/* 5. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Table representation for report */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Generated Report: {activeReport.replace(/_/g, ' ')}
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              Audit Period: {selectedMonth}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Designation</th>
                  <th className="py-3 px-4">Monthly Salary</th>
                  <th className="py-3 px-4">Attendance Records</th>
                  <th className="py-3 px-4 text-center">Attendance Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {employees.map((emp) => {
                  const metrics = getEmployeeAttendanceMetrics(emp);
                  return <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {emp.fullName}
                      <span className="block text-[10px] text-slate-400 font-mono font-normal">
                        {emp.employeeCode}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{emp.department}</td>
                    <td className="py-3 px-4 text-slate-700">{emp.designation}</td>
                    <td className="py-3 px-4 font-mono font-bold text-[#16A34A]">
                      ₹{Number(emp.basicSalary || 0).toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700">{metrics.recordCount}</td>
                    <td className="py-3 px-4 text-center">
                      {metrics.attendanceRate === null ? '—' : `${metrics.attendanceRate}%`}
                    </td>
                  </tr>
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Report Summary & Export Options */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Report Summary Panel
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">
              {activeReport.replace(/_/g, ' ')}
            </h3>
          </div>

          <div className="space-y-3.5 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Selected Cycle:</span>
                <span className="font-bold text-slate-800">{selectedMonth}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Staff Audited:</span>
                <span className="font-bold text-slate-800">{employees.length} Members</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Gross Payroll Value:</span>
                <span className="font-mono font-bold text-[#16A34A]">
                  ₹{totalPayrollProcessed.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5">
                <span className="text-slate-500">Audit Status:</span>
                <span className="font-bold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded">
                  Reconciled
                </span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                Export Data Options
              </p>
              <button
                onClick={() => handleExport('Excel')}
                className="w-full py-2.5 px-3 rounded-xl bg-white border border-slate-200 text-slate-800 font-bold hover:bg-slate-50 transition-colors text-center text-xs flex items-center justify-center gap-2 shadow-xs"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                Generate XLSX Spreadsheet
              </button>
              <button
                onClick={() => handleExport('PDF')}
                className="w-full py-2.5 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center text-xs flex items-center justify-center gap-2 shadow-xs"
              >
                <Download className="w-4 h-4" />
                Generate Executive PDF
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}