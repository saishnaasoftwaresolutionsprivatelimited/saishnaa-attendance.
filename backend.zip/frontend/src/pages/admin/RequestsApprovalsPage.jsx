import React, { useState, useEffect } from 'react';
import { adminStore } from '../../services/adminStore';
import {
  FileCheck2,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
  Filter,
  Calendar,
  User,
  Building,
  AlertCircle,
  Check,
  X,
  Briefcase,
  HelpCircle,
  FileEdit,
} from 'lucide-react';

export default function RequestsApprovalsPage() {
  const [requests, setRequests] = useState([]);
  const [activeTab, setActiveTab] = useState('ALL'); // 'ALL' | 'Pending' | 'Approved' | 'Rejected'
  const [selectedType, setSelectedType] = useState('ALL');
  const [search, setSearch] = useState('');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [toastMsg, setToastMsg] = useState('');

  useEffect(() => {
    loadRequests();
    window.addEventListener('saishnaa_store_updated', loadRequests);
    return () => window.removeEventListener('saishnaa_store_updated', loadRequests);
  }, []);

  function loadRequests() {
    const list = adminStore.getRequests();
    setRequests(list);
    if (list.length > 0 && !selectedRequest) {
      setSelectedRequest(list[0]);
    } else if (selectedRequest) {
      const updated = list.find((r) => r.id === selectedRequest.id);
      if (updated) setSelectedRequest(updated);
    }
  }

  // Summary Metrics
  const pendingCount = requests.filter((r) => r.status === 'Pending').length;
  const approvedCount = requests.filter((r) => r.status === 'Approved').length;
  const rejectedCount = requests.filter((r) => r.status === 'Rejected').length;

  // Filtered List
  const filteredRequests = requests.filter((req) => {
    const matchesTab = activeTab === 'ALL' || req.status === activeTab;
    const matchesType = selectedType === 'ALL' || req.type === selectedType;
    const matchesSearch =
      req.employeeName.toLowerCase().includes(search.toLowerCase()) ||
      req.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
      req.reason.toLowerCase().includes(search.toLowerCase());
    return matchesTab && matchesType && matchesSearch;
  });

  function handleDecision(id, decision) {
    const updated = adminStore.updateRequestStatus(id, decision, adminNotes);
    if (updated) {
      setSelectedRequest(updated);
      setAdminNotes('');
      setToastMsg(`Request ${updated.id} marked as ${decision}!`);
      setTimeout(() => setToastMsg(''), 4000);
    }
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#16A34A] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FileCheck2 className="w-6 h-6 text-[#16A34A]" />
            Requests & Workflow Approvals
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Review and adjudicate employee leave, permission, on-duty, WFH, and biometric correction requests.
          </p>
        </div>
      </div>

      {/* 2. SUMMARY CARDS (Top 3 KPI Cards: Pending, Approved, Rejected) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Pending Requests */}
        <div className="p-4 rounded-2xl bg-[#FEF9C3] border border-[#FDE047] text-[#854D0E] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#854D0E]/80 uppercase tracking-wider">
              Pending Requests
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#854D0E]">{pendingCount}</h3>
            <p className="text-[11px] text-[#854D0E]/70 mt-0.5">Awaiting Administrator Review</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FDE047] flex items-center justify-center text-[#CA8A04] shadow-xs">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Approved Requests */}
        <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#065F46]/80 uppercase tracking-wider">
              Approved This Month
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#065F46]">{approvedCount}</h3>
            <p className="text-[11px] text-[#065F46]/70 mt-0.5">Discharged & Reconciled</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#A7F3D0] flex items-center justify-center text-[#16A34A] shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Rejected Requests */}
        <div className="p-4 rounded-2xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239] flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#9F1239]/80 uppercase tracking-wider">
              Rejected Requests
            </p>
            <h3 className="text-2xl font-black mt-1 text-[#9F1239]">{rejectedCount}</h3>
            <p className="text-[11px] text-[#9F1239]/70 mt-0.5">Denied with Justification Note</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-white border border-[#FECDD3] flex items-center justify-center text-[#E11D48] shadow-xs">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. TABS & SEARCH BAR */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
        {/* Status Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-bold">
          {['ALL', 'Pending', 'Approved', 'Rejected'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === tab
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab === 'ALL' ? 'All Requests' : tab}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2 flex-1 max-w-lg justify-end">
          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:border-[#16A34A]"
          >
            <option value="ALL">All Request Types</option>
            <option value="Leave">Leave (CL / SL / PL)</option>
            <option value="Permission">Permission Hours</option>
            <option value="On-Duty">On-Duty Official</option>
            <option value="Work From Home">Work From Home</option>
            <option value="Attendance Correction">Attendance Correction</option>
          </select>

          {/* Search */}
          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search request..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
            />
          </div>
        </div>
      </div>

      {/* 4. MAIN CONTENT & DETAIL PANEL (MASTER-DETAIL UI PATTERN) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Requests Table */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Submitted Applications</h3>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredRequests.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Request Type</th>
                  <th className="py-3 px-4">Dates / Duration</th>
                  <th className="py-3 px-4">Submitted</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRequests.map((req) => {
                  const isSelected = selectedRequest?.id === req.id;
                  let badgeClass = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]';
                  if (req.status === 'Pending') {
                    badgeClass = 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]';
                  } else if (req.status === 'Rejected') {
                    badgeClass = 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]';
                  }

                  return (
                    <tr
                      key={req.id}
                      onClick={() => setSelectedRequest(req)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {req.employeeName}
                        <span className="block text-[10px] text-slate-400 font-mono font-normal">
                          {req.employeeCode} · {req.department}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-800">
                        {req.type}
                        <span className="block text-[10px] text-slate-500">{req.subType}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">{req.dates}</td>
                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">{req.submittedAt}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}
                        >
                          {req.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        {req.status === 'Pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDecision(req.id, 'Approved');
                              }}
                              title="Approve"
                              className="p-1 rounded-lg bg-[#DCFCE7] text-[#15803D] hover:bg-emerald-200 transition-colors"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDecision(req.id, 'Rejected');
                              }}
                              title="Reject"
                              className="p-1 rounded-lg bg-[#FFE4E6] text-[#BE123C] hover:bg-rose-200 transition-colors"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium">Decided</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Full Request Inspection & Adjudication */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Request Detail Panel
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedRequest ? `${selectedRequest.type} Request` : 'Select a request'}
              </h3>
            </div>
            {selectedRequest && (
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  selectedRequest.status === 'Approved'
                    ? 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]'
                    : selectedRequest.status === 'Pending'
                    ? 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]'
                    : 'bg-[#FFE4E6] text-[#BE123C] border-[#FDA4AF]'
                }`}
              >
                {selectedRequest.status}
              </span>
            )}
          </div>

          {selectedRequest ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Applicant:</span>
                  <span className="font-bold text-slate-800">{selectedRequest.employeeName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee Code:</span>
                  <span className="font-mono text-slate-800">{selectedRequest.employeeCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Department:</span>
                  <span className="text-slate-800 font-medium">{selectedRequest.department}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-1.5">
                  <span className="text-slate-500">Leave Quota / Balance:</span>
                  <span className="font-bold text-[#16A34A]">{selectedRequest.balance}</span>
                </div>
              </div>

              {/* Justification & Dates */}
              <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Application Date / Window:</span>
                  <span className="font-bold text-slate-800">{selectedRequest.dates}</span>
                </div>
                <div className="pt-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Employee Reason & Context:
                  </span>
                  <p className="text-[11px] text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100 mt-1 leading-relaxed">
                    "{selectedRequest.reason}"
                  </p>
                </div>
              </div>

              {/* Manager / Admin Notes */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Administrator Remarks / Response Note
                </label>
                <textarea
                  rows="2"
                  placeholder="Optional approval notes or reason if rejected..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-[#16A34A]"
                />
              </div>

              {/* Adjudication Actions */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  onClick={() => handleDecision(selectedRequest.id, 'Approved')}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-[#16A34A] text-white font-bold hover:bg-[#15803D] transition-colors text-center text-xs flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Approve Request
                </button>
                <button
                  onClick={() => handleDecision(selectedRequest.id, 'Rejected')}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-rose-50 text-rose-600 font-bold hover:bg-rose-100 transition-colors text-center text-xs flex items-center justify-center gap-1.5"
                >
                  <X className="w-4 h-4" />
                  Reject Request
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              Please click a request row to review details.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
