from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
def edit(path, fn):
    p=root/path
    p.write_text(fn(p.read_text(encoding='utf-8')),encoding='utf-8')

for filename, model in [('permissionController.js','permissionRequest'), ('onDutyController.js','onDutyRequest')]:
    def update(s):
        s="import { canManageEmployee, canReadEmployee } from '../services/accessPolicy.js';\n"+s
        s=s.replace('    const where = {};', "    const where = req.user.role === 'HR' ? { employee: { user: { role: 'EMPLOYEE' } } } : {};")
        needle=f'    const updated = await prisma.{model}.update('
        s=s.replace(needle, f"""    const target = await prisma.{model}.findUnique({{ where: {{ id }}, include: {{ employee: {{ include: {{ user: {{ select: {{ role: true }} }} }} }} }} }});
    if (!target) return sendError(res, 'Request not found.', 404);
    if (!canManageEmployee(req.user, target.employee)) return sendError(res, 'HR can review normal employee requests only. Personal requests require Admin.', 403);
    if (target.status !== 'PENDING') return sendError(res, 'This request has already been reviewed.', 409);
{needle}""")
        if model=='permissionRequest':
            s=s.replace('    const yearMonth =', "    const target = await prisma.employee.findUnique({ where: { id: employeeId }, include: { user: { select: { role: true } } } });\n    if (!target || !canReadEmployee(req.user, target)) return sendError(res, 'Access denied.', 403);\n    const yearMonth =",1)
        return s
    edit('backend/src/controllers/'+filename, update)

def correction(s):
    s="import { canManageEmployee } from '../services/accessPolicy.js';\n"+s
    s=s.replace('    const [total, requests] =', "    if (req.user.role === 'HR') where.employee = { ...where.employee, user: { role: 'EMPLOYEE' } };\n    const [total, requests] =")
    s=s.replace('            shiftAssignments: {', '            user: { select: { role: true } },\n            shiftAssignments: {')
    s=s.replace("    if (request.status !== 'PENDING')", "    if (!canManageEmployee(req.user, request.employee)) return sendError(res, 'HR can review normal employee corrections only. Personal requests require Admin.', 403);\n    if (request.status !== 'PENDING')")
    return s
edit('backend/src/controllers/correctionController.js',correction)

def attendance(s):
    s="import { canManageEmployee } from '../services/accessPolicy.js';\n"+s
    s=s.replace('  where: { id: employeeId },\n});', '  where: { id: employeeId },\n  include: { user: { select: { role: true } } },\n});')
    s=s.replace('// Always use the company-wide office timing', "if (!canManageEmployee(req.user, employee)) return sendError(res, 'HR can correct normal employee attendance only. Personal corrections require Admin.', 403);\n\n// Always use the company-wide office timing")
    return s
edit('backend/src/controllers/attendanceController.js',attendance)

for filename in ['permissionRoutes.js','correctionRoutes.js','onDutyRoutes.js','reportRoutes.js']:
    edit('backend/src/routes/'+filename,lambda s:s.replace("authorizeRoles('ADMIN')", "authorizeRoles('ADMIN', 'HR')"))
edit('backend/src/controllers/reportController.js', lambda s:s.replace("NOT: { user: { role: 'ADMIN' } },", "user: { role: req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' } },").replace("header: 'Shift'", "header: 'Office Timing'"))
for filename in ['attendanceController.js','payrollController.js','salaryController.js','reportController.js']:
    edit('backend/src/controllers/'+filename,lambda s:re.sub(r'(leaveRequest\.find(?:Many|First)\(\{\s*where:\s*\{)',r"\1\n          leaveType: { code: { not: 'SL' } },",re.sub(r'(leaveRequests:\s*\{\s*where:\s*\{)',r"\1\n            leaveType: { code: { not: 'SL' } },",s)))

edit('backend/src/controllers/salaryController.js',lambda s:s.replace("if (req.user.role === 'HR')", "if (req.user.role === 'HR' && !isSelf)",1))
# Salary policy and balance changes remain Admin authority; HR uses calculations.
edit('backend/src/routes/salaryRoutes.js',lambda s:s.replace("authorizeRoles('ADMIN', 'HR')", "authorizeRoles('ADMIN')"))
edit('backend/src/routes/leaveRoutes.js',lambda s:s.replace("router.put('/admin/balances/:employeeId', authenticateUser, authorizeRoles('ADMIN', 'HR')", "router.put('/admin/balances/:employeeId', authenticateUser, authorizeRoles('ADMIN')"))
edit('backend/src/routes/employeeRoutes.js',lambda s:s.replace("  '/:id/attendance-benefits',\n  authenticateUser,\n  authorizeRoles('ADMIN', 'HR')", "  '/:id/attendance-benefits',\n  authenticateUser,\n  authorizeRoles('ADMIN')").replace("  '/:id/assign-shift',\n  authenticateUser,\n  authorizeRoles('ADMIN', 'HR')", "  '/:id/assign-shift',\n  authenticateUser,\n  authorizeRoles('ADMIN')"))

for filename in ['backend/src/controllers/authController.js','backend/src/middleware/authMiddleware.js']:
    edit(filename,lambda s:s.replace('      role: user.role,', '      role: user.role,\n      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,'))
edit('backend/src/middleware/authMiddleware.js',lambda s:s+"""
export function authorizePayrollPayment(req, res, next) {
  if (req.user?.role === 'ADMIN' || req.user?.canAuthorizePayrollPayment === true) return next();
  return sendError(res, 'Payment authorization requires Admin or an explicitly configured Paying Authority.', 403);
}
""")
edit('backend/src/routes/payrollRoutes.js',lambda s:s.replace('authenticateUser, authorizeRoles }', 'authenticateUser, authorizeRoles, authorizePayrollPayment }').replace("router.post('/calculations/:calculationId/payment', authorizeRoles('ADMIN')", "router.post('/calculations/:calculationId/payment', authorizePayrollPayment"))

def payroll(s):
    s="import { canAuthorizePayment, canReadEmployee } from '../services/accessPolicy.js';\n"+s
    # Permit HR's own payslip, while preserving normal-employee-only operations.
    a=s.index('export async function downloadPayslipPdf')
    s=s[:a]+s[a:].replace("req.user.role === 'HR'\n", "req.user.role === 'HR' && !isOwner\n",1)
    a=s.index('export async function recordPayment')
    b=s.index('export async function getMyPayslips',a)
    payment=s[a:b]
    payment=payment.replace('  try {', "  try {\n    if (!canAuthorizePayment(req.user)) return sendError(res, 'Payment authorization denied.', 403);",1)
    payment=payment.replace('employee: true,', 'employee: { include: { user: { select: { role: true } } } },')
    payment=payment.replace('    /*\n     * Payment only after Admin approval.', "    if (req.user.role !== 'ADMIN' && (calculation.employeeId === req.user.employeeId || calculation.employee.user?.role !== 'EMPLOYEE')) return sendError(res, 'Paying Authority cannot authorize their own or privileged accounts payments.', 403);\n\n    /*\n     * Payment only after Admin approval.")
    s=s[:a]+payment+s[b:]
    # Reject arbitrary workflow status values, as well as payment states.
    s=s.replace('    const forbiddenStatuses = [', "    if (status && !['DRAFT', 'PROJECTED', 'CALCULATED', 'HR_REVIEWED'].includes(status)) return sendError(res, 'Invalid review status.', 400);\n    const forbiddenStatuses = [")
    return s
edit('backend/src/controllers/payrollController.js',payroll)

def employee(s):
    # Admin may explicitly grant this narrowly scoped authority to HR.
    s=s.replace('    const data = {};', "    const data = {};\n    if (req.body.canAuthorizePayrollPayment !== undefined) {\n      if (req.user.role !== 'ADMIN') return sendError(res, 'Only Admin can configure Paying Authority.', 403);\n      if ((role || employee.user?.role) !== 'HR') return sendError(res, 'Paying Authority delegation is available for HR accounts only.', 400);\n      data.user = { update: { canAuthorizePayrollPayment: req.body.canAuthorizePayrollPayment } };\n    }")
    s=s.replace('data.user = { update: { role: normalizeRole(role) } };', "data.user = { update: { ...data.user?.update, role: normalizeRole(role), ...(role !== 'HR' ? { canAuthorizePayrollPayment: false } : {}) } };")
    s=s.replace('    accountStatus: true,', '    accountStatus: true,\n    canAuthorizePayrollPayment: true,')
    s=s.replace("          employeeStatus: 'ACTIVE',\n        },", "          employeeStatus: 'ACTIVE',\n          isDeleted: false,\n          ...(req.user.role === 'HR' ? { user: { role: 'EMPLOYEE' } } : {}),\n        },")
    return s
edit('backend/src/controllers/employeeController.js',employee)
edit('backend/src/validators/employeeValidator.js',lambda s:s.replace('export const updateEmployeeSchema = z.object({', 'export const updateEmployeeSchema = z.object({\n  canAuthorizePayrollPayment: z.boolean().optional(),\n  address: z.string().optional().nullable(),'))
