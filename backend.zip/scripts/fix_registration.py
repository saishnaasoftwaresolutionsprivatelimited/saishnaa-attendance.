from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
def edit(path, fn):
    p = root / path
    p.write_text(fn(p.read_text(encoding='utf-8')), encoding='utf-8')

def employee(s):
    s = s.replace("import bcrypt from 'bcryptjs';", "import { hashPassword } from '../utils/passwordHelper.js';\nimport { logAudit } from '../services/auditService.js';\nimport prisma from '../config/db.js';\nimport dayjs from 'dayjs';\nimport { DEFAULT_TZ } from '../utils/timeHelper.js';")
    s = s.replace("import { PrismaClient } from '@prisma/client';\n\nconst prisma = new PrismaClient();", '')
    a = s.index('/* ============================================================\n   SIMPLE AUDIT')
    b = s.index('/* ============================================================\n   UTILITY', a)
    s = s[:a] + s[b:]
    s = s.replace('      temporaryPassword,\n', '      temporaryPassword,\n      lateAllowanceMonthly = 2,\n      permissionAllowanceMonthly = 1,\n      clRemainingDays = 1,\n      upiId,\n')
    s = s.replace('temporaryPassword?.trim() ||', 'temporaryPassword ||')
    s = s.replace('await bcrypt.hash(password, 12)', 'await hashPassword(password)')
    a = s.index('    /*\n     * IMPORTANT:')
    b = s.index('    const result =', a)
    s = s[:a] + s[b:]
    s = s.replace('          role: requestedRole,\n', '')
    s = s.replace('          userId: user.id,', '          user: { connect: { id: user.id } },')
    s = s.replace('lateAttendanceAllowance: 2,', 'lateAttendanceAllowance: Number(lateAllowanceMonthly),')
    s = s.replace('permissionAllowancePerMonth: 1,', 'permissionAllowancePerMonth: Number(permissionAllowanceMonthly),')
    s = s.replace('bankName: bankName?.trim() || null,', "bankName: paymentMethod === 'BANK_TRANSFER' ? bankName?.trim() || null : null,")
    s = s.replace('bankAccountNumber:\n              bankAccountNumber?.trim() || null,', "accountNumber: paymentMethod === 'BANK_TRANSFER' ? bankAccountNumber?.trim() || null : null,\n            upiId: paymentMethod === 'UPI' ? upiId?.trim() || null : null,")
    s = s.replace('ifscCode:\n              ifscCode?.trim()?.toUpperCase() || null,', "ifscCode: paymentMethod === 'BANK_TRANSFER' ? ifscCode?.trim()?.toUpperCase() || null : null,")
    needle = '      return {\n        user,\n        employee,\n      };'
    s = s.replace(needle, """      const monthYear = dayjs().tz(DEFAULT_TZ).format('YYYY-MM');
      const clType = await tx.leaveType.upsert({
        where: { code: 'CL' }, update: {},
        create: { code: 'CL', name: 'Casual Leave', annualQuota: 12, isPaid: true },
      });
      await tx.leaveBalance.create({ data: {
        employeeId: employee.id, leaveTypeId: clType.id, year: Number(monthYear.slice(0, 4)),
        totalAllocated: Number(clRemainingDays), remainingDays: Number(clRemainingDays),
      } });
      await tx.leaveLedger.create({ data: {
        employeeId: employee.id, leaveTypeCode: 'CL', monthYear,
        creditedDays: Number(clRemainingDays), closingBalance: Number(clRemainingDays),
        remarks: 'Initial CL allocation at registration (includes registration month)',
      } });
      return { employee };
""")
    s = s.replace("    const where = {};", "    const where = { isDeleted: false, NOT: { user: { role: 'ADMIN' } } };")
    s = s.replace("where.role = 'EMPLOYEE';", "where.user = { role: 'EMPLOYEE' };")
    s = s.replace('        employees,\n', '        employees: employees.map(e => ({ ...e, role: e.user?.role, accountStatus: e.user?.accountStatus })),\n')
    s = s.replace("employee.role === 'ADMIN'", "employee.user?.role === 'ADMIN'")
    s = s.replace("employee.role !== 'EMPLOYEE'", "employee.user?.role !== 'EMPLOYEE'")
    s = s.replace("      employee.user?.role === 'ADMIN'\n", "      employee.user?.role !== 'EMPLOYEE' && employee.id !== req.user.employeeId\n", 1)
    s = s.replace('      employee,\n      \'Employee loaded', "      { ...employee, role: employee.user?.role },\n      'Employee loaded")
    # All operational target lookups require the actual User relation.
    s = s.replace('        id: req.params.id,\n      },\n    });', '        id: req.params.id,\n      },\n      include: { user: { select: { id: true, role: true } } },\n    });')
    s = s.replace('        id: employeeId,\n      },\n    });', '        id: employeeId,\n      },\n      include: { user: { select: { id: true, role: true } } },\n    });')
    s = s.replace('data.role = normalizeRole(role);', 'data.user = { update: { role: normalizeRole(role) } };')
    a = s.index('    if (\n      req.user?.role === \'ADMIN\' &&\n      role &&')
    b = s.index('    await logAudit', a)
    s = s[:a] + s[b:]
    s = s.replace("        employeeStatus: nextStatus,", "        employeeStatus: nextStatus,\n        ...(employee.user ? { user: { update: { accountStatus: nextStatus } } } : {}),")
    a = s.index('    if (employee.userId)')
    b = s.index('    return sendSuccess', a)
    s = s[:a] + s[b:]
    a = s.index('    /*\n     * Same note as createEmployee:')
    b = s.index('    await prisma.user.update', a)
    s = s[:a] + s[b:]
    s = s.replace('        password: temporaryPassword,\n        isActive: true,', "        passwordHash: await hashPassword(temporaryPassword),\n        accountStatus: 'ACTIVE',\n        mustChangePassword: true,")
    a = s.index('    /*\n     * Existing schema relation name')
    b = s.index('    return sendSuccess', a)
    s = s[:a] + """    await prisma.$transaction(async tx => {
      await tx.employeeShiftAssignment.updateMany({ where: { employeeId: employee.id, effectiveTo: null }, data: { effectiveTo: new Date() } });
      await tx.employeeShiftAssignment.create({ data: { employeeId: employee.id, shiftId, effectiveFrom: new Date(req.body.effectiveFrom || Date.now()) } });
    });

""" + s[b:]
    a = s.index('    /*\n     * Employee records normally')
    b = s.index('    return sendSuccess', a)
    s = s[:a] + """    await prisma.employee.update({
      where: { id: employee.id },
      data: { isDeleted: true, employeeStatus: 'INACTIVE',
        ...(employee.user ? { user: { update: { accountStatus: 'INACTIVE' } } } : {}),
      },
    });

""" + s[b:]
    return s

edit('backend/src/controllers/employeeController.js', employee)
edit('backend/src/validators/employeeValidator.js', lambda s: s.replace("['BANK_TRANSFER', 'CHEQUE', 'CASH']", "['BANK_TRANSFER', 'UPI', 'CASH']").replace('  bankName: z.string()', '  upiId: z.string().trim().optional().nullable(),\n  bankName: z.string()').replace("  ifscCode: z.string().optional().nullable(),\n});", "  ifscCode: z.string().optional().nullable(),\n}).refine(data => data.paymentMethod !== 'UPI' || /^[^\\s@]+@[^\\s@]+$/.test(data.upiId || ''), { path: ['upiId'], message: 'Enter a valid UPI ID' });"))

for schema in ['backend/prisma/schema.prisma', 'backend/prisma/schema.sqlite.prisma']:
    edit(schema, lambda s: s.replace('  mustChangePassword  Boolean', '  canAuthorizePayrollPayment Boolean        @default(false)\n  mustChangePassword  Boolean').replace('  bankName                   String?', '  upiId                      String?\n  monthlyClCredit            Float     @default(1)\n  bankName                   String?').replace('// BANK_TRANSFER, CHEQUE, CASH', '// BANK_TRANSFER, UPI, CASH'))
