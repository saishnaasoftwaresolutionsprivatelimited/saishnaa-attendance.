import prisma from '../config/db.js';

/**
 * Concurrency-safe Employee Code Generator
 * Produces format: EMP001, EMP002, EMP003, etc.
 */
export async function generateNextEmployeeCode(prefix = 'EMP') {
  // Query existing employee codes matching prefix
  const employees = await prisma.employee.findMany({
    where: {
      employeeCode: {
        startsWith: prefix,
      },
    },
    select: {
      employeeCode: true,
    },
  });

  let maxNumber = 0;
  const regex = new RegExp(`^${prefix}(\\d+)$`, 'i');

  for (const emp of employees) {
    const match = emp.employeeCode.match(regex);
    if (match && match[1]) {
      const num = parseInt(match[1], 10);
      if (num > maxNumber) {
        maxNumber = num;
      }
    }
  }

  const nextNumber = maxNumber + 1;
  const paddedNumber = String(nextNumber).padStart(3, '0');
  return `${prefix}${paddedNumber}`;
}
