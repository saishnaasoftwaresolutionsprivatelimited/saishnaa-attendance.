import { getCompanySettings } from './companySettingsService.js';
import { evaluateAttendanceLocation, locationConfigFromSettings } from '../../../shared/attendanceLocation.mjs';
export { calculateDistanceMeters } from '../../../shared/attendanceLocation.mjs';

export function getAttendanceLocationConfig() {
  return locationConfigFromSettings(getCompanySettings());
}

export function validateAttendanceLocation(latitude, longitude, accuracy) {
  // Re-read the saved settings on every punch; never accept a client verdict.
  const config = getAttendanceLocationConfig();
  const result = evaluateAttendanceLocation(config, latitude, longitude);
  if (!result.allowed && result.statusCode === 403) {
    result.message = `Device GPS places you approximately ${Math.round(result.distanceMeters)} m from the configured office (allowed radius: ${config.radiusMeters} m). Enable precise location or ask Admin to verify the office pin and radius.`;
  }
  if (process.env.NODE_ENV === 'development') {
    console.log({ employeeLatitude: latitude, employeeLongitude: longitude, accuracy,
      officeLatitude: config.latitude, officeLongitude: config.longitude,
      allowedRadius: config.radiusMeters, distanceMeters: result.distanceMeters });
  }
  return result;
}
