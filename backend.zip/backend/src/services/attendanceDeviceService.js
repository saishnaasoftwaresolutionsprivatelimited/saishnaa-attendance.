import { createHash, randomBytes } from 'node:crypto';
import prisma from '../config/db.js';

export const DEVICE_COOKIE = 'saishnaa_office_device';
export const publicDeviceSelect = {
  id: true, deviceName: true, deviceIdentifier: true, deviceType: true, description: true,
  isActive: true, registeredAt: true, lastUsedAt: true, registeredById: true, updatedAt: true,
};

export const hashDeviceToken = (token) => createHash('sha256').update(token).digest('hex');
export function createDeviceCredential() {
  const token = randomBytes(32).toString('base64url');
  return { token, tokenHash: hashDeviceToken(token) };
}
export function deviceCookieOptions(req) {
  return { httpOnly: true, secure: process.env.NODE_ENV === 'production' || req.secure === true,
    sameSite: 'strict', path: '/api', maxAge: 365 * 24 * 60 * 60 * 1000 };
}
export async function findRegisteredDevice(req) {
  const token = req.cookies?.[DEVICE_COOKIE];
  if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
  return prisma.registeredAttendanceDevice.findUnique({
    where: { tokenHash: hashDeviceToken(token) }, select: publicDeviceSelect,
  });
}

export function isDesktopRequest(req) {
  const agent = String(req.get('user-agent') || '');
  return Boolean(agent) && req.get('sec-ch-ua-mobile') !== '?1'
    && !/android|iphone|ipad|ipod|mobile|tablet|opera mini|iemobile/i.test(agent);
}
