import { isIP } from 'node:net';
import proxyaddr from 'proxy-addr';

export function validateNetworkCidrs(cidrs) {
  if (!Array.isArray(cidrs) || cidrs.length > 32 || cidrs.some((cidr) => {
    if (typeof cidr !== 'string') return true;
    const parts = cidr.split('/');
    const family = isIP(parts[0]);
    return parts.length !== 2 || !family || !/^\d{1,3}$/.test(parts[1])
      || Number(parts[1]) > (family === 4 ? 32 : 128);
  })) {
    throw Object.assign(new Error('Enter valid IPv4/IPv6 CIDRs, one per line (for example 192.168.1.0/24).'), { statusCode: 422 });
  }
  // The same established parser Express uses, including IPv4-mapped IPv6 handling.
  proxyaddr.compile(cidrs);
  return cidrs;
}

export function matchesOfficeNetwork(clientIp, cidrs) {
  try {
    validateNetworkCidrs(cidrs);
    return Boolean(isIP(clientIp || '') && cidrs.length && proxyaddr.compile(cidrs)(clientIp));
  } catch { return false; }
}

export function configureTrustedProxies(app, value = '') {
  const cidrs = value.split(',').map((item) => item.trim()).filter(Boolean);
  validateNetworkCidrs(cidrs);
  // Never trust arbitrary forwarded headers or a generic hop count.
  app.set('trust proxy', cidrs.length ? proxyaddr.compile(cidrs) : false);
}

export function getOfficeNetworkStatus(req, settings) {
  const clientIp = req.ip || req.socket?.remoteAddress || '';
  const required = settings.attendanceRequireOfficeNetwork !== false;
  const approved = matchesOfficeNetwork(clientIp, settings.attendanceNetworkCidrs);
  return { required, allowed: !required || approved, approved, clientIp,
    message: !required ? 'Office network not required by Admin.' : approved ? 'Office Network'
      : !settings.attendanceNetworkCidrs?.length ? 'Office network is not configured. Contact your administrator.'
        : 'Not connected through the approved office network.' };
}
