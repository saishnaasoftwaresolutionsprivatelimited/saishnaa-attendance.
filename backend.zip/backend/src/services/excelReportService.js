import ExcelJS from 'exceljs';

/**
 * Generate a beautifully styled corporate Excel workbook for attendance and payroll reports
 */
export async function generateExcelReport({
  title,
  subtitle,
  columns,
  data,
  summaryTotals = null,
}) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'SAISHNAA SMART EMPLOYEE ATTENDANCE SYSTEM';
  workbook.created = new Date();

  const worksheet = workbook.addWorksheet('Attendance Report', {
    views: [{ showGridLines: true }],
  });

  // 1. Company Banner Row
  worksheet.mergeCells('A1', `${String.fromCharCode(64 + columns.length)}1`);
  const bannerCell = worksheet.getCell('A1');
  bannerCell.value = 'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED';
  bannerCell.font = { name: 'Arial', size: 14, bold: true, color: { argb: 'FFFFFFFF' } };
  bannerCell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF20266D' }, // Primary Navy
  };
  bannerCell.alignment = { horizontal: 'center', vertical: 'middle' };
  worksheet.getRow(1).height = 28;

  // 2. Report Subtitle / Scope Row
  worksheet.mergeCells('A2', `${String.fromCharCode(64 + columns.length)}2`);
  const subtitleCell = worksheet.getCell('A2');
  subtitleCell.value = `${title.toUpperCase()} - ${subtitle || 'CONFIDENTIAL CORPORATE REPORT'}`;
  subtitleCell.font = { name: 'Arial', size: 10, italic: true, color: { argb: 'FF334155' } };
  subtitleCell.alignment = { horizontal: 'center', vertical: 'middle' };
  worksheet.getRow(2).height = 20;

  // Blank Row 3
  worksheet.getRow(3).height = 8;

  // 3. Header Row (Row 4)
  const headerRow = worksheet.getRow(4);
  headerRow.height = 24;

  columns.forEach((col, idx) => {
    const cell = headerRow.getCell(idx + 1);
    cell.value = col.header;
    cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF2563EB' }, // Tech Blue
    };
    cell.alignment = { horizontal: col.alignment || 'left', vertical: 'middle' };
    cell.border = {
      top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
      left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
      bottom: { style: 'medium', color: { argb: 'FF1E293B' } },
      right: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    };
  });

  // 4. Data Rows
  let currentRowIndex = 5;
  data.forEach((row, rIdx) => {
    const rowObj = worksheet.getRow(currentRowIndex);
    rowObj.height = 20;
    const isEven = rIdx % 2 === 0;

    columns.forEach((col, cIdx) => {
      const cell = rowObj.getCell(cIdx + 1);
      const val = row[col.key];
      cell.value = val !== undefined && val !== null ? val : '--';
      cell.font = { name: 'Arial', size: 9, color: { argb: 'FF1E293B' } };
      cell.alignment = { horizontal: col.alignment || 'left', vertical: 'middle' };

      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: isEven ? 'FFFFFFFF' : 'FFF8FAFC' },
      };

      cell.border = {
        top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        right: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      };
    });

    currentRowIndex++;
  });

  // 5. Summary / Totals Row if provided
  if (summaryTotals) {
    const totalRow = worksheet.getRow(currentRowIndex);
    totalRow.height = 22;
    columns.forEach((col, cIdx) => {
      const cell = totalRow.getCell(cIdx + 1);
      const val = summaryTotals[col.key];
      cell.value = val !== undefined ? val : (cIdx === 0 ? 'TOTAL' : '');
      cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FF0F172A' } };
      cell.alignment = { horizontal: col.alignment || 'left', vertical: 'middle' };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE2E8F0' },
      };
      cell.border = {
        top: { style: 'medium', color: { argb: 'FF64748B' } },
        bottom: { style: 'double', color: { argb: 'FF0F172A' } },
      };
    });
  }

  // 6. Column Widths
  columns.forEach((col, idx) => {
    let maxLen = col.header.length;
    data.forEach((item) => {
      const val = String(item[col.key] || '');
      if (val.length > maxLen) maxLen = val.length;
    });
    worksheet.getColumn(idx + 1).width = Math.min(35, Math.max(12, maxLen + 4));
  });

  return await workbook.xlsx.writeBuffer();
}
