import prisma from '../config/db.js';

/**
 * Log administrative, authentication, or critical lifecycle actions to the audit log
 */
export async function logAudit({ userId = null, action, entityType, entityId = null, details = null, req = null }) {
  try {
    let ipAddress = null;
    if (req) {
      ipAddress = req.ip || req.socket?.remoteAddress || null;
    }

    const detailsStr = details ? (typeof details === 'string' ? details : JSON.stringify(details)) : null;

    await prisma.auditLog.create({
      data: {
        userId,
        action,
        entityType,
        entityId: entityId ? String(entityId) : null,
        details: detailsStr,
        ipAddress,
      },
    });
  } catch (error) {
    console.error('Audit logging failed (non-blocking):', error.message);
  }
}
