import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

/**
 * SAISHNAA PAYROLL CALCULATION ENGINE
 *
 * Final Rules:
 * - Fixed 30-day salary divisor
 * - Salary eligibility starts from joining date
 * - Future dates are excluded
 * - Company holidays are paid
 * - Approved paid leave is paid
 * - Approved OD is paid
 * - Unpaid leave = no salary
 * - Past working day without valid attendance = absent / no salary
 * - Half day = 50% salary
 * - Attendance deductions are not based on shift timing
 */

export function calculateDailySalary({
  monthlySalary,
  calculationMethod = 'CALENDAR_DAYS',
  customDivisor = 30,
  year,
  month,
}) {
  // FINAL COMPANY POLICY:
  // Monthly salary is ALWAYS divided by 30.
  // Keep the old arguments only for API compatibility.
  const divisor = 30;

  const salary = Number(monthlySalary || 0);

  const dailySalary = Number(
    (salary / divisor).toFixed(2)
  );

  return {
    dailySalary,
    divisor,
    divisorMethod: 'FIXED_30',
  };
}

export function calculateEmployeePayroll({
  employee,
  salaryConfig,
  attendanceRecords = [],
  approvedLeaves = [],
  approvedOnDuties = [],
  holidays = [],
  year,
  month,
  asOfDate = null,
}) {
  const monthStr =
    `${year}-${String(month).padStart(2, '0')}`;

  const totalCalendarDays = dayjs(
    `${monthStr}-01`
  ).daysInMonth();

  const monthlySalary = Number(
    salaryConfig?.monthlySalary || 0
  );

  const {
    dailySalary,
    divisor,
    divisorMethod,
  } = calculateDailySalary({
    monthlySalary,
    calculationMethod:
      salaryConfig?.calculationMethod,
    customDivisor:
      salaryConfig?.customDivisor,
    year,
    month,
  });

  const calculationDate = asOfDate
    ? dayjs(asOfDate).startOf('day')
    : dayjs().tz(DEFAULT_TZ).startOf('day');

  /*
   * JOINING DATE
   * Dates before joining are not payroll eligible.
   */
  const joiningDateRaw =
    employee?.joiningDate || null;

  const joiningDate = joiningDateRaw
    ? dayjs(joiningDateRaw).startOf('day')
    : null;

  /*
   * ATTENDANCE MAP
   */
  const attMap = new Map();

  for (const record of attendanceRecords) {
    if (record?.workDate) {
      attMap.set(record.workDate, record);
    }
  }

  /*
   * LEAVE MAPS
   */
  const paidLeaveDates = new Set();
  const unpaidLeaveDates = new Set();

  for (const leave of approvedLeaves) {
    if (!leave?.startDate || !leave?.endDate) {
      continue;
    }

    let current = dayjs(leave.startDate);
    const end = dayjs(leave.endDate);

    while (
      current.isBefore(end, 'day') ||
      current.isSame(end, 'day')
    ) {
      const dateString =
        current.format('YYYY-MM-DD');

      if (dateString.startsWith(monthStr)) {
        if (leave.leaveType?.isPaid !== false) {
          paidLeaveDates.add(dateString);
        } else {
          unpaidLeaveDates.add(dateString);
        }
      }

      current = current.add(1, 'day');
    }
  }

  /*
   * ON DUTY
   */
  const odDates = new Set();

  for (const od of approvedOnDuties) {
    if (
      od?.odDate &&
      od.odDate.startsWith(monthStr)
    ) {
      odDates.add(od.odDate);
    }
  }

  /*
   * HOLIDAYS
   */
  const holidayDates = new Set();

  for (const holiday of holidays) {
    if (
      holiday?.date &&
      holiday.date.startsWith(monthStr)
    ) {
      holidayDates.add(holiday.date);
    }
  }

  /*
   * COUNTERS
   */
  let eligibleDays = 0;

  let presentDays = 0;
  let halfDays = 0;

  let paidLeaveDays = 0;
  let unpaidLeaveDays = 0;

  let approvedOdDays = 0;

  let paidHolidaysCount = 0;
  let paidWeeklyOffsCount = 0;

  let absentDays = 0;
  let incompleteDays = 0;

  let lateDaysCount = 0;

  /*
   * Kept only for DB/API compatibility.
   * Future dates are NOT payroll days.
   */
  let scheduledDays = 0;

  const dailyBreakdown = [];

  /*
   * PROCESS EACH CALENDAR DATE
   */
  for (
    let day = 1;
    day <= totalCalendarDays;
    day++
  ) {
    const dateString =
      `${monthStr}-${String(day).padStart(2, '0')}`;

    const date = dayjs(dateString);

    /*
     * BEFORE JOINING DATE
     */
    if (
      joiningDate &&
      date.isBefore(joiningDate, 'day')
    ) {
      dailyBreakdown.push({
        date: dateString,
        status: 'NOT_EMPLOYED',
        checkInTime: null,
        checkOutTime: null,
        daySalary: 0,
        notes: 'Before employee joining date',
      });

      continue;
    }

    /*
     * FUTURE DATE
     *
     * Do not count as:
     * - eligible
     * - absent
     * - deduction
     * - earning
     *
     * scheduledDays remains 0 because future
     * projections are removed from payroll.
     */
    if (
      date.isAfter(calculationDate, 'day')
    ) {
      dailyBreakdown.push({
        date: dateString,
        status: 'FUTURE',
        checkInTime: null,
        checkOutTime: null,
        daySalary: 0,
        notes:
          'Future date - excluded from payroll',
      });

      continue;
    }

    eligibleDays += 1;

    const isHoliday =
      holidayDates.has(dateString);

    const hasPaidLeave =
      paidLeaveDates.has(dateString);

    const hasUnpaidLeave =
      unpaidLeaveDates.has(dateString);

    const hasOD =
      odDates.has(dateString);

    const attendance =
      attMap.get(dateString);

    let rowStatus = 'ABSENT';
    let rowCheckIn = null;
    let rowCheckOut = null;
    let rowSalary = 0;
    let rowNotes = '';

    /*
     * PRIORITY:
     * OD / Leave / Holiday are approved
     * day-level states and should not become absent
     * simply because there is no punch.
     */

    if (hasOD) {
      approvedOdDays += 1;

      rowStatus = 'ON_DUTY';
      rowSalary = dailySalary;
      rowNotes = 'Approved On-Duty';
    }

    else if (hasPaidLeave) {
      paidLeaveDays += 1;

      rowStatus = 'LEAVE';
      rowSalary = dailySalary;
      rowNotes = 'Approved paid leave';
    }

    else if (hasUnpaidLeave) {
      unpaidLeaveDays += 1;

      rowStatus = 'UNPAID_LEAVE';
      rowSalary = 0;
      rowNotes = 'Approved unpaid leave';
    }

    else if (isHoliday) {
      paidHolidaysCount += 1;

      rowStatus = 'HOLIDAY';
      rowSalary = dailySalary;
      rowNotes = 'Paid company holiday';
    }

    /*
     * NORMAL WORKING DAY
     */
    else if (attendance) {
      if (attendance.checkInAt) {
        rowCheckIn = dayjs(
          attendance.checkInAt
        )
          .tz(DEFAULT_TZ)
          .format('hh:mm A');
      }

      if (attendance.checkOutAt) {
        rowCheckOut = dayjs(
          attendance.checkOutAt
        )
          .tz(DEFAULT_TZ)
          .format('hh:mm A');
      }

      const classification =
        attendance.attendanceClassification;

      const fullDayStatuses = [
        'PRESENT',
        'PUNCTUAL_PRESENT',
        'LATE',
        'LATE_ARRIVAL',
      ];

      if (
        fullDayStatuses.includes(classification)
      ) {
        const completePunch = Boolean(
          attendance.checkInAt &&
          attendance.checkOutAt
        );

        if (completePunch) {
          presentDays += 1;

          rowStatus = 'PRESENT';

          rowSalary = dailySalary;

          if (!rowNotes) {
            rowNotes =
              'Completed working day';
          }
        }

        /*
         * CURRENT DAY MAY STILL BE ACTIVE.
         * Do not mark current date absent before
         * the work session is complete.
         */
        else if (
          date.isSame(calculationDate, 'day')
        ) {
          rowStatus = attendance.checkInAt
            ? 'WORKING'
            : 'NOT_RECORDED';

          rowSalary = 0;

          rowNotes = attendance.checkInAt
            ? 'Work session is still in progress'
            : 'Attendance not completed yet';
        }

        /*
         * PAST DAY WITH INCOMPLETE PUNCH
         */
        else {
          incompleteDays += 1;
          absentDays += 1;

          rowStatus = 'INCOMPLETE';
          rowSalary = 0;

          rowNotes =
            'Incomplete attendance - correction required';
        }
      }

      else if (
        classification === 'HALF_DAY'
      ) {
        halfDays += 1;

        rowStatus = 'HALF_DAY';

        rowSalary = Number(
          (dailySalary * 0.5).toFixed(2)
        );

        rowNotes =
          'Half-day attendance - 50% salary';
      }

      else if (
        classification === 'ABSENT'
      ) {
        absentDays += 1;

        rowStatus = 'ABSENT';
        rowSalary = 0;

        rowNotes =
          attendance.notes ||
          'Absent working day';
      }

      else {
        /*
         * Unknown/incomplete classification.
         */
        if (
          date.isBefore(calculationDate, 'day')
        ) {
          absentDays += 1;

          rowStatus = 'ABSENT';
          rowSalary = 0;

          rowNotes =
            attendance.notes ||
            'Attendance not valid for payroll';
        } else {
          rowStatus = 'NOT_RECORDED';
          rowSalary = 0;

          rowNotes =
            'Current day attendance not completed';
        }
      }
    }

    /*
     * NO ATTENDANCE ON NORMAL WORKING DAY
     */
    else {
      if (
        date.isBefore(calculationDate, 'day')
      ) {
        absentDays += 1;

        rowStatus = 'ABSENT';
        rowSalary = 0;

        rowNotes =
          'No attendance recorded';
      } else {
        /*
         * TODAY:
         * Do not create salary deduction before
         * the current workday is complete.
         */
        rowStatus = 'NOT_RECORDED';
        rowSalary = 0;

        rowNotes =
          'Current day attendance not completed';
      }
    }

    dailyBreakdown.push({
      date: dateString,
      status: rowStatus,
      checkInTime: rowCheckIn,
      checkOutTime: rowCheckOut,
      daySalary: Number(
        Number(rowSalary || 0).toFixed(2)
      ),
      notes: rowNotes,
    });
  }

  /*
   * PAYABLE DAYS
   */
  const payableDays = Number(
    (
      presentDays +
      halfDays * 0.5 +
      paidLeaveDays +
      approvedOdDays +
      paidHolidaysCount +
      paidWeeklyOffsCount
    ).toFixed(1)
  );

  /*
   * LATE POLICY
   *
   * 2 allowed late occurrences.
   * Allowed late itself has no direct
   * payroll deduction.
   *
   * Escalated Half-Day LOP must already
   * be reflected in attendance classification.
   */
  const lateAllowanceTotal =
    salaryConfig?.lateAttendanceAllowance ?? 2;

  const lateAllowanceConsumed = Math.min(
    Number(lateAllowanceTotal),
    lateDaysCount
  );

  const lateDeductions = 0;

  /*
   * PERMISSION
   *
   * Payroll engine does not directly deduct
   * approved permission.
   */
  const permissionCount = 0;
  const permissionDeductions = 0;

  /*
   * OVERTIME REMOVED
   */
  const overtimeHours = 0;
  const overtimePay = 0;

  /*
   * EARNED SALARY
   *
   * Each paid/payable eligible day earns
   * monthlySalary / 30.
   *
   * Future dates earn nothing.
   */
  let grossEarnings = Number(
    dailyBreakdown
      .reduce(
        (sum, row) =>
          sum +
          Number(row.daySalary || 0),
        0
      )
      .toFixed(2)
  );

  /*
   * Prevent rounding from exceeding monthly salary.
   */
  grossEarnings = Math.min(
    grossEarnings,
    monthlySalary
  );

  /*
   * DISPLAY DEDUCTIONS
   *
   * These values are informational.
   * They must NOT be deducted again from
   * grossEarnings because unpaid days already
   * earned zero salary.
   */
  const absenceDeductions = Number(
    (absentDays * dailySalary).toFixed(2)
  );

  const unpaidLeaveDeductions = Number(
    (unpaidLeaveDays * dailySalary).toFixed(2)
  );

  const halfDayDeductions = Number(
    (halfDays * dailySalary * 0.5).toFixed(2)
  );

  const totalDeductions = Number(
    (
      absenceDeductions +
      unpaidLeaveDeductions +
      halfDayDeductions
    ).toFixed(2)
  );

  /*
   * NET PAYABLE UP TO CURRENT DATE
   *
   * Earnings model already excludes unpaid portions.
   */
  const netSalary = grossEarnings;

  return {
    monthlySalary,

    dailySalary,

    divisorMethod,
    divisorUsed: divisor,

    totalCalendarDays,
    eligibleDays,

    payableDays,

    presentDays,
    halfDays,

    paidLeaveDays,
    approvedOdDays,

    paidHolidaysCount,
    paidWeeklyOffsCount,

    unpaidLeaveDays,
    absentDays,

    // Future projection removed.
    scheduledDays,

    incompleteDays,

    lateDaysCount,
    lateAllowanceConsumed,
    lateDeductions,

    permissionCount,
    permissionDeductions,

    overtimeHours,
    overtimePay,

    additionalEarnings: 0,

    absenceDeductions,
    unpaidLeaveDeductions,
    otherDeductions: totalDeductions,

    grossEarnings,
    totalDeductions,
    netSalary,

    dailyBreakdown,
  };
}