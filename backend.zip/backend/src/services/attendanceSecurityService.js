import { getCompanySettings } from './companySettingsService.js';
import { findRegisteredDevice, isDesktopRequest } from './attendanceDeviceService.js';
import { getOfficeNetworkStatus } from './officeNetworkService.js';
import { locationConfigFromSettings, evaluateAttendanceLocation } from '../../../shared/attendanceLocation.mjs';

export async function getAttendanceSecurityStatus(req, { validateGps = false } = {}) {
  const settings = getCompanySettings();
  const registered = await findRegisteredDevice(req);
  const identityAllowed = ['EMPLOYEE', 'HR', 'ADMIN'].includes(req.user?.role)
    && req.employee?.employeeStatus === 'ACTIVE' && !req.employee?.isDeleted;
  const desktopAllowed = isDesktopRequest(req);
  const deviceRequired = settings.attendanceRequireRegisteredDevice !== false;
  const deviceAllowed = !deviceRequired || registered?.isActive === true;
  const network = getOfficeNetworkStatus(req, settings);
  const gpsRequired = settings.attendanceLocationEnabled === true;
  // No position parsing or distance calculation occurs when GPS is disabled.
  const gps = gpsRequired && validateGps
    ? evaluateAttendanceLocation(locationConfigFromSettings(settings), req.body?.latitude, req.body?.longitude)
    : null;
  const checks = {
    account: { allowed: Boolean(identityAllowed), message: identityAllowed ? 'Authenticated employee account' : 'An active Employee/HR profile is required for attendance.' },
    desktop: { allowed: desktopAllowed, message: desktopAllowed ? 'Desktop/Laptop' : 'Attendance punches require a desktop or laptop browser.' },
    device: { required: deviceRequired, allowed: deviceAllowed, registered: Boolean(registered?.isActive),
      deviceName: registered?.deviceName || null,
      message: !deviceRequired ? 'Registered device not required by Admin.' : registered?.isActive ? 'Registered Office Device'
        : registered ? 'This office device has been disabled. Contact your administrator.' : 'This device is not registered for office attendance. Contact your administrator.' },
    network,
    gps: { required: gpsRequired, allowed: gps?.allowed ?? !gpsRequired,
      ...(gpsRequired ? { config: locationConfigFromSettings(settings) } : {}),
      message: gps?.message || (gpsRequired ? 'GPS verification required.' : 'GPS not required.') },
  };
  const environmentAllowed = checks.account.allowed && desktopAllowed && deviceAllowed && network.allowed;
  const allowed = environmentAllowed && (!gpsRequired || !validateGps || gps.allowed);
  const failure = [checks.account, checks.desktop, checks.device, checks.network, ...(validateGps ? [checks.gps] : [])].find((check) => !check.allowed);
  return { allowed, checks, deviceId: registered?.id || null,
    message: failure?.message || (gpsRequired && !validateGps ? 'Office device and network verified. GPS verification required.' : 'Ready for attendance punches') };
}
