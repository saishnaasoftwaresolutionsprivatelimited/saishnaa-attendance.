import prisma from '../config/db.js';
import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

// Credit each missing calendar month once, carrying the last closing balance
// across year boundaries. Existing balances are preserved as the opening value.
export async function processMonthlyClAccrualForEmployee(employeeId, yearMonth = null) {
  const target = yearMonth || dayjs().tz(DEFAULT_TZ).format('YYYY-MM');
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(target)) throw new Error('Invalid CL month');
  return prisma.$transaction(async tx => {
    const existing = await tx.leaveLedger.findUnique({ where: { employeeId_leaveTypeCode_monthYear: { employeeId, leaveTypeCode: 'CL', monthYear: target } } });
    if (existing) return existing;
    const employee = await tx.employee.findUnique({ where: { id: employeeId }, include: { salaryConfig: true } });
    if (!employee || employee.isDeleted) return null;
    const joiningMonth = dayjs(employee.joiningDate).format('YYYY-MM');
    if (target < joiningMonth) return null;
    const cl = await tx.leaveType.upsert({ where: { code: 'CL' }, update: {}, create: { code: 'CL', name: 'Casual Leave', annualQuota: 12, isPaid: true } });
    const previous = await tx.leaveLedger.findFirst({ where: { employeeId, leaveTypeCode: 'CL', monthYear: { lt: target } }, orderBy: { monthYear: 'desc' } });
    const balance = await tx.leaveBalance.findFirst({ where: { employeeId, leaveTypeId: cl.id, year: { lte: Number(target.slice(0, 4)) } }, orderBy: { year: 'desc' } });
    let opening = previous?.closingBalance ?? balance?.remainingDays ?? 0;
    let month = previous ? dayjs(`${previous.monthYear}-01`).add(1, 'month').format('YYYY-MM') : target;
    const creditedDays = employee.salaryConfig?.monthlyClCredit ?? 1;
    let ledger;
    while (month <= target) {
      const closingBalance = opening + creditedDays;
      ledger = await tx.leaveLedger.create({ data: {
        employeeId, leaveTypeCode: 'CL', monthYear: month, openingBalance: opening,
        creditedDays, closingBalance, remarks: `Monthly CL credit for ${month}`,
      } });
      const year = Number(month.slice(0, 4));
      await tx.leaveBalance.upsert({
        where: { employeeId_leaveTypeId_year: { employeeId, leaveTypeId: cl.id, year } },
        update: { remainingDays: closingBalance, totalAllocated: { increment: creditedDays } },
        create: { employeeId, leaveTypeId: cl.id, year, remainingDays: closingBalance, totalAllocated: closingBalance },
      });
      opening = closingBalance;
      month = dayjs(`${month}-01`).add(1, 'month').format('YYYY-MM');
    }
    return ledger;
  });
}

export async function recordLeaveUsageInLedger({ employeeId, leaveTypeCode, daysCount, monthYear }, tx = prisma) {
  const month = monthYear || dayjs().tz(DEFAULT_TZ).format('YYYY-MM');
  return tx.leaveLedger.update({
    where: { employeeId_leaveTypeCode_monthYear: { employeeId, leaveTypeCode, monthYear: month } },
    data: { usedDays: { increment: daysCount }, closingBalance: { decrement: daysCount } },
  });
}
