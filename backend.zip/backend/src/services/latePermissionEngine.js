import prisma from '../config/db.js';
import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

/**
 * Late Attendance & 1-Hour Permission Linkage Engine (Prompt Requirement 8 & 9)
 *
 * Rules:
 * - Every employee receives 2 late attendance allowances per calendar month.
 * - Late and permission quotas come from the employee's salary configuration.
 * - After both free late allowances are used, one 1-hour permission is available.
 * - Pending and approved permissions consume the current month's quota.
 * - Resets dynamically on the 1st of every new calendar month.
 * - Enforces the strict rule on both backend and frontend.
 */

export async function getMonthlyLateAndPermissionStatus(employeeId, yearMonth = null) {
  const currentYM = yearMonth || dayjs().tz(DEFAULT_TZ).format('YYYY-MM');

  const [lateRecords, salaryConfig, approvedPermissionCount, activePermissionCount] = await Promise.all([
    prisma.attendanceRecord.findMany({
      where: {
        employeeId,
        workDate: { startsWith: currentYM },
        lateMinutes: { gt: 0 },
      },
      select: {
        id: true,
        workDate: true,
        lateMinutes: true,
        checkInAt: true,
      },
      orderBy: { workDate: 'asc' },
    }),
    prisma.salaryConfiguration.findUnique({ where: { employeeId } }),
    prisma.permissionRequest.count({
      where: {
        employeeId,
        permissionDate: { startsWith: currentYM },
        status: 'APPROVED',
      },
    }),
    prisma.permissionRequest.count({
      where: {
        employeeId,
        permissionDate: { startsWith: currentYM },
        status: { in: ['PENDING', 'APPROVED'] },
      },
    }),
  ]);

  const lateCount = lateRecords.length;
  const maxLateAllowance = salaryConfig?.lateAttendanceAllowance ?? 2;
  const maxPermissionAllowance = salaryConfig?.permissionAllowancePerMonth ?? 1;
  const remainingLateAllowances = Math.max(0, maxLateAllowance - lateCount);
  const remainingPermissionAllowances = Math.max(0, maxPermissionAllowance - activePermissionCount);
  const hasUsedFreeLates = lateCount >= maxLateAllowance;
  const hasPermissionQuota = remainingPermissionAllowances > 0;
  const isPermissionEligible = hasUsedFreeLates && hasPermissionQuota;

  const restrictionReason = !hasUsedFreeLates
    ? `Use the ${maxLateAllowance} monthly late allowances first. One-hour permission becomes available after they are used.`
    : !hasPermissionQuota
      ? `You have already used or requested your ${maxPermissionAllowance} permission allowance for this month.`
      : null;

  return {
    monthYear: currentYM,
    maxLateAllowance,
    maxPermissionAllowance,
    lateCount,
    remainingLateAllowances,
    remainingPermissionAllowances,
    lateRecords,
    isPermissionEligible,
    restrictionReason,
    approvedPermissionCount,
    activePermissionCount,
  };
}

/**
 * Validate permission request eligibility before creation
 * Permission becomes available after both free late allowances are used, subject to the monthly quota.
 */
export async function validatePermissionEligibility(employeeId, permissionDate) {
  const ym = permissionDate.substring(0, 7);
  const status = await getMonthlyLateAndPermissionStatus(employeeId, ym);

  if (!status.isPermissionEligible) {
    return {
      allowed: false,
      message: status.restrictionReason,
    };
  }

  return {
    allowed: true,
    message: 'Eligible for 1-hour permission request.',
  };
}
