import PDFDocument from 'pdfkit';
import dayjs from 'dayjs';

/**
 * Generate Simple Corporate Employee Payslip PDF
 *
 * Design:
 * - Simple teal header
 * - Compact employee information
 * - Earnings and deductions side-by-side
 * - Dark teal Net Pay bar
 * - Small attendance/payroll information
 * - Payment details when available
 */
export function generatePayslipPdf({
  payrollCalculation,
  employee,
  salaryConfig,
  companyInfo = {},
}) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margin: 0,
      });

      const buffers = [];

      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', (err) => reject(err));

      /* =========================================================
         PAGE SETTINGS
      ========================================================= */

      const pageWidth = doc.page.width;
      const pageHeight = doc.page.height;

      const margin = 42;
      const contentWidth = pageWidth - margin * 2;

      /* =========================================================
         COLORS
      ========================================================= */

      const TEAL = '#28B8B0';
      const DARK_TEAL = '#123F3D';

      const TEXT = '#263238';
      const MUTED = '#667085';

      const LIGHT_SECTION = '#F4F1EA';
      const LIGHT_BORDER = '#E7E4DC';

      const GREEN = '#11998E';
      const WHITE = '#FFFFFF';

      /* =========================================================
         HELPERS
      ========================================================= */

      const safeNumber = (value) => {
        const number = Number(value);

        return Number.isFinite(number)
          ? number
          : 0;
      };

      const money = (value) =>
        safeNumber(value).toLocaleString('en-IN', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        });

      const days = (value) => {
        const number = safeNumber(value);

        return Number.isInteger(number)
          ? String(number)
          : number.toFixed(1);
      };

      /* =========================================================
         BASIC DATA
      ========================================================= */

      const companyName = (
        companyInfo?.companyName ||
        'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED'
      ).toUpperCase();

      const companyAddress =
        companyInfo?.address || '';

      const companyWebsite =
        companyInfo?.website || '';

      const employeeName =
        employee?.fullName || 'Employee';

      const employeeCode =
        employee?.employeeCode || '-';

      const department =
        employee?.department?.name || '-';

      const designation =
        employee?.designation?.title ||
        employee?.designation?.name ||
        '-';

      const monthYear =
        payrollCalculation?.monthYear || '';

      const payslipMonth = monthYear
        ? dayjs(`${monthYear}-01`).format('MMMM YYYY')
        : '-';

      const payslipNumber =
        payrollCalculation?.payslipNumber || '-';

      /* =========================================================
         PAYROLL VALUES
      ========================================================= */

      const monthlySalary = safeNumber(
        payrollCalculation?.monthlySalary
      );

      const grossEarnings = safeNumber(
        payrollCalculation?.grossEarnings
      );

      const additionalEarnings = safeNumber(
        payrollCalculation?.additionalEarnings
      );

      const absenceDeduction = safeNumber(
        payrollCalculation?.absenceDeductions
      );

      const unpaidLeaveDeduction = safeNumber(
        payrollCalculation?.unpaidLeaveDeductions
      );

      const otherDeductions = safeNumber(
        payrollCalculation?.otherDeductions
      );

      const totalDeductions = safeNumber(
        payrollCalculation?.totalDeductions
      );

      const netSalary = safeNumber(
        payrollCalculation?.netSalary
      );

      const dailySalary = safeNumber(
        payrollCalculation?.dailySalary
      );

      const payableDays = safeNumber(
        payrollCalculation?.payableDays
      );

      const presentDays = safeNumber(
        payrollCalculation?.presentDays
      );

      const paidLeaveDays = safeNumber(
        payrollCalculation?.paidLeaveDays
      );

      const odDays = safeNumber(
        payrollCalculation?.approvedOdDays
      );

      const absentDays = safeNumber(
        payrollCalculation?.absentDays
      );

      const unpaidLeaveDays = safeNumber(
        payrollCalculation?.unpaidLeaveDays
      );

      /* =========================================================
         HEADER
      ========================================================= */

      const headerY = 36;
      const headerHeight = 60;

      doc
        .roundedRect(
          margin,
          headerY,
          contentWidth,
          headerHeight,
          10
        )
        .fill(TEAL);

      doc
        .fillColor(WHITE)
        .font('Helvetica-Bold')
        .fontSize(14)
        .text(
          companyName,
          margin + 16,
          headerY + 13,
          {
            width: contentWidth - 32,
            ellipsis: true,
          }
        );

      doc
        .fillColor('#E8FFFF')
        .font('Helvetica')
        .fontSize(8.5)
        .text(
          `Payslip  •  ${payslipMonth}`,
          margin + 16,
          headerY + 36
        );

      /* =========================================================
         COMPANY SMALL DETAILS
      ========================================================= */

      let currentY = headerY + headerHeight + 11;

      if (companyAddress || companyWebsite) {
        const companyLine = [
          companyAddress,
          companyWebsite,
        ]
          .filter(Boolean)
          .join('  •  ');

        doc
          .fillColor(MUTED)
          .font('Helvetica')
          .fontSize(7.5)
          .text(
            companyLine,
            margin + 2,
            currentY,
            {
              width: contentWidth - 4,
            }
          );

        currentY += 18;
      }

      /* =========================================================
         EMPLOYEE DETAILS
      ========================================================= */

      const labelX = margin + 2;
      const valueX = margin + 92;

      const detailRow = (label, value) => {
        doc
          .fillColor(MUTED)
          .font('Helvetica-Bold')
          .fontSize(8.5)
          .text(
            label,
            labelX,
            currentY,
            {
              width: 82,
            }
          );

        doc
          .fillColor(TEXT)
          .font('Helvetica')
          .fontSize(8.5)
          .text(
            String(value || '-'),
            valueX,
            currentY,
            {
              width: contentWidth - 100,
            }
          );

        currentY += 16;
      };

      detailRow(
        'Employee',
        employeeName
      );

      detailRow(
        'Designation',
        designation
      );

      detailRow(
        'Department',
        department
      );

      detailRow(
        'Month',
        payslipMonth
      );

      detailRow(
        'Emp ID',
        employeeCode
      );

      /* =========================================================
         SMALL PAYSLIP NUMBER
      ========================================================= */

      doc
        .fillColor('#98A2B3')
        .font('Helvetica')
        .fontSize(7)
        .text(
          `Payslip No: ${payslipNumber}`,
          margin + 2,
          currentY + 1
        );

      currentY += 22;

      /* =========================================================
         ATTENDANCE SUMMARY - SIMPLE ONE LINE
      ========================================================= */

      doc
        .roundedRect(
          margin,
          currentY,
          contentWidth,
          28,
          6
        )
        .fill('#F8FAFA');

      doc
        .fillColor(MUTED)
        .font('Helvetica')
        .fontSize(7.5)
        .text(
          `Payable Days: ${days(
            payableDays
          )}    •    Present: ${days(
            presentDays
          )}    •    Paid Leave: ${days(
            paidLeaveDays
          )}    •    On Duty: ${days(
            odDays
          )}    •    Absent / LOP: ${days(
            absentDays
          )}`,
          margin + 12,
          currentY + 10,
          {
            width: contentWidth - 24,
            align: 'center',
          }
        );

      currentY += 42;

      /* =========================================================
         EARNINGS / DEDUCTIONS COLUMNS
      ========================================================= */

      const columnGap = 14;

      const columnWidth =
        (contentWidth - columnGap) / 2;

      const earningsX = margin;

      const deductionsX =
        margin + columnWidth + columnGap;

      /* =========================================================
         SECTION HEADERS
      ========================================================= */

      const sectionHeaderHeight = 23;

      doc
        .roundedRect(
          earningsX,
          currentY,
          columnWidth,
          sectionHeaderHeight,
          6
        )
        .fill(LIGHT_SECTION);

      doc
        .roundedRect(
          deductionsX,
          currentY,
          columnWidth,
          sectionHeaderHeight,
          6
        )
        .fill(LIGHT_SECTION);

      doc
        .fillColor(TEXT)
        .font('Helvetica-Bold')
        .fontSize(9)
        .text(
          'Earnings',
          earningsX + 11,
          currentY + 7
        );

      doc
        .fillColor(TEXT)
        .font('Helvetica-Bold')
        .fontSize(9)
        .text(
          'Deductions',
          deductionsX + 11,
          currentY + 7
        );

      currentY += 35;

      /* =========================================================
         ROW HELPER
      ========================================================= */

      const salaryRow = ({
        x,
        y,
        label,
        amount,
        bold = false,
        green = false,
      }) => {
        doc
          .fillColor(
            green
              ? GREEN
              : TEXT
          )
          .font(
            bold
              ? 'Helvetica-Bold'
              : 'Helvetica'
          )
          .fontSize(8.5)
          .text(
            label,
            x + 8,
            y,
            {
              width: columnWidth - 100,
            }
          );

        doc
          .fillColor(
            green
              ? GREEN
              : TEXT
          )
          .font(
            bold
              ? 'Helvetica-Bold'
              : 'Helvetica'
          )
          .fontSize(8.5)
          .text(
            money(amount),
            x + columnWidth - 90,
            y,
            {
              width: 80,
              align: 'right',
            }
          );
      };

      /* =========================================================
         EARNINGS ROWS
      ========================================================= */

      const rowsStartY = currentY;

      salaryRow({
        x: earningsX,
        y: rowsStartY,
        label: 'Basic Salary',
        amount: monthlySalary,
      });

      salaryRow({
        x: earningsX,
        y: rowsStartY + 20,
        label: 'Earned Salary',
        amount: grossEarnings,
      });

      salaryRow({
        x: earningsX,
        y: rowsStartY + 40,
        label: 'Additional Earnings',
        amount: additionalEarnings,
      });

      /* =========================================================
         DEDUCTION ROWS
      ========================================================= */

      salaryRow({
        x: deductionsX,
        y: rowsStartY,
        label: `Absent / LOP (${days(
          absentDays
        )} days)`,
        amount: absenceDeduction,
      });

      salaryRow({
        x: deductionsX,
        y: rowsStartY + 20,
        label: `Unpaid Leave (${days(
          unpaidLeaveDays
        )} days)`,
        amount: unpaidLeaveDeduction,
      });

      salaryRow({
        x: deductionsX,
        y: rowsStartY + 40,
        label: 'Other Deductions',
        amount: otherDeductions,
      });

      /* =========================================================
         DIVIDER LINES
      ========================================================= */

      const dividerY =
        rowsStartY + 62;

      doc
        .moveTo(
          earningsX + 7,
          dividerY
        )
        .lineTo(
          earningsX +
            columnWidth -
            7,
          dividerY
        )
        .strokeColor(LIGHT_BORDER)
        .lineWidth(0.8)
        .stroke();

      doc
        .moveTo(
          deductionsX + 7,
          dividerY
        )
        .lineTo(
          deductionsX +
            columnWidth -
            7,
          dividerY
        )
        .strokeColor(LIGHT_BORDER)
        .lineWidth(0.8)
        .stroke();

      /* =========================================================
         TOTALS
      ========================================================= */

      const totalY =
        dividerY + 11;

      salaryRow({
        x: earningsX,
        y: totalY,
        label: 'Gross Earnings',
        amount: grossEarnings,
        bold: true,
        green: true,
      });

      salaryRow({
        x: deductionsX,
        y: totalY,
        label: 'Total Deductions',
        amount: totalDeductions,
        bold: true,
        green: true,
      });

      /* =========================================================
         NET PAY BAR
      ========================================================= */

      currentY =
        totalY + 38;

      const netPayHeight = 43;

      doc
        .roundedRect(
          margin,
          currentY,
          contentWidth,
          netPayHeight,
          7
        )
        .fill(DARK_TEAL);

      doc
        .fillColor(WHITE)
        .font('Helvetica-Bold')
        .fontSize(10)
        .text(
          'NET PAY',
          margin + 14,
          currentY + 15
        );

      doc
        .fillColor(WHITE)
        .font('Helvetica-Bold')
        .fontSize(15)
        .text(
          `Rs. ${money(netSalary)}`,
          margin +
            contentWidth -
            220,
          currentY + 12,
          {
            width: 205,
            align: 'right',
          }
        );

      currentY +=
        netPayHeight + 17;

      /* =========================================================
         PAYMENT DETAILS
      ========================================================= */

      const paymentReference =
        payrollCalculation?.paymentReference ||
        '';

      const paymentMethod =
        payrollCalculation?.paymentMethod ||
        '';

      const paymentDate =
        payrollCalculation?.paymentDate
          ? dayjs(
              payrollCalculation.paymentDate
            ).format('DD MMM YYYY')
          : '';

      const isPaid =
        payrollCalculation?.status === 'PAID';

      if (
        isPaid ||
        paymentReference ||
        paymentMethod
      ) {
        doc
          .fillColor(TEXT)
          .font('Helvetica-Bold')
          .fontSize(8.5)
          .text(
            'Payment Details',
            margin + 2,
            currentY
          );

        currentY += 15;

        const paymentParts = [];

        paymentParts.push(
          `Status: ${
            isPaid
              ? 'PAID'
              : payrollCalculation?.status || '-'
          }`
        );

        if (paymentMethod) {
          paymentParts.push(
            `Method: ${paymentMethod.replaceAll(
              '_',
              ' '
            )}`
          );
        }

        if (paymentReference) {
          paymentParts.push(
            `Transaction ID: ${paymentReference}`
          );
        }

        if (paymentDate) {
          paymentParts.push(
            `Date: ${paymentDate}`
          );
        }

        doc
          .fillColor(MUTED)
          .font('Helvetica')
          .fontSize(7.5)
          .text(
            paymentParts.join('   •   '),
            margin + 2,
            currentY,
            {
              width: contentWidth - 4,
            }
          );

        currentY += 24;
      }

      /* =========================================================
         PAYROLL INFO
      ========================================================= */

      doc
        .fillColor('#98A2B3')
        .font('Helvetica')
        .fontSize(7)
        .text(
          `Daily Salary: Rs. ${money(
            dailySalary
          )}   •   Salary Divisor: ${
            payrollCalculation?.divisorUsed ||
            30
          } days`,
          margin + 2,
          currentY,
          {
            width: contentWidth - 4,
          }
        );

      /* =========================================================
         FOOTER
      ========================================================= */

      doc
        .moveTo(
          margin,
          pageHeight - 62
        )
        .lineTo(
          pageWidth - margin,
          pageHeight - 62
        )
        .strokeColor('#ECECEC')
        .lineWidth(0.7)
        .stroke();

      doc
        .fillColor('#98A2B3')
        .font('Helvetica')
        .fontSize(6.8)
        .text(
          'This is a computer-generated payslip and does not require a physical signature.',
          margin,
          pageHeight - 48,
          {
            width: contentWidth,
            align: 'center',
          }
        );

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}