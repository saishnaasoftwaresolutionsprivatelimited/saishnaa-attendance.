import PDFDocument from 'pdfkit';

/**
 * Generate a branded corporate PDF report for attendance summaries
 */
export function generatePdfReport({
  title,
  subtitle,
  dateRange,
  columns,
  data,
  summaryTotals = null,
}) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        margin: 36,
        size: 'A4',
        layout: 'landscape', // Landscape for multi-column attendance tables
      });

      const buffers = [];
      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', (err) => reject(err));

      const pageWidth = doc.page.width;
      const margin = 36;
      const contentWidth = pageWidth - margin * 2;

      // 1. Corporate Header Top Bar
      doc.rect(margin, margin, contentWidth, 40).fill('#20266D'); // Primary Navy

      doc.fillColor('#FFFFFF')
        .font('Helvetica-Bold')
        .fontSize(14)
        .text('SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED', margin + 12, margin + 8);

      doc.fillColor('#93C5FD')
        .font('Helvetica')
        .fontSize(9)
        .text('SMART EMPLOYEE ATTENDANCE MANAGEMENT SYSTEM | CORPORATE AUDIT REPORT', margin + 12, margin + 24);

      // 2. Report Subheading & Metadata
      let currentY = margin + 50;

      doc.fillColor('#0F172A')
        .font('Helvetica-Bold')
        .fontSize(13)
        .text(title.toUpperCase(), margin, currentY);

      doc.fillColor('#64748B')
        .font('Helvetica')
        .fontSize(9)
        .text(
          `Scope: ${subtitle || 'All Departments'} | Period: ${dateRange || 'Current Work Period'} | Generated: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} (IST)`,
          margin,
          currentY + 16
        );

      currentY += 36;

      // 3. Table Column Layout
      // Calculate column widths based on content width
      const totalColWeight = columns.reduce((sum, col) => sum + (col.widthWeight || 1), 0);
      const colWidths = columns.map((col) => (contentWidth * (col.widthWeight || 1)) / totalColWeight);

      // Draw Table Header
      doc.rect(margin, currentY, contentWidth, 20).fill('#2563EB'); // Tech Blue

      let currentX = margin;
      columns.forEach((col, idx) => {
        doc.fillColor('#FFFFFF')
          .font('Helvetica-Bold')
          .fontSize(8.5)
          .text(col.header, currentX + 4, currentY + 5, {
            width: colWidths[idx] - 8,
            align: col.alignment || 'left',
          });
        currentX += colWidths[idx];
      });

      currentY += 20;

      // 4. Data Rows
      data.forEach((row, rIdx) => {
        // Page break handling
        if (currentY > doc.page.height - 50) {
          doc.addPage();
          currentY = margin;
        }

        const isEven = rIdx % 2 === 0;
        const rowHeight = 18;

        doc.rect(margin, currentY, contentWidth, rowHeight).fill(isEven ? '#FFFFFF' : '#F8FAFC');

        currentX = margin;
        columns.forEach((col, idx) => {
          const val = row[col.key] !== undefined && row[col.key] !== null ? String(row[col.key]) : '--';

          doc.fillColor('#1E293B')
            .font('Helvetica')
            .fontSize(8)
            .text(val, currentX + 4, currentY + 5, {
              width: colWidths[idx] - 8,
              align: col.alignment || 'left',
            });

          currentX += colWidths[idx];
        });

        currentY += rowHeight;
      });

      // 5. Summary Row if provided
      if (summaryTotals) {
        if (currentY > doc.page.height - 50) {
          doc.addPage();
          currentY = margin;
        }

        const totalRowHeight = 20;
        doc.rect(margin, currentY, contentWidth, totalRowHeight).fill('#E2E8F0');

        currentX = margin;
        columns.forEach((col, idx) => {
          const val = summaryTotals[col.key] !== undefined ? String(summaryTotals[col.key]) : (idx === 0 ? 'TOTAL' : '');

          doc.fillColor('#0F172A')
            .font('Helvetica-Bold')
            .fontSize(8.5)
            .text(val, currentX + 4, currentY + 5, {
              width: colWidths[idx] - 8,
              align: col.alignment || 'left',
            });

          currentX += colWidths[idx];
        });

        currentY += totalRowHeight;
      }

      // 6. Confidential Footer
      const totalPages = doc.bufferedPageRange().count;
      for (let i = 0; i < totalPages; i++) {
        doc.switchToPage(i);
        doc.fillColor('#94A3B8')
          .font('Helvetica')
          .fontSize(7.5)
          .text(
            `CONFIDENTIAL - SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED | PAGE ${i + 1} OF ${totalPages}`,
            margin,
            doc.page.height - 24,
            { align: 'center', width: contentWidth }
          );
      }

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}
