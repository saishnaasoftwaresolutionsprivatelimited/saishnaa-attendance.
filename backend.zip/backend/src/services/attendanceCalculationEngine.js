import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

export function evaluateCheckIn() {
  return {
    isLate: false,
    lateMinutes: 0,
    classification: 'PRESENT',
  };
}

export function evaluateCheckOut({ attendanceRecord, checkOutTime }) {
  const checkIn = dayjs(attendanceRecord.checkInAt).tz(DEFAULT_TZ);
  const checkOut = dayjs(checkOutTime).tz(DEFAULT_TZ);
  const totalDurationMinutes = Math.max(0, checkOut.diff(checkIn, 'minute'));
  const totalBreakMinutes = Math.max(0, Number(attendanceRecord.totalBreakMinutes) || 0);
  const netWorkMinutes = Math.max(0, totalDurationMinutes - totalBreakMinutes);

  return {
    totalDurationMinutes,
    netWorkMinutes,
    earlyDepartureMinutes: 0,
    overtimeMinutes: 0,
    attendanceClassification: attendanceRecord.attendanceClassification || 'PRESENT',
  };
}
