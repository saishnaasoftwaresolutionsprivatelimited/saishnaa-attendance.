export function canManageEmployee(user, employee) {
  return user?.role === 'ADMIN' || (
    user?.role === 'HR' && employee?.user?.role === 'EMPLOYEE' &&
    employee.id !== user.employeeId
  );
}

export function canReadEmployee(user, employee) {
  return employee?.id === user?.employeeId || canManageEmployee(user, employee);
}

export function canAuthorizePayment(user) {
  return user?.role === 'ADMIN' || user?.canAuthorizePayrollPayment === true;
}
