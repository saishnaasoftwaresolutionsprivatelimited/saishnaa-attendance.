import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import prisma from '../config/db.js';
import { validateNetworkCidrs } from './officeNetworkService.js';
import { parseLocationNumber, locationConfigFromSettings, validCoordinates } from '../../../shared/attendanceLocation.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const settingsFilePath = path.join(__dirname, '../config/companySettings.json');
const WORK_SCHEDULE_SETTINGS = [
  'officeStartTime',
  'officeEndTime',
  'workingHours',
  'requiredWorkMinutes',
  'gracePeriodMinutes',
  'breakDurationMinutes',
  'weeklyOffDays',
];

const DEFAULT_SETTINGS = {
  companyName: 'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED',
  address: 'OMR IT Corridor, Chennai, Tamil Nadu - 600096',
  website: 'www.saishnaa.com',
  email: 'hr@saishnaa.com',
  phone: '+91 98401 23456',
  tagline: 'Smart Employee Attendance & Payroll System',
  attendanceLocationEnabled: false,
  attendanceRequireRegisteredDevice: true,
  attendanceRequireOfficeNetwork: true,
  attendanceNetworkName: 'Saishnaa Office LAN',
  attendanceNetworkCidrs: [],
  attendanceOfficeName: 'Saishnaa Software Solutions Private Limited',
  attendanceOfficeAddress: 'D, No.5/232, 2nd St, Sakthi Nagar, Thindal, Erode, Tamil Nadu 638012',
  attendanceLatitude: null,
  attendanceLongitude: null,
  attendanceRadiusMeters: null,
};

function normalizeLocationSettings(settings) {
  return {
    ...settings,
    attendanceLocationEnabled: settings.attendanceLocationEnabled === true,
    attendanceRequireRegisteredDevice: settings.attendanceRequireRegisteredDevice !== false,
    attendanceRequireOfficeNetwork: settings.attendanceRequireOfficeNetwork !== false,
    attendanceLatitude: parseLocationNumber(settings.attendanceLatitude),
    attendanceLongitude: parseLocationNumber(settings.attendanceLongitude),
    attendanceRadiusMeters: parseLocationNumber(settings.attendanceRadiusMeters),
  };
}

export function getCompanySettings() {
  // An unreadable settings file must never silently restore an old geofence.
  const saved = JSON.parse(fs.readFileSync(settingsFilePath, 'utf8'));
  if (!saved || typeof saved !== 'object' || Array.isArray(saved)) {
    throw new Error('Company settings are unavailable.');
  }
  WORK_SCHEDULE_SETTINGS.forEach((key) => delete saved[key]);
  return normalizeLocationSettings({ ...DEFAULT_SETTINGS, ...saved });
}

export function mergeCompanySettings(current, newSettings) {
  if (!newSettings || typeof newSettings !== 'object' || Array.isArray(newSettings)) {
    throw Object.assign(new Error('Invalid company settings.'), { statusCode: 422 });
  }
  for (const key of ['attendanceLocationEnabled', 'attendanceRequireRegisteredDevice', 'attendanceRequireOfficeNetwork']) {
    if (newSettings[key] !== undefined && typeof newSettings[key] !== 'boolean') {
      throw Object.assign(new Error('Attendance security switches must be true or false.'), { statusCode: 422 });
    }
  }
  if (newSettings.attendanceNetworkCidrs !== undefined) validateNetworkCidrs(newSettings.attendanceNetworkCidrs);
  const merged = normalizeLocationSettings({ ...current, ...newSettings });
  WORK_SCHEDULE_SETTINGS.forEach((key) => delete merged[key]);
  const config = locationConfigFromSettings(merged);
  const invalidSuppliedNumber = ['attendanceLatitude', 'attendanceLongitude', 'attendanceRadiusMeters']
    .some((key) => newSettings[key] !== undefined && merged[key] === null && (config.enabled || ![null, ''].includes(newSettings[key])));
  if (invalidSuppliedNumber || (config.enabled && (!validCoordinates(config.latitude, config.longitude)
    || !(config.radiusMeters > 0) || !config.officeName || !config.officeAddress))
    || (config.latitude !== null && Math.abs(config.latitude) > 90)
    || (config.longitude !== null && Math.abs(config.longitude) > 180)
    || (config.radiusMeters !== null && config.radiusMeters <= 0)) {
    throw Object.assign(new Error('Enter valid office coordinates and a positive radius in meters, with an office name and address.'), { statusCode: 422 });
  }
  return merged;
}

export async function updateCompanySettings(newSettings) {
  try {
    const current = getCompanySettings();
    const updated = {
      ...current,
      ...mergeCompanySettings(current, newSettings),
      companyName: newSettings.companyName ? String(newSettings.companyName).trim() : current.companyName,
      address: newSettings.address !== undefined ? String(newSettings.address).trim() : current.address,
      website: newSettings.website !== undefined ? String(newSettings.website).trim() : current.website,
      email: newSettings.email !== undefined ? String(newSettings.email).trim() : current.email,
      phone: newSettings.phone !== undefined ? String(newSettings.phone).trim() : current.phone,
      tagline: newSettings.tagline !== undefined ? String(newSettings.tagline).trim() : current.tagline,
      attendanceLocationEnabled: newSettings.attendanceLocationEnabled !== undefined
        ? newSettings.attendanceLocationEnabled === true
        : current.attendanceLocationEnabled === true,
      attendanceOfficeName: newSettings.attendanceOfficeName !== undefined
        ? String(newSettings.attendanceOfficeName).trim()
        : current.attendanceOfficeName || '',
      attendanceOfficeAddress: newSettings.attendanceOfficeAddress !== undefined
        ? String(newSettings.attendanceOfficeAddress).trim()
        : current.attendanceOfficeAddress || '',

    };
    WORK_SCHEDULE_SETTINGS.forEach((key) => delete updated[key]);
    const temporaryPath = `${settingsFilePath}.tmp`;
    fs.writeFileSync(temporaryPath, JSON.stringify(updated, null, 2), 'utf8');
    fs.renameSync(temporaryPath, settingsFilePath);

    // Keep the required database relation without applying a work schedule.
    try {
      await syncStandardOfficeTiming();
    } catch (e) {
      console.warn('Could not sync to DB shift:', e.message);
    }

    return updated;
  } catch (err) {
    console.error('Error writing company settings:', err);
    throw err;
  }
}

export async function syncStandardOfficeTiming() {
  try {
    const shiftData = {
      name: 'General Shift',
      startTime: '00:00',
      endTime: '00:00',
      gracePeriodMinutes: 0,
      breakDurationMinutes: 0,
      requiredWorkMinutes: 60,
      weeklyOffDays: JSON.stringify([]),
      overtimeEnabled: false,
      isOvernight: false,
    };

    let shift = await prisma.shift.findFirst({ where: { name: 'General Shift' } });
    if (!shift) {
      shift = await prisma.shift.findFirst({ where: { name: 'General Office Timing (8 Hours)' } });
    }
    if (!shift) {
      shift = await prisma.shift.create({ data: shiftData });
    } else {
      shift = await prisma.shift.update({
        where: { id: shift.id },
        data: shiftData,
      });
    }
    return shift;
  } catch (err) {
    console.error('syncStandardOfficeTiming error:', err);
    return null;
  }
}
