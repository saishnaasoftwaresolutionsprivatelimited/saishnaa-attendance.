import { Router } from 'express';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { getAuditLogs } from '../controllers/auditController.js';

const router = Router();

router.get('/', authenticateUser, authorizeRoles('ADMIN'), getAuditLogs);

export default router;
