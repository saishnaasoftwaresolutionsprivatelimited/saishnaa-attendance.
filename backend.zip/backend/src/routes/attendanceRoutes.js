import { Router } from 'express';
import * as attendanceController from '../controllers/attendanceController.js';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { enforceAttendanceLocation } from '../middleware/attendanceLocationMiddleware.js';
import { enforceDesktopAttendance } from '../middleware/attendanceDeviceMiddleware.js';

const router = Router();

// Employee Attendance Actions
router.post('/check-in', authenticateUser, enforceDesktopAttendance, enforceAttendanceLocation, attendanceController.checkIn);
router.post('/break-start', authenticateUser, attendanceController.startBreak);
router.post('/break-end', authenticateUser, attendanceController.endBreak);
router.post('/check-out', authenticateUser, enforceDesktopAttendance, enforceAttendanceLocation, attendanceController.checkOut);

// Employee Attendance Retrieval
router.get('/today', authenticateUser, attendanceController.getTodayAttendance);
router.get('/me', authenticateUser, attendanceController.getMyAttendance);

// Admin & HR Live Monitoring Table & Dashboard KPIs
router.get('/admin/live', authenticateUser, authorizeRoles('ADMIN', 'HR'), attendanceController.getLiveAdminAttendance);
router.post('/admin/override', authenticateUser, authorizeRoles('ADMIN', 'HR'), attendanceController.adminManualAttendanceOverride);

export default router;

