import { Router } from 'express';
import * as correctionController from '../controllers/correctionController.js';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { validateRequest } from '../middleware/validationMiddleware.js';
import { submitCorrectionSchema, decideCorrectionSchema } from '../validators/correctionValidator.js';

const router = Router();

// Employee endpoints
router.post(
  '/',
  authenticateUser,
  validateRequest(submitCorrectionSchema),
  correctionController.submitCorrection
);
router.get('/me', authenticateUser, correctionController.getMyCorrections);

// Admin & HR endpoints
router.get('/admin', authenticateUser, authorizeRoles('ADMIN', 'HR'), correctionController.getAllCorrections);
router.patch(
  '/admin/:id/decision',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  validateRequest(decideCorrectionSchema),
  correctionController.decideCorrection
);

export default router;
