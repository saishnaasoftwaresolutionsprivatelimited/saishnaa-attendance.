import { Router } from 'express';
import { authenticateUser, authorizeRoles, authorizePayrollPayment } from '../middleware/authMiddleware.js';
import {
  calculatePayroll,
  getPayrollPeriods,
  getPayrollPeriodDetails,
  approvePayrollPeriod,
  recordPayment,
  getMyPayslips,
  downloadPayslipPdf,
  getCompanyBranding,
  updateCompanyBranding,
  updatePayrollCalculation,
} from '../controllers/payrollController.js';

const router = Router();

router.use(authenticateUser);

// Company branding (payslip headers & corporate details)
router.get('/company-branding', getCompanyBranding);
router.put('/company-branding', authorizeRoles('ADMIN'), updateCompanyBranding);

// Employee routes
router.get('/my-payslips', getMyPayslips);
router.get('/payslips/:id/download', downloadPayslipPdf);

// Admin / HR routes
router.post('/calculate', authorizeRoles('ADMIN', 'HR'), calculatePayroll);
router.get('/periods', authorizeRoles('ADMIN', 'HR'), getPayrollPeriods);
router.get('/periods/:id', authorizeRoles('ADMIN', 'HR'), getPayrollPeriodDetails);
router.post('/periods/:id/approve', authorizeRoles('ADMIN'), approvePayrollPeriod);
router.post('/calculations/:calculationId/payment', authorizePayrollPayment, recordPayment);
router.patch('/calculations/:calculationId', authorizeRoles('ADMIN', 'HR'), updatePayrollCalculation);

export default router;
