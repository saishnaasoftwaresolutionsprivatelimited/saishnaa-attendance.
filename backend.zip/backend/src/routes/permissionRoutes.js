import { Router } from 'express';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import {
  getPermissionStatus,
  applyPermission,
  getMyPermissions,
  getAdminPermissions,
  decidePermission,
} from '../controllers/permissionController.js';

const router = Router();

router.use(authenticateUser);

router.get('/status', getPermissionStatus);
router.post('/apply', applyPermission);
router.get('/me', getMyPermissions);

router.get('/admin', authorizeRoles('ADMIN', 'HR'), getAdminPermissions);
router.post('/admin/:id/decision', authorizeRoles('ADMIN', 'HR'), decidePermission);

export default router;
