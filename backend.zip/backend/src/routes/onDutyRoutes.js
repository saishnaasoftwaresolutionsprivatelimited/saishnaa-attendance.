import { Router } from 'express';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import {
  applyOnDuty,
  getMyOnDuty,
  getAdminOnDuty,
  decideOnDuty,
} from '../controllers/onDutyController.js';

const router = Router();

router.use(authenticateUser);

router.post('/apply', applyOnDuty);
router.get('/me', getMyOnDuty);

router.get('/admin', authorizeRoles('ADMIN', 'HR'), getAdminOnDuty);
router.post('/admin/:id/decision', authorizeRoles('ADMIN', 'HR'), decideOnDuty);

export default router;
