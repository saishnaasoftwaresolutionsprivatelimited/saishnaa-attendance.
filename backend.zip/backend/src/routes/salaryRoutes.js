import { Router } from 'express';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { getSalaryConfig, updateSalaryConfig, getMySalaryBreakdown } from '../controllers/salaryController.js';

const router = Router();

router.use(authenticateUser);

router.get('/my-salary', getMySalaryBreakdown);
router.get('/config/:employeeId', getSalaryConfig);
router.put('/config/:employeeId', authorizeRoles('ADMIN'), updateSalaryConfig);
router.post('/config/:employeeId', authorizeRoles('ADMIN'), updateSalaryConfig);

export default router;
