import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import * as authController from '../controllers/authController.js';
import { authenticateUser, optionallyAuthenticateUser } from '../middleware/authMiddleware.js';
import { validateRequest } from '../middleware/validationMiddleware.js';
import {
  loginSchema,
  activateAccountSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  changePasswordSchema,
} from '../validators/authValidator.js';

const router = Router();

// Password reset rate limiting to prevent spamming reset emails
const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many password reset requests. Please try again after 15 minutes.',
  },
});

router.post('/login', validateRequest(loginSchema), authController.login);
router.post('/logout', optionallyAuthenticateUser, authController.logout);
router.get('/me', authenticateUser, authController.getMe);
router.post('/activate', validateRequest(activateAccountSchema), authController.activateAccount);
router.post('/forgot-password', forgotPasswordLimiter, validateRequest(forgotPasswordSchema), authController.forgotPassword);
router.post('/reset-password', validateRequest(resetPasswordSchema), authController.resetPassword);
router.post('/change-password', authenticateUser, validateRequest(changePasswordSchema), authController.changePassword);
router.post('/first-login-change-password', authenticateUser, authController.firstLoginChangePassword);

export default router;
