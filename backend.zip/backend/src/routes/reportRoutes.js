import { Router } from 'express';
import * as reportController from '../controllers/reportController.js';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';

const router = Router();

// Reports endpoints (Admin and HR)
router.get('/daily', authenticateUser, authorizeRoles('ADMIN', 'HR'), reportController.getDailyReport);
router.get('/monthly', authenticateUser, authorizeRoles('ADMIN', 'HR'), reportController.getMonthlyPayrollReport);
router.get('/late-arrival', authenticateUser, authorizeRoles('ADMIN', 'HR'), reportController.getLateArrivalReport);
router.get('/overtime', authenticateUser, authorizeRoles('ADMIN', 'HR'), reportController.getOvertimeReport);

export default router;
