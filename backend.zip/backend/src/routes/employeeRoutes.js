import { Router } from 'express';
import * as employeeController from '../controllers/employeeController.js';
import {
  authenticateUser,
  authorizeRoles,
} from '../middleware/authMiddleware.js';
import { validateRequest } from '../middleware/validationMiddleware.js';

import {
  createEmployeeSchema,
  updateEmployeeSchema,
  assignShiftSchema,
  toggleStatusSchema,
} from '../validators/employeeValidator.js';

const router = Router();

router.patch(
  '/me/profile-photo',
  authenticateUser,
  authorizeRoles('EMPLOYEE', 'HR'),
  employeeController.updateMyProfilePhoto
);

/* ============================================================
   METADATA
============================================================ */

router.get(
  '/metadata',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  employeeController.getMetadata
);

/* ============================================================
   DEPARTMENT MANAGEMENT
   ADMIN ONLY
============================================================ */

router.post(
  '/metadata/departments',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.createDepartment
);

router.patch(
  '/metadata/departments/:departmentId',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.updateDepartment
);

router.delete(
  '/metadata/departments/:departmentId',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.deleteDepartment
);

/* ============================================================
   DESIGNATION MANAGEMENT
   ADMIN ONLY
============================================================ */

router.post(
  '/metadata/designations',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.createDesignation
);

router.patch(
  '/metadata/designations/:designationId',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.updateDesignation
);

router.delete(
  '/metadata/designations/:designationId',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.deleteDesignation
);

/* ============================================================
   EMPLOYEE CRUD
============================================================ */

router.post(
  '/',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  validateRequest(createEmployeeSchema),
  employeeController.createEmployee
);

router.get(
  '/',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  employeeController.getAllEmployees
);

/* ============================================================
   EMPLOYEE STATUS
============================================================ */

router.patch(
  '/:id/status',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  validateRequest(toggleStatusSchema),
  employeeController.toggleEmployeeStatus
);

/* ============================================================
   OFFICE TIMING / LEGACY SHIFT
   Compatibility route only.
   No shift-based UI should be exposed.
============================================================ */

router.post(
  '/:id/assign-shift',
  authenticateUser,
  authorizeRoles('ADMIN'),
  validateRequest(assignShiftSchema),
  employeeController.assignShift
);

/* ============================================================
   RESET ACCOUNT ACCESS
============================================================ */

router.post(
  '/:id/reset-access',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  employeeController.resetAccountAccess
);

/* ============================================================
   ATTENDANCE / BENEFIT ADJUSTMENT
============================================================ */

router.patch(
  '/:id/attendance-benefits',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.updateAttendanceBenefits
);

/* ============================================================
   GET SINGLE EMPLOYEE
   Keep dynamic /:id routes AFTER metadata routes.
============================================================ */

router.get(
  '/:id',
  authenticateUser,
  employeeController.getEmployeeById
);

/* ============================================================
   UPDATE EMPLOYEE
============================================================ */

router.patch(
  '/:id',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  validateRequest(updateEmployeeSchema),
  employeeController.updateEmployee
);

/* ============================================================
   DELETE EMPLOYEE
   ADMIN ONLY
============================================================ */

router.delete(
  '/:id',
  authenticateUser,
  authorizeRoles('ADMIN'),
  employeeController.deleteEmployee
);

export default router;