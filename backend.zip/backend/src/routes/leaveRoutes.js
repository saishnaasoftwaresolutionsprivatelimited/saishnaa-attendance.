import { Router } from 'express';
import * as leaveController from '../controllers/leaveController.js';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { validateRequest } from '../middleware/validationMiddleware.js';
import { applyLeaveSchema, decideLeaveSchema } from '../validators/leaveValidator.js';

const router = Router();

// Public / Authenticated Leave Types
router.get('/types', authenticateUser, leaveController.getLeaveTypes);

// Employee Leave Endpoints
router.post('/', authenticateUser, validateRequest(applyLeaveSchema), leaveController.applyLeave);
router.get('/me', authenticateUser, leaveController.getMyLeaves);
router.patch('/:id/cancel', authenticateUser, leaveController.cancelLeave);

// Admin & HR Leave Endpoints
router.get('/admin', authenticateUser, authorizeRoles('ADMIN', 'HR'), leaveController.getAllLeaves);
router.get('/admin/balances', authenticateUser, authorizeRoles('ADMIN', 'HR'), leaveController.getAdminLeaveBalances);
router.put('/admin/balances/:employeeId', authenticateUser, authorizeRoles('ADMIN'), leaveController.updateEmployeeLeaveBalance);
router.patch(
  '/admin/:id/decision',
  authenticateUser,
  authorizeRoles('ADMIN', 'HR'),
  validateRequest(decideLeaveSchema),
  leaveController.decideLeave
);

export default router;
