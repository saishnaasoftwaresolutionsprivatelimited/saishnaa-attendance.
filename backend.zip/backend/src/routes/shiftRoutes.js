import { Router } from 'express';
import * as shiftController from '../controllers/shiftController.js';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { validateRequest } from '../middleware/validationMiddleware.js';
import { createShiftSchema, updateShiftSchema } from '../validators/shiftValidator.js';

const router = Router();

// Shifts viewing (all authenticated users)
router.get('/', authenticateUser, shiftController.getAllShifts);

// Shift management (Admin & HR)
router.post(
  '/',
  authenticateUser,
  authorizeRoles('ADMIN'),
  validateRequest(createShiftSchema),
  shiftController.createShift
);

router.patch(
  '/:id',
  authenticateUser,
  authorizeRoles('ADMIN'),
  validateRequest(updateShiftSchema),
  shiftController.updateShift
);

router.delete('/:id', authenticateUser, authorizeRoles('ADMIN'), shiftController.deleteShift);

export default router;
