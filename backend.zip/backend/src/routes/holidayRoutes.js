import { Router } from 'express';
import { authenticateUser, authorizeRoles } from '../middleware/authMiddleware.js';
import { getHolidays, createHoliday, deleteHoliday } from '../controllers/holidayController.js';

const router = Router();

router.use(authenticateUser);

router.get('/', getHolidays);
router.post('/', authorizeRoles('ADMIN'), createHoliday);
router.delete('/:id', authorizeRoles('ADMIN'), deleteHoliday);

export default router;
