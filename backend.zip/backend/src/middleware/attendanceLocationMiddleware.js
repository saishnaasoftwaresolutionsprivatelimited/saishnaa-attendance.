import { sendError } from '../utils/responseFormatter.js';
import { validateAttendanceLocation } from '../services/attendanceLocationService.js';

export function enforceAttendanceLocation(req, res, next) {
  let result;
  try {
    result = validateAttendanceLocation(req.body?.latitude, req.body?.longitude, req.body?.accuracy);
  } catch {
    return sendError(res, 'Office location settings are unavailable. Please retry or contact Admin.', 503);
  }
  if (!result.allowed) {
    return sendError(res, result.message, result.statusCode);
  }

  req.attendanceLocation = result;
  return next();
}
