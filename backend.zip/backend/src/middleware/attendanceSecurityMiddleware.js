import { getAttendanceSecurityStatus } from '../services/attendanceSecurityService.js';
import prisma from '../config/db.js';
import { sendError } from '../utils/responseFormatter.js';

export async function enforceAttendanceSecurity(req, res, next) {
  try {
    const status = await getAttendanceSecurityStatus(req, { validateGps: true });
    if (!status.allowed) return sendError(res, status.message, 403);
    // Recheck activity while touching the credential. Revocation is consulted on every punch.
    if (status.deviceId) {
      const used = await prisma.registeredAttendanceDevice.updateMany({
        where: { id: status.deviceId, isActive: true }, data: { lastUsedAt: new Date() },
      });
      if (status.checks.device.required && used.count !== 1) return sendError(res, 'This office device has been disabled.', 403);
    }
    req.attendanceSecurity = status;
    return next();
  } catch {
    return sendError(res, 'Attendance security could not be verified. Please retry or contact Admin.', 503);
  }
}
