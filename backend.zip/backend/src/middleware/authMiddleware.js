import prisma from '../config/db.js';
import { verifyToken } from '../utils/jwtHelper.js';
import { sendError } from '../utils/responseFormatter.js';

export const COOKIE_NAME = 'saishnaa_token';

/**
 * Middleware to authenticate requests via HTTP-Only cookie or Bearer token
 */
export async function authenticateUser(req, res, next) {
  try {
    let token = req.cookies?.[COOKIE_NAME];

    if (!token && req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return sendError(res, 'Authentication required. Please sign in.', 401);
    }

    const decoded = verifyToken(token);
    if (!decoded || !decoded.userId) {
      return sendError(res, 'Invalid or expired session. Please sign in again.', 401);
    }

    // Fetch user with employee profile, department, designation, and active shift
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: {
        employee: {
          include: {
            department: true,
            designation: true,
            branch: true,
            shiftAssignments: {
              where: {
                effectiveTo: null,
              },
              include: {
                shift: true,
              },
              take: 1,
            },
          },
        },
      },
    });

    if (!user) {
      return sendError(res, 'User account no longer exists.', 401);
    }

    if (user.accountStatus !== 'ACTIVE') {
      return sendError(res, `Account is ${user.accountStatus.toLowerCase()}. Contact your administrator.`, 403);
    }

    // Check if employee is soft deleted
    if (user.employee && user.employee.isDeleted) {
      return sendError(res, 'Employee account has been deactivated.', 403);
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,
      accountStatus: user.accountStatus,
      employeeId: user.employeeId,
      employee: user.employee || null,
    };

    req.employee = user.employee || null;

    next();
  } catch (error) {
    console.error('Authentication middleware error:', error);
    return sendError(res, 'Authentication failed.', 500);
  }
}

/**
 * Attach the current user when a valid session is present, but never block the
 * request. Used by logout so the cookie can always be cleared while valid
 * sessions still produce an attributable audit entry.
 */
export async function optionallyAuthenticateUser(req, res, next) {
  try {
    let token = req.cookies?.[COOKIE_NAME];
    if (!token && req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }
    if (!token) return next();

    const decoded = verifyToken(token);
    if (!decoded?.userId) return next();

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { employee: true },
    });
    if (user) {
      req.user = {
        id: user.id,
        email: user.email,
        role: user.role,
      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,
        accountStatus: user.accountStatus,
        employeeId: user.employeeId,
        employee: user.employee || null,
      };
    }
    return next();
  } catch {
    return next();
  }
}

/**
 * Middleware to restrict access based on user roles
 */
export function authorizeRoles(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return sendError(res, 'Authentication required.', 401);
    }

    if (!allowedRoles.includes(req.user.role)) {
      return sendError(res, 'Access denied. You do not have permission to perform this action.', 403);
    }

    next();
  };
}

export function authorizePayrollPayment(req, res, next) {
  if (req.user?.role === 'ADMIN' || req.user?.canAuthorizePayrollPayment === true) return next();
  return sendError(res, 'Payment authorization requires Admin or an explicitly configured Paying Authority.', 403);
}
