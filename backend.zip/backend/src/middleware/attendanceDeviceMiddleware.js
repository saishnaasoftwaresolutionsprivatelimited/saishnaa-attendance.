import { sendError } from '../utils/responseFormatter.js';

// Attendance punches are allowed only from desktop/laptop browsers.
// Other application features remain available from any device and location.
export function enforceDesktopAttendance(req, res, next) {
  const userAgent = String(req.get('user-agent') || '').toLowerCase();
  const mobileOrTablet = /android|iphone|ipad|ipod|mobile|tablet|opera mini|iemobile/.test(userAgent);

  if (mobileOrTablet) {
    return sendError(res, 'Check-In and Check-Out are available only from an office desktop or laptop.', 403);
  }

  return next();
}
