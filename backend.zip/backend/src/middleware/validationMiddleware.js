import { sendError } from '../utils/responseFormatter.js';

/**
 * Higher-order middleware to validate incoming request data using Zod schema
 */
export function validateRequest(schema, source = 'body') {
  return async (req, res, next) => {
    try {
      const dataToValidate = req[source];
      const parsed = await schema.parseAsync(dataToValidate);
      req[source] = parsed;
      next();
    } catch (error) {
      if (error.errors) {
        const formattedErrors = error.errors.map((err) => ({
          field: err.path.join('.'),
          message: err.message,
        }));
        return sendError(res, 'Validation failed. Please check your input.', 422, formattedErrors);
      }
      return sendError(res, 'Invalid request data.', 400);
    }
  };
}
