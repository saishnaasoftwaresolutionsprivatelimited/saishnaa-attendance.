import argon2 from 'argon2';

/**
 * Hash a plain text password using Argon2id
 */
export async function hashPassword(plainPassword) {
  return argon2.hash(plainPassword, {
    type: argon2.argon2id,
    memoryCost: 2 ** 16, // 64 MB
    timeCost: 3,
    parallelism: 4,
  });
}

/**
 * Verify a plain text password against an Argon2id hash
 */
export async function verifyPassword(hash, plainPassword) {
  try {
    return await argon2.verify(hash, plainPassword);
  } catch (error) {
    console.error('Password verification error:', error);
    return false;
  }
}
