import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore.js';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter.js';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(isSameOrBefore);
dayjs.extend(isSameOrAfter);

export const DEFAULT_TZ = process.env.DEFAULT_TIMEZONE || 'Asia/Kolkata';

/**
 * Get current time in default office timezone
 */
export function getNow(tz = DEFAULT_TZ) {
  return dayjs().tz(tz);
}

/**
 * Get current date string (YYYY-MM-DD) in default office timezone
 */
export function getTodayDateString(tz = DEFAULT_TZ) {
  return dayjs().tz(tz).format('YYYY-MM-DD');
}

/**
 * Convert any Date or ISO string to office timezone Dayjs object
 */
export function toOfficeTime(date, tz = DEFAULT_TZ) {
  if (!date) return null;
  return dayjs(date).tz(tz);
}

/**
 * Format a Date to readable time e.g. "09:15 AM"
 */
export function formatTime(date, tz = DEFAULT_TZ) {
  if (!date) return '--:--';
  return dayjs(date).tz(tz).format('hh:mm A');
}

/**
 * Format a Date to readable date e.g. "24 Sep 2026"
 */
export function formatDate(date, tz = DEFAULT_TZ) {
  if (!date) return '--';
  return dayjs(date).tz(tz).format('DD MMM YYYY');
}

/**
 * Combine a date string (YYYY-MM-DD) and a time string (HH:mm) into a Date object in the office timezone
 */
export function parseDateTime(dateStr, timeStr, tz = DEFAULT_TZ) {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return dayjs.tz(`${dateStr} ${timeStr}:00`, 'YYYY-MM-DD HH:mm:ss', tz).toDate();
}

/**
 * Calculate difference in minutes between two dates
 */
export function diffInMinutes(start, end) {
  if (!start || !end) return 0;
  const s = dayjs(start);
  const e = dayjs(end);
  return Math.max(0, e.diff(s, 'minute'));
}

/**
 * Format minutes into "Xh Ym" string
 */
export function formatMinutesToHours(minutes) {
  if (!minutes || minutes <= 0) return '0h 0m';
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hrs}h ${mins}m`;
}
