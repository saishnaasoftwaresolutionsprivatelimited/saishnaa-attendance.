import { canManageEmployee, canReadEmployee } from '../services/accessPolicy.js';
import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';

/**
 * Apply for On-Duty (OD)
 */
export async function applyOnDuty(req, res) {
  try {
    const employee = req.user.employee;
    if (!employee) {
      return sendError(res, 'Only registered employees can submit On-Duty applications.', 403);
    }

    const {
      odDate,
      startTime = '09:00',
      endTime = '18:00',
      isFullDay = true,
      location,
      purpose = 'CLIENT_MEETING',
      description,
      documentUrl,
    } = req.body;

    if (!odDate || !location || !description) {
      return sendError(res, 'OD Date, Location, and Description/Purpose are required.', 400);
    }

    const odRequest = await prisma.onDutyRequest.create({
      data: {
        employeeId: employee.id,
        odDate,
        startTime,
        endTime,
        isFullDay: Boolean(isFullDay),
        location,
        purpose,
        description,
        documentUrl,
        status: 'PENDING',
      },
    });

    return sendSuccess(res, odRequest, 'On-Duty (OD) application submitted successfully.', 201);
  } catch (error) {
    console.error('Apply OD error:', error);
    return sendError(res, 'Failed to submit On-Duty application.', 500);
  }
}

/**
 * Get My OD Applications
 */
export async function getMyOnDuty(req, res) {
  try {
    const employee = req.user.employee;
    if (!employee) {
      return sendError(res, 'Employee record not found.', 404);
    }

    const requests = await prisma.onDutyRequest.findMany({
      where: { employeeId: employee.id },
      orderBy: { odDate: 'desc' },
      include: {
        reviewer: { select: { email: true, role: true } },
      },
    });

    return sendSuccess(res, requests, 'On-Duty applications retrieved.');
  } catch (error) {
    console.error('Get my OD error:', error);
    return sendError(res, 'Failed to fetch On-Duty applications.', 500);
  }
}

/**
 * Admin / HR: List all OD applications
 */
export async function getAdminOnDuty(req, res) {
  try {
    const { status, date } = req.query;
    const where = req.user.role === 'HR' ? { employee: { user: { role: 'EMPLOYEE' } } } : {};
    if (status) where.status = status;
    if (date) where.odDate = date;

    const requests = await prisma.onDutyRequest.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        employee: {
          select: {
            id: true,
            employeeCode: true,
            fullName: true,
            department: { select: { name: true } },
            designation: { select: { title: true } },
          },
        },
        reviewer: { select: { email: true, role: true } },
      },
    });

    return sendSuccess(res, requests, 'All On-Duty requests retrieved.');
  } catch (error) {
    console.error('Get admin OD error:', error);
    return sendError(res, 'Failed to fetch On-Duty requests.', 500);
  }
}

/**
 * Admin / HR: Approve or Reject OD application
 */
export async function decideOnDuty(req, res) {
  try {
    const { id } = req.params;
    const { status, reviewerComments } = req.body;

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      return sendError(res, 'Status must be APPROVED or REJECTED.', 400);
    }

    const target = await prisma.onDutyRequest.findUnique({ where: { id }, include: { employee: { include: { user: { select: { role: true } } } } } });
    if (!target) return sendError(res, 'Request not found.', 404);
    if (!canManageEmployee(req.user, target.employee)) return sendError(res, 'HR can review normal employee requests only. Personal requests require Admin.', 403);
    if (target.status !== 'PENDING') return sendError(res, 'This request has already been reviewed.', 409);
    const updated = await prisma.onDutyRequest.update({
      where: { id },
      data: {
        status,
        reviewerComments,
        reviewerId: req.user.id,
        reviewedAt: new Date(),
      },
    });

    return sendSuccess(res, updated, `On-Duty request has been ${status.toLowerCase()}.`);
  } catch (error) {
    console.error('Decide OD error:', error);
    return sendError(res, 'Failed to process On-Duty decision.', 500);
  }
}
