import { canManageEmployee, canReadEmployee } from '../services/accessPolicy.js';
import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import {
  getMonthlyLateAndPermissionStatus,
  validatePermissionEligibility,
} from '../services/latePermissionEngine.js';
import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

/**
 * Get permission eligibility and late allowance status for current month
 */
export async function getPermissionStatus(req, res) {
  try {
    const employeeId = req.query.employeeId || req.user.employee?.id;
    if (!employeeId) {
      return sendError(res, 'Employee ID required.', 400);
    }

    const target = await prisma.employee.findUnique({ where: { id: employeeId }, include: { user: { select: { role: true } } } });
    if (!target || !canReadEmployee(req.user, target)) return sendError(res, 'Access denied.', 403);
    const yearMonth = req.query.monthYear || dayjs().tz(DEFAULT_TZ).format('YYYY-MM');
    const status = await getMonthlyLateAndPermissionStatus(employeeId, yearMonth);

    return sendSuccess(res, status, 'Permission eligibility and late allowance status retrieved.');
  } catch (error) {
    console.error('Get permission status error:', error);
    return sendError(res, 'Failed to fetch permission status.', 500);
  }
}

/**
 * Apply for 1-hour permission
 * Strictly enforces monthly late and permission allowances.
 */
export async function applyPermission(req, res) {
  try {
    const employee = req.user.employee;
    if (!employee) {
      return sendError(res, 'Only registered employees can request permissions.', 403);
    }

    const { permissionDate, startTime, endTime, durationMinutes = 60, permissionType = 'PERSONAL_WORK', reason } = req.body;

    if (!permissionDate || !startTime || !endTime || !reason) {
      return sendError(res, 'Permission date, start time, end time, and reason are required.', 400);
    }

    // Enforce max 60 minutes duration
    const dur = Number(durationMinutes);
    if (dur > 60) {
      return sendError(res, 'Permission duration cannot exceed 1 hour (60 minutes).', 400);
    }

    // Enforce both the monthly late threshold and the monthly permission quota.
    const eligibility = await validatePermissionEligibility(employee.id, permissionDate);
    if (!eligibility.allowed) {
      return sendError(res, eligibility.message, 403);
    }

    const permission = await prisma.permissionRequest.create({
      data: {
        employeeId: employee.id,
        permissionDate,
        startTime,
        endTime,
        durationMinutes: dur,
        permissionType,
        reason,
        status: 'PENDING',
      },
    });

    return sendSuccess(res, permission, '1-Hour Permission request submitted successfully.', 201);
  } catch (error) {
    console.error('Apply permission error:', error);
    return sendError(res, 'Failed to submit permission request.', 500);
  }
}

/**
 * Get My Permission Requests
 */
export async function getMyPermissions(req, res) {
  try {
    const employee = req.user.employee;
    if (!employee) {
      return sendError(res, 'Employee record not found.', 404);
    }

    const permissions = await prisma.permissionRequest.findMany({
      where: { employeeId: employee.id },
      orderBy: { permissionDate: 'desc' },
      include: {
        reviewer: { select: { email: true, role: true } },
      },
    });

    return sendSuccess(res, permissions, 'Permission requests retrieved.');
  } catch (error) {
    console.error('Get my permissions error:', error);
    return sendError(res, 'Failed to fetch permission requests.', 500);
  }
}

/**
 * Admin / HR: List all permission requests
 */
export async function getAdminPermissions(req, res) {
  try {
    const { status, date } = req.query;
    const where = req.user.role === 'HR' ? { employee: { user: { role: 'EMPLOYEE' } } } : {};
    if (status) where.status = status;
    if (date) where.permissionDate = date;

    const permissions = await prisma.permissionRequest.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        employee: {
          select: {
            id: true,
            employeeCode: true,
            fullName: true,
            department: { select: { name: true } },
            designation: { select: { title: true } },
          },
        },
        reviewer: { select: { email: true, role: true } },
      },
    });

    return sendSuccess(res, permissions, 'All permission requests retrieved.');
  } catch (error) {
    console.error('Get admin permissions error:', error);
    return sendError(res, 'Failed to fetch permission requests.', 500);
  }
}

/**
 * Admin / HR: Review permission request (Approve / Reject)
 */
export async function decidePermission(req, res) {
  try {
    const { id } = req.params;
    const { status, reviewerComments } = req.body;

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      return sendError(res, 'Invalid decision status. Must be APPROVED or REJECTED.', 400);
    }

    const target = await prisma.permissionRequest.findUnique({ where: { id }, include: { employee: { include: { user: { select: { role: true } } } } } });
    if (!target) return sendError(res, 'Request not found.', 404);
    if (!canManageEmployee(req.user, target.employee)) return sendError(res, 'HR can review normal employee requests only. Personal requests require Admin.', 403);
    if (target.status !== 'PENDING') return sendError(res, 'This request has already been reviewed.', 409);
    const updated = await prisma.permissionRequest.update({
      where: { id },
      data: {
        status,
        reviewerComments,
        reviewerId: req.user.id,
        reviewedAt: new Date(),
      },
    });

    return sendSuccess(res, updated, `Permission request has been ${status.toLowerCase()}.`);
  } catch (error) {
    console.error('Decide permission error:', error);
    return sendError(res, 'Failed to process permission decision.', 500);
  }
}
