import { canManageEmployee } from '../services/accessPolicy.js';
import prisma from '../config/db.js';
import { getNow, getTodayDateString, DEFAULT_TZ, diffInMinutes, parseDateTime } from '../utils/timeHelper.js';
import { evaluateCheckIn, evaluateCheckOut } from '../services/attendanceCalculationEngine.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { logAudit } from '../services/auditService.js';
import { syncStandardOfficeTiming } from '../services/companySettingsService.js';
import dayjs from 'dayjs';

/**
 * Employee Check-In
 */
export async function checkIn(req, res) {
  try {
    const employee = req.employee;
    if (!employee) {
      return sendError(res, 'No employee record associated with this user account.', 400);
    }

    if (employee.employeeStatus !== 'ACTIVE' || employee.isDeleted) {
      return sendError(res, 'Employee account is inactive.', 403);
    }

    const serverNow = getNow().toDate();
    const workDate = getTodayDateString();

    // The schema retains an internal shift reference, but attendance is not schedule-based.
    const shift = await syncStandardOfficeTiming();

    // Check if attendance record already exists for this employee on today's workDate
    const existingRecord = await prisma.attendanceRecord.findUnique({
      where: {
        employeeId_workDate: {
          employeeId: employee.id,
          workDate,
        },
      },
      include: { events: true, breakRecords: true, shift: true },
    });

    if (existingRecord) {
      return sendError(
        res,
        'Attendance has already been marked for today. Duplicate check-in is not permitted.',
        400,
        { existingRecord }
      );
    }

    const checkInEval = evaluateCheckIn();

    // Create attendance record & initial event inside a transaction
    const record = await prisma.$transaction(async (tx) => {
      const att = await tx.attendanceRecord.create({
        data: {
          employeeId: employee.id,
          workDate,
          shiftId: shift.id,
          checkInAt: serverNow,
          workSessionStatus: 'WORKING',
          attendanceClassification: checkInEval.classification,
          lateMinutes: checkInEval.lateMinutes,
          notes: 'Attendance check-in recorded',
        },
        include: {
          shift: true,
          events: true,
          breakRecords: true,
        },
      });

      await tx.attendanceEvent.create({
        data: {
          attendanceId: att.id,
          eventType: 'CHECK_IN',
          eventTimestamp: serverNow,
          notes: `Check-in recorded at ${dayjs(serverNow).tz(DEFAULT_TZ).format('hh:mm A')}`,
        },
      });

      return att;
    });

    await logAudit({
      userId: req.user.id,
      action: 'CHECK_IN',
      entityType: 'ATTENDANCE',
      entityId: record.id,
      details: { workDate },
      req,
    });

    return sendSuccess(
      res,
      record,
      'Check-in recorded successfully.',
      201
    );
  } catch (error) {
    console.error('Check-in error:', error);
    return sendError(res, 'Failed to record check-in.', 500);
  }
}

/**
 * Employee Start Break
 */
export async function startBreak(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const workDate = getTodayDateString();
    const serverNow = getNow().toDate();

    const record = await prisma.attendanceRecord.findUnique({
      where: { employeeId_workDate: { employeeId: employee.id, workDate } },
      include: { breakRecords: true },
    });

    if (!record) {
      return sendError(res, 'You must check in before taking a break.', 400);
    }

    if (record.workSessionStatus === 'CHECKED_OUT') {
      return sendError(res, 'Attendance has already been completed for today.', 400);
    }

    if (record.workSessionStatus === 'ON_BREAK') {
      return sendError(res, 'You are already on an active break.', 400);
    }

    // Check if an open break already exists
    const openBreak = record.breakRecords.find((b) => b.breakEndAt === null);
    if (openBreak) {
      return sendError(res, 'An active break is already in progress.', 400);
    }

    const updated = await prisma.$transaction(async (tx) => {
      const newBreak = await tx.breakRecord.create({
        data: {
          attendanceId: record.id,
          breakStartAt: serverNow,
        },
      });

      const updatedRecord = await tx.attendanceRecord.update({
        where: { id: record.id },
        data: { workSessionStatus: 'ON_BREAK' },
        include: { breakRecords: true, events: true, shift: true },
      });

      await tx.attendanceEvent.create({
        data: {
          attendanceId: record.id,
          eventType: 'BREAK_START',
          eventTimestamp: serverNow,
          notes: `Break started at ${dayjs(serverNow).tz(DEFAULT_TZ).format('hh:mm A')}`,
        },
      });

      return updatedRecord;
    });

    return sendSuccess(res, updated, 'Break started. Enjoy your break!');
  } catch (error) {
    console.error('Start break error:', error);
    return sendError(res, 'Failed to start break.', 500);
  }
}

/**
 * Employee End Break
 */
export async function endBreak(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const workDate = getTodayDateString();
    const serverNow = getNow().toDate();

    const record = await prisma.attendanceRecord.findUnique({
      where: { employeeId_workDate: { employeeId: employee.id, workDate } },
      include: { breakRecords: true },
    });

    if (!record) {
      return sendError(res, 'No active attendance record found for today.', 400);
    }

    const openBreak = record.breakRecords.find((b) => b.breakEndAt === null);
    if (!openBreak) {
      return sendError(res, 'No active break was found to end.', 400);
    }

    const breakDuration = diffInMinutes(openBreak.breakStartAt, serverNow);

    const updated = await prisma.$transaction(async (tx) => {
      // 1. Close current break record
      await tx.breakRecord.update({
        where: { id: openBreak.id },
        data: {
          breakEndAt: serverNow,
          durationMinutes: breakDuration,
        },
      });

      // 2. Compute total break minutes across all breaks for this attendance record
      const allBreaks = await tx.breakRecord.findMany({
        where: { attendanceId: record.id, breakEndAt: { not: null } },
      });
      const totalBreakMinutes = allBreaks.reduce((sum, b) => sum + (b.durationMinutes || 0), 0);

      // 3. Update attendance record status back to WORKING
      const updatedRecord = await tx.attendanceRecord.update({
        where: { id: record.id },
        data: {
          workSessionStatus: 'WORKING',
          totalBreakMinutes,
        },
        include: { breakRecords: true, events: true, shift: true },
      });

      await tx.attendanceEvent.create({
        data: {
          attendanceId: record.id,
          eventType: 'BREAK_END',
          eventTimestamp: serverNow,
          notes: `Break ended (${breakDuration} mins) at ${dayjs(serverNow).tz(DEFAULT_TZ).format('hh:mm A')}`,
        },
      });

      return updatedRecord;
    });

    return sendSuccess(res, updated, `Break ended (${breakDuration} mins). Welcome back to work!`);
  } catch (error) {
    console.error('End break error:', error);
    return sendError(res, 'Failed to end break.', 500);
  }
}

/**
 * Employee Check-Out
 */
export async function checkOut(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const workDate = getTodayDateString();
    const serverNow = getNow().toDate();

    const record = await prisma.attendanceRecord.findUnique({
      where: { employeeId_workDate: { employeeId: employee.id, workDate } },
      include: { breakRecords: true, shift: true },
    });

    if (!record) {
      return sendError(res, 'You have not checked in for today yet.', 400);
    }

    if (record.workSessionStatus === 'CHECKED_OUT' && record.checkOutAt) {
      return sendError(res, 'You have already checked out for today.', 400);
    }

    // Prevent checkout during active break
    if (record.workSessionStatus === 'ON_BREAK') {
      return sendError(res, 'You are currently on an active break. Please click END BREAK before checking out.', 400);
    }

    const openBreak = record.breakRecords.find((b) => b.breakEndAt === null);
    if (openBreak) {
      return sendError(res, 'Please end your active break before checking out.', 400);
    }

    const checkOutEval = evaluateCheckOut({
      attendanceRecord: record,
      checkOutTime: serverNow,
    });

    const updated = await prisma.$transaction(async (tx) => {
      const att = await tx.attendanceRecord.update({
        where: { id: record.id },
        data: {
          checkOutAt: serverNow,
          workSessionStatus: 'CHECKED_OUT',
          netWorkMinutes: checkOutEval.netWorkMinutes,
          earlyDepartureMinutes: checkOutEval.earlyDepartureMinutes,
          overtimeMinutes: checkOutEval.overtimeMinutes,
          attendanceClassification: checkOutEval.attendanceClassification,
        },
        include: {
          shift: true,
          events: { orderBy: { eventTimestamp: 'asc' } },
          breakRecords: true,
        },
      });

      await tx.attendanceEvent.create({
        data: {
          attendanceId: record.id,
          eventType: 'CHECK_OUT',
          eventTimestamp: serverNow,
          notes: `Check-out recorded at ${dayjs(serverNow).tz(DEFAULT_TZ).format('hh:mm A')}. Net Work: ${Math.floor(checkOutEval.netWorkMinutes / 60)}h ${checkOutEval.netWorkMinutes % 60}m`,
        },
      });

      return att;
    });

    await logAudit({
      userId: req.user.id,
      action: 'CHECK_OUT',
      entityType: 'ATTENDANCE',
      entityId: updated.id,
      details: {
        workDate,
        netWorkMinutes: checkOutEval.netWorkMinutes,
        classification: checkOutEval.attendanceClassification,
      },
      req,
    });

    const netHoursStr = `${Math.floor(checkOutEval.netWorkMinutes / 60)}h ${checkOutEval.netWorkMinutes % 60}m`;
    return sendSuccess(
      res,
      updated,
      `Checked out successfully! Total net working time today: ${netHoursStr}. Have a great evening!`
    );
  } catch (error) {
    console.error('Check-out error:', error);
    return sendError(res, 'Failed to record check-out.', 500);
  }
}

/**
 * Get Today's Live Attendance details for the authenticated employee
 */
export async function getTodayAttendance(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const workDate = getTodayDateString();

    const [record, activeAssignment, leaveBalances, recentRecords] = await Promise.all([
      prisma.attendanceRecord.findUnique({
        where: { employeeId_workDate: { employeeId: employee.id, workDate } },
        include: {
          shift: true,
          events: { orderBy: { eventTimestamp: 'asc' } },
          breakRecords: { orderBy: { breakStartAt: 'asc' } },
        },
      }),
      prisma.employeeShiftAssignment.findFirst({
        where: { employeeId: employee.id, effectiveTo: null },
        include: { shift: true },
      }),
      prisma.leaveBalance.findMany({
        where: { employeeId: employee.id, year: new Date().getFullYear() },
        include: { leaveType: true },
      }),
      prisma.attendanceRecord.findMany({
        where: { employeeId: employee.id },
        take: 7,
        orderBy: { workDate: 'desc' },
        include: { shift: true },
      }),
    ]);

    const activeShift = activeAssignment?.shift || null;

    // Calculate live elapsed time if currently working (with exact second precision)
    let liveElapsedMinutes = 0;
    let liveElapsedSeconds = 0;
    if (record && record.checkInAt && record.workSessionStatus !== 'CHECKED_OUT') {
      const now = getNow();
      const checkIn = dayjs(record.checkInAt).tz(DEFAULT_TZ);

      // Calculate completed break seconds with sub-minute precision
      let completedBreakSeconds = 0;
      if (record.breakRecords && record.breakRecords.length > 0) {
        for (const br of record.breakRecords) {
          if (br.breakStartAt && br.breakEndAt) {
            completedBreakSeconds += Math.max(0, dayjs(br.breakEndAt).diff(dayjs(br.breakStartAt), 'second'));
          } else if (br.breakStartAt && !br.breakEndAt) {
            // Active break in progress
            completedBreakSeconds += Math.max(0, now.diff(dayjs(br.breakStartAt), 'second'));
          }
        }
      } else {
        completedBreakSeconds = (record.totalBreakMinutes || 0) * 60;
      }

      const totalElapsedSeconds = Math.max(0, now.diff(checkIn, 'second'));
      liveElapsedSeconds = Math.max(0, totalElapsedSeconds - completedBreakSeconds);
      liveElapsedMinutes = Math.floor(liveElapsedSeconds / 60);
    } else if (record && record.netWorkMinutes) {
      liveElapsedMinutes = record.netWorkMinutes;
      liveElapsedSeconds = record.netWorkMinutes * 60;
    }

    return sendSuccess(
      res,
      {
        workDate,
        currentTime: getNow().format('YYYY-MM-DD HH:mm:ss'),
        timezone: DEFAULT_TZ,
        activeShift,
        attendance: record,
        liveElapsedMinutes,
        liveElapsedSeconds,
        leaveBalances,
        recentRecords,
      },
      "Today's attendance status retrieved."
    );
  } catch (error) {
    console.error('Get today attendance error:', error);
    return sendError(res, 'Failed to retrieve attendance status.', 500);
  }
}

/**
 * Get personal attendance history for authenticated employee
 */
export async function getMyAttendance(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const { startDate, endDate, status, page = 1, limit = 31 } = req.query;

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 31;
    const skip = (pageNum - 1) * limitNum;

    const where = {
      employeeId: employee.id,
    };

    if (startDate && endDate) {
      where.workDate = { gte: startDate, lte: endDate };
    } else if (startDate) {
      where.workDate = { gte: startDate };
    } else if (endDate) {
      where.workDate = { lte: endDate };
    }

    if (status) {
      if (status === 'PRESENT') {
        where.attendanceClassification = { in: ['PRESENT', 'PUNCTUAL_PRESENT'] };
      } else if (status === 'LATE') {
        where.attendanceClassification = { in: ['LATE', 'LATE_ARRIVAL'] };
      } else {
        where.attendanceClassification = status;
      }
    }

    const [total, records] = await Promise.all([
      prisma.attendanceRecord.count({ where }),
      prisma.attendanceRecord.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: { workDate: 'desc' },
        include: {
          shift: true,
          events: { orderBy: { eventTimestamp: 'asc' } },
          breakRecords: true,
          correctionRequests: true,
        },
      }),
    ]);

    return sendSuccess(
      res,
      {
        records,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages: Math.ceil(total / limitNum),
        },
      },
      'Attendance history retrieved.'
    );
  } catch (error) {
    console.error('Get my attendance error:', error);
    return sendError(res, 'Failed to retrieve attendance history.', 500);
  }
}

/**
 * Live Admin Attendance Monitoring & Analytics Dashboard
 */
export async function getLiveAdminAttendance(req, res) {
  try {
    const {
      date = getTodayDateString(),
      departmentId,
      shiftId,
      status,
      search = '',
      page = 1,
      limit = 50,
    } = req.query;

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 50;
    const skip = (pageNum - 1) * limitNum;

    // 1. Fetch all active employees (excluding ADMIN accounts who do not punch attendance)
    const visibleUserRole = req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' };
    const employeeWhere = {
      isDeleted: false,
      user: { role: visibleUserRole },
    };
    if (departmentId) employeeWhere.departmentId = departmentId;
    if (search) {
      employeeWhere.OR = [
        { fullName: { contains: search } },
        { employeeCode: { contains: search } },
      ];
    }

    const allActiveEmployees = await prisma.employee.findMany({
      where: employeeWhere,
      include: {
        department: true,
        designation: true,
        shiftAssignments: {
          where: { effectiveTo: null },
          include: { shift: true },
          take: 1,
        },
        leaveRequests: {
          where: {
            leaveType: { code: { not: 'SL' } },
            status: 'APPROVED',
            startDate: { lte: date },
            endDate: { gte: date },
          },
          include: { leaveType: true },
        },
        attendanceRecords: {
          where: { workDate: date },
          include: {
            shift: true,
            breakRecords: true,
            correctionRequests: true,
          },
        },
      },
      orderBy: { employeeCode: 'asc' },
    });

    const lateRecordsThisMonth = await prisma.attendanceRecord.findMany({
      where: {
        employeeId: { in: allActiveEmployees.map((employee) => employee.id) },
        workDate: { startsWith: date.slice(0, 7) },
        lateMinutes: { gt: 0 },
      },
      select: { id: true, employeeId: true, workDate: true, createdAt: true },
      orderBy: [{ workDate: 'asc' }, { createdAt: 'asc' }],
    });
    const lateOccurrenceByRecordId = new Map();
    const lateCountByEmployeeId = new Map();
    for (const lateRecord of lateRecordsThisMonth) {
      const occurrence = (lateCountByEmployeeId.get(lateRecord.employeeId) || 0) + 1;
      lateCountByEmployeeId.set(lateRecord.employeeId, occurrence);
      lateOccurrenceByRecordId.set(lateRecord.id, occurrence);
    }

    // 2. Synthesize complete live table for all employees on the given date
    let liveRows = allActiveEmployees.map((emp) => {
      const activeShift = emp.shiftAssignments?.[0]?.shift || null;
      const attRecord = emp.attendanceRecords?.[0] || null;
      const onLeave = emp.leaveRequests?.[0] || null;

      let displayStatus = 'NOT_CHECKED_IN';
      if (onLeave) {
        displayStatus = 'ON_LEAVE';
      } else if (attRecord) {
        displayStatus = attRecord.workSessionStatus; // WORKING, ON_BREAK, CHECKED_OUT
      }

      return {
        id: attRecord ? attRecord.id : `virtual_${emp.id}`,
        employeeId: emp.id,
        employeeCode: emp.employeeCode,
        fullName: emp.fullName,
        department: emp.department?.name || 'Unassigned',
        departmentId: emp.departmentId,
        designation: emp.designation?.title || 'Unassigned',
        assignedShift: activeShift ? activeShift.name : 'Unassigned',
        shiftId: activeShift ? activeShift.id : null,
        workDate: date,
        checkInAt: attRecord?.checkInAt || null,
        checkOutAt: attRecord?.checkOutAt || null,
        totalBreakMinutes: attRecord?.totalBreakMinutes || 0,
        netWorkMinutes: attRecord?.netWorkMinutes || 0,
        lateMinutes: attRecord?.lateMinutes || 0,
        lateOccurrence: attRecord?.lateMinutes > 0 ? lateOccurrenceByRecordId.get(attRecord.id) : null,
        overtimeMinutes: attRecord?.overtimeMinutes || 0,
        workSessionStatus: displayStatus,
        attendanceClassification: onLeave
          ? 'ON_LEAVE'
          : attRecord
          ? attRecord.attendanceClassification
          : 'ABSENT',
        hasPendingCorrection: attRecord?.correctionRequests?.some((c) => c.status === 'PENDING') || false,
        onLeaveDetails: onLeave ? { type: onLeave.leaveType.name, reason: onLeave.reason } : null,
      };
    });

    // Apply shift filter and status filter
    if (shiftId) {
      liveRows = liveRows.filter((r) => r.shiftId === shiftId);
    }
    if (status) {
      liveRows = liveRows.filter(
        (r) => r.workSessionStatus === status || r.attendanceClassification === status
      );
    }

    // 3. Compute the 8 Key Metrics Cards for Admin Dashboard (excluding ADMIN accounts)
    const totalEmployees = await prisma.employee.count({
      where: {
        isDeleted: false,
        user: { role: visibleUserRole },
      },
    });
    const activeEmployees = await prisma.employee.count({
      where: {
        isDeleted: false,
        employeeStatus: 'ACTIVE',
        user: { role: visibleUserRole },
      },
    });

    // Count today's metrics
    const currentlyCheckedIn = liveRows.filter(
      (r) => r.workSessionStatus === 'WORKING' || r.workSessionStatus === 'ON_BREAK'
    ).length;
    const notYetCheckedIn = liveRows.filter(
      (r) => r.workSessionStatus === 'NOT_CHECKED_IN' && r.attendanceClassification !== 'ON_LEAVE'
    ).length;
    const onApprovedLeave = liveRows.filter((r) => r.workSessionStatus === 'ON_LEAVE').length;
    const lateArrivals = liveRows.filter((r) => r.lateMinutes > 0).length;
    const employeesCheckedOut = liveRows.filter((r) => r.workSessionStatus === 'CHECKED_OUT').length;

    const pendingCorrections = await prisma.attendanceCorrectionRequest.count({
      where: { status: 'PENDING' },
    });

    const summaryCards = {
      totalEmployees,
      activeEmployees,
      currentlyCheckedIn,
      notYetCheckedIn,
      onApprovedLeave,
      lateArrivals,
      employeesCheckedOut,
      pendingCorrections,
    };

    // 4. Analytics: Department-wise Distribution
    const deptDistributionMap = {};
    for (const row of liveRows) {
      const dept = row.department;
      if (!deptDistributionMap[dept]) {
        deptDistributionMap[dept] = { department: dept, total: 0, checkedIn: 0, late: 0, onLeave: 0 };
      }
      deptDistributionMap[dept].total++;
      if (row.workSessionStatus === 'WORKING' || row.workSessionStatus === 'ON_BREAK' || row.workSessionStatus === 'CHECKED_OUT') {
        deptDistributionMap[dept].checkedIn++;
      }
      if (row.lateMinutes > 0) {
        deptDistributionMap[dept].late++;
      }
      if (row.workSessionStatus === 'ON_LEAVE') {
        deptDistributionMap[dept].onLeave++;
      }
    }
    const departmentDistribution = Object.values(deptDistributionMap);

    // 5. Daily Attendance Status Pie/Donut Data
    const dailyStatusDistribution = [
      { name: 'Working', value: liveRows.filter((r) => r.workSessionStatus === 'WORKING').length, color: '#2563EB' },
      { name: 'On Break', value: liveRows.filter((r) => r.workSessionStatus === 'ON_BREAK').length, color: '#F59E0B' },
      { name: 'Checked Out', value: employeesCheckedOut, color: '#37B086' },
      { name: 'On Leave', value: onApprovedLeave, color: '#8B5CF6' },
      { name: 'Not Checked In', value: notYetCheckedIn, color: '#94A3B8' },
    ];

  // 6. Attendance Trend (Past 10 days)
const weeklyTrends = [];
const refDay = dayjs(date).tz(DEFAULT_TZ);
for (let i = 9; i >= 0; i--) {
      const day = refDay.subtract(i, 'day');
      const dStr = day.format('YYYY-MM-DD');
      const countPresent = await prisma.attendanceRecord.count({
        where: {
          workDate: dStr,
          checkInAt: { not: null },
          employee: {
            isDeleted: false,
            user: { role: visibleUserRole },
          },
        },
      });
      const countLate = await prisma.attendanceRecord.count({
        where: {
          workDate: dStr,
          lateMinutes: { gt: 0 },
          employee: {
            isDeleted: false,
            user: { role: visibleUserRole },
          },
        },
      });
      weeklyTrends.push({
        date: day.format('DD MMM'),
        fullDate: dStr,
        present: countPresent,
        late: countLate,
      });
    }

    const paginatedRows = liveRows.slice(skip, skip + limitNum);

    return sendSuccess(
      res,
      {
        date,
        summaryCards,
        records: paginatedRows,
        charts: {
          dailyStatusDistribution,
          departmentDistribution,
          weeklyTrends,
        },
        pagination: {
          total: liveRows.length,
          page: pageNum,
          limit: limitNum,
          totalPages: Math.ceil(liveRows.length / limitNum),
        },
      },
      'Live admin attendance monitoring data retrieved.'
    );
  } catch (error) {
    console.error('Get live admin attendance error:', error);
    return sendError(res, 'Failed to retrieve live attendance data.', 500);
  }
}

/**
 * Admin / HR Manual Attendance Override / Punch Edit
 * Enables Admin or HR to manually correct or create check-in/out for an employee
 * (e.g., when technical/biometric glitches prevent normal employee login)
 */
export async function adminManualAttendanceOverride(req, res) {
  try {
    const {
      employeeId,
      workDate = getTodayDateString(),
      checkInTime, // "09:30" (HH:mm) or null/empty
      checkOutTime, // "18:30" (HH:mm) or null/empty
      attendanceClassification = 'PRESENT',
      workSessionStatus = 'CHECKED_OUT',
      notes = '',
    } = req.body;

    if (!employeeId) {
      return sendError(res, 'Employee ID is required.', 400);
    }

    const employee = await prisma.employee.findUnique({
  where: { id: employeeId },
  include: { user: { select: { role: true } } },
});

if (!employee) {
  return sendError(res, 'Employee not found.', 404);
}

if (!canManageEmployee(req.user, employee)) return sendError(res, 'HR can correct normal employee attendance only. Personal corrections require Admin.', 403);

// Keep the required database relation without applying any work schedule.
const shift = await syncStandardOfficeTiming();

if (!shift) {
  return sendError(res, 'Attendance reference could not be initialized.', 400);
}

    let checkInAt = null;
    let checkOutAt = null;
    let netWorkMinutes = 0;
    let lateMinutes = 0;

    if (checkInTime && checkInTime.trim()) {
      checkInAt = parseDateTime(workDate, checkInTime.trim());
    }

    if (checkOutTime && checkOutTime.trim()) {
      checkOutAt = parseDateTime(workDate, checkOutTime.trim());
    }

    // Determine final check-in and check-out based on session status
    let finalCheckInAt = checkInAt;
    let finalCheckOutAt = checkOutAt;

    if (workSessionStatus === 'WORKING' || workSessionStatus === 'ON_BREAK') {
      // Employee is actively working today. Check-out has not happened yet!
      finalCheckOutAt = null;
      netWorkMinutes = 0;
    } else if (workSessionStatus === 'NOT_CHECKED_IN' || workSessionStatus === 'ABSENT') {
      finalCheckInAt = null;
      finalCheckOutAt = null;
      netWorkMinutes = 0;
      lateMinutes = 0;
    } else if (workSessionStatus === 'CHECKED_OUT') {
      if (finalCheckInAt && finalCheckOutAt) {
        const diffMin = dayjs(finalCheckOutAt).diff(dayjs(finalCheckInAt), 'minute');
        netWorkMinutes = Math.max(0, diffMin);
      }
    }

    const existingRecord = await prisma.attendanceRecord.findUnique({
      where: {
        employeeId_workDate: {
          employeeId,
          workDate,
        },
      },
    });

    const adminNote = notes.trim()
      ? `[Admin Override: ${notes.trim()}]`
      : `[Manual punch entered by Admin/HR on ${dayjs().tz(DEFAULT_TZ).format('DD MMM YYYY, hh:mm A')}]`;

    let record;
    if (existingRecord) {
      record = await prisma.attendanceRecord.update({
        where: { id: existingRecord.id },
        data: {
          checkInAt: finalCheckInAt !== undefined ? finalCheckInAt : existingRecord.checkInAt,
          checkOutAt: finalCheckOutAt,
          workSessionStatus,
          attendanceClassification,
          netWorkMinutes,
          lateMinutes,
          notes: existingRecord.notes ? `${existingRecord.notes} | ${adminNote}` : adminNote,
        },
      });

      await prisma.attendanceEvent.create({
        data: {
          attendanceId: record.id,
          eventType: 'ADMIN_OVERRIDE',
          eventTimestamp: getNow().toDate(),
          notes: `Administrative attendance edit: Status ${workSessionStatus}, In ${checkInTime || 'unchanged'}, Out ${finalCheckOutAt ? dayjs(finalCheckOutAt).format('HH:mm') : 'None (Active Session)'}. Reason: ${notes || 'Technical adjustment'}`,
        },
      });
    } else {
      record = await prisma.attendanceRecord.create({
        data: {
          employeeId,
          workDate,
          shiftId: shift.id,
          checkInAt: finalCheckInAt,
          checkOutAt: finalCheckOutAt,
          workSessionStatus,
          attendanceClassification,
          netWorkMinutes,
          lateMinutes,
          notes: adminNote,
        },
      });

      if (finalCheckInAt) {
        await prisma.attendanceEvent.create({
          data: {
            attendanceId: record.id,
            eventType: 'CHECK_IN',
            eventTimestamp: finalCheckInAt,
            notes: `Manual check-in logged by Admin. Reason: ${notes || 'Manual override'}`,
          },
        });
      }
      if (finalCheckOutAt) {
        await prisma.attendanceEvent.create({
          data: {
            attendanceId: record.id,
            eventType: 'CHECK_OUT',
            eventTimestamp: finalCheckOutAt,
            notes: `Manual check-out logged by Admin. Reason: ${notes || 'Manual override'}`,
          },
        });
      }
    }

    await logAudit({
      userId: req.user.id,
      action: 'ADMIN_MANUAL_ATTENDANCE_OVERRIDE',
      entityType: 'ATTENDANCE_RECORD',
      entityId: record.id,
      details: {
        targetEmployeeId: employeeId,
        targetEmployeeCode: employee.employeeCode,
        workDate,
        checkInTime,
        checkOutTime: finalCheckOutAt ? dayjs(finalCheckOutAt).format('HH:mm') : null,
        workSessionStatus,
        attendanceClassification,
        reason: notes,
      },
      req,
    });

    return sendSuccess(
      res,
      record,
      `Attendance record for ${employee.fullName} (${employee.employeeCode}) updated successfully.`
    );
  } catch (error) {
    console.error('Admin manual attendance override error:', error);
    return sendError(res, 'Failed to update attendance record.', 500);
  }
}
