import crypto from 'crypto';
import { hashPassword } from '../utils/passwordHelper.js';
import { logAudit } from '../services/auditService.js';
import prisma from '../config/db.js';
import dayjs from 'dayjs';
import { DEFAULT_TZ } from '../utils/timeHelper.js';



/* ============================================================
   RESPONSE HELPERS
============================================================ */

function sendSuccess(res, data = null, message = 'Success', statusCode = 200) {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
  });
}

function sendError(res, message = 'Something went wrong.', statusCode = 500) {
  return res.status(statusCode).json({
    success: false,
    message,
  });
}

/* ============================================================
   UTILITY
============================================================ */

function normalizeRole(role) {
  const value = String(role || 'EMPLOYEE').toUpperCase();

  if (!['ADMIN', 'HR', 'EMPLOYEE'].includes(value)) {
    return 'EMPLOYEE';
  }

  return value;
}

function generateEmployeeCode(sequence) {
  return `EMP${String(sequence).padStart(3, '0')}`;
}

function generateTemporaryPassword() {
  return `Saish@${crypto.randomBytes(4).toString('hex')}`;
}

function generateMasterCode(value = '') {
  const base = String(value)
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);

  const suffix = crypto
    .randomBytes(2)
    .toString('hex')
    .toUpperCase();

  return `${base || 'ITEM'}_${suffix}`;
}

async function findEmployeeById(id) {
  return prisma.employee.findUnique({
    where: { id },

    include: {
      department: true,
      designation: true,
      branch: true,
      reportingManager: true,

   user: {
  select: {
    id: true,
    email: true,
    role: true,
    accountStatus: true,
    canAuthorizePayrollPayment: true,
  },
},

      salaryConfig: true,
    },
  });
}
/* ============================================================
   METADATA
============================================================ */

export async function getMetadata(req, res) {
  try {
    const [
      departments,
      designations,
      branches,
      managers,
    ] = await Promise.all([
      prisma.department.findMany({
        orderBy: {
          name: 'asc',
        },
      }),

      prisma.designation.findMany({
        orderBy: {
          title: 'asc',
        },
      }),

      prisma.branch.findMany({
        orderBy: {
          name: 'asc',
        },
      }),

      prisma.employee.findMany({
        where: {
          employeeStatus: 'ACTIVE',
          isDeleted: false,
          ...(req.user.role === 'HR' ? { user: { role: 'EMPLOYEE' } } : {}),
        },

        select: {
          id: true,
          employeeCode: true,
          fullName: true,
          departmentId: true,
          designationId: true,
        },

        orderBy: {
          fullName: 'asc',
        },
      }),
    ]);

    return sendSuccess(
      res,
      {
        departments,
        designations,
        branches,
        managers,
      },
      'Employee metadata loaded successfully.'
    );
  } catch (error) {
    console.error('Get metadata error:', error);

    return sendError(
      res,
      error.message || 'Failed to load employee metadata.',
      500
    );
  }
}

/* ============================================================
   CREATE EMPLOYEE
============================================================ */

export async function createEmployee(req, res) {
  try {
    const {
      employeeCode: requestedEmployeeCode,
      fullName,
      email,
      phone,
      gender,
      dob,
      joiningDate,
      departmentId,
      designationId,
      branchId,
      employmentType,
      reportingManagerId,
      role,
      monthlySalary,
      salaryEffectiveDate,
      calculationMethod,
      customDivisor,
      paymentMethod,
      bankName,
      bankAccountNumber,
      ifscCode,
      address,
      temporaryPassword,
      lateAllowanceMonthly = 0,
      permissionAllowanceMonthly = 0,
      clRemainingDays = 0,
      upiId,
    } = req.body;

    if (!fullName?.trim()) {
      return sendError(res, 'Employee name is required.', 400);
    }

    if (!email?.trim()) {
      return sendError(res, 'Employee email is required.', 400);
    }

    if (!joiningDate) {
      return sendError(res, 'Date of joining is required.', 400);
    }

    if (!departmentId) {
      return sendError(res, 'Department is required.', 400);
    }

    if (!designationId) {
      return sendError(res, 'Designation is required.', 400);
    }

    if (!branchId) {
      return sendError(res, 'Branch is required.', 400);
    }

    const normalizedEmail = email.trim().toLowerCase();

    const existingUser = await prisma.user.findUnique({
      where: {
        email: normalizedEmail,
      },
    });

    if (existingUser) {
      return sendError(
        res,
        'An account already exists with this email address.',
        409
      );
    }

    const department = await prisma.department.findUnique({
      where: {
        id: departmentId,
      },
    });

    if (!department) {
      return sendError(res, 'Selected department does not exist.', 400);
    }

    const designation = await prisma.designation.findUnique({
      where: {
        id: designationId,
      },
    });

    if (!designation) {
      return sendError(res, 'Selected designation does not exist.', 400);
    }

    if (
      designation.departmentId &&
      designation.departmentId !== departmentId
    ) {
      return sendError(
        res,
        'Selected designation does not belong to the selected department.',
        400
      );
    }

    const branch = await prisma.branch.findUnique({
      where: {
        id: branchId,
      },
    });

    if (!branch) {
      return sendError(res, 'Selected branch does not exist.', 400);
    }

    if (reportingManagerId) {
      const manager = await prisma.employee.findUnique({
        where: {
          id: reportingManagerId,
        },
      });

      if (!manager) {
        return sendError(res, 'Reporting manager does not exist.', 400);
      }
    }

    const employeeCount = await prisma.employee.count();

    let employeeCode = requestedEmployeeCode?.trim().toUpperCase();
    if (employeeCode) {
      const existingEmployeeCode = await prisma.employee.findUnique({ where: { employeeCode } });
      if (existingEmployeeCode) return sendError(res, 'This employee code is already in use.', 409);
    } else {
      let nextNumber = employeeCount + 1;
      employeeCode = generateEmployeeCode(nextNumber);
      while (await prisma.employee.findUnique({ where: { employeeCode } })) {
        nextNumber += 1;
        employeeCode = generateEmployeeCode(nextNumber);
      }
    }

    const requestedRole =
      req.user?.role === 'ADMIN'
        ? normalizeRole(role)
        : 'EMPLOYEE';

  const password =
  temporaryPassword || generateTemporaryPassword();

const passwordHash = await hashPassword(password);

    const result = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
  data: {
    email: normalizedEmail,
    role: requestedRole,
    passwordHash,
    accountStatus: 'ACTIVE',
    mustChangePassword: true,
  },
});

      const employee = await tx.employee.create({
        data: {
          employeeCode,
          fullName: fullName.trim(),
          email: normalizedEmail,
          phone: phone?.trim() || null,
          gender: gender || null,

          dob: dob ? new Date(dob) : null,

          joiningDate: new Date(joiningDate),

          departmentId,
          designationId,
          branchId,

          employmentType: employmentType || 'FULL_TIME',

          reportingManagerId: reportingManagerId || null,


          employeeStatus: 'ACTIVE',

          address: address?.trim() || null,

          user: { connect: { id: user.id } },
        },
      });

      if (monthlySalary !== undefined && monthlySalary !== null) {
        await tx.salaryConfiguration.create({
          data: {
            employeeId: employee.id,

            monthlySalary: Number(monthlySalary) || 0,

            effectiveDate: new Date(
              salaryEffectiveDate || joiningDate
            ),

            calculationMethod:
              calculationMethod || 'CALENDAR_DAYS',

            customDivisor:
              Number(customDivisor) || 30,

            lateAttendanceAllowance: Number(lateAllowanceMonthly),

            permissionAllowancePerMonth: Number(permissionAllowanceMonthly),

            paymentMethod:
              paymentMethod || 'BANK_TRANSFER',

            bankName: paymentMethod === 'BANK_TRANSFER' ? bankName?.trim() || null : null,

            accountNumber: paymentMethod === 'BANK_TRANSFER' ? bankAccountNumber?.trim() || null : null,
            upiId: paymentMethod === 'UPI' ? upiId?.trim() || null : null,

            ifscCode: paymentMethod === 'BANK_TRANSFER' ? ifscCode?.trim()?.toUpperCase() || null : null,
          },
        });
      }

      const monthYear = dayjs().tz(DEFAULT_TZ).format('YYYY-MM');
      const clType = await tx.leaveType.upsert({
        where: { code: 'CL' }, update: {},
        create: { code: 'CL', name: 'Casual Leave', annualQuota: 12, isPaid: true },
      });
      await tx.leaveBalance.create({ data: {
        employeeId: employee.id, leaveTypeId: clType.id, year: Number(monthYear.slice(0, 4)),
        totalAllocated: Number(clRemainingDays), remainingDays: Number(clRemainingDays),
      } });
      await tx.leaveLedger.create({ data: {
        employeeId: employee.id, leaveTypeCode: 'CL', monthYear,
        creditedDays: Number(clRemainingDays), closingBalance: Number(clRemainingDays),
        remarks: 'Initial CL allocation at registration (includes registration month)',
      } });
      return { employee };

    });

    await logAudit({
      userId: req.user?.id,
      action: 'EMPLOYEE_CREATED',
      entityType: 'EMPLOYEE',
      entityId: result.employee.id,
      details: {
        employeeCode,
        fullName,
        role: requestedRole,
      },
    });

    return sendSuccess(
      res,
      {
        employee: result.employee,

        credentials: {
          temporaryPassword: password,
        },
      },
      'Employee created successfully.',
      201
    );
  } catch (error) {
    console.error('Create employee error:', error);

    return sendError(
      res,
      error.message || 'Failed to create employee.',
      500
    );
  }
}

/* ============================================================
   GET ALL EMPLOYEES
============================================================ */

export async function getAllEmployees(req, res) {
  try {
    const {
      search = '',
      departmentId = '',
      status = '',
    } = req.query;

    const where = { isDeleted: false, NOT: { user: { role: 'ADMIN' } } };

    if (departmentId) {
      where.departmentId = departmentId;
    }

    if (status) {
      where.employeeStatus = status;
    }

    if (search.trim()) {
      where.OR = [
        {
          fullName: {
            contains: search.trim(),
          },
        },
        {
          employeeCode: {
            contains: search.trim(),
          },
        },
        {
          email: {
            contains: search.trim(),
          },
        },
      ];
    }

    // HR can view regular employees only
    if (req.user?.role === 'HR') {
      where.user = { role: 'EMPLOYEE' };
    }

    const employees = await prisma.employee.findMany({
      where,

      include: {
        department: true,
        designation: true,
        branch: true,

        reportingManager: {
          select: {
            id: true,
            employeeCode: true,
            fullName: true,
          },
        },

        salaryConfig: true,

        user: {
          select: {
            id: true,
            email: true,
            role: true,
            accountStatus: true,
    canAuthorizePayrollPayment: true,
          },
        },
      },

      orderBy: {
        fullName: 'asc',
      },
    });

    return sendSuccess(
      res,
      {
        employees: employees.map(e => ({ ...e, role: e.user?.role, accountStatus: e.user?.accountStatus })),
        total: employees.length,
      },
      'Employees loaded successfully.'
    );
  } catch (error) {
    console.error('Get employees error:', error);

    return sendError(
      res,
      error.message || 'Failed to load employees.',
      500
    );
  }
}

/* ============================================================
   GET EMPLOYEE BY ID
============================================================ */

export async function getEmployeeById(req, res) {
  try {
    const employee = await findEmployeeById(req.params.id);

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'EMPLOYEE' &&
      req.user?.employeeId !== employee.id
    ) {
      return sendError(res, 'Access denied.', 403);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE' && employee.id !== req.user.employeeId
    ) {
      return sendError(res, 'Access denied.', 403);
    }

    return sendSuccess(
      res,
      { ...employee, role: employee.user?.role },
      'Employee loaded successfully.'
    );
  } catch (error) {
    console.error('Get employee error:', error);

    return sendError(
      res,
      error.message || 'Failed to load employee.',
      500
    );
  }
}

export async function updateMyProfilePhoto(req, res) {
  try {
    const employeeId = req.employee?.id;
    if (!employeeId || !['EMPLOYEE', 'HR'].includes(req.user?.role)) {
      return sendError(res, 'An employee profile is required to update a profile photo.', 403);
    }

    const { profilePhoto } = req.body;
    if (profilePhoto !== null && typeof profilePhoto !== 'string') {
      return sendError(res, 'Provide a valid profile photo or null to remove it.', 422);
    }

    if (typeof profilePhoto === 'string') {
      const match = profilePhoto.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
      if (!match) return sendError(res, 'Profile photo must be a PNG, JPEG, or WebP image.', 422);
      const imageBuffer = Buffer.from(match[2], 'base64');
      if (imageBuffer.length > 1024 * 1024) {
        return sendError(res, 'Profile photo must be 1 MB or smaller.', 413);
      }
      const isPng = match[1] === 'png' && imageBuffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
      const isJpeg = match[1] === 'jpeg' && imageBuffer.subarray(0, 3).equals(Buffer.from([255, 216, 255]));
      const isWebp = match[1] === 'webp' && imageBuffer.toString('ascii', 0, 4) === 'RIFF'
        && imageBuffer.toString('ascii', 8, 12) === 'WEBP';
      if (!isPng && !isJpeg && !isWebp) {
        return sendError(res, 'The selected file is not a valid PNG, JPEG, or WebP image.', 422);
      }
    }

    const updated = await prisma.employee.update({
      where: { id: employeeId },
      data: { profilePhoto },
      select: { id: true, profilePhoto: true },
    });

    await logAudit({
      userId: req.user.id,
      action: profilePhoto ? 'EMPLOYEE_PROFILE_PHOTO_UPDATED' : 'EMPLOYEE_PROFILE_PHOTO_REMOVED',
      entityType: 'EMPLOYEE',
      entityId: employeeId,
      req,
    });

    return sendSuccess(res, updated, 'Profile photo updated.');
  } catch (error) {
    console.error('Update employee profile photo error:', error);
    return sendError(res, 'Failed to update profile photo.', 500);
  }
}

/* ============================================================
   UPDATE EMPLOYEE
============================================================ */

export async function updateEmployee(req, res) {
  try {
    const employee = await prisma.employee.findUnique({
      where: {
        id: req.params.id,
      },
      include: { user: { select: { id: true, role: true } } },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can update regular employees only.',
        403
      );
    }

    const {
      employeeCode,
      email,
      fullName,
      phone,
      gender,
      dob,
      departmentId,
      designationId,
      branchId,
      employmentType,
      reportingManagerId,
      role,
      address,
      joiningDate,
    } = req.body;

    if (email && email.trim().toLowerCase() !== employee.email.toLowerCase()) {
      const existingUser = await prisma.user.findUnique({ where: { email: email.trim().toLowerCase() } });
      if (existingUser) return sendError(res, 'An account already exists with this email address.', 409);
      const existingEmployee = await prisma.employee.findUnique({ where: { email: email.trim().toLowerCase() } });
      if (existingEmployee && existingEmployee.id !== employee.id) {
        return sendError(res, 'An employee already exists with this email address.', 409);
      }
    }
    if (employeeCode && employeeCode.trim().toUpperCase() !== employee.employeeCode) {
      const existingCode = await prisma.employee.findUnique({ where: { employeeCode: employeeCode.trim().toUpperCase() } });
      if (existingCode) return sendError(res, 'This employee code is already in use.', 409);
    }

    if (departmentId) {
      const department = await prisma.department.findUnique({
        where: {
          id: departmentId,
        },
      });

      if (!department) {
        return sendError(res, 'Department not found.', 400);
      }
    }

    if (designationId) {
      const designation = await prisma.designation.findUnique({
        where: {
          id: designationId,
        },
      });

      if (!designation) {
        return sendError(res, 'Designation not found.', 400);
      }

      const targetDepartmentId =
        departmentId || employee.departmentId;

      if (
        designation.departmentId &&
        designation.departmentId !== targetDepartmentId
      ) {
        return sendError(
          res,
          'Designation does not belong to the selected department.',
          400
        );
      }
    }

    const data = {};
    const userUpdate = {};
    if (req.body.canAuthorizePayrollPayment !== undefined) {
      if (req.user.role !== 'ADMIN') return sendError(res, 'Only Admin can configure Paying Authority.', 403);
      if ((role || employee.user?.role) !== 'HR') return sendError(res, 'Paying Authority delegation is available for HR accounts only.', 400);
      userUpdate.canAuthorizePayrollPayment = req.body.canAuthorizePayrollPayment;
    }

    if (employeeCode !== undefined) data.employeeCode = employeeCode.trim().toUpperCase();
    if (email !== undefined) {
      data.email = email.trim().toLowerCase();
      userUpdate.email = email.trim().toLowerCase();
    }
    if (fullName !== undefined) data.fullName = fullName.trim();
    if (phone !== undefined) data.phone = phone?.trim() || null;
    if (gender !== undefined) data.gender = gender;
    if (dob !== undefined) data.dob = dob ? new Date(dob) : null;
    if (departmentId !== undefined) data.departmentId = departmentId;
    if (designationId !== undefined) data.designationId = designationId;
    if (branchId !== undefined) data.branchId = branchId;

    if (employmentType !== undefined) {
      data.employmentType = employmentType;
    }

    if (reportingManagerId !== undefined) {
      data.reportingManagerId = reportingManagerId || null;
    }

    if (address !== undefined) {
      data.address = address?.trim() || null;
    }
    if (joiningDate !== undefined) data.joiningDate = new Date(joiningDate);

    if (req.user?.role === 'ADMIN' && role !== undefined) {
      userUpdate.role = normalizeRole(role);
      if (role !== 'HR') userUpdate.canAuthorizePayrollPayment = false;
    }
    if (Object.keys(userUpdate).length) data.user = { update: userUpdate };

    const updated = await prisma.employee.update({
      where: {
        id: employee.id,
      },

      data,

      include: {
        department: true,
        designation: true,
        branch: true,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'EMPLOYEE_UPDATED',
      entityType: 'EMPLOYEE',
      entityId: employee.id,
      details: data,
    });

    return sendSuccess(
      res,
      updated,
      'Employee updated successfully.'
    );
  } catch (error) {
    console.error('Update employee error:', error);

    return sendError(
      res,
      error.message || 'Failed to update employee.',
      500
    );
  }
}

/* ============================================================
   TOGGLE EMPLOYEE STATUS
============================================================ */

export async function toggleEmployeeStatus(req, res) {
  try {
    const employee = await prisma.employee.findUnique({
      where: {
        id: req.params.id,
      },
      include: { user: { select: { id: true, role: true } } },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can change regular employee status only.',
        403
      );
    }

    const nextStatus =
      req.body.employeeStatus ||
      req.body.status ||
      (employee.employeeStatus === 'ACTIVE'
        ? 'INACTIVE'
        : 'ACTIVE');

    if (!['ACTIVE', 'INACTIVE'].includes(nextStatus)) {
      return sendError(
        res,
        'Employee status must be ACTIVE or INACTIVE.',
        400
      );
    }

    const updated = await prisma.employee.update({
      where: {
        id: employee.id,
      },

      data: {
        employeeStatus: nextStatus,
        ...(employee.user ? { user: { update: { accountStatus: nextStatus } } } : {}),
      },
    });

    return sendSuccess(
      res,
      updated,
      `Employee ${nextStatus === 'ACTIVE' ? 'activated' : 'deactivated'} successfully.`
    );
  } catch (error) {
    console.error('Employee status error:', error);

    return sendError(
      res,
      error.message || 'Failed to change employee status.',
      500
    );
  }
}

/* ============================================================
   ASSIGN SHIFT

   Kept only because your current employeeRoutes.js still has
   this compatibility endpoint. Your UI should not expose shifts.
============================================================ */

export async function assignShift(req, res) {
  try {
    const employee = await prisma.employee.findUnique({
      where: {
        id: req.params.id,
      },
      include: { user: { select: { id: true, role: true } } },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can manage regular employees only.',
        403
      );
    }

    const shiftId = req.body.shiftId;

    if (!shiftId) {
      return sendError(res, 'Office timing ID is required.', 400);
    }

    const shift = await prisma.shift.findUnique({
      where: {
        id: shiftId,
      },
    });

    if (!shift) {
      return sendError(res, 'Office timing not found.', 404);
    }

    await prisma.$transaction(async tx => {
      await tx.employeeShiftAssignment.updateMany({ where: { employeeId: employee.id, effectiveTo: null }, data: { effectiveTo: new Date() } });
      await tx.employeeShiftAssignment.create({ data: { employeeId: employee.id, shiftId, effectiveFrom: new Date(req.body.effectiveFrom || Date.now()) } });
    });

    return sendSuccess(
      res,
      {
        employeeId: employee.id,
        shiftId: shift.id,
      },
      'Office timing validated successfully.'
    );
  } catch (error) {
    console.error('Office timing assignment error:', error);

    return sendError(
      res,
      error.message || 'Failed to assign office timing.',
      500
    );
  }
}

/* ============================================================
   RESET ACCOUNT ACCESS
============================================================ */

export async function resetAccountAccess(req, res) {
  try {
    const employee = await prisma.employee.findUnique({
      where: {
        id: req.params.id,
      },

      include: {
        user: true,
      },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can reset regular employee accounts only.',
        403
      );
    }

    if (!employee.user) {
      return sendError(
        res,
        'Employee login account was not found.',
        404
      );
    }

    const temporaryPassword = generateTemporaryPassword();

    await prisma.user.update({
      where: {
        id: employee.user.id,
      },

      data: {
        passwordHash: await hashPassword(temporaryPassword),
        accountStatus: 'ACTIVE',
        mustChangePassword: true,
      },
    });

    return sendSuccess(
      res,
      {
        temporaryPassword,
      },
      'Employee account access reset successfully.'
    );
  } catch (error) {
    console.error('Reset account access error:', error);

    return sendError(
      res,
      error.message || 'Failed to reset employee access.',
      500
    );
  }
}

/* ============================================================
   ATTENDANCE BENEFIT ADJUSTMENT
============================================================ */

export async function updateAttendanceBenefits(req, res) {
  try {
    const employeeId = req.params.id;

    const employee = await prisma.employee.findUnique({
      where: {
        id: employeeId,
      },
      include: { user: { select: { id: true, role: true } } },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (
      req.user?.role === 'HR' &&
      employee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can adjust regular employee records only.',
        403
      );
    }

    const lateAdjustment =
      Number(req.body.lateAdjustment) || 0;

    const permissionAdjustment =
      Number(req.body.permissionAdjustment) || 0;

    const reason = String(req.body.reason || '').trim();

    if (
      lateAdjustment === 0 &&
      permissionAdjustment === 0
    ) {
      return sendError(
        res,
        'Enter at least one attendance adjustment.',
        400
      );
    }

    if (!reason) {
      return sendError(res, 'Adjustment reason is required.', 400);
    }

    let salaryConfiguration =
      await prisma.salaryConfiguration.findUnique({
        where: {
          employeeId,
        },
      });

    if (!salaryConfiguration) {
      return sendError(
        res,
        'Salary configuration was not found for this employee.',
        404
      );
    }

    const newLateAllowance = Math.max(
      0,
      Number(
        salaryConfiguration.lateAttendanceAllowance || 0
      ) + lateAdjustment
    );

    const newPermissionAllowance = Math.max(
      0,
      Number(
        salaryConfiguration.permissionAllowancePerMonth || 0
      ) + permissionAdjustment
    );

    salaryConfiguration =
      await prisma.salaryConfiguration.update({
        where: {
          employeeId,
        },

        data: {
          lateAttendanceAllowance: newLateAllowance,

          permissionAllowancePerMonth:
            newPermissionAllowance,
        },
      });

    await logAudit({
      userId: req.user?.id,
      action: 'ATTENDANCE_BENEFITS_ADJUSTED',
      entityType: 'EMPLOYEE',
      entityId: employeeId,
      details: {
        lateAdjustment,
        permissionAdjustment,
        reason,
      },
    });

    return sendSuccess(
      res,
      {
        employeeId,

        lateAttendanceAllowance:
          salaryConfiguration.lateAttendanceAllowance,

        permissionAllowancePerMonth:
          salaryConfiguration.permissionAllowancePerMonth,
      },
      'Attendance adjustment saved successfully.'
    );
  } catch (error) {
    console.error('Attendance benefit adjustment error:', error);

    return sendError(
      res,
      error.message || 'Failed to update attendance adjustment.',
      500
    );
  }
}

/* ============================================================
   DELETE EMPLOYEE
============================================================ */

export async function deleteEmployee(req, res) {
  try {
    const employee = await prisma.employee.findUnique({
      where: {
        id: req.params.id,
      },
      include: { user: { select: { id: true, role: true } } },
    });

    if (!employee) {
      return sendError(res, 'Employee not found.', 404);
    }

    if (employee.user?.role === 'ADMIN') {
      return sendError(
        res,
        'Administrator account cannot be deleted here.',
        403
      );
    }

    await prisma.employee.update({
      where: { id: employee.id },
      data: { isDeleted: true, employeeStatus: 'INACTIVE',
        ...(employee.user ? { user: { update: { accountStatus: 'INACTIVE' } } } : {}),
      },
    });

    return sendSuccess(
      res,
      null,
      'Employee deleted successfully.'
    );
  } catch (error) {
    console.error('Delete employee error:', error);

    return sendError(
      res,
      error.message || 'Failed to delete employee.',
      500
    );
  }
}

/* ============================================================
   DEPARTMENT MANAGEMENT
============================================================ */

export async function createDepartment(req, res) {
  try {
    const name = String(req.body?.name || '').trim();

    if (!name) {
      return sendError(res, 'Department name is required.', 400);
    }

    const departments = await prisma.department.findMany({
      select: {
        id: true,
        name: true,
      },
    });

    const duplicate = departments.find(
      (department) =>
        String(department.name).trim().toLowerCase() ===
        name.toLowerCase()
    );

    if (duplicate) {
      return sendError(
        res,
        'A department with this name already exists.',
        409
      );
    }

    const department = await prisma.department.create({
      data: {
        name,
        code: generateMasterCode(name),
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DEPARTMENT_CREATED',
      entityType: 'DEPARTMENT',
      entityId: department.id,
      details: {
        name: department.name,
        code: department.code,
      },
    });

    return sendSuccess(
      res,
      department,
      'Department added successfully.',
      201
    );
  } catch (error) {
    console.error('Create department error:', error);

    return sendError(
      res,
      error.message || 'Failed to create department.',
      500
    );
  }
}

export async function updateDepartment(req, res) {
  try {
    const { departmentId } = req.params;

    const name = String(req.body?.name || '').trim();

    if (!name) {
      return sendError(res, 'Department name is required.', 400);
    }

    const existing = await prisma.department.findUnique({
      where: {
        id: departmentId,
      },
    });

    if (!existing) {
      return sendError(res, 'Department not found.', 404);
    }

    const departments = await prisma.department.findMany({
      where: {
        NOT: {
          id: departmentId,
        },
      },

      select: {
        id: true,
        name: true,
      },
    });

    const duplicate = departments.find(
      (department) =>
        String(department.name).trim().toLowerCase() ===
        name.toLowerCase()
    );

    if (duplicate) {
      return sendError(
        res,
        'Another department already uses this name.',
        409
      );
    }

    const updated = await prisma.department.update({
      where: {
        id: departmentId,
      },

      data: {
        name,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DEPARTMENT_UPDATED',
      entityType: 'DEPARTMENT',
      entityId: departmentId,
      details: {
        previousName: existing.name,
        newName: name,
      },
    });

    return sendSuccess(
      res,
      updated,
      'Department updated successfully.'
    );
  } catch (error) {
    console.error('Update department error:', error);

    return sendError(
      res,
      error.message || 'Failed to update department.',
      500
    );
  }
}

export async function deleteDepartment(req, res) {
  try {
    const { departmentId } = req.params;

    const department = await prisma.department.findUnique({
      where: {
        id: departmentId,
      },

      include: {
        _count: {
          select: {
            employees: true,
            designations: true,
          },
        },
      },
    });

    if (!department) {
      return sendError(res, 'Department not found.', 404);
    }

    if (department._count?.employees > 0) {
      return sendError(
        res,
        `This department is assigned to ${department._count.employees} employee(s). Reassign them before deleting the department.`,
        409
      );
    }

    if (department._count?.designations > 0) {
      return sendError(
        res,
        `This department contains ${department._count.designations} designation(s). Delete or move those designations first.`,
        409
      );
    }

    await prisma.department.delete({
      where: {
        id: departmentId,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DEPARTMENT_DELETED',
      entityType: 'DEPARTMENT',
      entityId: departmentId,
      details: {
        name: department.name,
      },
    });

    return sendSuccess(
      res,
      null,
      'Department deleted successfully.'
    );
  } catch (error) {
    console.error('Delete department error:', error);

    return sendError(
      res,
      error.message || 'Failed to delete department.',
      500
    );
  }
}

/* ============================================================
   DESIGNATION MANAGEMENT
============================================================ */

export async function createDesignation(req, res) {
  try {
    const title = String(req.body?.title || '').trim();

    const departmentId = String(
      req.body?.departmentId || ''
    ).trim();

    if (!title) {
      return sendError(res, 'Designation name is required.', 400);
    }

    if (!departmentId) {
      return sendError(res, 'Please select a department.', 400);
    }

    const department = await prisma.department.findUnique({
      where: {
        id: departmentId,
      },
    });

    if (!department) {
      return sendError(
        res,
        'Selected department does not exist.',
        404
      );
    }

    const designations = await prisma.designation.findMany({
      where: {
        departmentId,
      },

      select: {
        id: true,
        title: true,
      },
    });

    const duplicate = designations.find(
      (designation) =>
        String(designation.title).trim().toLowerCase() ===
        title.toLowerCase()
    );

    if (duplicate) {
      return sendError(
        res,
        'This designation already exists in the selected department.',
        409
      );
    }

    const designation = await prisma.designation.create({
      data: {
        title,
        departmentId,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DESIGNATION_CREATED',
      entityType: 'DESIGNATION',
      entityId: designation.id,
      details: {
        title: designation.title,
        departmentId,
        departmentName: department.name,
      },
    });

    return sendSuccess(
      res,
      designation,
      'Designation added successfully.',
      201
    );
  } catch (error) {
    console.error('Create designation error:', error);

    return sendError(
      res,
      error.message || 'Failed to create designation.',
      500
    );
  }
}

export async function updateDesignation(req, res) {
  try {
    const { designationId } = req.params;

    const title = String(req.body?.title || '').trim();

    const departmentId = String(
      req.body?.departmentId || ''
    ).trim();

    if (!title) {
      return sendError(res, 'Designation name is required.', 400);
    }

    if (!departmentId) {
      return sendError(res, 'Please select a department.', 400);
    }

    const existing = await prisma.designation.findUnique({
      where: {
        id: designationId,
      },
    });

    if (!existing) {
      return sendError(res, 'Designation not found.', 404);
    }

    const department = await prisma.department.findUnique({
      where: {
        id: departmentId,
      },
    });

    if (!department) {
      return sendError(
        res,
        'Selected department does not exist.',
        404
      );
    }

    const designations = await prisma.designation.findMany({
      where: {
        departmentId,

        NOT: {
          id: designationId,
        },
      },

      select: {
        id: true,
        title: true,
      },
    });

    const duplicate = designations.find(
      (designation) =>
        String(designation.title).trim().toLowerCase() ===
        title.toLowerCase()
    );

    if (duplicate) {
      return sendError(
        res,
        'Another designation with this name already exists in the selected department.',
        409
      );
    }

    const updated = await prisma.designation.update({
      where: {
        id: designationId,
      },

      data: {
        title,
        departmentId,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DESIGNATION_UPDATED',
      entityType: 'DESIGNATION',
      entityId: designationId,
      details: {
        previousTitle: existing.title,
        newTitle: title,
        previousDepartmentId: existing.departmentId,
        newDepartmentId: departmentId,
      },
    });

    return sendSuccess(
      res,
      updated,
      'Designation updated successfully.'
    );
  } catch (error) {
    console.error('Update designation error:', error);

    return sendError(
      res,
      error.message || 'Failed to update designation.',
      500
    );
  }
}

export async function deleteDesignation(req, res) {
  try {
    const { designationId } = req.params;

    const designation = await prisma.designation.findUnique({
      where: {
        id: designationId,
      },

      include: {
        _count: {
          select: {
            employees: true,
          },
        },
      },
    });

    if (!designation) {
      return sendError(res, 'Designation not found.', 404);
    }

    if (designation._count?.employees > 0) {
      return sendError(
        res,
        `This designation is assigned to ${designation._count.employees} employee(s). Reassign them before deleting the designation.`,
        409
      );
    }

    await prisma.designation.delete({
      where: {
        id: designationId,
      },
    });

    await logAudit({
      userId: req.user?.id,
      action: 'DESIGNATION_DELETED',
      entityType: 'DESIGNATION',
      entityId: designationId,
      details: {
        title: designation.title,
        departmentId: designation.departmentId,
      },
    });

    return sendSuccess(
      res,
      null,
      'Designation deleted successfully.'
    );
  } catch (error) {
    console.error('Delete designation error:', error);

    return sendError(
      res,
      error.message || 'Failed to delete designation.',
      500
    );
  }
}
