import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';

/**
 * Admin-only audit feed. Authentication events and privileged HR actions are
 * attributable to the acting user and can be filtered by role or action.
 */
export async function getAuditLogs(req, res) {
  try {
    const { role = 'HR', action = '', search = '', page = 1, limit = 50 } = req.query;
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(100, Math.max(1, Number(limit) || 50));
    const where = {};

    if (role && role !== 'ALL') where.user = { role };
    if (action) where.action = action;
    if (search) {
      where.OR = [
        { action: { contains: search } },
        { entityType: { contains: search } },
        { user: { email: { contains: search } } },
        { user: { employee: { fullName: { contains: search } } } },
      ];
    }

    const [total, logs] = await Promise.all([
      prisma.auditLog.count({ where }),
      prisma.auditLog.findMany({
        where,
        skip: (pageNum - 1) * limitNum,
        take: limitNum,
        orderBy: { createdAt: 'desc' },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              role: true,
              employee: { select: { employeeCode: true, fullName: true } },
            },
          },
        },
      }),
    ]);

    const auditLogs = logs.map((log) => {
      let details = log.details;
      if (typeof details === 'string') {
        try { details = JSON.parse(details); } catch { /* preserve legacy text */ }
      }
      return { ...log, details };
    });

    return sendSuccess(res, {
      auditLogs,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
      },
    }, 'Audit activity retrieved.');
  } catch (error) {
    console.error('Get audit logs error:', error);
    return sendError(res, 'Failed to retrieve audit activity.', 500);
  }
}
