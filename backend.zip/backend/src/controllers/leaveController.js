import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { logAudit } from '../services/auditService.js';
import dayjs from 'dayjs';
import { processMonthlyClAccrualForEmployee, recordLeaveUsageInLedger } from '../services/clAccrualService.js';
import { DEFAULT_TZ } from '../utils/timeHelper.js';

/**
 * Apply for leave
 */
export async function applyLeave(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const {
      leaveTypeId,
      startDate,
      endDate,
      daysCount,
      isHalfDay,
      halfDayType,
      reason,
      documentUrl,
    } = req.body;

    const leaveType = await prisma.leaveType.findUnique({ where: { id: leaveTypeId } });
    if (!leaveType || leaveType.code === 'SL') return sendError(res, 'This leave type is not available.', 400);
    if (leaveType.code === 'CL') await processMonthlyClAccrualForEmployee(employee.id);

    if (dayjs(endDate).isBefore(dayjs(startDate))) {
      return sendError(res, 'End date cannot be earlier than start date.', 400);
    }

    // Check for conflicting/overlapping leave requests
    const overlapping = await prisma.leaveRequest.findFirst({
      where: {
        employeeId: employee.id,
        status: { in: ['PENDING', 'APPROVED'] },
        OR: [
          {
            startDate: { lte: endDate },
            endDate: { gte: startDate },
          },
        ],
      },
      include: { leaveType: true },
    });

    if (overlapping) {
      return sendError(
        res,
        `You already have an existing ${overlapping.status.toLowerCase()} leave request (${overlapping.leaveType.name}) between ${overlapping.startDate} and ${overlapping.endDate}.`,
        400
      );
    }

    // Check leave balance for current year
    const currentYear = leaveType.code === 'CL' ? dayjs().tz(DEFAULT_TZ).year() : dayjs(startDate).year();
    const balance = await prisma.leaveBalance.findUnique({
      where: {
        employeeId_leaveTypeId_year: {
          employeeId: employee.id,
          leaveTypeId,
          year: currentYear,
        },
      },
      include: { leaveType: true },
    });

    if (!balance) {
      return sendError(res, 'Leave balance record not found for this leave type and year.', 404);
    }

    // If leave type is paid and not LWP, verify remaining balance
    if (balance.leaveType.isPaid && balance.leaveType.code !== 'LWP') {
      const availableDays = balance.remainingDays - balance.pendingDays;
      if (daysCount > availableDays) {
        return sendError(
          res,
          `Insufficient leave balance. You have ${availableDays} days available for ${balance.leaveType.name}, but requested ${daysCount} days.`,
          400
        );
      }
    }

    // Create leave request and reserve pending days
    const result = await prisma.$transaction(async (tx) => {
      const leave = await tx.leaveRequest.create({
        data: {
          employeeId: employee.id,
          leaveTypeId,
          startDate,
          endDate,
          daysCount,
          isHalfDay,
          halfDayType,
          reason,
          documentUrl,
          status: 'PENDING',
        },
        include: { leaveType: true },
      });

      // Update pending days in balance
      await tx.leaveBalance.update({
        where: { id: balance.id },
        data: {
          pendingDays: balance.pendingDays + daysCount,
        },
      });

      return leave;
    });

    await logAudit({
      userId: req.user.id,
      action: 'LEAVE_APPLIED',
      entityType: 'LEAVE',
      entityId: result.id,
      details: {
        leaveType: result.leaveType.name,
        startDate,
        endDate,
        daysCount,
      },
      req,
    });

    return sendSuccess(res, result, 'Leave request submitted successfully and is pending approval.', 201);
  } catch (error) {
    console.error('Apply leave error:', error);
    return sendError(res, 'Failed to submit leave request.', 500);
  }
}

/**
 * Get leave requests for current authenticated employee
 */
export async function getMyLeaves(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    await processMonthlyClAccrualForEmployee(employee.id);
    const currentYear = dayjs().tz(DEFAULT_TZ).year();

    const [requests, balances, clLedger] = await Promise.all([
      prisma.leaveRequest.findMany({
        where: { employeeId: employee.id, leaveType: { code: { not: 'SL' } } },
        orderBy: { createdAt: 'desc' },
        include: {
          leaveType: true,
          reviewer: { select: { email: true, role: true } },
        },
      }),
      prisma.leaveBalance.findMany({
        where: { employeeId: employee.id, year: currentYear, leaveType: { code: { not: 'SL' } } },
        include: { leaveType: true },
        orderBy: { leaveType: { name: 'asc' } },
      }),
      prisma.leaveLedger.findMany({
        where: { employeeId: employee.id, leaveTypeCode: 'CL' },
        orderBy: { monthYear: 'desc' },
      }),
    ]);

    return sendSuccess(res, { requests, balances, clLedger }, 'Leave history and balances retrieved.');
  } catch (error) {
    console.error('Get my leaves error:', error);
    return sendError(res, 'Failed to retrieve leave information.', 500);
  }
}

/**
 * Get all leave requests for Admin and HR
 */
export async function getAllLeaves(req, res) {
  try {
    const { status, departmentId, search = '', page = 1, limit = 20 } = req.query;

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;
    const skip = (pageNum - 1) * limitNum;

    const where = { leaveType: { code: { not: 'SL' } } };
    const employeeFilter = {};
    if (status) where.status = status;
    if (req.user.role === 'HR') employeeFilter.user = { role: 'EMPLOYEE' };
    if (departmentId) employeeFilter.departmentId = departmentId;
    if (search) {
      employeeFilter.OR = [
        { fullName: { contains: search } },
        { employeeCode: { contains: search } },
      ];
    }
    if (Object.keys(employeeFilter).length > 0) where.employee = employeeFilter;

    const [total, requests] = await Promise.all([
      prisma.leaveRequest.count({ where }),
      prisma.leaveRequest.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: { createdAt: 'desc' },
        include: {
          employee: {
            include: { department: true, designation: true },
          },
          leaveType: true,
          reviewer: { select: { email: true, role: true } },
        },
      }),
    ]);

    return sendSuccess(
      res,
      {
        requests,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages: Math.ceil(total / limitNum),
        },
      },
      'Leave requests retrieved.'
    );
  } catch (error) {
    console.error('Get all leaves error:', error);
    return sendError(res, 'Failed to retrieve leave requests.', 500);
  }
}

/**
 * Approve or Reject leave request (Admin/HR)
 */
export async function decideLeave(req, res) {
  try {
    const { id } = req.params;
    const { status, reviewerComments } = req.body;

    const leaveRequest = await prisma.leaveRequest.findUnique({
      where: { id },
      include: { employee: { include: { user: true } }, leaveType: true },
    });

    if (!leaveRequest) {
      return sendError(res, 'Leave request not found.', 404);
    }

    if (req.user.role === 'HR' && leaveRequest.employee.user?.role !== 'EMPLOYEE') {
      return sendError(res, 'HR can review leave requests for employees only.', 403);
    }

    if (leaveRequest.leaveType.code === 'SL') return sendError(res, 'This leave type is not available.', 400);
    if (leaveRequest.leaveType.code === 'CL') await processMonthlyClAccrualForEmployee(leaveRequest.employeeId);

    if (leaveRequest.status !== 'PENDING') {
      return sendError(res, `This request has already been ${leaveRequest.status.toLowerCase()}.`, 400);
    }

    const currentYear = leaveRequest.leaveType.code === 'CL' ? dayjs().tz(DEFAULT_TZ).year() : dayjs(leaveRequest.startDate).year();
    const balance = await prisma.leaveBalance.findUnique({
      where: {
        employeeId_leaveTypeId_year: {
          employeeId: leaveRequest.employeeId,
          leaveTypeId: leaveRequest.leaveTypeId,
          year: currentYear,
        },
      },
    });

    if (status === 'APPROVED' && balance && balance.remainingDays < leaveRequest.daysCount) return sendError(res, 'Insufficient leave balance for approval.', 409);
    const reviewedAt = new Date();

    const updated = await prisma.$transaction(async (tx) => {
      const claimed = await tx.leaveRequest.updateMany({ where: { id, status: 'PENDING' }, data: { status } });
      if (claimed.count !== 1) throw new Error('This request has already been reviewed.');
      // 1. Update Leave Request status
      const updatedLeave = await tx.leaveRequest.update({
        where: { id },
        data: {
          status,
          reviewerId: req.user.id,
          reviewerComments: reviewerComments || null,
          reviewedAt,
        },
        include: { leaveType: true, employee: true },
      });

      // 2. Adjust Leave Balances
      if (balance) {
        if (status === 'APPROVED') {
          await tx.leaveBalance.update({
            where: { id: balance.id },
            data: {
              usedDays: balance.usedDays + leaveRequest.daysCount,
              pendingDays: Math.max(0, balance.pendingDays - leaveRequest.daysCount),
              remainingDays: Math.max(0, balance.remainingDays - leaveRequest.daysCount),
            },
          });
        } else if (status === 'REJECTED') {
          await tx.leaveBalance.update({
            where: { id: balance.id },
            data: {
              pendingDays: Math.max(0, balance.pendingDays - leaveRequest.daysCount),
            },
          });
        }
      }

      if (status === 'APPROVED' && leaveRequest.leaveType.code === 'CL') {
        await recordLeaveUsageInLedger({ employeeId: leaveRequest.employeeId, leaveTypeCode: 'CL', daysCount: leaveRequest.daysCount }, tx);
      }
      return updatedLeave;
    });

    await logAudit({
      userId: req.user.id,
      action: status === 'APPROVED' ? 'LEAVE_APPROVED' : 'LEAVE_REJECTED',
      entityType: 'LEAVE',
      entityId: id,
      details: {
        employeeCode: leaveRequest.employee.employeeCode,
        leaveType: leaveRequest.leaveType.name,
        daysCount: leaveRequest.daysCount,
        reviewerComments,
      },
      req,
    });

    return sendSuccess(
      res,
      updated,
      `Leave request ${status.toLowerCase()} successfully.`
    );
  } catch (error) {
    console.error('Decide leave error:', error);
    return sendError(res, 'Failed to update leave decision.', 500);
  }
}

/**
 * Cancel a pending leave request (by Employee)
 */
export async function cancelLeave(req, res) {
  try {
    const { id } = req.params;
    const employee = req.employee;

    const leave = await prisma.leaveRequest.findUnique({
      where: { id },
      include: { leaveType: true },
    });

    if (!leave) return sendError(res, 'Leave request not found.', 404);

    if (leave.employeeId !== employee.id) {
      return sendError(res, 'You are not authorized to cancel this request.', 403);
    }

    if (leave.status !== 'PENDING') {
      return sendError(res, `Cannot cancel a request that is already ${leave.status.toLowerCase()}.`, 400);
    }

    const currentYear = leave.leaveType.code === 'CL' ? dayjs().tz(DEFAULT_TZ).year() : dayjs(leave.startDate).year();
    const balance = await prisma.leaveBalance.findUnique({
      where: {
        employeeId_leaveTypeId_year: {
          employeeId: employee.id,
          leaveTypeId: leave.leaveTypeId,
          year: currentYear,
        },
      },
    });

    await prisma.$transaction(async (tx) => {
      await tx.leaveRequest.update({
        where: { id },
        data: { status: 'CANCELLED' },
      });

      if (balance) {
        await tx.leaveBalance.update({
          where: { id: balance.id },
          data: {
            pendingDays: Math.max(0, balance.pendingDays - leave.daysCount),
          },
        });
      }
    });

    return sendSuccess(res, null, 'Leave request cancelled successfully.');
  } catch (error) {
    console.error('Cancel leave error:', error);
    return sendError(res, 'Failed to cancel leave request.', 500);
  }
}

/**
 * Get all configured leave types
 */
export async function getLeaveTypes(req, res) {
  try {
    const types = await prisma.leaveType.findMany({ where: { code: { not: 'SL' } }, orderBy: { name: 'asc' } });
    return sendSuccess(res, types, 'Leave types retrieved.');
  } catch (error) {
    console.error('Get leave types error:', error);
    return sendError(res, 'Failed to retrieve leave types.', 500);
  }
}

/**
 * Get all employees with their current leave balances and monthly CL carryforward ledger (Admin / HR)
 */
export async function getAdminLeaveBalances(req, res) {
  try {
    const activeEmployees = await prisma.employee.findMany({ where: { isDeleted: false, employeeStatus: 'ACTIVE', user: { role: req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' } } }, select: { id: true } });
    for (const employee of activeEmployees) await processMonthlyClAccrualForEmployee(employee.id);
    const currentYear = new Date().getFullYear();
    const employees = await prisma.employee.findMany({
      where: {
        isDeleted: false,
        ...(req.user.role === 'HR' ? { user: { role: 'EMPLOYEE' } } : {}),
      },
      include: {
        department: true,
        designation: true,
        leaveBalances: {
          where: { year: currentYear, leaveType: { code: { not: 'SL' } } },
          include: { leaveType: true },
        },
        leaveLedgers: {
          where: { leaveTypeCode: 'CL' },
          orderBy: { monthYear: 'desc' },
          take: 12,
        },
      },
      orderBy: { employeeCode: 'asc' },
    });

    return sendSuccess(res, employees, 'Employee leave balances and ledgers retrieved.');
  } catch (error) {
    console.error('Get admin leave balances error:', error);
    return sendError(res, 'Failed to fetch employee leave balances.', 500);
  }
}

/**
 * Admin adjust/allocate an employee's leave balance (CL, SL, etc.) and record ledger adjustment
 */
export async function updateEmployeeLeaveBalance(req, res) {
  try {
    const { employeeId } = req.params;

    const {
      leaveTypeCode = 'CL',
      adjustment,
      reason,
    } = req.body;

    if (leaveTypeCode !== 'CL') return sendError(res, 'Only CL adjustments are available.', 400);
    const adjustmentValue = Number(adjustment);

    if (!Number.isFinite(adjustmentValue) || adjustmentValue === 0) {
      return sendError(
        res,
        'A valid non-zero leave adjustment is required.',
        400
      );
    }

    if (!reason?.trim()) {
      return sendError(
        res,
        'Reason is required for leave balance adjustment.',
        400
      );
    }

    const targetEmployee = await prisma.employee.findUnique({
      where: { id: employeeId },
      include: { user: true },
    });

    if (!targetEmployee || targetEmployee.isDeleted) {
      return sendError(res, 'Employee not found.', 404);
    }

    // HR can adjust regular employees only.
    if (
      req.user.role === 'HR' &&
      targetEmployee.user?.role !== 'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can adjust leave balances for employees only.',
        403
      );
    }

    // Extra protection: HR cannot adjust own balance.
    if (
      req.user.role === 'HR' &&
      req.employee?.id === targetEmployee.id
    ) {
      return sendError(
        res,
        'HR cannot adjust their own leave balance.',
        403
      );
    }

    const leaveType = await prisma.leaveType.findFirst({
      where: { code: leaveTypeCode },
    });

    if (!leaveType) {
      return sendError(res, 'Leave type not found.', 404);
    }

    await processMonthlyClAccrualForEmployee(employeeId);
    const year = dayjs().tz(DEFAULT_TZ).year();
    const currentYM = dayjs().tz(DEFAULT_TZ).format('YYYY-MM');

    const result = await prisma.$transaction(async (tx) => {
      let balance = await tx.leaveBalance.findUnique({
        where: {
          employeeId_leaveTypeId_year: {
            employeeId,
            leaveTypeId: leaveType.id,
            year,
          },
        },
      });

      if (!balance) {
        balance = await tx.leaveBalance.create({
          data: {
            employeeId,
            leaveTypeId: leaveType.id,
            year,
            totalAllocated: 0,
            usedDays: 0,
            pendingDays: 0,
            remainingDays: 0,
          },
        });
      }

      const oldBalance = Number(balance.remainingDays || 0);

      const newBalance = oldBalance + adjustmentValue;

      if (newBalance < 0) {
        throw new Error(
          `CL balance cannot be negative. Current balance: ${oldBalance}`
        );
      }

      const updatedBalance = await tx.leaveBalance.update({
        where: { id: balance.id },

        data: {
          remainingDays: newBalance,

          // Bonus/additional leave increases allocation.
          totalAllocated:
            adjustmentValue > 0
              ? Number(balance.totalAllocated || 0) +
                adjustmentValue
              : balance.totalAllocated,
        },
      });

      const existingLedger = await tx.leaveLedger.findUnique({
        where: {
          employeeId_leaveTypeCode_monthYear: {
            employeeId,
            leaveTypeCode,
            monthYear: currentYM,
          },
        },
      });

      if (existingLedger) {
        await tx.leaveLedger.update({
          where: { id: existingLedger.id },

          data: {
            adjustedDays:
              Number(existingLedger.adjustedDays || 0) +
              adjustmentValue,

            closingBalance: newBalance,

            remarks: reason.trim(),
          },
        });
      } else {
        await tx.leaveLedger.create({
          data: {
            employeeId,
            leaveTypeCode,
            monthYear: currentYM,

            openingBalance: oldBalance,
            creditedDays: 0,
            usedDays: 0,

            adjustedDays: adjustmentValue,
            closingBalance: newBalance,

            remarks: reason.trim(),
          },
        });
      }

      return {
        balance: updatedBalance,
        oldBalance,
        adjustment: adjustmentValue,
        newBalance,
      };
    });

    await logAudit({
      userId: req.user.id,
      action: 'LEAVE_BALANCE_ADJUSTED',
      entityType: 'LEAVE',
      entityId: employeeId,

      details: {
        employeeCode: targetEmployee.employeeCode,
        leaveTypeCode,
        previousBalance: result.oldBalance,
        adjustment: result.adjustment,
        newBalance: result.newBalance,
        reason: reason.trim(),
      },

      req,
    });

    return sendSuccess(
      res,
      result,
      `${leaveTypeCode} balance adjusted successfully.`
    );
  } catch (error) {
    console.error('Update leave balance error:', error);

    return sendError(
      res,
      error.message || 'Failed to update leave balance.',
      500
    );
  }
}