import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { logAudit } from '../services/auditService.js';

/**
 * Get all configured shifts with active employee counts
 */
export async function getAllShifts(req, res) {
  try {
    const shifts = await prisma.shift.findMany({
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: {
            assignments: {
              where: { effectiveTo: null },
            },
          },
        },
      },
    });

    const formatted = shifts.map((s) => ({
      ...s,
      weeklyOffDays: typeof s.weeklyOffDays === 'string' ? JSON.parse(s.weeklyOffDays) : s.weeklyOffDays,
      activeEmployeesCount: s._count.assignments,
    }));

    return sendSuccess(res, formatted, 'Shifts retrieved successfully.');
  } catch (error) {
    console.error('Get shifts error:', error);
    return sendError(res, 'Failed to retrieve shifts.', 500);
  }
}

/**
 * Create a new shift (Admin)
 */
export async function createShift(req, res) {
  try {
    const {
      name,
      startTime,
      endTime,
      gracePeriodMinutes = 10,
      breakDurationMinutes = 60,
      requiredWorkMinutes = 480,
      isOvernight = false,
      weeklyOffDays = ['SUNDAY'],
      overtimeEnabled = true,
    } = req.body;

    const existing = await prisma.shift.findUnique({ where: { name } });
    if (existing) {
      return sendError(res, `A shift with name '${name}' already exists.`, 409);
    }

    const shift = await prisma.shift.create({
      data: {
        name,
        startTime,
        endTime,
        gracePeriodMinutes,
        breakDurationMinutes,
        requiredWorkMinutes,
        isOvernight: isOvernight || endTime < startTime,
        weeklyOffDays: JSON.stringify(weeklyOffDays),
        overtimeEnabled,
      },
    });

    await logAudit({
      userId: req.user.id,
      action: 'SHIFT_CREATED',
      entityType: 'SHIFT',
      entityId: shift.id,
      details: { name, startTime, endTime },
      req,
    });

    return sendSuccess(res, shift, `Shift '${name}' created successfully.`, 201);
  } catch (error) {
    console.error('Create shift error:', error);
    return sendError(res, 'Failed to create shift.', 500);
  }
}

/**
 * Update shift configuration (Admin)
 */
export async function updateShift(req, res) {
  try {
    const { id } = req.params;
    const {
      name,
      startTime,
      endTime,
      gracePeriodMinutes,
      breakDurationMinutes,
      requiredWorkMinutes,
      isOvernight,
      weeklyOffDays,
      overtimeEnabled,
    } = req.body;

    const existing = await prisma.shift.findUnique({ where: { id } });
    if (!existing) {
      return sendError(res, 'Shift not found.', 404);
    }

    const updateData = {};
    if (name) updateData.name = name;
    if (startTime) updateData.startTime = startTime;
    if (endTime) updateData.endTime = endTime;
    if (gracePeriodMinutes !== undefined) updateData.gracePeriodMinutes = gracePeriodMinutes;
    if (breakDurationMinutes !== undefined) updateData.breakDurationMinutes = breakDurationMinutes;
    if (requiredWorkMinutes !== undefined) updateData.requiredWorkMinutes = requiredWorkMinutes;
    if (isOvernight !== undefined) updateData.isOvernight = isOvernight;
    if (weeklyOffDays !== undefined) updateData.weeklyOffDays = JSON.stringify(weeklyOffDays);
    if (overtimeEnabled !== undefined) updateData.overtimeEnabled = overtimeEnabled;

    const updated = await prisma.shift.update({
      where: { id },
      data: updateData,
    });

    await logAudit({
      userId: req.user.id,
      action: 'SHIFT_UPDATED',
      entityType: 'SHIFT',
      entityId: id,
      details: { updatedFields: req.body },
      req,
    });

    return sendSuccess(res, updated, `Shift '${updated.name}' updated successfully.`);
  } catch (error) {
    console.error('Update shift error:', error);
    return sendError(res, 'Failed to update shift.', 500);
  }
}

/**
 * Delete a shift if no active employees or records depend on it
 */
export async function deleteShift(req, res) {
  try {
    const { id } = req.params;

    const activeAssignments = await prisma.employeeShiftAssignment.count({
      where: { shiftId: id, effectiveTo: null },
    });

    if (activeAssignments > 0) {
      return sendError(
        res,
        `Cannot delete this shift because ${activeAssignments} employee(s) are currently assigned to it. Reassign employees first.`,
        400
      );
    }

    await prisma.shift.delete({ where: { id } });

    await logAudit({
      userId: req.user.id,
      action: 'SHIFT_DELETED',
      entityType: 'SHIFT',
      entityId: id,
      req,
    });

    return sendSuccess(res, null, 'Shift deleted successfully.');
  } catch (error) {
    console.error('Delete shift error:', error);
    return sendError(res, 'Failed to delete shift.', 500);
  }
}
