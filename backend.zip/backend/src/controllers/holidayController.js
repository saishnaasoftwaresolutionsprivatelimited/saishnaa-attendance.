import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';

export async function getHolidays(req, res) {
  try {
    const holidays = await prisma.holiday.findMany({
      where: req.query.year && /^\d{4}$/.test(req.query.year) ? { date: { startsWith: `${req.query.year}-` } } : {},
      orderBy: { date: 'asc' },
    });
    return sendSuccess(res, holidays, 'Holidays retrieved.');
  } catch (error) {
    console.error('Get holidays error:', error);
    return sendError(res, 'Failed to fetch holidays.', 500);
  }
}

export async function createHoliday(req, res) {
  try {
    const { name, date, isOptional = false } = req.body;
    if (typeof name !== 'string' || !name.trim() || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0, 10) !== date) {
      return sendError(res, 'Holiday name and date are required.', 400);
    }

    const holiday = await prisma.holiday.create({
      data: {
        name: name.trim(),
        date,
        isOptional: Boolean(isOptional),
      },
    });

    return sendSuccess(res, holiday, 'Holiday created successfully.', 201);
  } catch (error) {
    console.error('Create holiday error:', error);
    return sendError(res, 'Failed to create holiday.', 500);
  }
}

export async function deleteHoliday(req, res) {
  try {
    const { id } = req.params;
    await prisma.holiday.delete({ where: { id } });
    return sendSuccess(res, null, 'Holiday deleted successfully.');
  } catch (error) {
    console.error('Delete holiday error:', error);
    return sendError(res, 'Failed to delete holiday.', 500);
  }
}
