import { canAuthorizePayment, canReadEmployee } from '../services/accessPolicy.js';
import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { calculateEmployeePayroll } from '../services/salaryCalculationEngine.js';
import { processMonthlyClAccrualForEmployee } from '../services/clAccrualService.js';
import { generatePayslipPdf } from '../services/payslipPdfService.js';
import {
  getCompanySettings,
  updateCompanySettings,
} from '../services/companySettingsService.js';
import { logAudit } from '../services/auditService.js';
import dayjs from 'dayjs';

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function roundMoney(value) {
  return Number(Number(value || 0).toFixed(2));
}

function payrollDataFromEngine(payrollLine) {
  /*
   * IMPORTANT:
   * Only fields that actually exist in PayrollCalculation
   * are persisted here.
   *
   * eligibleDays and dailyBreakdown are intentionally excluded
   * because they are not columns in the current Prisma model.
   */
  return {
    monthlySalary: roundMoney(payrollLine.monthlySalary),
    dailySalary: roundMoney(payrollLine.dailySalary),

    divisorMethod: payrollLine.divisorMethod || 'FIXED_30',
    divisorUsed: Number(payrollLine.divisorUsed || 30),

    totalCalendarDays: Number(payrollLine.totalCalendarDays || 30),

    payableDays: Number(payrollLine.payableDays || 0),
    presentDays: Number(payrollLine.presentDays || 0),
    halfDays: Number(payrollLine.halfDays || 0),

    paidLeaveDays: Number(payrollLine.paidLeaveDays || 0),
    approvedOdDays: Number(payrollLine.approvedOdDays || 0),

    paidHolidaysCount: Number(
      payrollLine.paidHolidaysCount || 0
    ),

    paidWeeklyOffsCount: Number(
      payrollLine.paidWeeklyOffsCount || 0
    ),

    unpaidLeaveDays: Number(
      payrollLine.unpaidLeaveDays || 0
    ),

    absentDays: Number(payrollLine.absentDays || 0),

    /*
     * Future projection is removed from payroll.
     * Keep database field only for backward compatibility.
     */
    scheduledDays: 0,

    incompleteDays: Number(
      payrollLine.incompleteDays || 0
    ),

    lateDaysCount: Number(
      payrollLine.lateDaysCount || 0
    ),

    lateAllowanceConsumed: Number(
      payrollLine.lateAllowanceConsumed || 0
    ),

    lateDeductions: roundMoney(
      payrollLine.lateDeductions
    ),

    permissionCount: Number(
      payrollLine.permissionCount || 0
    ),

    permissionDeductions: roundMoney(
      payrollLine.permissionDeductions
    ),

    /*
     * Overtime removed from company payroll.
     * Fields remain in DB only for compatibility.
     */
    overtimeHours: 0,
    overtimePay: 0,

    additionalEarnings: roundMoney(
      payrollLine.additionalEarnings
    ),

    absenceDeductions: roundMoney(
      payrollLine.absenceDeductions
    ),

    unpaidLeaveDeductions: roundMoney(
      payrollLine.unpaidLeaveDeductions
    ),

    otherDeductions: roundMoney(
      payrollLine.otherDeductions
    ),

    grossEarnings: roundMoney(
      payrollLine.grossEarnings
    ),

    totalDeductions: roundMoney(
      payrollLine.totalDeductions
    ),

    netSalary: roundMoney(
      payrollLine.netSalary
    ),
  };
}

function visibleCalculationWhere(role) {
  if (role === 'HR') {
    return {
      employee: {
        user: {
          role: 'EMPLOYEE',
        },
      },
    };
  }

  return {
    NOT: {
      employee: {
        user: {
          role: 'ADMIN',
        },
      },
    },
  };
}

function employeeSelect() {
  return {
    id: true,
    employeeCode: true,
    fullName: true,

    department: {
      select: {
        name: true,
      },
    },

    designation: {
      select: {
        title: true,
      },
    },

    salaryConfig: {
      select: {
        bankName: true,
        accountNumber: true,
        paymentMethod: true,
      },
    },

    user: {
      select: {
        role: true,
      },
    },
  };
}

/*
|--------------------------------------------------------------------------
| Calculate Payroll
|--------------------------------------------------------------------------
|
| Rules:
| - Admin can calculate Employee + HR payroll
| - HR can calculate Employee payroll only
| - Fixed 30-day salary calculation comes from salaryCalculationEngine
| - Joining date handled by engine
| - Future dates excluded
| - No PROJECTED payroll
| - No overtime
| - Recalculation is idempotent
|
*/

export async function calculatePayroll(req, res) {
  try {
    const year =
      Number(req.body.year) || dayjs().year();

    const month =
      Number(req.body.month) ||
      dayjs().month() + 1;

    if (
      !Number.isInteger(year) ||
      !Number.isInteger(month) ||
      month < 1 ||
      month > 12
    ) {
      return sendError(
        res,
        'Invalid payroll month or year.',
        400
      );
    }

    const monthStr =
      `${year}-${String(month).padStart(2, '0')}`;

    const actualDaysInMonth = dayjs(
      `${monthStr}-01`
    ).daysInMonth();

    const startDate = `${monthStr}-01`;

    const endDate =
      `${monthStr}-${String(actualDaysInMonth).padStart(2, '0')}`;

    /*
     * Prevent accidentally calculating a completely future month.
     */
    const selectedMonthStart = dayjs(startDate);
    const currentMonthStart = dayjs().startOf('month');

    if (
      selectedMonthStart.isAfter(
        currentMonthStart,
        'month'
      )
    ) {
      return sendError(
        res,
        'Future month payroll cannot be calculated.',
        400
      );
    }

    /*
     * Find or create Payroll Period
     */
    let period =
      await prisma.payrollPeriod.findUnique({
        where: {
          monthYear: monthStr,
        },
      });

    if (!period) {
      period =
        await prisma.payrollPeriod.create({
          data: {
            monthYear: monthStr,
            startDate,
            endDate,

            /*
             * Calendar month metadata.
             * Salary divisor remains fixed at 30 in engine.
             */
            totalCalendarDays:
              actualDaysInMonth,

            status: 'CALCULATED',
            generatedAt: new Date(),
          },
        });
    }

    /*
     * If payroll was already approved,
     * don't silently overwrite finalized values.
     */
    if (period.status === 'ADMIN_APPROVED') {
      return sendError(
        res,
        'This payroll period is already approved. Reopen or edit the required employee calculation before recalculating.',
        409
      );
    }

    /*
     * Active employees
     *
     * HR:
     *   Employee payroll only
     *
     * Admin:
     *   Employee + HR payroll
     *   ADMIN account excluded
     */
    const employees =
      await prisma.employee.findMany({
        where: {
          isDeleted: false,
          employeeStatus: 'ACTIVE',

          user:
            req.user.role === 'HR'
              ? {
                  role: 'EMPLOYEE',
                }
              : {
                  role: {
                    not: 'ADMIN',
                  },
                },
        },

        include: {
          department: true,
          designation: true,
          branch: true,
          salaryConfig: true,
          user: true,
        },

        orderBy: {
          employeeCode: 'asc',
        },
      });

    /*
     * Fetch monthly data in parallel
     */
    const [
      allAttendance,
      allLeaves,
      allOnDuties,
      allHolidays,
    ] = await Promise.all([
      prisma.attendanceRecord.findMany({
        where: {
          workDate: {
            startsWith: monthStr,
          },
        },
      }),

      prisma.leaveRequest.findMany({
        where: {
          leaveType: { code: { not: 'SL' } },
          status: 'APPROVED',

          startDate: {
            lte: endDate,
          },

          endDate: {
            gte: startDate,
          },
        },

        include: {
          leaveType: true,
        },
      }),

      prisma.onDutyRequest.findMany({
        where: {
          status: 'APPROVED',

          odDate: {
            startsWith: monthStr,
          },
        },
      }),

      prisma.holiday.findMany({
        where: {
          date: {
            startsWith: monthStr,
          },
        },
      }),
    ]);

    let totalGross = 0;
    let totalNet = 0;

    const calculationResults = [];

    /*
     * Process employee-by-employee
     */
    for (const emp of employees) {
      /*
       * Monthly CL accrual remains idempotent.
       */
      await processMonthlyClAccrualForEmployee(
        emp.id,
        monthStr
      );

      const empAttendance =
        allAttendance.filter(
          (record) =>
            record.employeeId === emp.id
        );

      const empLeaves =
        allLeaves.filter(
          (leave) =>
            leave.employeeId === emp.id
        );

      const empOD =
        allOnDuties.filter(
          (od) =>
            od.employeeId === emp.id
        );

      /*
       * Default salary configuration
       *
       * FIXED 30 calculation is enforced by
       * salaryCalculationEngine.
       */
      const salaryConfig =
        emp.salaryConfig || {
          monthlySalary: 20000,
          calculationMethod:
            'CALENDAR_DAYS',
          customDivisor: 30,
          lateAttendanceAllowance: 2,
          permissionAllowancePerMonth: 1,
        };

      const payrollLine =
        calculateEmployeePayroll({
          employee: emp,
          salaryConfig,

          attendanceRecords:
            empAttendance,

          approvedLeaves:
            empLeaves,

          approvedOnDuties:
            empOD,

          holidays:
            allHolidays,

          year,
          month,
        });

      /*
       * THIS FIXES THE OLD:
       *
       * ReferenceError:
       * calcData is not defined
       */
      const calcData =
        payrollDataFromEngine(
          payrollLine
        );

      const payslipNumber =
        `PAY-${year}${String(month).padStart(2, '0')}-${emp.employeeCode}`;

      /*
       * Future-day PROJECTED status removed.
       *
       * Current-to-date calculation is simply
       * CALCULATED.
       */
      const calculationStatus =
        'CALCULATED';

      const savedCalc =
        await prisma.payrollCalculation.upsert({
          where: {
            employeeId_monthYear: {
              employeeId: emp.id,
              monthYear: monthStr,
            },
          },

          update: {
            ...calcData,

            payrollPeriodId:
              period.id,

            status:
              calculationStatus,

            /*
             * Recalculation does not automatically
             * modify payment information.
             */
          },

          create: {
            ...calcData,

            payrollPeriodId:
              period.id,

            employeeId:
              emp.id,

            monthYear:
              monthStr,

            payslipNumber,

            status:
              calculationStatus,
          },
        });

      totalGross += Number(
        payrollLine.grossEarnings || 0
      );

      totalNet += Number(
        payrollLine.netSalary || 0
      );

      calculationResults.push(
        savedCalc
      );
    }

    /*
     * Update period totals
     */
    const updatedPeriod =
      await prisma.payrollPeriod.update({
        where: {
          id: period.id,
        },

        data: {
          totalGrossPayout:
            roundMoney(totalGross),

          totalNetPayout:
            roundMoney(totalNet),

          totalEmployees:
            employees.length,

          /*
           * PROJECTED removed.
           */
          status: 'CALCULATED',

          generatedAt:
            new Date(),
        },
      });

    await logAudit({
      userId: req.user.id,

      action:
        'PAYROLL_CALCULATED',

      entityType:
        'PAYROLL_PERIOD',

      entityId:
        updatedPeriod.id,

      details: {
        monthYear: monthStr,

        calculationsCount:
          calculationResults.length,

        performedByRole:
          req.user.role,

        calculationMode:
          'CURRENT_DATE_ONLY',

        salaryDivisor: 30,
      },

      req,
    });

    return sendSuccess(
      res,
      {
        period:
          updatedPeriod,

        calculationsCount:
          calculationResults.length,
      },

      `Payroll calculated successfully for ${monthStr}. Future dates are not included.`
    );
  } catch (error) {
    console.error(
      'Calculate payroll error:',
      error
    );

    return sendError(
      res,
      error?.message ||
        'Failed to calculate monthly payroll.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Payroll Period List
|--------------------------------------------------------------------------
*/

export async function getPayrollPeriods(
  req,
  res
) {
  try {
    const { year } = req.query;

    const where = {};

    if (year) {
      where.monthYear = {
        startsWith: String(year),
      };
    }

    const calculationWhere =
      visibleCalculationWhere(
        req.user.role
      );

    const periods =
      await prisma.payrollPeriod.findMany({
        where,

        orderBy: {
          monthYear: 'desc',
        },

        include: {
          approvedBy: {
            select: {
              email: true,

              employee: {
                select: {
                  fullName: true,
                },
              },
            },
          },

          calculations: {
            where:
              calculationWhere,

            include: {
              employee: {
                select:
                  employeeSelect(),
              },
            },

            orderBy: {
              employee: {
                employeeCode:
                  'asc',
              },
            },
          },
        },
      });

    const enriched =
      periods.map((period) => {
        const parts =
          (
            period.monthYear || ''
          ).split('-');

        const parsedYear =
          parseInt(
            parts[0],
            10
          );

        const parsedMonth =
          parseInt(
            parts[1],
            10
          );

        /*
         * HR sees only employee payroll.
         * Therefore recalculate visible totals
         * from the filtered calculations.
         */
        const visibleGross =
          period.calculations.reduce(
            (sum, calc) =>
              sum +
              Number(
                calc.grossEarnings ||
                  0
              ),
            0
          );

        const visibleNet =
          period.calculations.reduce(
            (sum, calc) =>
              sum +
              Number(
                calc.netSalary ||
                  0
              ),
            0
          );

        return {
          ...period,

          ...(req.user.role ===
          'HR'
            ? {
                totalGrossPayout:
                  roundMoney(
                    visibleGross
                  ),

                totalNetPayout:
                  roundMoney(
                    visibleNet
                  ),

                totalEmployees:
                  period
                    .calculations
                    .length,
              }
            : {}),

          year:
            Number.isNaN(
              parsedYear
            )
              ? undefined
              : parsedYear,

          month:
            Number.isNaN(
              parsedMonth
            )
              ? undefined
              : parsedMonth,
        };
      });

    return sendSuccess(
      res,
      enriched,
      'Payroll periods retrieved.'
    );
  } catch (error) {
    console.error(
      'Get payroll periods error:',
      error
    );

    return sendError(
      res,
      'Failed to fetch payroll periods.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Payroll Period Details
|--------------------------------------------------------------------------
*/

export async function getPayrollPeriodDetails(
  req,
  res
) {
  try {
    const { id } = req.params;

    const calculationWhere =
      visibleCalculationWhere(
        req.user.role
      );

    const period =
      await prisma.payrollPeriod.findUnique({
        where: {
          id,
        },

        include: {
          approvedBy: {
            select: {
              email: true,

              employee: {
                select: {
                  fullName: true,
                },
              },
            },
          },

          calculations: {
            where:
              calculationWhere,

            include: {
              employee: {
                select:
                  employeeSelect(),
              },
            },

            orderBy: {
              employee: {
                employeeCode:
                  'asc',
              },
            },
          },
        },
      });

    if (!period) {
      return sendError(
        res,
        'Payroll period not found.',
        404
      );
    }

    let visiblePeriod =
      period;

    if (req.user.role === 'HR') {
      const totalGross =
        period.calculations.reduce(
          (sum, calc) =>
            sum +
            Number(
              calc.grossEarnings ||
                0
            ),
          0
        );

      const totalNet =
        period.calculations.reduce(
          (sum, calc) =>
            sum +
            Number(
              calc.netSalary ||
                0
            ),
          0
        );

      visiblePeriod = {
        ...period,

        totalGrossPayout:
          roundMoney(totalGross),

        totalNetPayout:
          roundMoney(totalNet),

        totalEmployees:
          period.calculations.length,
      };
    }

    return sendSuccess(
      res,
      visiblePeriod,
      'Payroll period details retrieved.'
    );
  } catch (error) {
    console.error(
      'Get payroll period details error:',
      error
    );

    return sendError(
      res,
      'Failed to fetch payroll period details.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Approve Payroll
|--------------------------------------------------------------------------
|
| Admin only - enforced by payrollRoutes.js
|
| OLD PROJECTED / SCHEDULED DAYS LOCK REMOVED.
|
*/

export async function approvePayrollPeriod(
  req,
  res
) {
  try {
    const { id } = req.params;

    const {
      status = 'ADMIN_APPROVED',
    } = req.body;

    if (
      status !==
      'ADMIN_APPROVED'
    ) {
      return sendError(
        res,
        'Payroll approval can only set ADMIN_APPROVED status.',
        400
      );
    }

    const existingPeriod =
      await prisma.payrollPeriod.findUnique({
        where: {
          id,
        },

        include: {
          calculations: {
            select: {
              id: true,
              status: true,
            },
          },
        },
      });

    if (!existingPeriod) {
      return sendError(
        res,
        'Payroll period not found.',
        404
      );
    }

    if (
      existingPeriod
        .calculations.length === 0
    ) {
      return sendError(
        res,
        'Calculate payroll before approving it.',
        409
      );
    }

    if (
      existingPeriod.status ===
      'ADMIN_APPROVED'
    ) {
      return sendSuccess(
        res,
        existingPeriod,
        'Payroll is already approved.'
      );
    }

    /*
     * NO:
     * - PROJECTED check
     * - scheduledDays check
     * - month-end restriction
     *
     * Payroll represents current-to-date
     * calculated values.
     */
    const [
      period,
    ] = await prisma.$transaction([
      prisma.payrollPeriod.update({
        where: {
          id,
        },

        data: {
          status:
            'ADMIN_APPROVED',

          approvedAt:
            new Date(),

          approvedById:
            req.user.id,
        },
      }),

      prisma.payrollCalculation.updateMany({
        where: {
          payrollPeriodId:
            id,
        },

        data: {
          status:
            'ADMIN_APPROVED',
        },
      }),
    ]);

    await logAudit({
      userId:
        req.user.id,

      action:
        'PAYROLL_APPROVED',

      entityType:
        'PAYROLL_PERIOD',

      entityId:
        id,

      details: {
        monthYear:
          existingPeriod.monthYear,

        calculationsCount:
          existingPeriod
            .calculations
            .length,
      },

      req,
    });

    return sendSuccess(
      res,
      period,
      'Payroll approved successfully.'
    );
  } catch (error) {
    console.error(
      'Approve payroll error:',
      error
    );

    return sendError(
      res,
      'Failed to approve payroll.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Record Employee Payment
|--------------------------------------------------------------------------
*/

export async function recordPayment(
  req,
  res
) {
  try {
    if (!canAuthorizePayment(req.user)) return sendError(res, 'Payment authorization denied.', 403);
    const {
      calculationId,
    } = req.params;

    const {
      paymentMethod,
      paymentReference,
      paymentNotes,
      status = 'PAID',
    } = req.body;

    const calculation =
      await prisma.payrollCalculation.findUnique({
        where: {
          id: calculationId,
        },

        include: {
          payrollPeriod: true,
          employee: { include: { user: { select: { role: true } } } },
        },
      });

    if (!calculation) {
      return sendError(
        res,
        'Payroll calculation record not found.',
        404
      );
    }

    if (req.user.role !== 'ADMIN' && (calculation.employeeId === req.user.employeeId || calculation.employee.user?.role !== 'EMPLOYEE')) return sendError(res, 'Paying Authority cannot authorize their own or privileged accounts payments.', 403);

    /*
     * Payment only after Admin approval.
     */
    if (
      calculation
        .payrollPeriod
        .status !==
      'ADMIN_APPROVED'
    ) {
      return sendError(
        res,
        'Payment can be recorded after Admin approves the calculated salary.',
        409
      );
    }

    const allowedStatuses = [
      'PAYMENT_PENDING',
      'PAYMENT_PROCESSING',
      'PAID',
      'PAYMENT_FAILED',
    ];

    if (
      !allowedStatuses.includes(
        status
      )
    ) {
      return sendError(
        res,
        'Invalid payment status.',
        400
      );
    }

    const updated =
      await prisma.payrollCalculation.update({
        where: {
          id: calculationId,
        },

        data: {
          paymentMethod:
            paymentMethod ||
            calculation.paymentMethod ||
            'BANK_TRANSFER',

          paymentReference:
            paymentReference ||
            null,

          paymentNotes:
            paymentNotes ||
            null,

          paymentDate:
            status === 'PAID'
              ? new Date()
              : null,

          status,
        },
      });

    /*
     * If every calculation in the period is PAID,
     * mark the period PAID.
     */
    const remainingUnpaid =
      await prisma.payrollCalculation.count({
        where: {
          payrollPeriodId:
            calculation.payrollPeriodId,

          status: {
            not: 'PAID',
          },

          NOT: {
            employee: {
              user: {
                role: 'ADMIN',
              },
            },
          },
        },
      });

    if (
      remainingUnpaid === 0
    ) {
      await prisma.payrollPeriod.update({
        where: {
          id:
            calculation.payrollPeriodId,
        },

        data: {
          status: 'PAID',
        },
      });
    }

    await logAudit({
      userId:
        req.user.id,

      action:
        'PAYROLL_PAYMENT_RECORDED',

      entityType:
        'PAYROLL_CALCULATION',

      entityId:
        calculationId,

      details: {
        employeeCode:
          calculation.employee
            ?.employeeCode,

        paymentMethod:
          updated.paymentMethod,

        paymentReference:
          updated.paymentReference,

        status:
          updated.status,
      },

      req,
    });

    return sendSuccess(
      res,
      updated,
      'Payment recorded successfully.'
    );
  } catch (error) {
    console.error(
      'Record payment error:',
      error
    );

    return sendError(
      res,
      'Failed to record payment.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Employee Payslips
|--------------------------------------------------------------------------
*/

export async function getMyPayslips(
  req,
  res
) {
  try {
    let employee =
      req.employee ||
      req.user?.employee ||
      null;

    if (
      !employee &&
      req.user?.employeeId
    ) {
      employee =
        await prisma.employee.findUnique({
          where: {
            id:
              req.user.employeeId,
          },
        });
    }

    if (!employee) {
      return sendError(
        res,
        'Employee record not found.',
        404
      );
    }

    const payslips =
      await prisma.payrollCalculation.findMany({
        where: {
          employeeId:
            employee.id,
        },

        orderBy: {
          monthYear: 'desc',
        },

        include: {
          payrollPeriod: {
            select: {
              id: true,
              status: true,
              monthYear: true,
              startDate: true,
              endDate: true,
              approvedAt: true,
            },
          },
        },
      });

    const enriched =
      payslips.map(
        (payslip) => {
          const periodValue =
            payslip.monthYear ||
            payslip
              .payrollPeriod
              ?.monthYear ||
            '';

          const [
            yearText,
            monthText,
          ] =
            periodValue.split(
              '-'
            );

          const year =
            parseInt(
              yearText,
              10
            );

          const month =
            parseInt(
              monthText,
              10
            );

          return {
            ...payslip,

            year:
              Number.isNaN(year)
                ? undefined
                : year,

            month:
              Number.isNaN(month)
                ? undefined
                : month,

            grossSalary:
              payslip.grossEarnings,

            paymentStatus:
              payslip.status,

            payrollPeriod: {
              ...(
                payslip.payrollPeriod ||
                {}
              ),

              year:
                Number.isNaN(
                  year
                )
                  ? undefined
                  : year,

              month:
                Number.isNaN(
                  month
                )
                  ? undefined
                  : month,
            },
          };
        }
      );

    return sendSuccess(
      res,
      enriched,
      'Payslips retrieved.'
    );
  } catch (error) {
    console.error(
      'Get my payslips error:',
      error
    );

    return sendError(
      res,
      'Failed to fetch payslips.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Download Payslip PDF
|--------------------------------------------------------------------------
*/

export async function downloadPayslipPdf(
  req,
  res
) {
  try {
    const { id } =
      req.params;

    const calculation =
      await prisma.payrollCalculation.findUnique({
        where: {
          id,
        },

        include: {
          employee: {
            include: {
              department: true,
              designation: true,
            },
          },

          payrollPeriod: true,
        },
      });

    if (!calculation) {
      return sendError(
        res,
        'Payslip not found.',
        404
      );
    }

    /*
     * Employee:
     * own payslip only
     *
     * HR/Admin:
     * allowed by current application design
     */
    const employeeId =
      req.employee?.id ||
      req.user?.employeeId ||
      req.user?.employee?.id;

    const isOwner =
      employeeId ===
      calculation.employeeId;

    const isAdminOrHR =
      req.user.role ===
        'ADMIN' ||
      req.user.role ===
        'HR';

    if (
      !isOwner &&
      !isAdminOrHR
    ) {
      return sendError(
        res,
        'Unauthorized to view this payslip.',
        403
      );
    }

    /*
     * HR cannot download HR payroll.
     */
    if (
      req.user.role === 'HR' && !isOwner
    ) {
      const targetUser =
        await prisma.user.findUnique({
          where: {
            employeeId:
              calculation.employeeId,
          },

          select: {
            role: true,
          },
        });

      if (
        targetUser?.role !==
        'EMPLOYEE'
      ) {
        return sendError(
          res,
          'HR can access employee payslips only.',
          403
        );
      }
    }

    const salaryConfig =
      await prisma.salaryConfiguration.findUnique({
        where: {
          employeeId:
            calculation.employeeId,
        },
      });

    const companyInfo =
      getCompanySettings();

    const pdfBuffer =
      await generatePayslipPdf({
        payrollCalculation:
          calculation,

        employee:
          calculation.employee,

        salaryConfig,

        companyInfo,
      });

    const safePayslipNumber =
      calculation.payslipNumber ||
      calculation.id;

    const filename =
      `Payslip_${safePayslipNumber}.pdf`;

    res.setHeader(
      'Content-Type',
      'application/pdf'
    );

    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${filename}"`
    );

    return res.send(
      pdfBuffer
    );
  } catch (error) {
    console.error(
      'Download payslip PDF error:',
      error
    );

    return sendError(
      res,
      'Failed to generate payslip PDF.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Company Branding / Payslip Settings
|--------------------------------------------------------------------------
*/

export async function getCompanyBranding(
  req,
  res
) {
  try {
    const settings =
      getCompanySettings();

    return sendSuccess(
      res,
      settings,
      'Company branding settings retrieved.'
    );
  } catch (error) {
    console.error(
      'Get company branding error:',
      error
    );

    return sendError(
      res,
      'Failed to fetch company branding settings.',
      500
    );
  }
}

export async function updateCompanyBranding(
  req,
  res
) {
  try {
    const updated =
      await updateCompanySettings(
        req.body
      );

    await logAudit({
      userId:
        req.user.id,

      action:
        'COMPANY_SETTINGS_UPDATED',

      entityType:
        'COMPANY_SETTINGS',

      entityId:
        null,

      details: {
        updatedByRole:
          req.user.role,
      },

      req,
    });

    return sendSuccess(
      res,
      updated,
      'Company and payslip settings updated successfully.'
    );
  } catch (error) {
    console.error(
      'Update company settings error:',
      error
    );

    return sendError(
      res,
      error.message ||
        'Failed to update company settings.',
      500
    );
  }
}

/*
|--------------------------------------------------------------------------
| Manual Payroll Correction
|--------------------------------------------------------------------------
|
| Admin:
|   Employee + HR payroll
|
| HR:
|   Employee payroll only
|
*/

export async function updatePayrollCalculation(
  req,
  res
) {
  try {
    const {
      calculationId,
    } = req.params;

    const {
      payableDays,
      absentDays,
      totalDeductions,
      netSalary,
      status,
      paymentNotes,
    } = req.body;

    const existing =
      await prisma.payrollCalculation.findUnique({
        where: {
          id: calculationId,
        },

        include: {
          payrollPeriod: true,

          employee: {
            include: {
              user: true,
            },
          },
        },
      });

    if (!existing) {
      return sendError(
        res,
        'Payroll calculation record not found.',
        404
      );
    }

    /*
     * HR cannot edit HR payroll.
     */
    if (
      req.user.role ===
        'HR' &&
      existing.employee
        ?.user?.role !==
        'EMPLOYEE'
    ) {
      return sendError(
        res,
        'HR can update employee payroll calculations only.',
        403
      );
    }

    /*
     * Approved / paid payroll should not be
     * silently modified.
     */
    if (
      existing
        .payrollPeriod
        ?.status ===
        'ADMIN_APPROVED' ||
      existing
        .payrollPeriod
        ?.status ===
        'PAID'
    ) {
      return sendError(
        res,
        'Approved or paid payroll cannot be edited directly.',
        409
      );
    }

    if (status && !['DRAFT', 'PROJECTED', 'CALCULATED', 'HR_REVIEWED'].includes(status)) return sendError(res, 'Invalid review status.', 400);
    const forbiddenStatuses = [
      'ADMIN_APPROVED',
      'PAYMENT_PENDING',
      'PAYMENT_PROCESSING',
      'PAID',
      'PAYMENT_FAILED',
    ];

    if (
      status &&
      forbiddenStatuses.includes(
        status
      )
    ) {
      return sendError(
        res,
        'Final approval and payment statuses must use the Admin approval/payment workflow.',
        400
      );
    }

    const dataToUpdate =
      {};

    if (
      payableDays !==
      undefined
    ) {
      const value =
        Number(payableDays);

      if (
        Number.isNaN(value) ||
        value < 0
      ) {
        return sendError(
          res,
          'Invalid payable days.',
          400
        );
      }

      dataToUpdate.payableDays =
        value;
    }

    if (
      absentDays !==
      undefined
    ) {
      const value =
        Number(absentDays);

      if (
        Number.isNaN(value) ||
        value < 0
      ) {
        return sendError(
          res,
          'Invalid absent days.',
          400
        );
      }

      dataToUpdate.absentDays =
        value;
    }

    if (
      totalDeductions !==
      undefined
    ) {
      const value =
        Number(
          totalDeductions
        );

      if (
        Number.isNaN(value) ||
        value < 0
      ) {
        return sendError(
          res,
          'Invalid deduction amount.',
          400
        );
      }

      dataToUpdate.totalDeductions =
        roundMoney(value);
    }

    if (
      netSalary !==
      undefined
    ) {
      const value =
        Number(netSalary);

      if (
        Number.isNaN(value) ||
        value < 0
      ) {
        return sendError(
          res,
          'Invalid net salary.',
          400
        );
      }

      dataToUpdate.netSalary =
        roundMoney(value);
    }

    if (status) {
      dataToUpdate.status =
        status;
    }

    if (
      paymentNotes !==
      undefined
    ) {
      dataToUpdate.paymentNotes =
        String(
          paymentNotes || ''
        ).trim();
    }

    if (
      Object.keys(
        dataToUpdate
      ).length === 0
    ) {
      return sendError(
        res,
        'No payroll changes were provided.',
        400
      );
    }

    const updated =
      await prisma.payrollCalculation.update({
        where: {
          id: calculationId,
        },

        data:
          dataToUpdate,

        include: {
          employee: {
            select:
              employeeSelect(),
          },
        },
      });

    /*
     * Recompute parent period totals.
     */
    const allPeriodCalcs =
      await prisma.payrollCalculation.findMany({
        where: {
          payrollPeriodId:
            existing.payrollPeriodId,

          NOT: {
            employee: {
              user: {
                role: 'ADMIN',
              },
            },
          },
        },
      });

    const totalGross =
      allPeriodCalcs.reduce(
        (sum, calc) =>
          sum +
          Number(
            calc.grossEarnings ||
              0
          ),
        0
      );

    const totalNet =
      allPeriodCalcs.reduce(
        (sum, calc) =>
          sum +
          Number(
            calc.netSalary ||
              0
          ),
        0
      );

    await prisma.payrollPeriod.update({
      where: {
        id:
          existing.payrollPeriodId,
      },

      data: {
        totalGrossPayout:
          roundMoney(totalGross),

        totalNetPayout:
          roundMoney(totalNet),

        totalEmployees:
          allPeriodCalcs.length,
      },
    });

    await logAudit({
      userId:
        req.user.id,

      action:
        'PAYROLL_CALCULATION_OVERRIDE',

      entityType:
        'PAYROLL_CALCULATION',

      entityId:
        calculationId,

      details: {
        employee:
          existing.employee
            ?.employeeCode,

        changes:
          dataToUpdate,

        performedByRole:
          req.user.role,
      },

      req,
    });

    return sendSuccess(
      res,
      updated,
      'Payroll calculation updated successfully.'
    );
  } catch (error) {
    console.error(
      'Update payroll calculation error:',
      error
    );

    return sendError(
      res,
      'Failed to update payroll calculation.',
      500
    );
  }
}