import prisma from '../config/db.js';
import { generateExcelReport } from '../services/excelReportService.js';
import { generatePdfReport } from '../services/pdfReportService.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { getTodayDateString, formatTime, DEFAULT_TZ } from '../utils/timeHelper.js';
import dayjs from 'dayjs';

/**
 * Helper to dispatch report response based on export parameter (JSON, Excel, PDF)
 */
async function respondWithReport(res, { title, subtitle, dateRange, columns, data, summaryTotals, exportFormat }) {
  if (exportFormat === 'excel') {
    const buffer = await generateExcelReport({
      title,
      subtitle,
      columns,
      data,
      summaryTotals,
    });
    const filename = `${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${dayjs().format('YYYYMMDD_HHmm')}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(buffer);
  }

  if (exportFormat === 'pdf') {
    const buffer = await generatePdfReport({
      title,
      subtitle,
      dateRange,
      columns,
      data,
      summaryTotals,
    });
    const filename = `${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${dayjs().format('YYYYMMDD_HHmm')}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(buffer);
  }

  return sendSuccess(res, { title, subtitle, dateRange, columns, data, summaryTotals }, `${title} retrieved.`);
}

/**
 * 1. Daily Attendance Report
 */
export async function getDailyReport(req, res) {
  try {
    const { date = getTodayDateString(), departmentId, export: exportFormat } = req.query;

    const where = {
      workDate: date,
      employee: {
        user: { role: req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' } },
      },
    };
    if (departmentId) where.employee.departmentId = departmentId;

    const records = await prisma.attendanceRecord.findMany({
      where,
      include: {
        employee: { include: { department: true, designation: true } },
        shift: true,
      },
      orderBy: { employee: { employeeCode: 'asc' } },
    });

    const data = records.map((r) => {
      const netHours = (r.netWorkMinutes / 60).toFixed(1);
      return {
        employeeCode: r.employee.employeeCode,
        fullName: r.employee.fullName,
        department: r.employee.department?.name || 'Unassigned',
        designation: r.employee.designation?.title || 'Unassigned',
        shift: r.shift.name,
        checkIn: formatTime(r.checkInAt),
        checkOut: formatTime(r.checkOutAt),
        breaksMinutes: r.totalBreakMinutes,
        netWorkHours: `${netHours} hrs`,
        lateMinutes: r.lateMinutes > 0 ? `${r.lateMinutes}m` : '--',
        status: r.attendanceClassification,
      };
    });

    const columns = [
      { key: 'employeeCode', header: 'Emp Code', widthWeight: 1 },
      { key: 'fullName', header: 'Employee Name', widthWeight: 2 },
      { key: 'department', header: 'Department', widthWeight: 1.5 },
      { key: 'shift', header: 'Office Timing', widthWeight: 1.2 },
      { key: 'checkIn', header: 'Check In', widthWeight: 1 },
      { key: 'checkOut', header: 'Check Out', widthWeight: 1 },
      { key: 'breaksMinutes', header: 'Break (m)', widthWeight: 1, alignment: 'right' },
      { key: 'netWorkHours', header: 'Net Work', widthWeight: 1, alignment: 'right' },
      { key: 'lateMinutes', header: 'Late (m)', widthWeight: 0.8, alignment: 'right' },
      { key: 'status', header: 'Status', widthWeight: 1 },
    ];

    const summaryTotals = {
      employeeCode: 'TOTAL',
      fullName: `${data.length} records`,
      netWorkHours: `${data.reduce((sum, d) => sum + parseFloat(d.netWorkHours), 0).toFixed(1)} hrs`,
    };

    return respondWithReport(res, {
      title: 'Daily Attendance Report',
      subtitle: `Date: ${date}`,
      dateRange: date,
      columns,
      data,
      summaryTotals,
      exportFormat,
    });
  } catch (error) {
    console.error('Daily report error:', error);
    return sendError(res, 'Failed to generate daily report.', 500);
  }
}

/**
 * 2. Monthly Attendance & Payroll-Ready Summary Report
 */
export async function getMonthlyPayrollReport(req, res) {
  try {
    const {
      year = dayjs().year(),
      month = dayjs().month() + 1, // 1 to 12
      departmentId,
      export: exportFormat,
    } = req.query;

    const startDate = dayjs(`${year}-${String(month).padStart(2, '0')}-01`).format('YYYY-MM-DD');
    const daysInMonth = dayjs(startDate).daysInMonth();
    const endDate = dayjs(`${year}-${String(month).padStart(2, '0')}-${daysInMonth}`).format('YYYY-MM-DD');

    const employeeWhere = {
      isDeleted: false,
      user: { role: req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' } },
    };
    if (departmentId) employeeWhere.departmentId = departmentId;

    const employees = await prisma.employee.findMany({
      where: employeeWhere,
      include: {
        department: true,
        designation: true,
        shiftAssignments: {
          where: { effectiveTo: null },
          include: { shift: true },
          take: 1,
        },
        attendanceRecords: {
          where: {
            workDate: { gte: startDate, lte: endDate },
          },
        },
        leaveRequests: {
          where: {
            leaveType: { code: { not: 'SL' } },
            status: 'APPROVED',
            startDate: { lte: endDate },
            endDate: { gte: startDate },
          },
          include: { leaveType: true },
        },
      },
      orderBy: { employeeCode: 'asc' },
    });

    // Query holidays in the month
    const holidaysCount = await prisma.holiday.count({
      where: { date: { gte: startDate, lte: endDate } },
    });

    const data = employees.map((emp) => {
      const records = emp.attendanceRecords;
      const presentCount = records.filter(
        (r) => r.attendanceClassification === 'PRESENT' || r.attendanceClassification === 'LATE'
      ).length;
      const halfDayCount = records.filter((r) => r.attendanceClassification === 'HALF_DAY').length;
      const lateArrivalsCount = records.filter((r) => r.lateMinutes > 0).length;

      // Leaves breakdown
      let paidLeaveDays = 0;
      let unpaidLeaveDays = 0;
      emp.leaveRequests.forEach((lr) => {
        if (lr.leaveType.isPaid) paidLeaveDays += lr.daysCount;
        else unpaidLeaveDays += lr.daysCount;
      });

      // Total Net Minutes
      const totalNetMinutes = records.reduce((sum, r) => sum + (r.netWorkMinutes || 0), 0);
      const totalNetHours = (totalNetMinutes / 60).toFixed(1);

      // Overtime Hours
      const totalOvertimeMinutes = records.reduce((sum, r) => sum + (r.overtimeMinutes || 0), 0);
      const totalOvertimeHours = (totalOvertimeMinutes / 60).toFixed(1);

      // Scheduled working days (approx weekdays excluding Sundays)
      let scheduledDays = 0;
      for (let d = 1; d <= daysInMonth; d++) {
        const curDate = dayjs(`${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`);
        if (curDate.day() !== 0) scheduledDays++; // Exclude Sundays
      }

      const totalRecorded = presentCount + halfDayCount * 0.5 + paidLeaveDays + unpaidLeaveDays;
      const absentDays = Math.max(0, scheduledDays - totalRecorded - holidaysCount);

      return {
        employeeCode: emp.employeeCode,
        fullName: emp.fullName,
        department: emp.department?.name || 'Unassigned',
        scheduledDays,
        presentDays: presentCount,
        halfDays: halfDayCount,
        lateDays: lateArrivalsCount,
        paidLeave: paidLeaveDays,
        unpaidLeave: unpaidLeaveDays,
        holidays: holidaysCount,
        absentDays: Math.round(absentDays * 10) / 10,
        netWorkHours: `${totalNetHours} hrs`,
        overtimeHours: `${totalOvertimeHours} hrs`,
      };
    });

    const columns = [
      { key: 'employeeCode', header: 'Emp Code', widthWeight: 1 },
      { key: 'fullName', header: 'Employee Name', widthWeight: 2 },
      { key: 'department', header: 'Department', widthWeight: 1.5 },
      { key: 'scheduledDays', header: 'Scheduled', widthWeight: 1, alignment: 'right' },
      { key: 'presentDays', header: 'Present', widthWeight: 1, alignment: 'right' },
      { key: 'halfDays', header: 'Half Days', widthWeight: 1, alignment: 'right' },
      { key: 'lateDays', header: 'Late', widthWeight: 0.8, alignment: 'right' },
      { key: 'paidLeave', header: 'Paid Leave', widthWeight: 1, alignment: 'right' },
      { key: 'unpaidLeave', header: 'LWP', widthWeight: 0.8, alignment: 'right' },
      { key: 'absentDays', header: 'Absent', widthWeight: 1, alignment: 'right' },
      { key: 'netWorkHours', header: 'Total Net Hrs', widthWeight: 1.2, alignment: 'right' },
      { key: 'overtimeHours', header: 'Overtime Hrs', widthWeight: 1.2, alignment: 'right' },
    ];

    const summaryTotals = {
      employeeCode: 'TOTAL',
      fullName: `${data.length} employees`,
      presentDays: data.reduce((sum, d) => sum + d.presentDays, 0),
      absentDays: data.reduce((sum, d) => sum + d.absentDays, 0),
      netWorkHours: `${data.reduce((sum, d) => sum + parseFloat(d.netWorkHours), 0).toFixed(1)} hrs`,
      overtimeHours: `${data.reduce((sum, d) => sum + parseFloat(d.overtimeHours), 0).toFixed(1)} hrs`,
    };

    const monthName = dayjs(startDate).format('MMMM YYYY');

    return respondWithReport(res, {
      title: 'Monthly Attendance & Payroll Summary Report',
      subtitle: `Period: ${monthName}`,
      dateRange: `${startDate} to ${endDate}`,
      columns,
      data,
      summaryTotals,
      exportFormat,
    });
  } catch (error) {
    console.error('Monthly payroll report error:', error);
    return sendError(res, 'Failed to generate monthly payroll report.', 500);
  }
}

/**
 * 3. Late Arrival & Punctuality Report
 */
export async function getLateArrivalReport(req, res) {
  try {
    const { startDate, endDate, departmentId, export: exportFormat } = req.query;

    const start = startDate || dayjs().startOf('month').format('YYYY-MM-DD');
    const end = endDate || dayjs().format('YYYY-MM-DD');

    const where = {
      workDate: { gte: start, lte: end },
      lateMinutes: { gt: 0 },
      employee: {
        user: { role: req.user.role === 'HR' ? 'EMPLOYEE' : { not: 'ADMIN' } },
      },
    };
    if (departmentId) where.employee.departmentId = departmentId;

    const records = await prisma.attendanceRecord.findMany({
      where,
      include: {
        employee: { include: { department: true, designation: true } },
        shift: true,
      },
      orderBy: { workDate: 'desc' },
    });

    const data = records.map((r) => ({
      employeeCode: r.employee.employeeCode,
      fullName: r.employee.fullName,
      department: r.employee.department?.name || 'Unassigned',
      workDate: r.workDate,
      shift: r.shift.name,
      checkInTime: formatTime(r.checkInAt),
      scheduledStart: r.shift.startTime,
      gracePeriod: `${r.shift.gracePeriodMinutes} mins`,
      lateMinutes: `${r.lateMinutes} mins`,
      notes: r.notes || 'Arrived after grace period',
    }));

    const columns = [
      { key: 'employeeCode', header: 'Emp Code', widthWeight: 1 },
      { key: 'fullName', header: 'Employee Name', widthWeight: 2 },
      { key: 'department', header: 'Department', widthWeight: 1.5 },
      { key: 'workDate', header: 'Date', widthWeight: 1 },
      { key: 'shift', header: 'Office Timing', widthWeight: 1.2 },
      { key: 'checkInTime', header: 'Actual Punch', widthWeight: 1 },
      { key: 'scheduledStart', header: 'Shift Start', widthWeight: 1 },
      { key: 'gracePeriod', header: 'Grace', widthWeight: 0.8 },
      { key: 'lateMinutes', header: 'Late By', widthWeight: 1, alignment: 'right' },
      { key: 'notes', header: 'Remarks', widthWeight: 2 },
    ];

    const summaryTotals = {
      employeeCode: 'TOTAL',
      fullName: `${data.length} late occurrences`,
      lateMinutes: `${data.reduce((sum, d) => sum + parseInt(d.lateMinutes, 10), 0)} mins total`,
    };

    return respondWithReport(res, {
      title: 'Late Arrival & Punctuality Report',
      subtitle: `From ${start} to ${end}`,
      dateRange: `${start} to ${end}`,
      columns,
      data,
      summaryTotals,
      exportFormat,
    });
  } catch (error) {
    console.error('Late arrival report error:', error);
    return sendError(res, 'Failed to generate late arrival report.', 500);
  }
}

/**
 * 4. Overtime & Extended Hours Report
 */
export async function getOvertimeReport(req, res) {
  try {
    const { startDate, endDate, departmentId, export: exportFormat } = req.query;

    const start = startDate || dayjs().startOf('month').format('YYYY-MM-DD');
    const end = endDate || dayjs().format('YYYY-MM-DD');

    const where = {
      workDate: { gte: start, lte: end },
      overtimeMinutes: { gt: 0 },
    };
    if (departmentId) where.employee = { departmentId };

    const records = await prisma.attendanceRecord.findMany({
      where,
      include: {
        employee: { include: { department: true, designation: true } },
        shift: true,
      },
      orderBy: { workDate: 'desc' },
    });

    const data = records.map((r) => ({
      employeeCode: r.employee.employeeCode,
      fullName: r.employee.fullName,
      department: r.employee.department?.name || 'Unassigned',
      workDate: r.workDate,
      shift: r.shift.name,
      checkInTime: formatTime(r.checkInAt),
      checkOutTime: formatTime(r.checkOutAt),
      netWorkHours: `${(r.netWorkMinutes / 60).toFixed(1)} hrs`,
      overtimeHours: `${(r.overtimeMinutes / 60).toFixed(1)} hrs`,
      overtimeMinutes: `${r.overtimeMinutes} mins`,
    }));

    const columns = [
      { key: 'employeeCode', header: 'Emp Code', widthWeight: 1 },
      { key: 'fullName', header: 'Employee Name', widthWeight: 2 },
      { key: 'department', header: 'Department', widthWeight: 1.5 },
      { key: 'workDate', header: 'Date', widthWeight: 1 },
      { key: 'shift', header: 'Office Timing', widthWeight: 1.2 },
      { key: 'checkInTime', header: 'Check In', widthWeight: 1 },
      { key: 'checkOutTime', header: 'Check Out', widthWeight: 1 },
      { key: 'netWorkHours', header: 'Net Work', widthWeight: 1, alignment: 'right' },
      { key: 'overtimeHours', header: 'Overtime', widthWeight: 1, alignment: 'right' },
    ];

    const summaryTotals = {
      employeeCode: 'TOTAL',
      fullName: `${data.length} records`,
      overtimeHours: `${data.reduce((sum, d) => sum + parseFloat(d.overtimeHours), 0).toFixed(1)} hrs`,
    };

    return respondWithReport(res, {
      title: 'Overtime & Extended Hours Report',
      subtitle: `Period: ${start} to ${end}`,
      dateRange: `${start} to ${end}`,
      columns,
      data,
      summaryTotals,
      exportFormat,
    });
  } catch (error) {
    console.error('Overtime report error:', error);
    return sendError(res, 'Failed to generate overtime report.', 500);
  }
}
