import { canManageEmployee } from '../services/accessPolicy.js';
import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { logAudit } from '../services/auditService.js';
import { evaluateCheckIn, evaluateCheckOut } from '../services/attendanceCalculationEngine.js';
import { DEFAULT_TZ, toOfficeTime } from '../utils/timeHelper.js';
import dayjs from 'dayjs';

/**
 * Submit an attendance correction request (Employee)
 */
export async function submitCorrection(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const {
      attendanceDate,
      correctionType,
      requestedCheckInAt,
      requestedCheckOutAt,
      reason,
      documentUrl,
    } = req.body;

    const requestedCheckIn = requestedCheckInAt ? new Date(requestedCheckInAt) : null;
    const requestedCheckOut = requestedCheckOutAt ? new Date(requestedCheckOutAt) : null;

    // Company rule: a correction can be submitted only on the work date or within the next day.
    const todayOffice = dayjs().tz(DEFAULT_TZ).startOf('day');
    const workDay = dayjs.tz(attendanceDate, 'YYYY-MM-DD', DEFAULT_TZ).startOf('day');
    const correctionDeadline = workDay.add(1, 'day').endOf('day');
    if (workDay.isAfter(todayOffice, 'day')) {
      return sendError(res, 'Future attendance cannot be corrected.', 422);
    }
    if (dayjs().tz(DEFAULT_TZ).isAfter(correctionDeadline)) {
      return sendError(res, 'Attendance correction must be submitted within the next day.', 422);
    }
    const validOfficeDates = [
      attendanceDate,
      dayjs(attendanceDate).add(1, 'day').format('YYYY-MM-DD'),
    ];

    if (
      requestedCheckIn &&
      toOfficeTime(requestedCheckIn).format('YYYY-MM-DD') !== attendanceDate
    ) {
      return sendError(res, 'Requested check-in time must belong to the selected work date.', 422);
    }

    if (
      requestedCheckOut &&
      !validOfficeDates.includes(toOfficeTime(requestedCheckOut).format('YYYY-MM-DD'))
    ) {
      return sendError(res, 'Requested check-out time must belong to the selected work date.', 422);
    }

    // Check if attendance record already exists for that date
    const attendance = await prisma.attendanceRecord.findUnique({
      where: {
        employeeId_workDate: {
          employeeId: employee.id,
          workDate: attendanceDate,
        },
      },
    });

    // Check if a pending correction request already exists for this date
    const pendingRequest = await prisma.attendanceCorrectionRequest.findFirst({
      where: {
        employeeId: employee.id,
        attendanceDate,
        status: 'PENDING',
      },
    });

    if (pendingRequest) {
      return sendError(
        res,
        'A correction request for this date is already pending review by HR/Admin.',
        400
      );
    }

    const newCorrection = await prisma.attendanceCorrectionRequest.create({
      data: {
        employeeId: employee.id,
        attendanceId: attendance ? attendance.id : null,
        attendanceDate,
        correctionType,
        requestedCheckInAt: requestedCheckIn,
        requestedCheckOutAt: requestedCheckOut,
        originalCheckInAt: attendance?.checkInAt || null,
        originalCheckOutAt: attendance?.checkOutAt || null,
        reason,
        documentUrl,
        status: 'PENDING',
      },
      include: {
        attendance: true,
      },
    });

    await logAudit({
      userId: req.user.id,
      action: 'CORRECTION_REQUEST_SUBMITTED',
      entityType: 'ATTENDANCE_CORRECTION',
      entityId: newCorrection.id,
      details: {
        attendanceDate,
        correctionType,
        reason,
      },
      req,
    });

    return sendSuccess(
      res,
      newCorrection,
      'Attendance correction request submitted successfully. Awaiting approval.',
      201
    );
  } catch (error) {
    console.error('Submit correction error:', error);
    return sendError(res, 'Failed to submit correction request.', 500);
  }
}

/**
 * Get correction requests for current authenticated employee
 */
export async function getMyCorrections(req, res) {
  try {
    const employee = req.employee;
    if (!employee) return sendError(res, 'Employee not found.', 404);

    const requests = await prisma.attendanceCorrectionRequest.findMany({
      where: { employeeId: employee.id },
      orderBy: { createdAt: 'desc' },
      include: {
        attendance: { include: { shift: true } },
        reviewer: { select: { email: true, role: true } },
      },
    });

    return sendSuccess(res, requests, 'Attendance correction requests retrieved.');
  } catch (error) {
    console.error('Get my corrections error:', error);
    return sendError(res, 'Failed to retrieve correction requests.', 500);
  }
}

/**
 * Get all correction requests for Admin & HR
 */
export async function getAllCorrections(req, res) {
  try {
    const { status, departmentId, search = '', page = 1, limit = 20 } = req.query;

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;
    const skip = (pageNum - 1) * limitNum;

    const where = {};
    if (status) where.status = status;
    if (departmentId) where.employee = { departmentId };
    if (search) {
      where.employee = {
        ...where.employee,
        OR: [
          { fullName: { contains: search } },
          { employeeCode: { contains: search } },
        ],
      };
    }

    if (req.user.role === 'HR') where.employee = { ...where.employee, user: { role: 'EMPLOYEE' } };
    const [total, requests] = await Promise.all([
      prisma.attendanceCorrectionRequest.count({ where }),
      prisma.attendanceCorrectionRequest.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: { createdAt: 'desc' },
        include: {
          employee: {
            include: { department: true, designation: true },
          },
          attendance: { include: { shift: true } },
          reviewer: { select: { email: true, role: true } },
          histories: true,
        },
      }),
    ]);

    return sendSuccess(
      res,
      {
        requests,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages: Math.ceil(total / limitNum),
        },
      },
      'Correction requests retrieved.'
    );
  } catch (error) {
    console.error('Get all corrections error:', error);
    return sendError(res, 'Failed to retrieve correction requests.', 500);
  }
}

/**
 * Approve or Reject attendance correction request (Admin/HR)
 */
export async function decideCorrection(req, res) {
  try {
    const { id } = req.params;
    const { status, reviewerComments } = req.body;

    const request = await prisma.attendanceCorrectionRequest.findUnique({
      where: { id },
      include: {
        employee: {
          include: {
            user: { select: { role: true } },
            shiftAssignments: {
              where: { effectiveTo: null },
              include: { shift: true },
              take: 1,
            },
          },
        },
        attendance: { include: { shift: true, breakRecords: true } },
      },
    });

    if (!request) {
      return sendError(res, 'Correction request not found.', 404);
    }

    if (!canManageEmployee(req.user, request.employee)) return sendError(res, 'HR can review normal employee corrections only. Personal requests require Admin.', 403);
    if (request.status !== 'PENDING') {
      return sendError(res, `This request has already been ${request.status.toLowerCase()}.`, 400);
    }

    const reviewedAt = new Date();

    if (status === 'REJECTED') {
      const updated = await prisma.attendanceCorrectionRequest.update({
        where: { id },
        data: {
          status: 'REJECTED',
          reviewerId: req.user.id,
          reviewerComments: reviewerComments || null,
          reviewedAt,
        },
      });

      await logAudit({
        userId: req.user.id,
        action: 'CORRECTION_REJECTED',
        entityType: 'ATTENDANCE_CORRECTION',
        entityId: id,
        details: { reviewerComments },
        req,
      });

      return sendSuccess(res, updated, 'Attendance correction request rejected.');
    }

    // When status === 'APPROVED', apply correction with auditable history
    const shift =
      request.attendance?.shift ||
      request.employee.shiftAssignments?.[0]?.shift ||
      (await prisma.shift.findFirst());

    const effectiveCheckIn = request.requestedCheckInAt || request.attendance?.checkInAt;
    const effectiveCheckOut = request.requestedCheckOutAt || request.attendance?.checkOutAt;

    // Evaluate Check In if available
    let checkInEval = { isLate: false, lateMinutes: 0, classification: 'PRESENT' };
    if (effectiveCheckIn) {
      checkInEval = evaluateCheckIn();
    }

    // Evaluate Check Out if available
    let checkOutEval = {
      netWorkMinutes: 0,
      earlyDepartureMinutes: 0,
      overtimeMinutes: 0,
      attendanceClassification: checkInEval.classification,
    };

    if (effectiveCheckIn && effectiveCheckOut) {
      checkOutEval = evaluateCheckOut({
        attendanceRecord: {
          workDate: request.attendanceDate,
          checkInAt: effectiveCheckIn,
          totalBreakMinutes: request.attendance?.totalBreakMinutes || 0,
          lateMinutes: checkInEval.lateMinutes,
          attendanceClassification: checkInEval.classification,
        },
        checkOutTime: effectiveCheckOut,
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      // 1. Create or Update Attendance Record
      let targetAttendance = request.attendance;
      if (!targetAttendance) {
        targetAttendance = await tx.attendanceRecord.create({
          data: {
            employeeId: request.employeeId,
            workDate: request.attendanceDate,
            shiftId: shift.id,
            checkInAt: effectiveCheckIn,
            checkOutAt: effectiveCheckOut,
            workSessionStatus: effectiveCheckOut ? 'CHECKED_OUT' : 'WORKING',
            lateMinutes: checkInEval.lateMinutes,
            netWorkMinutes: checkOutEval.netWorkMinutes,
            earlyDepartureMinutes: checkOutEval.earlyDepartureMinutes,
            overtimeMinutes: checkOutEval.overtimeMinutes,
            attendanceClassification: checkOutEval.attendanceClassification,
            notes: `Created via approved correction request #${request.id.substring(0, 8)}`,
          },
        });
      } else {
        targetAttendance = await tx.attendanceRecord.update({
          where: { id: targetAttendance.id },
          data: {
            checkInAt: effectiveCheckIn,
            checkOutAt: effectiveCheckOut,
            workSessionStatus: effectiveCheckOut ? 'CHECKED_OUT' : targetAttendance.workSessionStatus,
            lateMinutes: checkInEval.lateMinutes,
            netWorkMinutes: checkOutEval.netWorkMinutes,
            earlyDepartureMinutes: checkOutEval.earlyDepartureMinutes,
            overtimeMinutes: checkOutEval.overtimeMinutes,
            attendanceClassification: checkOutEval.attendanceClassification,
            notes: `Corrected via approved request #${request.id.substring(0, 8)}: ${request.reason}`,
          },
        });
      }

      // 2. Save immutable audit entry in AttendanceCorrectionHistory
      await tx.attendanceCorrectionHistory.create({
        data: {
          correctionRequestId: request.id,
          attendanceId: targetAttendance.id,
          originalCheckIn: request.originalCheckInAt,
          originalCheckOut: request.originalCheckOutAt,
          updatedCheckIn: effectiveCheckIn,
          updatedCheckOut: effectiveCheckOut,
          originalClassification: request.attendance?.attendanceClassification || 'ABSENT',
          updatedClassification: checkOutEval.attendanceClassification,
          modifiedByUserId: req.user.id,
          changedAt: reviewedAt,
        },
      });

      // 3. Record event in AttendanceEvent
      await tx.attendanceEvent.create({
        data: {
          attendanceId: targetAttendance.id,
          eventType: 'CORRECTION_APPLIED',
          eventTimestamp: reviewedAt,
          notes: `Correction approved by ${req.user.email}. Net working hours: ${Math.floor(checkOutEval.netWorkMinutes / 60)}h ${checkOutEval.netWorkMinutes % 60}m.`,
        },
      });

      // 4. Update the correction request status
      const updatedRequest = await tx.attendanceCorrectionRequest.update({
        where: { id },
        data: {
          status: 'APPROVED',
          attendanceId: targetAttendance.id,
          reviewerId: req.user.id,
          reviewerComments: reviewerComments || null,
          reviewedAt,
        },
      });

      return { updatedRequest, targetAttendance };
    });

    await logAudit({
      userId: req.user.id,
      action: 'CORRECTION_APPROVED',
      entityType: 'ATTENDANCE_CORRECTION',
      entityId: id,
      details: {
        attendanceDate: request.attendanceDate,
        newClassification: checkOutEval.attendanceClassification,
        reviewerComments,
      },
      req,
    });

    return sendSuccess(
      res,
      result,
      'Attendance correction approved and successfully applied to employee record.'
    );
  } catch (error) {
    console.error('Decide correction error:', error);
    return sendError(res, 'Failed to process correction decision.', 500);
  }
}
