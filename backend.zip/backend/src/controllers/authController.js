import crypto from 'crypto';
import prisma from '../config/db.js';
import { hashPassword, verifyPassword } from '../utils/passwordHelper.js';
import { signToken } from '../utils/jwtHelper.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { logAudit } from '../services/auditService.js';
import { processMonthlyClAccrualForEmployee } from '../services/clAccrualService.js';
import { COOKIE_NAME } from '../middleware/authMiddleware.js';

// Failed password attempt tracker (per identifier)
const failedPasswordAttempts = new Map();
const MAX_FAILED_PASSWORD_ATTEMPTS = 6;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes lockout

/**
 * Login user via Email or Employee Code
 */
export async function login(req, res) {
  try {
    const { identifier, password, rememberMe } = req.body;
    const authKey = (identifier || '').trim().toLowerCase();

    // Check if account has reached 6 incorrect password attempts
    const attemptInfo = failedPasswordAttempts.get(authKey);
    if (attemptInfo && attemptInfo.count >= MAX_FAILED_PASSWORD_ATTEMPTS) {
      if (Date.now() < attemptInfo.lockedUntil) {
        const minutesLeft = Math.max(1, Math.ceil((attemptInfo.lockedUntil - Date.now()) / (60 * 1000)));
        return sendError(
          res,
          `Too many authentication attempts. Please try again after ${minutesLeft} minute${minutesLeft > 1 ? 's' : ''}.`,
          429
        );
      } else {
        // Lockout period expired
        failedPasswordAttempts.delete(authKey);
      }
    }

    // Search user by email or by associated employeeCode
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: identifier.toLowerCase() },
          { employee: { employeeCode: identifier.toUpperCase() } },
        ],
      },
      include: {
        employee: {
          include: {
            department: true,
            designation: true,
            branch: true,
            shiftAssignments: {
              where: { effectiveTo: null },
              include: { shift: true },
              take: 1,
            },
          },
        },
      },
    });

    // Helper to register a failed password attempt
    const recordFailedAttempt = () => {
      const current = failedPasswordAttempts.get(authKey) || { count: 0, firstAttemptAt: Date.now() };
      current.count += 1;
      if (current.count >= MAX_FAILED_PASSWORD_ATTEMPTS) {
        current.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
        failedPasswordAttempts.set(authKey, current);
        return sendError(
          res,
          'Too many authentication attempts. Please try again after 15 minutes.',
          429
        );
      } else {
        failedPasswordAttempts.set(authKey, current);
        const remaining = MAX_FAILED_PASSWORD_ATTEMPTS - current.count;
        return sendError(
          res,
          `Invalid credentials. Incorrect password (${current.count} of 6 attempts used, ${remaining} remaining).`,
          401
        );
      }
    };

    if (!user) {
      await hashPassword('dummy_password_timing_mitigation');
      return recordFailedAttempt();
    }

    const isMatch = await verifyPassword(user.passwordHash, password);
    if (!isMatch) {
      return recordFailedAttempt();
    }

    // Correct password - reset failed attempt counter
    failedPasswordAttempts.delete(authKey);

    if (user.accountStatus !== 'ACTIVE') {
      return sendError(
        res,
        `Your account is currently ${user.accountStatus.toLowerCase()}. Please contact HR or the Administrator.`,
        403
      );
    }

    if (user.employee && user.employee.isDeleted) {
      return sendError(res, 'This employee account has been deactivated.', 403);
    }

    // Credit one CL on the employee's first login of each month. The ledger's
    // unique month key makes this safe to call on every successful login.
    if (user.employee?.id && user.role !== 'ADMIN') {
      await processMonthlyClAccrualForEmployee(user.employee.id);
    }

    // Sign JWT token
    const token = signToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,
      employeeId: user.employeeId,
    });

    // Update lastLoginAt
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    // Set secure HTTP-Only cookie
    const isProduction = process.env.NODE_ENV === 'production';
    const cookieMaxAge = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000; // 30 days vs 7 days

    res.cookie(COOKIE_NAME, token, {
      httpOnly: true,
      secure: isProduction,
      sameSite: isProduction ? 'strict' : 'lax',
      maxAge: cookieMaxAge,
    });

    // Log audit
    await logAudit({
      userId: user.id,
      action: 'USER_LOGIN',
      entityType: 'USER',
      entityId: user.id,
      details: { identifier, role: user.role },
      req,
    });

    const activeShift = user.employee?.shiftAssignments?.[0]?.shift || null;

    const sanitizedUser = {
      id: user.id,
      email: user.email,
      role: user.role,
      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,
      accountStatus: user.accountStatus,
      mustChangePassword: Boolean(user.mustChangePassword),
      lastLoginAt: user.lastLoginAt,
      employee: user.employee
        ? {
            id: user.employee.id,
            employeeCode: user.employee.employeeCode,
            fullName: user.employee.fullName,
            profilePhoto: user.employee.profilePhoto,
            email: user.employee.email,
            phone: user.employee.phone,
            department: user.employee.department?.name || 'Unassigned',
            departmentCode: user.employee.department?.code || null,
            designation: user.employee.designation?.title || 'Unassigned',
            branch: user.employee.branch?.name || 'Headquarters',
            timezone: user.employee.branch?.timezone || 'Asia/Kolkata',
            employmentType: user.employee.employmentType,
            joiningDate: user.employee.joiningDate,
            activeShift: activeShift
              ? {
                  id: activeShift.id,
                  name: activeShift.name,
                  startTime: activeShift.startTime,
                  endTime: activeShift.endTime,
                  gracePeriodMinutes: activeShift.gracePeriodMinutes,
                  breakDurationMinutes: activeShift.breakDurationMinutes,
                  requiredWorkMinutes: activeShift.requiredWorkMinutes,
                  isOvernight: activeShift.isOvernight,
                }
              : null,
          }
        : null,
    };

    return sendSuccess(res, { user: sanitizedUser, token }, 'Signed in successfully.');
  } catch (error) {
    console.error('Login error:', error);
    return sendError(res, 'Authentication failed due to an internal server error.', 500);
  }
}

/**
 * Logout user by clearing HTTP-Only cookie
 */
export async function logout(req, res) {
  try {
    const isProduction = process.env.NODE_ENV === 'production';
    res.clearCookie(COOKIE_NAME, {
      httpOnly: true,
      secure: isProduction,
      sameSite: isProduction ? 'strict' : 'lax',
    });

    if (req.user) {
      await logAudit({
        userId: req.user.id,
        action: 'USER_LOGOUT',
        entityType: 'USER',
        entityId: req.user.id,
        req,
      });
    }

    return sendSuccess(res, null, 'Signed out successfully.');
  } catch (error) {
    console.error('Logout error:', error);
    return sendError(res, 'Failed to sign out.', 500);
  }
}

/**
 * Get current authenticated user profile
 */
export async function getMe(req, res) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: {
        employee: {
          include: {
            department: true,
            designation: true,
            branch: true,
            shiftAssignments: {
              where: { effectiveTo: null },
              include: { shift: true },
              take: 1,
            },
          },
        },
      },
    });

    if (!user) {
      return sendError(res, 'User session invalid.', 401);
    }

    const activeShift = user.employee?.shiftAssignments?.[0]?.shift || null;

    const sanitizedUser = {
      id: user.id,
      email: user.email,
      role: user.role,
      canAuthorizePayrollPayment: user.canAuthorizePayrollPayment,
      accountStatus: user.accountStatus,
      mustChangePassword: Boolean(user.mustChangePassword),
      lastLoginAt: user.lastLoginAt,
      employee: user.employee
        ? {
            id: user.employee.id,
            employeeCode: user.employee.employeeCode,
            fullName: user.employee.fullName,
            profilePhoto: user.employee.profilePhoto,
            email: user.employee.email,
            phone: user.employee.phone,
            department: user.employee.department?.name || 'Unassigned',
            departmentCode: user.employee.department?.code || null,
            designation: user.employee.designation?.title || 'Unassigned',
            branch: user.employee.branch?.name || 'Headquarters',
            timezone: user.employee.branch?.timezone || 'Asia/Kolkata',
            employmentType: user.employee.employmentType,
            joiningDate: user.employee.joiningDate,
            activeShift: activeShift
              ? {
                  id: activeShift.id,
                  name: activeShift.name,
                  startTime: activeShift.startTime,
                  endTime: activeShift.endTime,
                  gracePeriodMinutes: activeShift.gracePeriodMinutes,
                  breakDurationMinutes: activeShift.breakDurationMinutes,
                  requiredWorkMinutes: activeShift.requiredWorkMinutes,
                  isOvernight: activeShift.isOvernight,
                }
              : null,
          }
        : null,
    };

    return sendSuccess(res, sanitizedUser, 'User profile retrieved.');
  } catch (error) {
    console.error('Get profile error:', error);
    return sendError(res, 'Failed to retrieve user profile.', 500);
  }
}

/**
 * Activate employee account and set initial password
 */
export async function activateAccount(req, res) {
  try {
    const { token, password } = req.body;

    const user = await prisma.user.findFirst({
      where: {
        activationToken: token,
        activationExpiresAt: { gt: new Date() },
      },
      include: { employee: true },
    });

    if (!user) {
      return sendError(res, 'Invalid or expired activation token. Please request a new activation link from HR.', 400);
    }

    const passwordHash = await hashPassword(password);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        passwordHash,
        accountStatus: 'ACTIVE',
        activationToken: null,
        activationExpiresAt: null,
      },
    });

    await logAudit({
      userId: user.id,
      action: 'ACCOUNT_ACTIVATED',
      entityType: 'USER',
      entityId: user.id,
      details: { email: user.email, employeeCode: user.employee?.employeeCode },
      req,
    });

    return sendSuccess(res, null, 'Account activated successfully! You can now log in with your credentials.');
  } catch (error) {
    console.error('Activation error:', error);
    return sendError(res, 'Account activation failed.', 500);
  }
}

/**
 * Request password reset token
 */
export async function forgotPassword(req, res) {
  try {
    const { email } = req.body;

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });

    // Always respond with success message to prevent user enumeration
    if (!user) {
      return sendSuccess(
        res,
        null,
        'If an account exists with this email address, a password reset link has been dispatched.'
      );
    }

    const resetToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        token: resetToken,
        expiresAt,
      },
    });

    await logAudit({
      userId: user.id,
      action: 'PASSWORD_RESET_REQUESTED',
      entityType: 'USER',
      entityId: user.id,
      req,
    });

    // In a production environment with SMTP configured, this sends an email.
    // For local development convenience, we return the reset link token in non-production.
    const isDev = process.env.NODE_ENV !== 'production';

    return sendSuccess(
      res,
      isDev ? { devResetToken: resetToken } : null,
      'If an account exists with this email address, a password reset link has been dispatched.'
    );
  } catch (error) {
    console.error('Forgot password error:', error);
    return sendError(res, 'Password reset request failed.', 500);
  }
}

/**
 * Reset password using token
 */
export async function resetPassword(req, res) {
  try {
    const { token, password } = req.body;

    const resetRecord = await prisma.passwordResetToken.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!resetRecord || resetRecord.usedAt || resetRecord.expiresAt < new Date()) {
      return sendError(res, 'Invalid or expired password reset link. Please request a new one.', 400);
    }

    const passwordHash = await hashPassword(password);

    await prisma.$transaction([
      prisma.user.update({
        where: { id: resetRecord.userId },
        data: { passwordHash },
      }),
      prisma.passwordResetToken.update({
        where: { id: resetRecord.id },
        data: { usedAt: new Date() },
      }),
    ]);

    await logAudit({
      userId: resetRecord.userId,
      action: 'PASSWORD_RESET_COMPLETED',
      entityType: 'USER',
      entityId: resetRecord.userId,
      req,
    });

    return sendSuccess(res, null, 'Password reset successfully. You can now log in with your new password.');
  } catch (error) {
    console.error('Reset password error:', error);
    return sendError(res, 'Failed to reset password.', 500);
  }
}

/**
 * Change password for authenticated user
 */
export async function changePassword(req, res) {
  try {
    const { currentPassword, newPassword } = req.body;

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) {
      return sendError(res, 'User not found.', 404);
    }

    const isMatch = await verifyPassword(user.passwordHash, currentPassword);
    if (!isMatch) {
      return sendError(res, 'Current password entered is incorrect.', 400);
    }

    const passwordHash = await hashPassword(newPassword);

    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash },
    });

    await logAudit({
      userId: user.id,
      action: 'PASSWORD_CHANGED',
      entityType: 'USER',
      entityId: user.id,
      req,
    });

    return sendSuccess(res, null, 'Password updated successfully.');
  } catch (error) {
    console.error('Change password error:', error);
    return sendError(res, 'Failed to change password.', 500);
  }
}

/**
 * Mandatory First-Login Password Change
 * Required for newly registered employees with temporary passwords
 */
export async function firstLoginChangePassword(req, res) {
  try {
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 8) {
      return sendError(res, 'New password must be at least 8 characters long.', 400);
    }

    const passwordHash = await hashPassword(newPassword);

    const updatedUser = await prisma.user.update({
      where: { id: req.user.id },
      data: {
        passwordHash,
        mustChangePassword: false,
        accountStatus: 'ACTIVE',
      },
    });

    await logAudit({
      userId: req.user.id,
      action: 'FIRST_LOGIN_PASSWORD_RESET',
      entityType: 'USER',
      entityId: req.user.id,
      req,
    });

    return sendSuccess(
      res,
      { mustChangePassword: false },
      'Temporary password successfully updated. You now have full access to your portal.'
    );
  } catch (error) {
    console.error('First login password change error:', error);
    return sendError(res, 'Failed to update initial password.', 500);
  }
}
