import prisma from '../config/db.js';
import { sendSuccess, sendError } from '../utils/responseFormatter.js';
import { calculateDailySalary, calculateEmployeePayroll } from '../services/salaryCalculationEngine.js';
import { logAudit } from '../services/auditService.js';
import dayjs from 'dayjs';

/**
 * Get salary configuration for an employee
 */
export async function getSalaryConfig(req, res) {
  try {
    const { employeeId } = req.params;
    const isSelf = req.user.employee?.id === employeeId;
    const isAdminOrHR = req.user.role === 'ADMIN' || req.user.role === 'HR';

    if (!isSelf && !isAdminOrHR) {
      return sendError(res, 'Access denied. You can only view your own salary configuration.', 403);
    }

    if (req.user.role === 'HR' && !isSelf) {
      const target = await prisma.employee.findUnique({ where: { id: employeeId }, include: { user: true } });
      if (!target || target.user?.role !== 'EMPLOYEE') {
        return sendError(res, 'HR salary access is limited to employee accounts.', 403);
      }
    }

    const config = await prisma.salaryConfiguration.findUnique({
      where: { employeeId },
      include: {
        employee: {
          select: {
            id: true,
            employeeCode: true,
            fullName: true,
            email: true,
            department: { select: { name: true } },
            designation: { select: { title: true } },
          },
        },
      },
    });

    if (!config) {
      return sendError(res, 'Salary configuration not found for this employee.', 404);
    }

    // Fetch current CL balance for this employee
    const clBalance = await prisma.leaveBalance.findFirst({
      where: {
        employeeId,
        leaveType: { code: 'CL' },
        year: new Date().getFullYear(),
      },
    });

    // Hide bank account details from regular employees if viewing through general endpoint
    let sanitized = {
      ...config,
      clRemainingDays: clBalance ? clBalance.remainingDays : 1,
      lateAllowanceMonthly: config.lateAttendanceAllowance ?? 2,
      permissionAllowanceMonthly: config.permissionAllowancePerMonth ?? 1,
    };
    if (!isAdminOrHR) {
      sanitized.accountNumber = config.accountNumber ? `xxxx${config.accountNumber.slice(-4)}` : null;
    }

    return sendSuccess(res, sanitized, 'Salary configuration retrieved.');
  } catch (error) {
    console.error('Get salary config error:', error);
    return sendError(res, 'Failed to fetch salary configuration.', 500);
  }
}

/**
 * Update salary configuration (Admin / Authorized HR only)
 */
export async function updateSalaryConfig(req, res) {
  try {
    const { employeeId } = req.params;
    const data = req.body;

    const target = await prisma.employee.findUnique({ where: { id: employeeId }, include: { user: true } });
    if (!target || target.isDeleted) {
      return sendError(res, 'Employee not found.', 404);
    }
    if (req.user.role === 'HR' && target.user?.role !== 'EMPLOYEE') {
      return sendError(res, 'HR can configure salary for employee accounts only.', 403);
    }

    const lateAllowance = data.lateAllowanceMonthly !== undefined ? Number(data.lateAllowanceMonthly) : (data.lateAttendanceAllowance !== undefined ? Number(data.lateAttendanceAllowance) : 2);
    const permissionAllowance = data.permissionAllowanceMonthly !== undefined ? Number(data.permissionAllowanceMonthly) : (data.permissionAllowancePerMonth !== undefined ? Number(data.permissionAllowancePerMonth) : 1);
    const calcMethod = data.salaryCalculationMethod || data.calculationMethod || 'CALENDAR_DAYS';
    const payMethod = data.salaryPaymentMethod || data.paymentMethod || 'BANK_TRANSFER';
    const accNumber = data.bankAccountNumber || data.accountNumber;

    const updated = await prisma.salaryConfiguration.upsert({
      where: { employeeId },
      update: {
        monthlySalary: data.monthlySalary ? Number(data.monthlySalary) : undefined,
        calculationMethod: calcMethod,
        customDivisor: data.customDivisor ? Number(data.customDivisor) : undefined,
        workingDaysPerWeek: data.workingDaysPerWeek ? Number(data.workingDaysPerWeek) : undefined,
        weeklyOffDays: data.weeklyOffDays ? (typeof data.weeklyOffDays === 'string' ? data.weeklyOffDays : JSON.stringify(data.weeklyOffDays)) : undefined,
        paymentMethod: payMethod,
        bankName: data.bankName,
        accountNumber: accNumber,
        ifscCode: data.ifscCode,
        branchName: data.branchName,
        panNumber: data.panNumber,
        uanNumber: data.uanNumber,
        overtimeHourlyRate: data.overtimeHourlyRate ? Number(data.overtimeHourlyRate) : undefined,
        lateAttendanceAllowance: lateAllowance,
        permissionAllowancePerMonth: permissionAllowance,
        lateDeductionPerIncident: data.lateDeductionPerIncident !== undefined ? Number(data.lateDeductionPerIncident) : undefined,
        latePenaltyPolicy: data.latePenaltyPolicy,
      },
      create: {
        employeeId,
        monthlySalary: Number(data.monthlySalary || 20000),
        calculationMethod: calcMethod,
        customDivisor: Number(data.customDivisor || 30),
        workingDaysPerWeek: Number(data.workingDaysPerWeek || 5),
        weeklyOffDays: data.weeklyOffDays ? (typeof data.weeklyOffDays === 'string' ? data.weeklyOffDays : JSON.stringify(data.weeklyOffDays)) : '["SATURDAY","SUNDAY"]',
        paymentMethod: payMethod,
        bankName: data.bankName,
        accountNumber: accNumber,
        ifscCode: data.ifscCode,
        branchName: data.branchName,
        panNumber: data.panNumber,
        uanNumber: data.uanNumber,
        overtimeHourlyRate: data.overtimeHourlyRate ? Number(data.overtimeHourlyRate) : undefined,
        lateAttendanceAllowance: lateAllowance,
        permissionAllowancePerMonth: permissionAllowance,
        lateDeductionPerIncident: data.lateDeductionPerIncident !== undefined ? Number(data.lateDeductionPerIncident) : 0,
        latePenaltyPolicy: data.latePenaltyPolicy || 'WARNING_ONLY',
      },
    });

    // If Casual Leave (CL) remaining balance was adjusted in this form, sync LeaveBalance & LeaveLedger
    if (data.clRemainingDays !== undefined && !isNaN(Number(data.clRemainingDays))) {
      const newCl = Number(data.clRemainingDays);
      const clType = await prisma.leaveType.findFirst({ where: { code: 'CL' } });
      if (clType) {
        const year = new Date().getFullYear();
        await prisma.leaveBalance.upsert({
          where: {
            employeeId_leaveTypeId_year: {
              employeeId,
              leaveTypeId: clType.id,
              year,
            },
          },
          update: { remainingDays: newCl },
          create: {
            employeeId,
            leaveTypeId: clType.id,
            year,
            totalAllocated: Math.max(1, newCl),
            remainingDays: newCl,
            usedDays: 0,
            pendingDays: 0,
          },
        });

        // Also sync the current month's LeaveLedger
        const currentYM = dayjs().format('YYYY-MM');
        await prisma.leaveLedger.upsert({
          where: {
            employeeId_leaveTypeCode_monthYear: {
              employeeId,
              leaveTypeCode: 'CL',
              monthYear: currentYM,
            },
          },
          update: {
            closingBalance: newCl,
            remarks: `${req.user.role} salary config allocation: ${newCl} CL days`,
          },
          create: {
            employeeId,
            leaveTypeCode: 'CL',
            monthYear: currentYM,
            openingBalance: newCl,
            creditedDays: 0,
            usedDays: 0,
            adjustedDays: 0,
            closingBalance: newCl,
            remarks: `${req.user.role} salary config allocation: ${newCl} CL days`,
          },
        });
      }
    }

    const responsePayload = {
      ...updated,
      clRemainingDays: data.clRemainingDays !== undefined ? Number(data.clRemainingDays) : 1,
      lateAllowanceMonthly: updated.lateAttendanceAllowance,
      permissionAllowanceMonthly: updated.permissionAllowancePerMonth,
    };

    await logAudit({
      userId: req.user.id,
      action: 'SALARY_CONFIGURATION_UPDATED',
      entityType: 'SALARY_CONFIGURATION',
      entityId: updated.id,
      details: { employeeId, employeeCode: target.employeeCode, changedByRole: req.user.role },
      req,
    });

    return sendSuccess(res, responsePayload, 'Salary configuration updated successfully.');
  } catch (error) {
    console.error('Update salary config error:', error);
    return sendError(res, 'Failed to update salary configuration.', 500);
  }
}

/**
 * Get My Salary breakdown & projected calculation for authenticated employee
 */
export async function getMySalaryBreakdown(req, res) {
  try {
    const employee = req.user.employee;
    if (!employee) {
      return sendError(res, 'No employee record associated with this account.', 404);
    }

    const year = Number(req.query.year) || dayjs().year();
    const month = Number(req.query.month) || (dayjs().month() + 1);
    const monthStr = `${year}-${String(month).padStart(2, '0')}`;

    const [salaryConfig, attendanceRecords, approvedLeaves, approvedOnDuties, holidays] = await Promise.all([
      prisma.salaryConfiguration.findUnique({ where: { employeeId: employee.id } }),
      prisma.attendanceRecord.findMany({
        where: { employeeId: employee.id, workDate: { startsWith: monthStr } },
      }),
      prisma.leaveRequest.findMany({
        where: {
          leaveType: { code: { not: 'SL' } },
          employeeId: employee.id,
          status: 'APPROVED',
          startDate: { lte: `${monthStr}-31` },
          endDate: { gte: `${monthStr}-01` },
        },
        include: { leaveType: true },
      }),
      prisma.onDutyRequest.findMany({
        where: { employeeId: employee.id, status: 'APPROVED', odDate: { startsWith: monthStr } },
      }),
      prisma.holiday.findMany({
        where: { date: { startsWith: monthStr } },
      }),
    ]);

    const calculation = calculateEmployeePayroll({
      employee,
      salaryConfig: salaryConfig || { monthlySalary: 20000, calculationMethod: 'CALENDAR_DAYS', customDivisor: 30 },
      attendanceRecords,
      approvedLeaves,
      approvedOnDuties,
      holidays,
      year,
      month,
    });

    const monthSummary = {
      dailySalary: calculation.dailySalary,
      effectiveDivisor: calculation.divisorUsed,
      calendarDays: calculation.totalCalendarDays,
      payableDays: calculation.payableDays,
      presentDays: calculation.presentDays,
      scheduledDays: calculation.scheduledDays,
      incompleteDays: calculation.incompleteDays,
      halfDays: calculation.halfDays,
      odDays: calculation.approvedOdDays,
      paidLeaveDays: calculation.paidLeaveDays,
      paidWeeklyOffs: calculation.paidWeeklyOffsCount,
      paidHolidays: calculation.paidHolidaysCount,
      unpaidDays: calculation.unpaidLeaveDays + calculation.absentDays,
      absenceDeductions: calculation.absenceDeductions,
      unpaidLeaveDeductions: calculation.unpaidLeaveDeductions,
      lateDeductions: calculation.lateDeductions,
      estimatedNet: calculation.netSalary,
      grossEarnings: calculation.grossEarnings,
    };

    const config = {
      monthlySalary: salaryConfig?.monthlySalary || 20000,
      salaryCalculationMethod: salaryConfig?.calculationMethod || 'CALENDAR_DAYS',
      dailySalary: calculation.dailySalary,
      bankName: salaryConfig?.bankName || 'State Bank of India',
      bankAccountNumber: salaryConfig?.accountNumber || '•••• •••• 4092',
      ifscCode: salaryConfig?.ifscCode || 'SBIN0001234',
      salaryPaymentMethod: salaryConfig?.paymentMethod || 'BANK_TRANSFER',
    };

    return sendSuccess(
      res,
      {
        calculation,
        salaryConfig,
        attendanceRecords,
        config,
        monthSummary,
        dailyBreakdown: calculation.dailyBreakdown || [],
      },
      'Salary breakdown calculated.'
    );
  } catch (error) {
    console.error('Get my salary breakdown error:', error);
    return sendError(res, 'Failed to retrieve salary breakdown.', 500);
  }
}
