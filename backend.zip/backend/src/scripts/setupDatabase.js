import { execSync } from 'child_process';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

dotenv.config();

const dbUrl = process.env.DATABASE_URL || '';
const isPostgres = dbUrl.startsWith('postgresql://') || dbUrl.startsWith('postgres://');

console.log('🔄 Checking Database Configuration...');
console.log(`Detected DATABASE_URL: ${dbUrl ? dbUrl.replace(/:([^:@]+)@/, ':****@') : 'None (Defaulting to local DB)'}`);

let schemaFile = 'prisma/schema.sqlite.prisma';
let envUrl = dbUrl;

if (isPostgres) {
  try {
    console.log('📡 Testing connection to configured PostgreSQL instance...');
    // Attempt prisma db push with postgresql
    execSync('npx prisma db push --schema=prisma/schema.prisma --skip-generate', { stdio: 'pipe' });
    schemaFile = 'prisma/schema.prisma';
    console.log('✅ Connected to PostgreSQL successfully!');
  } catch (err) {
    console.warn('⚠️ Could not connect to remote/local PostgreSQL server.');
    console.log('💡 Switching seamlessly to zero-setup local SQLite database for zero-friction development...');
    schemaFile = 'prisma/schema.sqlite.prisma';
    envUrl = 'file:./dev.db';
    // Update local .env for subsequent prisma client operations
    const envPath = path.resolve(process.cwd(), '.env');
    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf8');
      envContent = envContent.replace(/DATABASE_URL=".*"/, 'DATABASE_URL="file:./dev.db"');
    } else {
      envContent = 'DATABASE_URL="file:./dev.db"\nPORT=5000\nJWT_SECRET="saishnaa_super_secret_jwt_key_2026_enterprise_attendance"\n';
    }
    fs.writeFileSync(envPath, envContent);
    process.env.DATABASE_URL = 'file:./dev.db';
  }
} else {
  schemaFile = 'prisma/schema.sqlite.prisma';
  if (!dbUrl) {
    process.env.DATABASE_URL = 'file:./dev.db';
  }
}

try {
  console.log(`🔨 Generating Prisma Client from ${schemaFile}...`);
  execSync(`npx prisma generate --schema=${schemaFile}`, { stdio: 'inherit' });

  console.log(`📦 Pushing database schema to ${process.env.DATABASE_URL}...`);
  execSync(`npx prisma db push --schema=${schemaFile}`, { stdio: 'inherit' });

  console.log('🌱 Seeding database...');
  execSync('node prisma/seed.js', { stdio: 'inherit' });

  console.log('✨ Database setup completed successfully!');
} catch (error) {
  console.error('❌ Database setup failed:', error.message);
  process.exit(1);
}
