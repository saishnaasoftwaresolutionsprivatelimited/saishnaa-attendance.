import 'dotenv/config';
import prisma from '../config/db.js';
import path from 'node:path';
import fs from 'node:fs';

// Existing SQLite installations have no Prisma migration baseline. Apply only
// these additive columns, idempotently, after taking a consistent SQLite backup.
try {
  const url = process.env.DATABASE_URL;
  if (!url?.startsWith('file:')) throw new Error('This upgrade supports the existing SQLite database only.');
  const dbPath = path.resolve('prisma', url.slice(5));
  if (!fs.existsSync(dbPath)) throw new Error('Existing database not found; refusing to create a replacement.');
  const backup = `${dbPath}.backup-${Date.now()}`;
  await prisma.$executeRawUnsafe(`VACUUM INTO '${backup.replaceAll("'", "''")}'`);
  const changes = [
    ['SalaryConfiguration', 'upiId', 'TEXT'],
    ['SalaryConfiguration', 'monthlyClCredit', 'REAL NOT NULL DEFAULT 1'],
    ['User', 'canAuthorizePayrollPayment', 'BOOLEAN NOT NULL DEFAULT false'],
  ];
  await prisma.$transaction(async tx => {
    for (const [table, column, type] of changes) {
      const columns = await tx.$queryRawUnsafe(`PRAGMA table_info("${table}")`);
      if (!columns.some(c => c.name === column)) {
        await tx.$executeRawUnsafe(`ALTER TABLE "${table}" ADD COLUMN "${column}" ${type}`);
      }
    }
  });
  console.log(`Additive upgrade complete. Backup: ${backup}`);
} finally {
  await prisma.$disconnect();
}
