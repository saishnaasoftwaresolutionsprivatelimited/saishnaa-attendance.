import { z } from 'zod';

export const applyLeaveSchema = z.object({
  leaveTypeId: z.string().min(1, 'Leave type is required'),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Start date must be in YYYY-MM-DD format'),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'End date must be in YYYY-MM-DD format'),
  daysCount: z.number().positive('Days count must be greater than zero'),
  isHalfDay: z.boolean().default(false),
  halfDayType: z.enum(['FIRST_HALF', 'SECOND_HALF']).optional().nullable(),
  reason: z.string().min(5, 'Reason must be at least 5 characters').trim(),
  documentUrl: z.string().url().optional().nullable(),
});

export const decideLeaveSchema = z.object({
  status: z.enum(['APPROVED', 'REJECTED']),
  reviewerComments: z.string().optional().nullable(),
});
