import { z } from 'zod';

export const createEmployeeSchema = z.object({
  employeeCode: z.string().trim().min(2).optional(),
  fullName: z.string().min(2, 'Full name must have at least 2 characters').trim(),
  email: z.string().email('Valid email is required').trim().toLowerCase(),
  phone: z.string().optional().nullable(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).optional().nullable(),
  dob: z.string().optional().nullable(),
  profilePhoto: z.string().optional().nullable(),
  departmentId: z.string().optional().nullable(),
  designationId: z.string().optional().nullable(),
  branchId: z.string().optional().nullable(),
  joiningDate: z.string().optional().nullable(),
  employmentType: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN']).default('FULL_TIME'),
  reportingManagerId: z.string().optional().nullable(),
  assignedShiftId: z.string().optional().nullable(),
  role: z.enum(['ADMIN', 'HR', 'EMPLOYEE']).default('EMPLOYEE'),
  address: z.string().optional().nullable(),
  temporaryPassword: z.string().min(8, 'Temporary password must contain at least 8 characters').optional(),
  monthlySalary: z.coerce.number().positive('Monthly salary must be greater than zero').optional(),
  salaryEffectiveDate: z.string().optional().nullable(),
  calculationMethod: z.enum(['CALENDAR_DAYS', 'FIXED_26', 'CUSTOM_DIVISOR']).default('CALENDAR_DAYS'),
  customDivisor: z.coerce.number().int().min(1).max(31).default(30),
  lateAllowanceMonthly: z.coerce.number().int().min(0).max(31).default(0),
  permissionAllowanceMonthly: z.coerce.number().int().min(0).max(31).default(0),
  clRemainingDays: z.coerce.number().min(0).max(365).default(0),
  paymentMethod: z.enum(['BANK_TRANSFER', 'UPI', 'CASH']).default('BANK_TRANSFER'),
  upiId: z.string().trim().optional().nullable(),
  bankName: z.string().optional().nullable(),
  bankAccountNumber: z.string().optional().nullable(),
  ifscCode: z.string().optional().nullable(),
}).refine(data => data.paymentMethod !== 'UPI' || /^[^\s@]+@[^\s@]+$/.test(data.upiId || ''), { path: ['upiId'], message: 'Enter a valid UPI ID' });

export const updateEmployeeSchema = z.object({
  canAuthorizePayrollPayment: z.boolean().optional(),
  employeeCode: z.string().trim().min(2).optional(),
  email: z.string().email().trim().toLowerCase().optional(),
  joiningDate: z.string().optional(),
  address: z.string().optional().nullable(),
  fullName: z.string().min(2).optional(),
  phone: z.string().optional().nullable(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).optional().nullable(),
  dob: z.string().optional().nullable(),
  departmentId: z.string().optional(),
  designationId: z.string().optional(),
  branchId: z.string().optional().nullable(),
  employmentType: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN']).optional(),
  reportingManagerId: z.string().optional().nullable(),
  role: z.enum(['ADMIN', 'HR', 'EMPLOYEE']).optional(),
});

export const assignShiftSchema = z.object({
  shiftId: z.string().min(1, 'Shift ID is required'),
  effectiveFrom: z.string().optional(),
});

export const toggleStatusSchema = z.object({
  employeeStatus: z.enum(['ACTIVE', 'INACTIVE', 'PROBATION', 'RESIGNED']),
});
