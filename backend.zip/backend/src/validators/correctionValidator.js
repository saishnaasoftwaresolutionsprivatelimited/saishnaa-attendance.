import { z } from 'zod';

const timestampSchema = z
  .string()
  .datetime({ offset: true, message: 'Punch time must be a valid ISO timestamp with timezone.' });

export const submitCorrectionSchema = z
  .object({
    attendanceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format'),
    correctionType: z.enum(['CHECK_IN', 'CHECK_OUT', 'BOTH']),
    requestedCheckInAt: timestampSchema.optional().nullable(),
    requestedCheckOutAt: timestampSchema.optional().nullable(),
    reason: z.string().min(5, 'Reason must be at least 5 characters').trim(),
    documentUrl: z.string().url().optional().nullable(),
  })
  .superRefine((data, ctx) => {
    if ((data.correctionType === 'CHECK_IN' || data.correctionType === 'BOTH') && !data.requestedCheckInAt) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['requestedCheckInAt'],
        message: 'Requested check-in time is required for this correction type.',
      });
    }

    if ((data.correctionType === 'CHECK_OUT' || data.correctionType === 'BOTH') && !data.requestedCheckOutAt) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['requestedCheckOutAt'],
        message: 'Requested check-out time is required for this correction type.',
      });
    }

    if (
      data.requestedCheckInAt &&
      data.requestedCheckOutAt &&
      new Date(data.requestedCheckOutAt) <= new Date(data.requestedCheckInAt)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['requestedCheckOutAt'],
        message: 'Requested check-out time must be after the requested check-in time.',
      });
    }
  });

export const decideCorrectionSchema = z.object({
  status: z.enum(['APPROVED', 'REJECTED']),
  reviewerComments: z.string().optional().nullable(),
});
