import { z } from 'zod';

export const createShiftSchema = z.object({
  name: z.string().min(2, 'Shift name is required').trim(),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, 'Start time must be in HH:mm 24hr format'),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, 'End time must be in HH:mm 24hr format'),
  gracePeriodMinutes: z.number().int().min(0).default(10),
  breakDurationMinutes: z.number().int().min(0).default(60),
  requiredWorkMinutes: z.number().int().min(60).default(480),
  isOvernight: z.boolean().default(false),
  weeklyOffDays: z.array(z.string()).default(['SUNDAY']),
  overtimeEnabled: z.boolean().default(true),
});

export const updateShiftSchema = createShiftSchema.partial();
