import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import authRoutes from './routes/authRoutes.js';
import employeeRoutes from './routes/employeeRoutes.js';
import attendanceRoutes from './routes/attendanceRoutes.js';
import leaveRoutes from './routes/leaveRoutes.js';
import correctionRoutes from './routes/correctionRoutes.js';
import shiftRoutes from './routes/shiftRoutes.js';
import reportRoutes from './routes/reportRoutes.js';
import salaryRoutes from './routes/salaryRoutes.js';
import payrollRoutes from './routes/payrollRoutes.js';
import permissionRoutes from './routes/permissionRoutes.js';
import onDutyRoutes from './routes/onDutyRoutes.js';
import holidayRoutes from './routes/holidayRoutes.js';
import auditRoutes from './routes/auditRoutes.js';
import { sendError } from './utils/responseFormatter.js';
import prisma from './config/db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

// 1. Security Headers
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);

// 2. CORS Configuration
const allowedOrigins = [
  FRONTEND_URL,
  'http://localhost:5173',
  'http://localhost:3000',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:3000',
];

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like mobile apps, curl, Postman)
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(null, true); // Permissive in local dev
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept'],
  })
);

// 3. Body & Cookie Parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// 4. Request Logging (Minimal)
app.use((req, res, next) => {
  if (process.env.NODE_ENV !== 'test') {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.originalUrl}`);
  }
  next();
});

// 5. Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    company: 'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED',
    system: 'SMART EMPLOYEE ATTENDANCE & PAYROLL SYSTEM',
    timestamp: new Date().toISOString(),
  });
});

// 6. Routes
app.use('/api/auth', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/leave', leaveRoutes);
app.use('/api/attendance/corrections', correctionRoutes);
app.use('/api/shifts', shiftRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/salary', salaryRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/permissions', permissionRoutes);
app.use('/api/on-duty', onDutyRoutes);
app.use('/api/holidays', holidayRoutes);
app.use('/api/audit', auditRoutes);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendDist = path.resolve(__dirname, '../../frontend/dist');

// Serve static frontend assets if built
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
}

// 7. API 404 Route Handler
app.use('/api', (req, res) => {
  sendError(res, `API route '${req.method} ${req.originalUrl}' not found.`, 404);
});

// 8. SPA Fallback for client-side routing
app.get('*', (req, res) => {
  const indexPath = path.join(frontendDist, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    sendError(res, `Route '${req.originalUrl}' not found. Build frontend first.`, 404);
  }
});

// 8. Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  const message = process.env.NODE_ENV === 'production' ? 'Internal server error occurred.' : err.message;
  sendError(res, message, 500);
});

// 9. Start Server if not imported by test runner
if (process.env.NODE_ENV !== 'test' && !process.argv.some((arg) => arg.includes('test'))) {
  app.listen(PORT, () => {
    console.log(`
========================================================================
🚀 SAISHNAA SMART EMPLOYEE ATTENDANCE SYSTEM API SERVER
🏢 Saishnaa Software Solutions Private Limited
📡 Running on: http://localhost:${PORT}
🌐 Frontend Origin: ${FRONTEND_URL}
🕒 Timezone: ${process.env.DEFAULT_TIMEZONE || 'Asia/Kolkata'}
========================================================================
    `);
  });
}

export default app;
