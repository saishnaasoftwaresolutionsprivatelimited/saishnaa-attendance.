import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import dayjs from 'dayjs';
import { evaluateCheckIn, evaluateCheckOut } from '../src/services/attendanceCalculationEngine.js';
import { DEFAULT_TZ } from '../src/utils/timeHelper.js';

describe('Attendance Calculation Engine', () => {
  test('check-in time is recorded as present without a shift schedule', () => {
    const result = evaluateCheckIn({
      shift: null,
      checkInTime: dayjs.tz('2026-09-24 23:41:00', DEFAULT_TZ).toDate(),
      workDate: '2026-09-24',
      policy: { defaultGraceMinutes: 0 },
    });

    assert.equal(result.isLate, false);
    assert.equal(result.lateMinutes, 0);
    assert.equal(result.classification, 'PRESENT');
  });

  test('check-out calculates elapsed time after breaks without scheduled-hour rules', () => {
    const attendanceRecord = {
      checkInAt: dayjs.tz('2026-09-24 09:00:00', DEFAULT_TZ).toDate(),
      totalBreakMinutes: 60,
      attendanceClassification: 'PRESENT',
    };
    const result = evaluateCheckOut({
      attendanceRecord,
      shift: null,
      checkOutTime: dayjs.tz('2026-09-24 18:00:00', DEFAULT_TZ).toDate(),
      policy: { halfDayThresholdMinutes: 600 },
    });

    assert.equal(result.totalDurationMinutes, 540);
    assert.equal(result.netWorkMinutes, 480);
    assert.equal(result.earlyDepartureMinutes, 0);
    assert.equal(result.overtimeMinutes, 0);
    assert.equal(result.attendanceClassification, 'PRESENT');
  });

  test('long and short attendance sessions are not classified by shift thresholds', () => {
    const checkInAt = dayjs.tz('2026-09-24 09:00:00', DEFAULT_TZ).toDate();
    const shortSession = evaluateCheckOut({
      attendanceRecord: {
        checkInAt,
        totalBreakMinutes: 0,
        attendanceClassification: 'PRESENT',
      },
      checkOutTime: dayjs.tz('2026-09-24 12:00:00', DEFAULT_TZ).toDate(),
    });
    const longSession = evaluateCheckOut({
      attendanceRecord: {
        checkInAt,
        totalBreakMinutes: 30,
        attendanceClassification: 'PRESENT',
      },
      checkOutTime: dayjs.tz('2026-09-24 20:30:00', DEFAULT_TZ).toDate(),
    });

    assert.equal(shortSession.attendanceClassification, 'PRESENT');
    assert.equal(longSession.netWorkMinutes, 660);
    assert.equal(longSession.overtimeMinutes, 0);
  });

  test('checkout preserves an explicitly recorded attendance classification', () => {
    const result = evaluateCheckOut({
      attendanceRecord: {
        checkInAt: dayjs.tz('2026-09-24 09:00:00', DEFAULT_TZ).toDate(),
        totalBreakMinutes: 0,
        attendanceClassification: 'HALF_DAY',
      },
      checkOutTime: dayjs.tz('2026-09-24 18:00:00', DEFAULT_TZ).toDate(),
    });

    assert.equal(result.attendanceClassification, 'HALF_DAY');
  });
});
