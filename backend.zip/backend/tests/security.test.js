import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword } from '../src/utils/passwordHelper.js';
import { signToken, verifyToken } from '../src/utils/jwtHelper.js';

describe('Security & Cryptography Tests', () => {
  const plainPassword = 'SuperSecretCorporatePassword2026!';

  test('Argon2id password hashing produces valid hash and verifies correctly', async () => {
    const hash = await hashPassword(plainPassword);
    assert.ok(hash, 'Hash should not be empty');
    assert.ok(hash.startsWith('$argon2id$'), 'Hash should use argon2id algorithm variant');

    const isValid = await verifyPassword(hash, plainPassword);
    assert.equal(isValid, true, 'Original password should verify against generated hash');
  });

  test('Argon2id rejects incorrect password', async () => {
    const hash = await hashPassword(plainPassword);
    const isValid = await verifyPassword(hash, 'WrongPassword123!');
    assert.equal(isValid, false, 'Incorrect password should fail verification');
  });

  test('JWT Token signs and decodes claims properly', () => {
    const userPayload = {
      id: 'emp-uuid-1234',
      employeeId: 'EMP001',
      role: 'ADMIN',
      email: 'admin@saishnaa.com',
    };

    const token = signToken(userPayload);
    assert.ok(token, 'Access token string should be created');

    const decoded = verifyToken(token);
    assert.equal(decoded.id, userPayload.id);
    assert.equal(decoded.employeeId, userPayload.employeeId);
    assert.equal(decoded.role, userPayload.role);
    assert.equal(decoded.email, userPayload.email);
  });

  test('JWT Token rejects tampered signatures', () => {
    const userPayload = { id: 'emp-uuid-1234' };
    const token = signToken(userPayload);
    const tampered = token.slice(0, -5) + 'abcde';
    const decoded = verifyToken(tampered);
    assert.equal(decoded, null, 'Tampered token must return null');
  });
});
