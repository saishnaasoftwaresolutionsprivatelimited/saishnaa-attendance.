import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { calculateDailySalary, calculateEmployeePayroll } from '../src/services/salaryCalculationEngine.js';

describe('Salary & Payroll Engine Tests (Prompt Scenarios)', () => {
  test('Scenario A: Monthly Salary = Rs. 20,000 with 30-day divisor yields Rs. 666.67 daily salary', () => {
    const result = calculateDailySalary({
      monthlySalary: 20000,
      calculationMethod: 'CUSTOM_DIVISOR',
      customDivisor: 30,
      year: 2026,
      month: 9,
    });

    assert.equal(result.divisor, 30);
    assert.equal(result.dailySalary, 666.67);
  });

  test('Salary calculation uses the standard 30-day divisor', () => {
    const result = calculateDailySalary({
      monthlySalary: 20000,
      calculationMethod: 'FIXED_26',
      year: 2026,
      month: 9,
    });

    assert.equal(result.divisor, 30);
    assert.equal(result.dailySalary, 666.67);
  });

  test('No configured salary defaults to zero', () => {
    const payroll = calculateEmployeePayroll({
      employee: { id: 'emp-1' },
      year: 2026,
      month: 9,
      asOfDate: '2026-09-30',
    });

    assert.equal(payroll.monthlySalary, 0);
    assert.equal(payroll.dailySalary, 0);
    assert.equal(payroll.grossEarnings, 0);
  });

  test('A Sunday is not implicitly treated as a weekly off', () => {
    const payroll = calculateEmployeePayroll({
      employee: { id: 'emp-1' },
      salaryConfig: { monthlySalary: 30000 },
      year: 2026,
      month: 9,
      asOfDate: '2026-09-07',
    });

    assert.equal(payroll.paidWeeklyOffsCount, 0);
    assert.equal(payroll.dailyBreakdown.find((day) => day.date === '2026-09-06').status, 'ABSENT');
  });

  test('Recorded attendance for each day reconciles to monthly salary', () => {
    const employee = { id: 'emp-1', employeeCode: 'EMP003', fullName: 'Rajesh Kumar' };
    const salaryConfig = {
      monthlySalary: 20000,
      calculationMethod: 'CUSTOM_DIVISOR',
      customDivisor: 30,
      lateAttendanceAllowance: 2,
      weeklyOffDays: '["SUNDAY"]',
    };

    // Every day must have an explicit record; Sundays are not implicitly treated as days off.
    const attendanceRecords = [];
    for (let d = 1; d <= 30; d++) {
      const dStr = `2026-09-${String(d).padStart(2, '0')}`;
      attendanceRecords.push({
        workDate: dStr,
        attendanceClassification: 'PRESENT',
        checkInAt: `${dStr}T03:30:00.000Z`,
        checkOutAt: `${dStr}T12:30:00.000Z`,
        lateMinutes: 0,
        overtimeMinutes: 0,
      });
    }

    const payroll = calculateEmployeePayroll({
      employee,
      salaryConfig,
      attendanceRecords,
      approvedLeaves: [],
      approvedOnDuties: [],
      holidays: [],
      year: 2026,
      month: 9,
      asOfDate: '2026-09-30',
    });

    assert.equal(payroll.payableDays, 30);
    // When payableDays == divisor (30), gross and net salary must reconcile exactly to Rs. 20,000.00
    assert.equal(payroll.grossEarnings, 20000);
    assert.equal(payroll.totalDeductions, 0);
    assert.equal(payroll.netSalary, 20000);
  });

  test('1 Unpaid Leave Day correctly deducts daily salary of Rs. 666.67', () => {
    const employee = { id: 'emp-1', employeeCode: 'EMP003', fullName: 'Rajesh Kumar' };
    const salaryConfig = {
      monthlySalary: 20000,
      calculationMethod: 'CUSTOM_DIVISOR',
      customDivisor: 30,
      lateAttendanceAllowance: 2,
      weeklyOffDays: '["SUNDAY"]',
    };

    const attendanceRecords = [];
    for (let d = 1; d <= 29; d++) {
      attendanceRecords.push({
        workDate: `2026-09-${String(d).padStart(2, '0')}`,
        attendanceClassification: 'PRESENT',
        checkInAt: `2026-09-${String(d).padStart(2, '0')}T03:30:00.000Z`,
        checkOutAt: `2026-09-${String(d).padStart(2, '0')}T12:30:00.000Z`,
        lateMinutes: 0,
        overtimeMinutes: 0,
      });
    }

    // 1 Unpaid Leave on day 30
    const approvedLeaves = [
      {
        startDate: '2026-09-30',
        endDate: '2026-09-30',
        leaveType: { isPaid: false },
      },
    ];

    const payroll = calculateEmployeePayroll({
      employee,
      salaryConfig,
      attendanceRecords,
      approvedLeaves,
      approvedOnDuties: [],
      holidays: [],
      year: 2026,
      month: 9,
      asOfDate: '2026-09-30',
    });

    assert.equal(payroll.unpaidLeaveDays, 1);
    assert.equal(payroll.otherDeductions, 666.67);
  });

  test('Future workdays and today without a completed checkout stay scheduled, not present or absent', () => {
    const payroll = calculateEmployeePayroll({
      employee: { id: 'emp-1', employeeCode: 'EMP003' },
      salaryConfig: {
        monthlySalary: 20000,
        calculationMethod: 'CALENDAR_DAYS',
        weeklyOffDays: '["SUNDAY"]',
      },
      attendanceRecords: [
        {
          workDate: '2026-09-25',
          attendanceClassification: 'PRESENT',
          checkInAt: '2026-09-25T03:30:00.000Z',
          checkOutAt: '2026-09-25T12:30:00.000Z',
          lateMinutes: 0,
          overtimeMinutes: 0,
        },
        {
          workDate: '2026-09-26',
          attendanceClassification: 'PRESENT',
          checkInAt: '2026-09-26T04:10:00.000Z',
          checkOutAt: null,
          lateMinutes: 0,
          overtimeMinutes: 0,
        },
      ],
      year: 2026,
      month: 9,
      asOfDate: '2026-09-26',
    });

    assert.equal(payroll.presentDays, 1);
    assert.equal(payroll.scheduledDays, 0);
    assert.equal(payroll.dailyBreakdown.find((day) => day.date === '2026-09-26').status, 'WORKING');
    assert.equal(payroll.dailyBreakdown.find((day) => day.date === '2026-09-28').status, 'FUTURE');
  });

  test('A past check-in without checkout is incomplete and deducted as an absence', () => {
    const payroll = calculateEmployeePayroll({
      employee: { id: 'emp-1', employeeCode: 'EMP003' },
      salaryConfig: {
        monthlySalary: 20000,
        calculationMethod: 'CALENDAR_DAYS',
        weeklyOffDays: '["SUNDAY"]',
      },
      attendanceRecords: [{
        workDate: '2026-09-24',
        attendanceClassification: 'PRESENT',
        checkInAt: '2026-09-24T03:30:00.000Z',
        checkOutAt: null,
        lateMinutes: 0,
        overtimeMinutes: 0,
      }],
      year: 2026,
      month: 9,
      asOfDate: '2026-09-26',
    });

    assert.equal(payroll.incompleteDays, 1);
    assert.equal(payroll.dailyBreakdown.find((day) => day.date === '2026-09-24').status, 'INCOMPLETE');
    assert.ok(payroll.absenceDeductions >= payroll.dailySalary);
    assert.equal(payroll.totalDeductions, payroll.otherDeductions + payroll.lateDeductions);
  });
});
