import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { parseDateTime, toOfficeTime } from '../src/utils/timeHelper.js';
import { submitCorrectionSchema } from '../src/validators/correctionValidator.js';

describe('Attendance Correction Timezone Tests', () => {
  test('09:40 India office time is stored as 04:10 UTC and displays again as 09:40', () => {
    const timestamp = parseDateTime('2026-09-26', '09:40');

    assert.equal(timestamp.toISOString(), '2026-09-26T04:10:00.000Z');
    assert.equal(toOfficeTime(timestamp).format('hh:mm A'), '09:40 AM');
  });

  test('correction payload accepts timezone-aware punch timestamps', () => {
    const result = submitCorrectionSchema.safeParse({
      attendanceDate: '2026-09-26',
      correctionType: 'BOTH',
      requestedCheckInAt: '2026-09-26T04:10:00.000Z',
      requestedCheckOutAt: '2026-09-26T12:10:00.000Z',
      reason: 'Incorrect punches recorded',
    });

    assert.equal(result.success, true);
  });

  test('correction payload rejects a missing punch required by its type', () => {
    const result = submitCorrectionSchema.safeParse({
      attendanceDate: '2026-09-26',
      correctionType: 'BOTH',
      requestedCheckInAt: '2026-09-26T04:10:00.000Z',
      reason: 'Incorrect punches recorded',
    });

    assert.equal(result.success, false);
    assert.equal(result.error.issues[0].path.join('.'), 'requestedCheckOutAt');
  });
});
