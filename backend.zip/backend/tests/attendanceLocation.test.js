import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDistanceMeters,
  getAttendanceLocationConfig,
  validateAttendanceLocation,
} from '../src/services/attendanceLocationService.js';

describe('Attendance geofence rules', () => {
  test('attendance geofence matches the current Google Maps office pin and radius', () => {
    const config = getAttendanceLocationConfig();

    assert.equal(config.enabled, true);
    assert.equal(config.latitude, 11.32295);
    assert.equal(config.longitude, 77.6851411);
    assert.equal(config.radiusMeters, 500);
  });

  test('validates the exact Google Maps office pin within the geofence', () => {
    const result = validateAttendanceLocation(11.32295, 77.6851411);
    assert.equal(result.allowed, true);
    assert.ok(result.distanceMeters < 1);
  });

  test('rejects location far outside geofence', () => {
    // Chennai coordinates (far from Erode)
    const result = validateAttendanceLocation(13.0827, 80.2707);
    assert.equal(result.allowed, false);
    assert.equal(result.statusCode, 403);
  });

  test('distance calculation returns zero for the same coordinates', () => {
    assert.equal(calculateDistanceMeters(12.9716, 80.2452, 12.9716, 80.2452), 0);
  });

  test('one latitude degree is approximately 111 kilometres', () => {
    const distance = calculateDistanceMeters(0, 0, 1, 0);
    assert.ok(distance > 111000 && distance < 111300);
  });
});