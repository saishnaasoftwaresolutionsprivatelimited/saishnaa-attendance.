import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import prisma from '../src/config/db.js';
import { processMonthlyClAccrualForEmployee } from '../src/services/clAccrualService.js';

describe('Casual Leave (CL) Accrual & Carry Forward Tests (Prompt Rule 4)', () => {
  test('Employee receives 1 CL monthly credit and unused balance carries forward idempotently', async () => {
    const emp = await prisma.employee.findUnique({ where: { employeeCode: 'EMP003' } });
    assert.ok(emp);

    const testYM = '2026-07';

    // Delete test ledger if exists
    await prisma.leaveLedger.deleteMany({
      where: { employeeId: emp.id, leaveTypeCode: 'CL', monthYear: testYM },
    });

    // 1st run: Accrual creates ledger entry with 1 credited day
    const ledger1 = await processMonthlyClAccrualForEmployee(emp.id, testYM);
    assert.equal(ledger1.creditedDays, 1);
    assert.ok(ledger1.closingBalance >= 1);

    // 2nd run: Idempotent check ensures no duplicate credit
    const ledger2 = await processMonthlyClAccrualForEmployee(emp.id, testYM);
    assert.equal(ledger2.id, ledger1.id);
    assert.equal(ledger2.creditedDays, 1);

    // Clean up
    await prisma.leaveLedger.deleteMany({
      where: { employeeId: emp.id, leaveTypeCode: 'CL', monthYear: testYM },
    });
  });
});
