import { test, mock } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import app from '../src/server.js';
import prisma from '../src/config/db.js';
import { signToken } from '../src/utils/jwtHelper.js';
import { getTodayDateString } from '../src/utils/timeHelper.js';

test('Admin settings API, employee timing and both real punch routes stay synchronized', async () => {
  assert.ok(process.env.DATABASE_URL?.includes('regression'), 'Use an isolated regression database');
  // Exercise real disk persistence, redirecting only settings I/O into an isolated test file.
  const settingsPath = fileURLToPath(new URL('../src/config/companySettings.json', import.meta.url));
  const testPath = fileURLToPath(new URL(`../prisma/location-settings-${process.pid}.json`, import.meta.url));
  fs.copyFileSync(settingsPath, testPath);
  const redirect = (value) => typeof value === 'string' && path.resolve(value).startsWith(settingsPath)
    ? value.replace(settingsPath, testPath) : value;
  const originalRead = fs.readFileSync.bind(fs);
  const originalWrite = fs.writeFileSync.bind(fs);
  const originalRename = fs.renameSync.bind(fs);
  const read = mock.method(fs, 'readFileSync', (file, ...args) => originalRead(redirect(file), ...args));
  const write = mock.method(fs, 'writeFileSync', (file, ...args) => originalWrite(redirect(file), ...args));
  const rename = mock.method(fs, 'renameSync', (source, target) => originalRename(redirect(source), redirect(target)));
  const server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  try {
    const admin = await prisma.user.findFirst({ where: { role: 'ADMIN', accountStatus: 'ACTIVE' } });
    const employee = await prisma.user.findFirst({ where: { role: 'EMPLOYEE', accountStatus: 'ACTIVE', employee: { isDeleted: false, employeeStatus: 'ACTIVE' } } });
    assert.ok(admin && employee, 'Seeded Admin and Employee are required');
    const request = async (route, user, method = 'GET', body) => {
      const response = await fetch(`http://127.0.0.1:${server.address().port}/api${route}`, {
        method, headers: { Authorization: `Bearer ${signToken({ userId: user.id })}`, 'Content-Type': 'application/json' },
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      return { status: response.status, headers: response.headers, ...await response.json() };
    };
    const configRoute = '/payroll/company-branding';
    const saved = await request(configRoute, admin, 'PUT', {
      attendanceLatitude: '11.322962', attendanceLongitude: '77.685142', attendanceRadiusMeters: '1000',
      attendanceLocationEnabled: true, officeStartTime: '09:40', officeEndTime: '17:40', breakDurationMinutes: 30,
    });
    assert.equal(saved.status, 200, JSON.stringify(saved));
    const brandingOnly = await request(configRoute, admin, 'PUT', { tagline: 'Location regression test' });
    assert.equal(brandingOnly.status, 200);
    const stored = JSON.parse(originalRead(testPath, 'utf8'));
    assert.equal(stored.attendanceLatitude, 11.322962);
    assert.equal(stored.attendanceLongitude, 77.685142);
    assert.equal(stored.attendanceRadiusMeters, 1000);
    const employeeSettings = await request(configRoute, employee);
    assert.equal(employeeSettings.data.attendanceLatitude, stored.attendanceLatitude);
    assert.equal(employeeSettings.data.attendanceLongitude, stored.attendanceLongitude);
    assert.equal(employeeSettings.headers.get('cache-control'), 'no-store');
    assert.equal((await request(configRoute, employee, 'PUT', { attendanceLocationEnabled: false })).status, 403);
    assert.equal((await request(configRoute, admin, 'PUT', { attendanceRadiusMeters: 'bad' })).status, 422);
    assert.equal(JSON.parse(originalRead(testPath, 'utf8')).attendanceRadiusMeters, 1000);
    const today = await request('/attendance/today', employee);
    assert.equal(today.data.officeTiming.startTime, '09:40');
    assert.equal(today.data.officeTiming.endTime, '17:40');
    assert.equal(today.data.activeShift.breakDurationMinutes, 30);

    // Synthetic fixtures only; no employee's browser GPS or live attendance is changed.
    await prisma.attendanceRecord.deleteMany({ where: { employeeId: employee.employeeId, workDate: getTodayDateString() } });
    const atOffice = { latitude: 11.322962, longitude: 77.685142, accuracy: 12 };
    const outside = { ...atOffice, latitude: 11.322962 + 1001 / 6371000 * 180 / Math.PI, isInsideOffice: true };
    for (const route of ['/attendance/check-in', '/attendance/check-out']) {
      assert.equal((await request(route, employee, 'POST', outside)).status, 403);
      assert.equal((await request(route, employee, 'POST', { isInsideOffice: true })).status, 422);
      assert.equal((await request(route, employee, 'POST', { latitude: '', longitude: null })).status, 422);
    }
    const checkIn = await request('/attendance/check-in', employee, 'POST', atOffice);
    assert.equal(checkIn.status, 201, JSON.stringify(checkIn));
    // An Admin update between readiness/check-in and checkout must take effect immediately.
    await request(configRoute, admin, 'PUT', { attendanceLatitude: 11.36 });
    assert.equal((await request('/attendance/check-out', employee, 'POST', atOffice)).status, 403);
    await request(configRoute, admin, 'PUT', { attendanceLatitude: atOffice.latitude });
    const checkOut = await request('/attendance/check-out', employee, 'POST', atOffice);
    assert.equal(checkOut.status, 200, JSON.stringify(checkOut));
    assert.equal(checkOut.data.workSessionStatus, 'CHECKED_OUT');
  } finally {
    read.mock.restore(); write.mock.restore(); rename.mock.restore();
    fs.unlinkSync(testPath);
    await new Promise((resolve) => server.close(resolve));
    await prisma.$disconnect();
  }
});
