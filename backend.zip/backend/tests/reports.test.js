import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { generateExcelReport } from '../src/services/excelReportService.js';
import { generatePdfReport } from '../src/services/pdfReportService.js';

describe('Corporate Report Export Services Tests', () => {
  const sampleColumns = [
    { header: 'Employee Code', key: 'employeeCode', width: 16 },
    { header: 'Employee Name', key: 'name', width: 22 },
    { header: 'Department', key: 'department', width: 20 },
    { header: 'Check In', key: 'checkIn', width: 14, alignment: 'center' },
    { header: 'Check Out', key: 'checkOut', width: 14, alignment: 'center' },
    { header: 'Net Hours', key: 'netHours', width: 14, alignment: 'right' },
    { header: 'Status', key: 'status', width: 14, alignment: 'center' },
  ];

  const sampleData = [
    {
      employeeCode: 'EMP001',
      name: 'Rajesh Kumar',
      department: 'Software Engineering',
      checkIn: '09:02',
      checkOut: '18:05',
      netHours: '8.25',
      status: 'PRESENT',
    },
    {
      employeeCode: 'EMP002',
      name: 'Ananya Rao',
      department: 'Quality Assurance',
      checkIn: '09:28',
      checkOut: '18:10',
      netHours: '7.90',
      status: 'LATE',
    },
  ];

  test('generateExcelReport creates valid Excel workbook buffer', async () => {
    const buffer = await generateExcelReport({
      title: 'Daily Attendance Report',
      subtitle: 'Production Verification Test',
      columns: sampleColumns,
      data: sampleData,
      summaryTotals: { 'Total Records': 2, 'Present': 1, 'Late': 1 },
    });

    assert.ok(Buffer.isBuffer(buffer), 'Result must be a Node.js Buffer');
    assert.ok(buffer.length > 1000, 'Excel buffer size should be greater than 1KB');

    // Excel files (.xlsx) are ZIP archives starting with signature PK\x03\x04
    assert.equal(buffer[0], 0x50, 'First byte must be P (0x50)');
    assert.equal(buffer[1], 0x4B, 'Second byte must be K (0x4B)');
  });

  test('generatePdfReport creates valid PDF document buffer', async () => {
    const buffer = await generatePdfReport({
      title: 'Daily Attendance Summary',
      subtitle: 'Software Engineering Department',
      dateRange: '2026-09-24',
      columns: sampleColumns,
      data: sampleData,
      summaryTotals: { 'Total Records': 2, 'Present': 1, 'Late': 1 },
    });

    assert.ok(Buffer.isBuffer(buffer), 'Result must be a Node.js Buffer');
    assert.ok(buffer.length > 500, 'PDF buffer size should be greater than 500 bytes');

    // PDF files start with header "%PDF"
    const header = buffer.subarray(0, 4).toString('utf-8');
    assert.equal(header, '%PDF', 'Buffer should begin with %PDF magic bytes');
  });
});
