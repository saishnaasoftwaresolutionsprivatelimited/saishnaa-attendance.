import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import app from '../src/server.js';
import prisma from '../src/config/db.js';
import { signToken } from '../src/utils/jwtHelper.js';
import { verifyPassword } from '../src/utils/passwordHelper.js';

let server, base, admin, hr, employee, created;
async function request(url, token, method = 'GET', body) {
  const res = await fetch(`${base}/api${url}`, {
    method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json();
  return { status: res.status, ...data };
}
before(async () => {
  assert.ok(process.env.DATABASE_URL?.includes('regression'), 'Run against an isolated regression database');
  server = app.listen(0);
  await new Promise(resolve => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
  for (const role of ['ADMIN', 'HR', 'EMPLOYEE']) {
    const user = await prisma.user.findFirst({ where: { role, accountStatus: 'ACTIVE' } });
    const identity = { ...user, token: signToken({ userId: user.id }) };
    if (role === 'ADMIN') admin = identity;
    else if (role === 'HR') hr = identity;
    else employee = identity;
  }
});
after(async () => { await new Promise(resolve => server.close(resolve)); await prisma.$disconnect(); });

test('registration persists configured values and an authentication-compatible password; reset works', async () => {
  const department = await prisma.department.findFirst();
  const designation = await prisma.designation.findFirst({ where: { departmentId: department.id } });
  const branch = await prisma.branch.findFirst();
  const password = 'Custom@Registration2026!';
  const result = await request('/employees', admin.token, 'POST', {
    fullName: 'Regression Employee', email: `regression-${Date.now()}@example.com`,
    joiningDate: new Date().toISOString().slice(0, 10), departmentId: department.id,
    designationId: designation.id, branchId: branch.id,
    temporaryPassword: password, monthlySalary: 34567, lateAllowanceMonthly: 4,
    permissionAllowanceMonthly: 3, clRemainingDays: 2.5, paymentMethod: 'UPI', upiId: 'employee@okaxis',
  });
  assert.equal(result.status, 201, JSON.stringify(result));
  created = result.data.employee;
  const stored = await prisma.employee.findUnique({ where: { id: created.id }, include: { user: true, salaryConfig: true, leaveBalances: true, leaveLedgers: true } });
  assert.ok(stored.user.passwordHash.startsWith('$argon2id$'));
  assert.ok(await verifyPassword(stored.user.passwordHash, password));
  assert.equal(stored.user.accountStatus, 'ACTIVE');
  assert.equal(stored.salaryConfig.monthlySalary, 34567);
  assert.equal(stored.salaryConfig.lateAttendanceAllowance, 4);
  assert.equal(stored.salaryConfig.permissionAllowancePerMonth, 3);
  assert.equal(stored.salaryConfig.upiId, 'employee@okaxis');
  assert.equal(stored.leaveBalances[0].remainingDays, 2.5);
  assert.equal(stored.leaveLedgers[0].closingBalance, 2.5);
  assert.equal(JSON.stringify(result).includes('passwordHash'), false);
  const login = await request('/auth/login', '', 'POST', { identifier: created.email, password });
  assert.equal(login.status, 200, JSON.stringify(login));
  const balance = await prisma.leaveBalance.findFirst({ where: { employeeId: created.id } });
  assert.equal(balance.remainingDays, 2.5, 'Login must not credit initial month twice');
  const reset = await request(`/employees/${created.id}/reset-access`, admin.token, 'POST', {});
  assert.equal(reset.status, 200);
  const loginReset = await request('/auth/login', '', 'POST', { identifier: created.employeeCode, password: reset.data.temporaryPassword });
  assert.equal(loginReset.status, 200, JSON.stringify(loginReset));
});
