import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { createEmployeeSchema } from '../src/validators/employeeValidator.js';

describe('Employee registration compensation defaults', () => {
  test('new employee registration does not create fabricated salary or allowance amounts', () => {
    const employee = createEmployeeSchema.parse({
      fullName: 'New Employee',
      email: 'new.employee@example.com',
    });

    assert.equal(employee.monthlySalary, undefined);
    assert.equal(employee.calculationMethod, 'CALENDAR_DAYS');
    assert.equal(employee.lateAllowanceMonthly, 0);
    assert.equal(employee.permissionAllowanceMonthly, 0);
    assert.equal(employee.clRemainingDays, 0);
    assert.equal(employee.paymentMethod, 'BANK_TRANSFER');
  });

  test('registration accepts custom salary, position-related details, allowances, and bank details', () => {
    const employee = createEmployeeSchema.parse({
      fullName: 'Configured Employee',
      email: 'configured.employee@example.com',
      departmentId: 'department-id',
      designationId: 'designation-id',
      monthlySalary: '35000',
      salaryEffectiveDate: '2026-09-26',
      calculationMethod: 'FIXED_26',
      customDivisor: '26',
      lateAllowanceMonthly: '3',
      permissionAllowanceMonthly: '2',
      clRemainingDays: '1.5',
      paymentMethod: 'BANK_TRANSFER',
      bankName: 'Example Bank',
      bankAccountNumber: '1234567890',
      ifscCode: 'EXAM0001234',
    });

    assert.equal(employee.monthlySalary, 35000);
    assert.equal(employee.customDivisor, 26);
    assert.equal(employee.lateAllowanceMonthly, 3);
    assert.equal(employee.permissionAllowanceMonthly, 2);
    assert.equal(employee.clRemainingDays, 1.5);
    assert.equal(employee.bankAccountNumber, '1234567890');
  });
});
