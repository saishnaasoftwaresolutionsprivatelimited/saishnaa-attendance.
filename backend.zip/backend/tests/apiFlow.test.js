import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import app from '../src/server.js';
import prisma from '../src/config/db.js';
import { signToken } from '../src/utils/jwtHelper.js';

describe('HTTP REST API Integration Tests', () => {
  let server;
  let baseUrl;
  let adminToken;
  let hrToken;
  let hrEmployeeId;

  before(async () => {
    // Start server on an ephemeral port
    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://127.0.0.1:${port}`;
        resolve();
      });
    });
  });

  after(async () => {
    await new Promise((resolve) => server.close(resolve));
    await prisma.$disconnect();
  });

  test('GET /api/health returns company and system status', async () => {
    const res = await fetch(`${baseUrl}/api/health`);
    assert.equal(res.status, 200);

    const body = await res.json();
    assert.equal(body.status, 'OK');
    assert.equal(body.company, 'SAISHNAA SOFTWARE SOLUTIONS PRIVATE LIMITED');
    assert.equal(body.system, 'SMART EMPLOYEE ATTENDANCE & PAYROLL SYSTEM');
  });

  test('POST /api/auth/login succeeds for seeded Admin user', async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        identifier: 'admin@saishnaa.com',
        password: 'Admin@Saishnaa2026!',
      }),
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.ok(body.data.token, 'Token should be returned');
    assert.equal(body.data.user.role, 'ADMIN');

    adminToken = body.data.token;
  });

  test('GET /api/auth/me returns authenticated employee profile', async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`, {
      headers: {
        Authorization: `Bearer ${adminToken}`,
      },
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.equal(body.data.email, 'admin@saishnaa.com');
    assert.equal(body.data.role, 'ADMIN');
  });

  test('Admin workforce directory includes both HR and Employee accounts', async () => {
    const res = await fetch(`${baseUrl}/api/employees?limit=100`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    assert.equal(res.status, 200);
    const body = await res.json();
    const roles = body.data.employees.map((employee) => employee.role);
    assert.ok(roles.includes('HR'));
    assert.ok(roles.includes('EMPLOYEE'));
    assert.ok(!roles.includes('ADMIN'));
  });

  test('GET /api/attendance/admin/live returns 8 KPI cards and analytics', async () => {
    const res = await fetch(`${baseUrl}/api/attendance/admin/live`, {
      headers: {
        Authorization: `Bearer ${adminToken}`,
      },
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.ok(body.data.summaryCards, 'summaryCards should be present');
    assert.ok(body.data.summaryCards.totalEmployees >= 1);
    assert.ok(Array.isArray(body.data.records));
    assert.ok(Array.isArray(body.data.charts.departmentDistribution));
  });

  test('HR session can load employee dashboard data with its current database role', async () => {
    const hrUser = await prisma.user.findFirst({
      where: { role: 'HR', accountStatus: 'ACTIVE' },
      include: { employee: true },
    });
    assert.ok(hrUser, 'An active HR account must exist');

    hrToken = signToken({
      userId: hrUser.id,
      email: hrUser.email,
      role: hrUser.role,
      employeeId: hrUser.employeeId,
    });
    hrEmployeeId = hrUser.employeeId;
    const res = await fetch(`${baseUrl}/api/attendance/admin/live?date=2026-09-26`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(res.status, 200);

    const body = await res.json();
    assert.equal(body.success, true);
    assert.ok(body.data.summaryCards.totalEmployees >= 1);
    assert.ok(body.data.records.length >= 1);
  });

  test('HR can load personal attendance while Admin can monitor the HR attendance row', async () => {
    const personalRes = await fetch(`${baseUrl}/api/attendance/today`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(personalRes.status, 200);
    const personal = await personalRes.json();
    assert.equal(personal.success, true);

    const adminLiveRes = await fetch(`${baseUrl}/api/attendance/admin/live?date=2026-09-26&limit=100`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    assert.equal(adminLiveRes.status, 200);
    const adminLive = await adminLiveRes.json();
    assert.ok(adminLive.data.records.some((record) => record.employeeId === hrEmployeeId));
  });

  test('HR can manage employee leave data but cannot manage an HR leave balance', async () => {
    const requestsRes = await fetch(`${baseUrl}/api/leave/admin?limit=100`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(requestsRes.status, 200);
    const requests = await requestsRes.json();
    assert.ok(requests.data.requests.every((request) => request.employeeId !== hrEmployeeId));

    const balancesRes = await fetch(`${baseUrl}/api/leave/admin/balances`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(balancesRes.status, 200);
    const balances = await balancesRes.json();
    assert.ok(balances.data.every((employee) => employee.id !== hrEmployeeId));

    const forbiddenAdjustmentRes = await fetch(`${baseUrl}/api/leave/admin/balances/${hrEmployeeId}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${hrToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ leaveTypeCode: 'CL', remainingDays: 1, totalAllocated: 1 }),
    });
    assert.equal(forbiddenAdjustmentRes.status, 403);
  });

  test('HR receives employee-only directory data and cannot use Admin-only reports', async () => {
    const directoryRes = await fetch(`${baseUrl}/api/employees?role=HR`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(directoryRes.status, 200);
    const directory = await directoryRes.json();
    assert.ok(directory.data.employees.length >= 1);
    assert.ok(directory.data.employees.every((employee) => employee.role === 'EMPLOYEE'));

    const reportRes = await fetch(`${baseUrl}/api/reports/daily?format=json`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(reportRes.status, 403);
  });

  test('Admin can read HR login/logout activity while HR cannot access the audit feed', async () => {
    const logoutRes = await fetch(`${baseUrl}/api/auth/logout`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(logoutRes.status, 200);

    const forbiddenRes = await fetch(`${baseUrl}/api/audit?role=HR`, {
      headers: { Authorization: `Bearer ${hrToken}` },
    });
    assert.equal(forbiddenRes.status, 403);

    const auditRes = await fetch(`${baseUrl}/api/audit?role=HR&limit=100`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    assert.equal(auditRes.status, 200);
    const audit = await auditRes.json();
    assert.ok(audit.data.auditLogs.some((entry) => entry.action === 'USER_LOGOUT'));
  });

  test('GET /api/reports/daily?format=json returns daily attendance data', async () => {
    const res = await fetch(`${baseUrl}/api/reports/daily?format=json`, {
      headers: {
        Authorization: `Bearer ${adminToken}`,
      },
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.ok(body.data.summaryTotals);
    assert.ok(Array.isArray(body.data.data));
  });

  test('Current-month projected payroll cannot be approved or paid while scheduled days remain', async () => {
    const calculateRes = await fetch(`${baseUrl}/api/payroll/calculate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${adminToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ year: 2026, month: 9 }),
    });
    assert.equal(calculateRes.status, 200);

    const period = await prisma.payrollPeriod.findUnique({
      where: { monthYear: '2026-09' },
      include: { calculations: true },
    });
    assert.equal(period.status, 'PROJECTED');
    assert.ok(period.calculations.some((calculation) => calculation.scheduledDays > 0));

    const approveRes = await fetch(`${baseUrl}/api/payroll/periods/${period.id}/approve`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${adminToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ status: 'ADMIN_APPROVED' }),
    });
    assert.equal(approveRes.status, 409);

    const paymentRes = await fetch(`${baseUrl}/api/payroll/calculations/${period.calculations[0].id}/payment`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${adminToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentMethod: 'BANK_TRANSFER', paymentReference: 'SHOULD-NOT-PAY' }),
    });
    assert.equal(paymentRes.status, 409);
  });

  test('PATCH /api/payroll/calculations/:id updates payroll without a server error', async (t) => {
    const calculation = await prisma.payrollCalculation.findFirst({
      where: { employee: { user: { role: { not: 'ADMIN' } } } },
    });

    if (!calculation) {
      t.skip('No regular employee payroll calculation is available in the test database.');
      return;
    }

    const res = await fetch(`${baseUrl}/api/payroll/calculations/${calculation.id}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${adminToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        payableDays: calculation.payableDays,
        absentDays: calculation.absentDays,
        totalDeductions: calculation.totalDeductions,
        netSalary: calculation.netSalary,
        status: calculation.status,
        paymentNotes: calculation.paymentNotes || '',
      }),
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.equal(body.data.id, calculation.id);
  });

  test('Unauthorized request without token returns 401', async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`);
    assert.equal(res.status, 401);
  });
});
