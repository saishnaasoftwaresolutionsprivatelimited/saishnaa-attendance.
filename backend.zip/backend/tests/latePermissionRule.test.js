import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import prisma from '../src/config/db.js';
import {
  getMonthlyLateAndPermissionStatus,
  validatePermissionEligibility,
} from '../src/services/latePermissionEngine.js';

describe('Late Attendance & 1-Hour Permission Linkage Rule Tests (Prompt Rule 8 & 9)', () => {
  const testMonthYear = '2026-08'; // Use past test month

  test('Employee with 0 late arrivals has 2 late allowances remaining and permission is locked until late allowances are used', async () => {
    // Get test employee (EMP003)
    const emp = await prisma.employee.findUnique({ where: { employeeCode: 'EMP003' } });
    assert.ok(emp);

    // Delete any test records for testMonthYear
    await prisma.attendanceRecord.deleteMany({
      where: { employeeId: emp.id, workDate: { startsWith: testMonthYear } },
    });
    await prisma.permissionRequest.deleteMany({
      where: { employeeId: emp.id, permissionDate: { startsWith: testMonthYear } },
    });
    await prisma.salaryConfiguration.update({
      where: { employeeId: emp.id },
      data: { lateAttendanceAllowance: 2, permissionAllowancePerMonth: 1 },
    });

    const status = await getMonthlyLateAndPermissionStatus(emp.id, testMonthYear);
    assert.equal(status.lateCount, 0);
    assert.equal(status.remainingLateAllowances, 2);
    assert.equal(status.maxPermissionAllowance, 1);
    assert.equal(status.remainingPermissionAllowances, 1);
    assert.equal(status.isPermissionEligible, false);
    assert.equal(status.restrictionReason, 'Use the 2 monthly late allowances first. One-hour permission becomes available after they are used.');

    const eligibility = await validatePermissionEligibility(emp.id, `${testMonthYear}-10`);
    assert.equal(eligibility.allowed, false);
  });

  test('Employee with 1 late arrival has 1 late allowance remaining and permission is still locked', async () => {
    const emp = await prisma.employee.findUnique({ where: { employeeCode: 'EMP003' } });
    const shift = await prisma.shift.findFirst();

    // Create 1 late record
    await prisma.attendanceRecord.create({
      data: {
        employeeId: emp.id,
        workDate: `${testMonthYear}-01`,
        shiftId: shift.id,
        lateMinutes: 15,
        attendanceClassification: 'LATE',
      },
    });

    const status = await getMonthlyLateAndPermissionStatus(emp.id, testMonthYear);
    assert.equal(status.lateCount, 1);
    assert.equal(status.remainingLateAllowances, 1);
    assert.equal(status.isPermissionEligible, false);
    assert.equal(status.restrictionReason, 'Use the 2 monthly late allowances first. One-hour permission becomes available after they are used.');

    const eligibility = await validatePermissionEligibility(emp.id, `${testMonthYear}-10`);
    assert.equal(eligibility.allowed, false);
  });

  test('Employee with 2 late arrivals has 0 allowances remaining and permission UNLOCKS and becomes AVAILABLE', async () => {
    const emp = await prisma.employee.findUnique({ where: { employeeCode: 'EMP003' } });
    const shift = await prisma.shift.findFirst();

    // Create 2nd late record
    await prisma.attendanceRecord.create({
      data: {
        employeeId: emp.id,
        workDate: `${testMonthYear}-02`,
        shiftId: shift.id,
        lateMinutes: 20,
        attendanceClassification: 'LATE',
      },
    });

    const status = await getMonthlyLateAndPermissionStatus(emp.id, testMonthYear);
    assert.equal(status.lateCount, 2);
    assert.equal(status.remainingLateAllowances, 0);
    assert.equal(status.isPermissionEligible, true);
    assert.equal(status.restrictionReason, null);

    // Direct validation must succeed
    const eligibility = await validatePermissionEligibility(emp.id, `${testMonthYear}-10`);
    assert.equal(eligibility.allowed, true);
  });

  test('One pending permission consumes the unlocked monthly permission quota until reviewed', async () => {
    const emp = await prisma.employee.findUnique({ where: { employeeCode: 'EMP003' } });

    await prisma.permissionRequest.create({
      data: {
        employeeId: emp.id,
        permissionDate: `${testMonthYear}-12`,
        startTime: '10:00',
        endTime: '11:00',
        durationMinutes: 60,
        reason: 'Monthly quota test',
      },
    });

    const status = await getMonthlyLateAndPermissionStatus(emp.id, testMonthYear);
    assert.equal(status.activePermissionCount, 1);
    assert.equal(status.remainingPermissionAllowances, 0);
    assert.equal(status.isPermissionEligible, false);
    assert.equal(status.restrictionReason, 'You have already used or requested your 1 permission allowance for this month.');

    // Clean up test records
    await prisma.permissionRequest.deleteMany({
      where: { employeeId: emp.id, permissionDate: { startsWith: testMonthYear } },
    });
    await prisma.attendanceRecord.deleteMany({
      where: { employeeId: emp.id, workDate: { startsWith: testMonthYear } },
    });
  });
});
