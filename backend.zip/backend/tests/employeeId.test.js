import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { generateNextEmployeeCode } from '../src/services/employeeIdService.js';
import prisma from '../src/config/db.js';

describe('Sequential Employee Code Generator Tests', () => {
  test('Next employee code adheres to EMPxxx format and sequence', async () => {
    const nextCode = await generateNextEmployeeCode('EMP');
    assert.match(nextCode, /^EMP\d{3,}$/, 'Code must start with EMP followed by 3 or more digits');

    // Fetch existing highest employee code to verify mathematical increment
    const employees = await prisma.employee.findMany({
      where: { employeeCode: { startsWith: 'EMP' } },
      select: { employeeCode: true },
    });

    let maxNum = 0;
    for (const e of employees) {
      const match = e.employeeCode.match(/^EMP(\d+)$/i);
      if (match) {
        const val = parseInt(match[1], 10);
        if (val > maxNum) maxNum = val;
      }
    }

    const expectedNextCode = `EMP${String(maxNum + 1).padStart(3, '0')}`;
    assert.equal(nextCode, expectedNextCode);
  });
});
